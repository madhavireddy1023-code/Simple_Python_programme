import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './core/login/login.component';
import { AccessGuard } from '@shared/guards/access.guard';
import { GlobalErrorComponent } from '@shared/components/global-error/global-error.component';

const routes: Routes = [
  {
    path: 'summary-details',
    loadChildren: () => import('./features/summary/summary.module').then((m) => m.SummaryModule),
    canActivate: [AccessGuard],
  },
  {
    path: 'section-details',
    loadChildren: () => import('./features/section-details/section-details.module').then((m) => m.SectionDetailsModule),
    canActivate: [AccessGuard],
  },
  {
    path: 'market-details',
    loadChildren: () => import('./features/market-details/market-details.module').then((m) => m.MarketDetailsModule),
    canActivate: [AccessGuard],
  },
  {
    path: 'signing-details',
    loadChildren: () => import('./features/signing-details/signing-details.module').then((m) => m.SigningDetailsModule),
    canActivate: [AccessGuard],
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'error',
    component: GlobalErrorComponent,
  },
  {
    path: '',
    pathMatch: 'full',
    component: LoginComponent,
  },
  {
    path: 'error',
    component: GlobalErrorComponent,
  },
  { path: '**', pathMatch: 'full', redirectTo: 'summary-details' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
