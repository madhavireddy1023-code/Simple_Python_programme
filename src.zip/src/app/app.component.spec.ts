import { TestBed, waitForAsync, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

describe('AppComponent', () => {
  let authService: AuthenticationService;
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let referenceDataStoreService: ReferenceDataStoreService;
  const themeServiceSpy = jasmine.createSpyObj('ThemeService', ['getTheme', 'registerTheme']);

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
      providers: [
        AuthenticationService,
        ReferenceDataStoreService,
        { provide: 'ThemeService', useValue: themeServiceSpy },
        MockStore,
        provideMockStore(),
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    authService = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    referenceDataStoreService = TestBed.inject(ReferenceDataStoreService) as jasmine.SpyObj<ReferenceDataStoreService>;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('should call authenticate method', () => {
    spyOn(authService, 'authenticate').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    expect(authService.authenticate).toHaveBeenCalled();
  });

  xit('should call getRefData method', fakeAsync(() => {
    spyOnProperty(authService, 'session').and.returnValue(
      Promise.resolve({
        getIdToken(): any {
          return { payload: { key: 'custom:party', value: '12345' } };
        },
        getRefreshToken: () => {},
        getAccessToken: () => {},
        isValid: () => true,
      })
    );
    spyOn(referenceDataStoreService, 'getRefData');
    component.ngOnInit();
    tick();
    expect(referenceDataStoreService.getRefData).toHaveBeenCalled();
  }));

  afterEach(() => {
    fixture.destroy();
  });
});
