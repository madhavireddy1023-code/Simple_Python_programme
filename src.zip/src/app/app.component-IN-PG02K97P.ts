import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ThemeService } from '@dxc-technology/halstack-angular';
import { customTheme } from '../assets/standardTheme';
import { Router, NavigationStart, NavigationEnd, RouteConfigLoadStart, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { filter, map, takeUntil } from 'rxjs/operators';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import {
  HEADER_ALL_QUERIES_URL,
  HEADER_SEARCH_QUERIES_URL,
  HEADER_CREATE_QUERIES_URL,
  HEADER_ENQUIRY_DETAILS_URL,
  HEADER_CORRECTIONS_URL,
  HEADER_STOP_BLOCK_URL,
  HEADER_RELEASE_FOR_SETTLEMENT_URL,
  HEADER_COMPANY_REF_UPDATE_URL,
  HEADER_INSTALMENT_DETAILS_URL,
  HEADER_AUDIT_URL,
  HEADER_EXCHANGE_RATE_ENQUIRY,
  HEADER_NAIC_REPORTING_URL,
  HEADER_SURPLUS_LINES_URL,
  HEADER_HERITAGE_URL,
  REVIEW_ERRORS_URL,
  HEADER_DEF_INST_HIST,
  ENQUIRY_SUBMISSION_ID,
  EDIT_MODE,
} from '@shared/consts/shared.consts';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { PageTitle, Role } from '@shared/consts/shared.enums';
import { EditModePersistenceService } from '@shared/services/edit-mode-router-persistance/edit-mode-router-persistance.service';
import { GlobalSpinnerService } from '@shared/services/global-spinner/global-spinner.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  readonly roles = Role;
  private destroy$ = new Subject();

  isCreateQuery: boolean;
  isEnquiry: boolean;
  isEnquirySubmission: boolean;
  isLandingPage = true; // As landing page is the default
  isQueries: boolean;
  isCorrections: boolean;
  isAudit: boolean;
  isCompanyRefUpdate: boolean;
  isInstalmentDetails: boolean;
  isStopBlock: boolean;
  isReleaseForSettlement: boolean;
  isSearchQueries: boolean;
  isExchangeRateEnquiry: boolean;
  isNaicReporting: boolean;
  isSurplusLines: boolean;
  isHeritage: boolean;
  loggedIn: boolean;
  isReviewErrors: boolean;
  isDefInstHistRoute: boolean;
  isEditMode: boolean;
  title = 'premiums-ipos-tech-portal';

  constructor(
    @Inject('ThemeService') private themeService: ThemeService,
    private router: Router,
    private route: ActivatedRoute,
    private auth: AuthenticationService,
    private referenceDataStoreService: ReferenceDataStoreService,
    private editModePersistenceService: EditModePersistenceService,
    private globalSpinnerService: GlobalSpinnerService,
    private titleService: Title
  ) {}

  async ngOnInit(): Promise<void> {
    this.checkPageUrl();
    this.setPageTitle();
    this.themeService.registerTheme(customTheme);
    this.auth.authenticate();
    this.loggedIn = !!(await this.auth.session.catch((err) => null));
    if (this.loggedIn) {
      this.referenceDataStoreService.getRefData();
    }
    this.editModePersistenceService.monitorRouterEventsForEditMode();
  }

  private checkPageUrl(): void {
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event) => {
      if (event instanceof NavigationStart) {
        const { url } = event;
        if (
          url.includes('workflowSubmissionId') ||
          url.includes(HEADER_SEARCH_QUERIES_URL) ||
          url.includes(HEADER_HERITAGE_URL) ||
          url.includes(HEADER_ENQUIRY_DETAILS_URL)
        ) {
          sessionStorage.setItem('redirectedURL', url);
        }
        this.isSearchQueries = event.url.indexOf(`/${HEADER_SEARCH_QUERIES_URL}`) > -1;
        this.isCreateQuery = event.url.indexOf(`/${HEADER_CREATE_QUERIES_URL}`) > -1;
        this.isQueries =
          event.url.indexOf(`/${HEADER_ALL_QUERIES_URL}`) > -1 || this.isSearchQueries || this.isCreateQuery;
        this.isEnquiry = event.url.indexOf(`/${HEADER_ENQUIRY_DETAILS_URL}`) > -1;
        this.isEnquirySubmission = event.url.indexOf(`${ENQUIRY_SUBMISSION_ID}`) > -1;
        this.isEditMode = event.url.indexOf(`${EDIT_MODE}`) > -1;
        this.isCompanyRefUpdate = event.url.indexOf(`/${HEADER_COMPANY_REF_UPDATE_URL}`) > -1;
        this.isInstalmentDetails = event.url.indexOf(`/${HEADER_INSTALMENT_DETAILS_URL}`) > -1;
        this.isCorrections = event.url.indexOf(`/${HEADER_CORRECTIONS_URL}`) > -1;
        this.isAudit = event.url.indexOf(`/${HEADER_AUDIT_URL}`) > -1;
        this.isStopBlock = event.url.indexOf(`/${HEADER_STOP_BLOCK_URL}`) > -1;
        this.isNaicReporting = event.url.indexOf(`/${HEADER_NAIC_REPORTING_URL}`) > -1;
        this.isSurplusLines = event.url.indexOf(`/${HEADER_SURPLUS_LINES_URL}`) > -1;
        this.isHeritage = event.url.indexOf(`/${HEADER_HERITAGE_URL}`) > -1;
        this.isReleaseForSettlement = event.url.indexOf(`/${HEADER_RELEASE_FOR_SETTLEMENT_URL}`) > -1;
        this.isExchangeRateEnquiry = event.url.indexOf(`/${HEADER_EXCHANGE_RATE_ENQUIRY}`) > -1;
        this.isReviewErrors = event.url.indexOf(`/${REVIEW_ERRORS_URL}`) > -1;
        this.isDefInstHistRoute = event.url.indexOf(`/${HEADER_DEF_INST_HIST}`) > -1;
      }
      if (event instanceof NavigationStart && !event.url.includes('/login')) {
        this.isLandingPage = event.url === `/`;
      }
      if (event instanceof RouteConfigLoadStart) {
        this.globalSpinnerService.setLoading(this.isLandingPage);
      }
      if (event instanceof NavigationEnd) {
        this.isEditMode = event.url.indexOf(`${EDIT_MODE}`) > -1;
        this.editModePersistenceService.wasPreviousUrlInEditMode = this.isEditMode;
        this.globalSpinnerService.setLoading(false);
      }
    });
  }

  private setPageTitle(): void {
    this.router.events
      .pipe(
        takeUntil(this.destroy$),
        filter((event) => event instanceof NavigationEnd),
        map(() => {
          let route = this.router?.routerState?.root;
          let title = '';

          // Traverse the route tree to find the deepest route with a title
          while (route?.firstChild) {
            route = route?.firstChild;
            if (route?.snapshot?.data?.title) {
              title = route?.snapshot?.data?.title;
            }
          }

          if (title === PageTitle.ENQUIRY) {
            const queryParams = route?.snapshot?.queryParams;
            if (queryParams?.isfromDeferred) {
              title = PageTitle.DEFINSTALLMENTS;
            } else if (queryParams?.isfromCorrection) {
              title = PageTitle.CORRECTIONS;
            } else {
              title = PageTitle.ENQUIRY;
            }
          }

          return title;
        })
      )
      .subscribe((title) => {
        if (title) {
          this.titleService.setTitle(title);
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
