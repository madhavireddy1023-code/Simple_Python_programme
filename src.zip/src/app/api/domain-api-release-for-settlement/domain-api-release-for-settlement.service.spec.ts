import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as DomainApiModule, BASE_PATH } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { Configuration } from './configuration';
import { DomainAPIReleaseForSettlementService } from '.';

describe('DomainAPIReleaseForSettlementService', () => {
  let service: DomainAPIReleaseForSettlementService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        DomainApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.domainApi.base',
            })
        ),
      ],
      providers: [
        DomainAPIReleaseForSettlementService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.domainApi.base',
        },
      ],
    });

    service = TestBed.inject(DomainAPIReleaseForSettlementService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return DomainAPIReleaseForSettlement service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
