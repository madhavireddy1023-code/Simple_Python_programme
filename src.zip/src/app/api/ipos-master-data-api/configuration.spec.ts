import { Configuration } from '.';

describe('Configuration', () => {
  const configuration = new Configuration({
    basePath: 'endPoints.technicianPortal.basePath',
  });

  describe('selectHeaderContentType', () => {
    it('should return application/json', () => {
      expect(configuration.selectHeaderContentType(['application/json'])).toBe('application/json');
    });

    it('should return anything other than application/json', () => {
      expect(configuration.selectHeaderContentType(['text/html'])).toBe('text/html');
    });

    it('should return undefined', () => {
      expect(configuration.selectHeaderContentType([])).toBeUndefined();
    });
  });

  describe('selectHeaderAccept', () => {
    it('should return application/json', () => {
      expect(configuration.selectHeaderAccept(['application/json'])).toBe('application/json');
    });

    it('should return anything other than application/json', () => {
      expect(configuration.selectHeaderAccept(['text/html'])).toBe('text/html');
    });

    it('should return undefined', () => {
      expect(configuration.selectHeaderAccept([])).toBeUndefined();
    });
  });
});
