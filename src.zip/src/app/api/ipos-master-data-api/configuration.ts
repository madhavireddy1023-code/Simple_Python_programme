import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/ipos-master-data-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
