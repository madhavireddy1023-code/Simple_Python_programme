import { TestBed } from '@angular/core/testing';
import { IposMasterDataApiService } from './ipos-master-data-api.service';

describe('IposMasterDataApiService', () => {
  let service: IposMasterDataApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IposMasterDataApiService);
  });
});
