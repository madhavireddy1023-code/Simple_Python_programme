import {
  Configuration as ApiConfig,
  ConfigurationParameters,
} from '@dxc.lm.sdk.angular/premiums-base-workflow-experience-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
