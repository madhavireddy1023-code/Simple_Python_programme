import { TestBed } from '@angular/core/testing';
import { WorkflowSubmissionService } from './workflow-submission.service';

describe('WorkflowSubmissionService', () => {
  let service: WorkflowSubmissionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorkflowSubmissionService);
  });
});
