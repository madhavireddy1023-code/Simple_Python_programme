import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import {
  ApiModule as UtilitiesApiModule,
  BASE_PATH,
  UtilitiesService,
  Configuration,
} from '@dxc.lm.sdk.angular/portal-utilities-api';
export * from './configuration';

describe('DomainAPIQueriesService', () => {
  let service: UtilitiesService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        UtilitiesApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.domainApi.base',
            })
        ),
      ],
      providers: [
        UtilitiesService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.domainApi.base',
        },
      ],
    });

    service = TestBed.inject(UtilitiesService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return DomainAPIQueries service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
