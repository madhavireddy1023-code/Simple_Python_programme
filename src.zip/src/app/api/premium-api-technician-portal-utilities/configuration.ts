import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/portal-utilities-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
