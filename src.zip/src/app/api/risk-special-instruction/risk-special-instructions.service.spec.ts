import { TestBed } from '@angular/core/testing';
import { RiskSpecialInstructionsService } from './risk-special-instructions.service';

describe('RiskSpecialInstructionsService', () => {
  let service: RiskSpecialInstructionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RiskSpecialInstructionsService);
  });
});
