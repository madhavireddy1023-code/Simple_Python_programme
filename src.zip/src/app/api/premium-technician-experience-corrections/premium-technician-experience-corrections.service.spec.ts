import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';

import { TechnicianPortalCorrectionsExperienceService } from './premium-technician-experience-corrections.service';

describe('TechnicianPortalCorrectionsExperienceService', () => {
  let service: TechnicianPortalCorrectionsExperienceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Configuration],
    });
    service = TestBed.inject(TechnicianPortalCorrectionsExperienceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
