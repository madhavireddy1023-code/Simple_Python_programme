import { TestBed } from '@angular/core/testing';
import { WorkflowRulesService } from './workflow-rules.service';

describe('WorkflowRulesService', () => {
  let service: WorkflowRulesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorkflowRulesService);
  });
});
