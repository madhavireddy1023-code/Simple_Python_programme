import { TestBed } from '@angular/core/testing';
import { WorkflowXisService } from './workflow-xis.service';

describe('WorkflowXisService', () => {
  let service: WorkflowXisService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorkflowXisService);
  });
});
