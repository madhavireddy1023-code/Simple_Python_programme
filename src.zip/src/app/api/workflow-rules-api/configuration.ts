import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
