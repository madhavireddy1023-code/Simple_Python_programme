import { TestBed } from '@angular/core/testing';

import { CalculatevatService } from './calculatevat.service';

describe('CalculatevatService', () => {
  let service: CalculatevatService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculatevatService);
  });
});
