import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/ipos-party-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
