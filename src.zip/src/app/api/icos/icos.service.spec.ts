import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as PartyIcosApiModule, BASE_PATH } from '@dxc.lm.sdk.angular/ipos-party-api';
import { Configuration } from './configuration';
import { ICOSService } from '.';

describe('ICOSService', () => {
  let service: ICOSService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        PartyIcosApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.partyIcos.base',
            })
        ),
      ],
      providers: [
        ICOSService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.partyIcos.base',
        },
      ],
    });

    service = TestBed.inject(ICOSService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return ICOS service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
