import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';

import { PremiumTechnicianExperienceService } from './premium-technician-experience-api.service';

describe('PremiumTechnicianExperienceService', () => {
  let service: PremiumTechnicianExperienceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Configuration],
    });
    service = TestBed.inject(PremiumTechnicianExperienceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
