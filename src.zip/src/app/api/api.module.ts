import { NgModule } from '@angular/core';
import { ApiModule as TechnicianPortalApiModule } from '@dxc.lm.sdk.angular/ipos-premium-experience-api';
import { Configuration, TechnicianPortalService } from './technician-portal';

@NgModule({
  imports: [
    TechnicianPortalApiModule.forRoot(
      () =>
        new Configuration({
          basePath: 'endPoints.technicianPortal',
        })
    ),
  ],
  declarations: [],
  exports: [],
  providers: [TechnicianPortalService],
})
export class ApiModule {}
