import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';

import { TechnicianPortalValidationsService } from './technician-portal-validation.service';

describe('TechnicianPortalValidationsService', () => {
  let service: TechnicianPortalValidationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Configuration],
    });
    service = TestBed.inject(TechnicianPortalValidationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
