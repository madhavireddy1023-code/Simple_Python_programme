import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { PremiumTechnicianExperienceSubmissionService } from './premium-technician-experience-submission.service';

describe('PremiumTechnicianExperienceSubmissionService', () => {
  let service: PremiumTechnicianExperienceSubmissionService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Configuration],
    });
    service = TestBed.inject(PremiumTechnicianExperienceSubmissionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
