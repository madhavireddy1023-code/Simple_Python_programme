export * from './iPOS.service';
export * from './configuration';
