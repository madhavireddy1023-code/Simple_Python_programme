import {
  Configuration as ApiConfig,
  ConfigurationParameters,
} from '@dxc.lm.sdk.angular/premiums-base-workflow-experience-api';

export class IPOSConfig extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
