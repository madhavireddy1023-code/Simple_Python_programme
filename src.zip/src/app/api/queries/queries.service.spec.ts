import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Configuration } from '@dxc.lm.sdk.angular/portal-queries-api';

import { QueriesService } from './queries.service';

describe('QueriesService', () => {
  let service: QueriesService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Configuration],
    });
    service = TestBed.inject(QueriesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
