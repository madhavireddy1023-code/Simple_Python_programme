import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/portal-queries-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
