import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { TechnicianPortalEnquiryService } from './technician-portal-enquiry.service';

describe('TechnicianPortalEnquiryService', () => {
  let service: TechnicianPortalEnquiryService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Configuration],
    });
    service = TestBed.inject(TechnicianPortalEnquiryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
