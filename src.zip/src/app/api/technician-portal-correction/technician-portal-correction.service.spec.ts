import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import {
  ApiModule as TechnicianPortalCorrectionModule,
  BASE_PATH,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { Configuration } from './configuration';
import { TechnicianPortalCorrectionService } from '.';
import { HttpClient } from '@angular/common/http';

describe('TechnicianPortalCorrectionService', () => {
  let service: TechnicianPortalCorrectionService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        TechnicianPortalCorrectionModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.technicianPortalCorrection.base',
            })
        ),
      ],
      providers: [
        TechnicianPortalCorrectionService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.technicianPortalCorrection.base',
        },
      ],
    });

    service = TestBed.inject(TechnicianPortalCorrectionService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return TechnicianPortalCorrectionService service', (done) => {
    done();
    expect(service).toBeTruthy();
  });

  it('should http request be called when apiV1CorrectionSelectionsTextPost invoked', (done) => {
    done();
    spyOn(httpClient, 'request');
    service.apiV1CorrectionSelectionsTextPost();
    expect(httpClient.request).toHaveBeenCalled();
  });
});
