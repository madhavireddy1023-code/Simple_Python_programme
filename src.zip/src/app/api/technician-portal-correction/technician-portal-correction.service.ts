import { HttpClient, HttpEvent, HttpResponse } from '@angular/common/http';
import { Inject, Injectable, Optional } from '@angular/core';
import {
  BASE_PATH,
  Configuration,
  TechnicianPortalCorrectionService as ApiService,
  NewCorrectionSelection,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { Observable } from 'rxjs';
import { AppConfigService } from 'src/app/core/services/app-config/app-config.service';

@Injectable({
  providedIn: 'root',
})
export class TechnicianPortalCorrectionService extends ApiService {
  constructor(
    httpClient: HttpClient,
    @Optional() @Inject(BASE_PATH) basePath: string,
    configuration: Configuration,
    private appConfigService: AppConfigService
  ) {
    super(httpClient, basePath, configuration);

    this.configuration = configuration;
    this.basePath = this.appConfigService.get(basePath || configuration.basePath || '');
  }

  public apiV1CorrectionSelectionsTextPost(
    body?: Array<NewCorrectionSelection>,
    observe?: 'body',
    reportProgress?: boolean
  ): Observable<any>;
  public apiV1CorrectionSelectionsTextPost(
    body?: Array<NewCorrectionSelection>,
    observe?: 'response',
    reportProgress?: boolean
  ): Observable<HttpResponse<any>>;
  public apiV1CorrectionSelectionsTextPost(
    body?: Array<NewCorrectionSelection>,
    observe?: 'events',
    reportProgress?: boolean
  ): Observable<HttpEvent<any>>;
  public apiV1CorrectionSelectionsTextPost(
    body?: Array<NewCorrectionSelection>,
    observe: any = 'body',
    reportProgress: boolean = false
  ): Observable<any> {
    let headers = this.defaultHeaders;

    // to determine the Accept header
    const httpHeaderAccepts: string[] = ['application/json', 'application/problem+json'];
    const httpHeaderAcceptSelected: string | undefined = this.configuration.selectHeaderAccept(httpHeaderAccepts);
    if (httpHeaderAcceptSelected !== undefined) {
      headers = headers.set('Accept', httpHeaderAcceptSelected);
    }

    // to determine the Content-Type header
    const consumes: string[] = ['application/json'];
    const httpContentTypeSelected: string | undefined = this.configuration.selectHeaderContentType(consumes);
    if (httpContentTypeSelected !== undefined) {
      headers = headers.set('Content-Type', httpContentTypeSelected);
    }

    return this.httpClient.request('post', `${this.basePath}/api/v1/correctionSelections`, {
      body,
      withCredentials: this.configuration.withCredentials,
      headers,
      observe,
      responseType: 'text',
      reportProgress,
    });
  }
}
