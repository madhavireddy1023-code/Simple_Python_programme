import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
