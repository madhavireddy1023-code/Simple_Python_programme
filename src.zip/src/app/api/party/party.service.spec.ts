import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as PartyApiModule, BASE_PATH } from '@dxc.lm.sdk.angular/ipos-party-api';
import { Configuration } from './configuration';
import { PartyService } from '.';

describe('PartyService', () => {
  let service: PartyService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        PartyApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.party.base',
            })
        ),
      ],
      providers: [
        PartyService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.party.base',
        },
      ],
    });

    service = TestBed.inject(PartyService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return Party service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
