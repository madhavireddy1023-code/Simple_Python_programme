import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as WorkpackagesApiModule, BASE_PATH } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Configuration } from './configuration';
import { TechnicianPortalQueriesService } from '.';

describe('TechnicianPortalQueriesService', () => {
  let service: TechnicianPortalQueriesService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        WorkpackagesApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.workpackages.base',
            })
        ),
      ],
      providers: [
        TechnicianPortalQueriesService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.workpackages.base',
        },
      ],
    });

    service = TestBed.inject(TechnicianPortalQueriesService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return TechnicianPortalQueries service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
