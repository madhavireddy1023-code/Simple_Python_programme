import {
  Configuration as ApiConfig,
  ConfigurationParameters,
} from '@dxc.lm.sdk.angular/premiums-base-workflow-parties-api';

export class PartiesConfig extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
