import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/premiums-reachback-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
