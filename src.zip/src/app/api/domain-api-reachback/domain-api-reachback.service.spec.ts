import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as ReachBackRequestModule, BASE_PATH } from '@dxc.lm.sdk.angular/premiums-reachback-api';
import { Configuration } from './configuration';
import { ReachBackService } from './domain-api-reachback.service';

describe('ReachBackService', () => {
  let service: ReachBackService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        ReachBackRequestModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.reachBackBase',
            })
        ),
      ],
      providers: [
        ReachBackService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.reachBackBase',
        },
      ],
    });

    service = TestBed.inject(ReachBackService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return ReachBackService service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
