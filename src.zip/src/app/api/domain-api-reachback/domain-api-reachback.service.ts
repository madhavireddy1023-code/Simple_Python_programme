import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, Optional } from '@angular/core';
import {
  BASE_PATH,
  ReachbackRequestService as ApiService,
  Configuration,
} from '@dxc.lm.sdk.angular/premiums-reachback-api';
import { AppConfigService } from 'src/app/core/services/app-config/app-config.service';

@Injectable()
export class ReachBackService extends ApiService {
  constructor(
    httpClient: HttpClient,
    @Optional() @Inject(BASE_PATH) basePath: string,
    configuration: Configuration,
    private appConfigService: AppConfigService
  ) {
    super(httpClient, basePath, configuration);

    this.configuration = configuration;
    this.basePath = this.appConfigService.get(basePath || configuration.basePath || '');
  }
}
