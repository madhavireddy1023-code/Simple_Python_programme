import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as DomainApiModule, BASE_PATH } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { Configuration } from './configuration';
import { DomainAPISupervisoryWarningsService } from '.';

describe('DomainAPISupervisoryWarningsService', () => {
  let service: DomainAPISupervisoryWarningsService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        DomainApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.domainApi.base',
            })
        ),
      ],
      providers: [
        DomainAPISupervisoryWarningsService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.domainApi.base',
        },
      ],
    });

    service = TestBed.inject(DomainAPISupervisoryWarningsService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return DomainAPISupervisoryWarningsService service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
