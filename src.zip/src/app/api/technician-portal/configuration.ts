import { Configuration as ApiConfig, ConfigurationParameters } from '@dxc.lm.sdk.angular/ipos-premium-experience-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
