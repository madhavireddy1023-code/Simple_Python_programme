import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as WorkpackagesApiModule, BASE_PATH } from '@dxc.lm.sdk.angular/ipos-premium-experience-api';
import { Configuration } from './configuration';
import { TechnicianPortalService } from '.';

describe('TechnicianPortalService', () => {
  let service: TechnicianPortalService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        WorkpackagesApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.workpackages.base',
            })
        ),
      ],
      providers: [
        TechnicianPortalService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.workpackages.base',
        },
      ],
    });

    service = TestBed.inject(TechnicianPortalService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  xit('should return TechnicianPortal service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
