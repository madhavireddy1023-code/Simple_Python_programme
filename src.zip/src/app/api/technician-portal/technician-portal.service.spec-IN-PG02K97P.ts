import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ApiModule as experienceApiModule, BASE_PATH } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Configuration } from './configuration';
import { TechnicianPortalService } from '.';

describe('TechnicianPortalService', () => {
  let service: TechnicianPortalService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        experienceApiModule.forRoot(
          () =>
            new Configuration({
              basePath: 'endPoints.technicianPortal.base',
            })
        ),
      ],
      providers: [
        TechnicianPortalService,
        {
          provide: BASE_PATH,
          useValue: 'endPoints.technicianPortal.base',
        },
      ],
    });

    service = TestBed.inject(TechnicianPortalService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should return TechnicianPortalService service', (done) => {
    done();
    expect(service).toBeTruthy();
  });
});
