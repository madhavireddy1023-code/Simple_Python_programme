import { NgModule } from '@angular/core';
import { ApiModule as TechnicianPortalApiModule } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { ApiModule as WorkflowSubmissionApiModule } from '@dxc.lm.sdk.angular/premiums-base-workflow-experience-api';
import { ApiModule as WorkflowRulesApiModule } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';
import { ApiModule as DomainApiModule } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { ApiModule as QueriesApiModule } from '@dxc.lm.sdk.angular/portal-queries-api';
import { ApiModule as PartyApiModule } from '@dxc.lm.sdk.angular/ipos-party-api';
import { ApiModule as PartiesApiModule } from '@dxc.lm.sdk.angular/premiums-base-workflow-parties-api';
import { ApiModule as PremTechExperienceApiModule } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { ApiModule as PremUtilitiesApiModule } from '@dxc.lm.sdk.angular/portal-utilities-api';
import { ApiModule as PartyIcosApiModule } from '@dxc.lm.sdk.angular/ipos-party-api';
import { ApiModule as IposMasterDataModule } from '@dxc.lm.sdk.angular/ipos-master-data-api';
import { ApiModule as ReachBackRequestModule } from '@dxc.lm.sdk.angular/premiums-reachback-api';
import { Configuration, TechnicianPortalService } from './technician-portal';
import { TechnicianPortalQueriesService } from './technician-portal-queries';
import { Configuration as DomainAPIConfiguration, DomainAPIQueriesService } from './domain-api-queries';
import {
  Configuration as HeritageSubmissionApiConfiguration,
  HeritageSubmissionApiService,
} from './domain-api-heritage-submissions';
import {
  Configuration as DomainAPIReleaseForSettlementConfiguration,
  DomainAPIReleaseForSettlementService,
} from './domain-api-release-for-settlement';
import { TechnicianPortalEnquiryService } from './technicianPortalEnquiry/technician-portal-enquiry.service';
import { DomainAPITechnicianPortalService } from './domain-api-technician-portal';
import { TechnicianPortalCorrectionService } from './technician-portal-correction';
import { QueriesService } from './queries';
import { ApiModule as TechnicianPortalCorrectionApiModule } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { ApiModule as RiskSpecialInstructionApiModule } from '@dxc.lm.sdk.angular/ipos-risk-special-instruction-api';

import { ApiModule as NaicSurplusLinesModule } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';

import {
  Configuration as RiskSpecialInstructionConfiguration,
  RiskSpecialInstructionService,
  RiskSpecialInstructionsService,
} from './risk-special-instruction';
import { DomainAPITechnicianPortalCorrectionService } from './domain-api-technician-portal-correction';
import { Configuration as PartyAPIConfiguration, PartyService } from './party';
import {
  Configuration as PremTechExperienceConfiguration,
  TechnicianPortalValidationsService,
} from './premium-technician-portal-validation';
import {
  Configuration as UtilitiesServiceConfiguration,
  UtilitiesService,
} from './premium-api-technician-portal-utilities';
import { Configuration as ICOSAPIConfiguration, ICOSService } from './icos';
import { Configuration as workflowSubmissionConfiguration, WorkflowSubmissionService } from './workflow-submission-api';
import {
  Configuration as workflowRulesConfiguration,
  WorkflowRulesService,
  WorkflowXisService,
} from './workflow-rules-api';
import { Configuration as iposMasterDataConfiguration, IposMasterDataApiService } from './ipos-master-data-api';
import { Configuration as ReachBackConfiguration, ReachBackService } from './domain-api-reachback';
import {
  Configuration as naicSurplusLinesConfiguration,
  NaicApiService,
  UsSurplusLinesApiService,
} from './naic-surplus-lines-api';
import { TechnicianPortalSubmissionSummaryService } from './technician-portal-submission-summary';
import { TechnicianPortalReferenceDataService } from './reference-data';
import { TechnicianPortalUMRNavService } from './technician-portal-umr-nav';
import { TechnicianPortalWorkpackageService } from './technician-portal-workpackage';
import { TechnicianPortalNotepadService } from './technician-portal-notepad';
import { DomainAPITechnicianPortalWorkpageService } from './domain-api-technician-portal-workpage';
import {
  Configuration as TechnicianPortalNaicslConfiguration,
  TechnicianPortalNAICSLService,
} from './technician-portal-naicsl';
import { DomainAPITechnicianPortalSummaryService } from './domain-api-technician-portal-summary';
import { TechnicianPortalPartyIntegrationService } from './technician-portal-party-integration';
import { DomainAPITechnicianPortalLineSlipsService } from './domain-api-technician-portal-lineslips';
import { DomainAPISupervisoryWarningsService } from './domain-api-supervisory-warnings';
import { TechnicianPortalCorrectionsExperienceService } from './premium-technician-experience-corrections';
import { PremiumTechnicianExperienceService } from './premium-technician-experience-api';
import { PartiesConfig, PartiesService } from './parties';
import { IPOSService } from './iPOS';
import { DomainAPITechnicianPortalEnquiryService } from './domain-api-technician-portal-enquiry/domain-api-technician-portal-enquiry.service';
import { PremiumTechnicianExperienceSubmissionService } from './premium-technician-experience-submission';

@NgModule({
  imports: [
    TechnicianPortalApiModule.forRoot(
      () =>
        new Configuration({
          basePath: 'endPoints.technicianPortal',
        })
    ),

    DomainApiModule.forRoot(
      () =>
        new DomainAPIConfiguration({
          basePath: 'endPoints.domainApi',
        })
    ),
    DomainApiModule.forRoot(
      () =>
        new HeritageSubmissionApiConfiguration({
          basePath: 'endPoints.domainApi',
        })
    ),
    DomainApiModule.forRoot(
      () =>
        new DomainAPIReleaseForSettlementConfiguration({
          basePath: 'endPoints.domainApi', // TODO change when endpoin will be provided to environments files
        })
    ),
    TechnicianPortalCorrectionApiModule.forRoot(
      () =>
        new Configuration({
          basePath: 'endPoints.technicianPortalCorrection',
        })
    ),
    RiskSpecialInstructionApiModule.forRoot(
      () =>
        new RiskSpecialInstructionConfiguration({
          basePath: 'endPoints.riskSpecialInstructions',
        })
    ),
    QueriesApiModule.forRoot(
      () =>
        new Configuration({
          basePath: 'endPoints.technicianPortalQueries',
        })
    ),
    PartyApiModule.forRoot(
      () =>
        new PartyAPIConfiguration({
          basePath: 'endPoints.party',
        })
    ),
    PartiesApiModule.forRoot(() => new PartiesConfig({ basePath: 'endPoints.parties.base' })),
    PremTechExperienceApiModule.forRoot(
      () =>
        new PremTechExperienceConfiguration({
          basePath: 'endPoints.premiumTechnicianExperience',
        })
    ),
    PremUtilitiesApiModule.forRoot(
      () =>
        new UtilitiesServiceConfiguration({
          basePath: 'endPoints.premiumUtilities',
        })
    ),

    PartyIcosApiModule.forRoot(
      () =>
        new ICOSAPIConfiguration({
          basePath: 'endPoints.partyIcos',
        })
    ),
    WorkflowSubmissionApiModule.forRoot(() => new workflowSubmissionConfiguration({ basePath: 'endPoints.workflow' })),
    WorkflowRulesApiModule.forRoot(() => new workflowRulesConfiguration({ basePath: 'endPoints.workflowRules' })),
    IposMasterDataModule.forRoot(() => new iposMasterDataConfiguration({ basePath: 'endPoints.iposMasterData' })),
    NaicSurplusLinesModule.forRoot(() => new naicSurplusLinesConfiguration({ basePath: 'endPoints.naicSurplusLines' })),
    ReachBackRequestModule.forRoot(() => new ReachBackConfiguration({ basePath: 'endPoints.reachBackBase' })),
  ],
  declarations: [],
  exports: [],
  providers: [
    TechnicianPortalService,
    TechnicianPortalQueriesService,
    DomainAPIQueriesService,
    DomainAPIReleaseForSettlementService,
    TechnicianPortalEnquiryService,
    DomainAPITechnicianPortalService,
    DomainAPITechnicianPortalEnquiryService,
    TechnicianPortalCorrectionService,
    RiskSpecialInstructionService,
    RiskSpecialInstructionsService,
    QueriesService,
    DomainAPITechnicianPortalCorrectionService,
    PartyService,
    IPOSService,
    PartiesService,
    ICOSService,
    WorkflowSubmissionService,
    WorkflowRulesService,
    WorkflowXisService,
    IposMasterDataApiService,
    TechnicianPortalSubmissionSummaryService,
    TechnicianPortalReferenceDataService,
    TechnicianPortalWorkpackageService,
    TechnicianPortalNotepadService,
    DomainAPITechnicianPortalWorkpageService,
    TechnicianPortalNAICSLService,
    TechnicianPortalPartyIntegrationService,
    DomainAPITechnicianPortalSummaryService,
    DomainAPITechnicianPortalLineSlipsService,
    NaicApiService,
    UsSurplusLinesApiService,
    ReachBackService,
    DomainAPISupervisoryWarningsService,
    TechnicianPortalValidationsService,
    TechnicianPortalCorrectionsExperienceService,
    HeritageSubmissionApiService,
    PremiumTechnicianExperienceService,
    TechnicianPortalUMRNavService,
    PremiumTechnicianExperienceSubmissionService,
    UtilitiesService,
  ],
})
export class ApiModule {}
