import {
  Configuration as ApiConfig,
  ConfigurationParameters,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

export class Configuration extends ApiConfig {
  constructor(configurationParameters: ConfigurationParameters = {}) {
    super(configurationParameters);
  }
}
