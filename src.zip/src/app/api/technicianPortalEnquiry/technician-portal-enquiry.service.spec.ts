import { TestBed } from '@angular/core/testing';

import { TechnicianPortalEnquiryService } from './technician-portal-enquiry.service';

describe('TechnicianPortalEnquiryService', () => {
  let service: TechnicianPortalEnquiryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TechnicianPortalEnquiryService);
  });
});
