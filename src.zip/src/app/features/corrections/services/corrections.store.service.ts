import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from '../../../store/app.reducer';
import * as actions from '../store/actions/corrections.action';
import { Observable } from 'rxjs';
import {
  CorrectionSelectionPatch,
  CorrectionSelectionRecs,
  CorrectionSelectionUpdateRec,
  CorrectionStatusPatch,
  CorrectionTypeEnum,
  NewCorrectionSelection,
  SubmissionStatuses,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import * as selectors from '../store/selectors/corrections.selectors';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { CorrectionSignings } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { Http400Warning } from '@shared/interfaces/http-warning.model';
import { NewSubmssionIdsByPremiumId } from '../models/corrections.model';

@Injectable({
  providedIn: 'root',
})
export class CorrectionStoreService {
  constructor(private store: Store<AppState>) {}

  newCorrectionSelectionPost(
    correctionSelection: NewCorrectionSelection[],
    callback: string,
    workflowSubmissionId?: string
  ): void {
    this.store.dispatch(actions.newCorrectionSelectionPost({ correctionSelection, callback, workflowSubmissionId }));
  }

  newCorrectionSelectionGet(workPackageRef: string): void {
    if (!workPackageRef) {
      return;
    }
    this.store.dispatch(actions.newCorrectionSelectionGet({ workPackageRef }));
  }

  selectCorrectionSelectionResult(): Observable<CorrectionSelectionRecs> {
    return this.store.select(selectors.selectCorrectionSelectionResult);
  }

  selectIsReturnToWorkOn(): Observable<boolean> {
    return this.store.select(selectors.selectIsReturnToWorkflowOn);
  }

  selectSubmissionIds(): Observable<NewSubmssionIdsByPremiumId> {
    return this.store.select(selectors.selectSubmissionIds);
  }

  selectHttp400WarningDetails(): Observable<Http400Warning> {
    return this.store.select(selectors.select400WarningDetails);
  }

  setWarningStatus(warningDetails: Http400Warning): void {
    this.store.dispatch(actions.setWarningDetails({ warningDetails }));
  }

  workpackageSubmissionsCompletePost(workPackageRef: string): void {
    const correctionStatusPatch: CorrectionStatusPatch = {
      status: SubmissionStatuses.PortalComplete,
    };
    this.store.dispatch(actions.workpackageSubmissionsCompletePost({ workPackageRef, correctionStatusPatch }));
  }

  updateCorrectionSelection(
    etag: string,
    id: string,
    correctionSelectionPatch: CorrectionSelectionPatch,
    workPackageRef: string
  ): void {
    this.store.dispatch(
      actions.correctionSelectionStatusTypePatch({ etag, id, correctionSelectionPatch, workPackageRef })
    );
  }

  updateStatusBySubmissionId(submissionId: string, status: SubmissionStatuses, workPackageRef?: string): void {
    this.store.dispatch(actions.patchStatusBySubmission({ submissionId, status, workPackageRef }));
  }

  setCorrectionSubmissionPost(correctionSignings: CorrectionSignings, warningCodeList?: string[]): void {
    this.store.dispatch(actions.domainApiCorrectionSubmissionPost({ correctionSignings, warningCodeList }));
  }

  deleteCorrectionSubmission(etag: string, id: string, workPackageRef: string): void {
    this.store.dispatch(actions.deleteCollectionSelection({ etag, id, workPackageRef }));
  }

  removeItemFromStore(id: string): void {
    this.store.dispatch(actions.removeItem({ id }));
  }

  clearAllSelection(workPackageRef: string): void {
    this.store.dispatch(actions.clearAllSelection({ workPackageRef }));
  }

  updateCorrectionSelections(updateCorrectionSelections: CorrectionSelectionUpdateRec[], workPackageRef: string): void {
    if (!updateCorrectionSelections || updateCorrectionSelections?.length <= 0) {
      return;
    }
    this.store.dispatch(actions.updateCorrectionSelections({ updateCorrectionSelections, workPackageRef }));
  }
}
