import { TestBed } from '@angular/core/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import * as actions from '../store/actions/corrections.action';
import * as selectors from '../store/selectors/corrections.selectors';
import { CorrectionStoreService } from './corrections.store.service';
import {
  CorrectionSelectionPatch,
  CorrectionSelectionUpdateRec,
  CorrectionStatusPatch,
  CorrectionTypeEnum,
  NewCorrectionSelection,
  SubmissionStatuses,
  TechnicianPortalBureauEnum,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { mockInfoHeaderDetails } from '@shared/consts/mock-info-header.const';
import { mockCorrectionPost } from '../const/corrections-table.consts';
import { CorrectionSignings } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

describe('CorrectionsStoreService', () => {
  let service: CorrectionStoreService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockStore, provideMockStore()],
    });
    service = TestBed.inject(CorrectionStoreService);
    store = TestBed.inject(MockStore);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should newCorrectionSelectionGet to be called', () => {
    const workPackageRef = mockInfoHeaderDetails?.workPackageRef;
    spyOn(store, 'dispatch');
    service.newCorrectionSelectionGet(workPackageRef);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should selectCorrectionSelectionResult to be called', () => {
    spyOn(service, 'selectCorrectionSelectionResult');
    service.selectCorrectionSelectionResult();
    expect(service.selectCorrectionSelectionResult).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectCorrectionSelectionResult);
    expect(store.select).toHaveBeenCalled();
  });

  it('should newCorrectionSelectionPost to be called', () => {
    const correctionSelection: NewCorrectionSelection[] = mockCorrectionPost;
    const callback = 'link';
    spyOn(store, 'dispatch');
    service.newCorrectionSelectionPost(correctionSelection, callback);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should workpackageSubmissionsCompletePost to be called', () => {
    const workPackageRef = 'ABCDEF123';
    const correctionStatusPatch: CorrectionStatusPatch = {
      status: SubmissionStatuses.PortalComplete,
    };
    spyOn(store, 'dispatch');
    service.workpackageSubmissionsCompletePost(workPackageRef);
    store.dispatch(actions.workpackageSubmissionsCompletePost({ workPackageRef, correctionStatusPatch }));
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should updateCorrectionSelection to be called', () => {
    const workPackageRef = 'ABCDEF123';
    const correctionSelectionPatch: CorrectionSelectionPatch = {};
    const correctionStatusPatch: CorrectionStatusPatch = {};
    spyOn(store, 'dispatch');
    service.updateCorrectionSelection('etag', 'id', correctionSelectionPatch, workPackageRef);
    store.dispatch(actions.workpackageSubmissionsCompletePost({ workPackageRef, correctionStatusPatch }));
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should setCorrectionSubmissionPost to be called', () => {
    const correctionSignings: CorrectionSignings = {
      premiumSigningList: [],
      correctionType: CorrectionTypeEnum.C,
      workPackageRef: '123123',
    };
    const warningCodeList = [];
    spyOn(store, 'dispatch');
    service.setCorrectionSubmissionPost(correctionSignings, warningCodeList);
    store.dispatch(actions.domainApiCorrectionSubmissionPost({ correctionSignings, warningCodeList }));
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should deleteCorrectionSubmission to be called', () => {
    const etag = '123';
    const id = 'id';
    const workPackageRef = 'workPackageRef';
    spyOn(store, 'dispatch');
    service.deleteCorrectionSubmission(etag, id, workPackageRef);
    store.dispatch(actions.deleteCollectionSelection({ etag, id, workPackageRef }));
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should clearAllSelection to be called', () => {
    const workPackageRef = 'workPackageRef';
    spyOn(store, 'dispatch');
    service.clearAllSelection(workPackageRef);
    store.dispatch(actions.clearAllSelection({ workPackageRef }));
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should updateCorrectionSelections to be called', () => {
    const workPackageRef = 'workPackageRef';
    const updateCorrectionSelections: CorrectionSelectionUpdateRec[] = [
      {
        premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        version: 1,
        submissionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        correctionType: 'RA',
        status: 'Draft',
      },
    ];
    spyOn(store, 'dispatch');
    service.updateCorrectionSelections(updateCorrectionSelections, workPackageRef);
    store.dispatch(actions.updateCorrectionSelections({ updateCorrectionSelections, workPackageRef }));
    expect(store.dispatch).toHaveBeenCalled();
  });
});
