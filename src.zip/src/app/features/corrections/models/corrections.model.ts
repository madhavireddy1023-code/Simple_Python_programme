import {
  CorrectionSelectionRec,
  CorrectionSelectionRecs,
  TypeOfTransactionType,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { Http400Warning } from '@shared/interfaces/http-warning.model';

export interface NewCorrectionSelectionState {
  correctionSelectionResult: CorrectionSelectionRecs;
  isReturnToWorkflowOn: boolean;
  submissionIds: NewSubmssionIdsByPremiumId;
  warningDetails: Http400Warning;
}

export interface InProgressRedirectData {
  submissionId: string;
  bureau: string;
  workflowSubmissionId?: string;
}

export interface CorrectionSelectionRecTableView extends CorrectionSelectionRec {
  settlementCurrencypremiumNet: string;
  transactiontypeKey: TypeOfTransactionType;
  checkboxChecked: boolean;
}
export interface CorrectionSelectionRecsTableView extends Array<CorrectionSelectionRecTableView> {}

export interface QueryParams {
  bureau?: string;
  callback?: string | undefined;
  workflowSubmissionId?: string | undefined;
}

export interface SigningQueryParams {
  queryParams: {
    market_no: string;
    submissionId: string;
  } & QueryParams;
}

export interface SummaryQueryParams {
  queryParams: {
    corrSubmissionId: string;
  } & QueryParams;
}

// Define a union type for the possible return types
export type QueryParamsResult = SigningQueryParams | SummaryQueryParams;

export interface NewSubmssionIdsByPremiumId {
  [key: string]: string;
}
