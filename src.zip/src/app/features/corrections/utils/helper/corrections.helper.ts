import { TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { SUBMISSION_ATTRIBUTE } from '@shared/consts/shared.consts';

export function getBureau(infoHeaderDetails: TechnicianSVDetails): string {
  if (infoHeaderDetails?.submissionAttribute === 'Company') {
    return 'ILU';
  }
  return 'LLOYDS';
}

export function getBureauObj(infoHeaderDetails: TechnicianSVDetails): TechnicianPortalBureauEnum {
  if (infoHeaderDetails?.submissionAttribute === 'Company') {
    return TechnicianPortalBureauEnum.ILU;
  }
  return TechnicianPortalBureauEnum.LLOYDS;
}
