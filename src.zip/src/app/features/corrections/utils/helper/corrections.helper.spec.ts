import { TechnicianPortalBureauEnum, TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { getBureau, getBureauObj } from './corrections.helper';

describe('Corrections Helper', () => {
  it('should return ILU', () => {
    const infoHeaderDetails: TechnicianSVDetails = {
      submissionAttribute: 'Company',
    };
    const expectedResult = 'ILU';
    expect(getBureau(infoHeaderDetails)).toEqual(expectedResult);
  });

  it('should return LLOYDS', () => {
    const infoHeaderDetails: TechnicianSVDetails = {
      submissionAttribute: 'LLOYDS',
    };
    const expectedResult = 'LLOYDS';
    expect(getBureau(infoHeaderDetails)).toEqual(expectedResult);
  });

  it('should return ILU Object', () => {
    const infoHeaderDetails: TechnicianSVDetails = {
      submissionAttribute: 'Company',
    };
    const expectedResult = TechnicianPortalBureauEnum.ILU;
    expect(getBureauObj(infoHeaderDetails)).toEqual(expectedResult);
  });

  it('should return LLOYDS Object', () => {
    const infoHeaderDetails: TechnicianSVDetails = {
      submissionAttribute: 'LLOYDS',
    };
    const expectedResult = TechnicianPortalBureauEnum.LLOYDS;
    expect(getBureauObj(infoHeaderDetails)).toEqual(expectedResult);
  });
});
