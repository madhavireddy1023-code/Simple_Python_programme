import {
  clearAllSelection,
  correctionWorkpackageStatusPatch,
  deleteCollectionSelection,
  domainApiCorrectionSubmissionPost,
  newCorrectionSelectionGet,
  newCorrectionSelectionPost,
  patchStatusBySubmission,
  setCorrectionSelectionPostContent,
  setCorrectionSelectionResult,
  setNewSubmissionIds,
  workpackageSubmissionsCompletePost,
  updateCorrectionSelections,
} from './corrections.action';

describe('Corrections Actions', () => {
  it('should return correct types', () => {
    // set newCorrectionSelectionGet
    expect(newCorrectionSelectionGet.type).toEqual('[CORRECTIONS] GET_CORRECTION_SELECTION');

    // set setCorrectionSelectionResult
    expect(setCorrectionSelectionResult.type).toEqual('[CORRECTIONS] SET_CORRECTION_SELECTION_RESULT');

    // set newCorrectionSelectionPost
    expect(newCorrectionSelectionPost.type).toEqual('[CORRECTIONS] POST_CORRECTION_SELECTION');

    // set CorrectionSelectionPostContent
    expect(setCorrectionSelectionPostContent.type).toEqual('[CORRECTIONS] SET_CORRECTION_SELECTION_POST_CONTENT');

    // set WorkpackageSubmissionsCompletePost
    expect(workpackageSubmissionsCompletePost.type).toEqual(
      '[CORRECTIONS] POST_WORKPACKAGE_SUBMISSION_CORRECTION_SELECTION'
    );

    // set patchCorrectionWorkpackageStatus
    expect(correctionWorkpackageStatusPatch.type).toEqual('[CORRECTIONS] PATCH_WORKPACKAGE_SUBMISSION_COMPLETE');

    // set newSubmissionId
    expect(setNewSubmissionIds.type).toEqual('[CORRECTIONS] SET_NEW_SUBMISSION_ID');

    // set domainApiCorrectionSubmissionPost
    expect(domainApiCorrectionSubmissionPost.type).toEqual('[CORRECTIONS] SET_CORRECTION_SUBMISSION_POST');

    // Patch statusBySubmission api
    expect(patchStatusBySubmission.type).toEqual('[CORRECTIONS] PATCH_STATUS_BY_SUBMISSION');

    // delete correctionSelection api
    expect(deleteCollectionSelection.type).toEqual('[CORRECTIONS] DELETE_COLLECTION_SELECTION');

    // clear all selection
    expect(clearAllSelection.type).toEqual('[CORRECTIONS] CLEAR_ALL_SELECTION');

    expect(updateCorrectionSelections.type).toEqual('[CORRECTIONS] UPDATE_CORRECTION_SELECTIONS');
  });
});
