import {
  CorrectionSelectionPatch,
  CorrectionSelectionRecs,
  CorrectionStatusPatch,
  CorrectionTypeEnum,
  NewCorrectionSelection,
  SubmissionStatuses,
  CorrectionSelectionUpdateRec,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { CorrectionSignings } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { NewSubmssionIdsByPremiumId } from '@features/corrections/models/corrections.model';
import { createAction, props } from '@ngrx/store';
import { Http400Warning } from '@shared/interfaces/http-warning.model';

const CORRECTIONS_PREFIX = '[CORRECTIONS]';

// Get correction selection
const GET_CORRECTION_SELECTION = `${CORRECTIONS_PREFIX} GET_CORRECTION_SELECTION`;
export const newCorrectionSelectionGet = createAction(GET_CORRECTION_SELECTION, props<{ workPackageRef: string }>());

// set correction data in store
const SET_CORRECTION_SELECTION_RESULT = `${CORRECTIONS_PREFIX} SET_CORRECTION_SELECTION_RESULT`;
export const setCorrectionSelectionResult = createAction(
  SET_CORRECTION_SELECTION_RESULT,
  props<{ correctionSelectionResult: CorrectionSelectionRecs }>()
);

// post correction selection
const POST_CORRECTION_SELECTION = `${CORRECTIONS_PREFIX} POST_CORRECTION_SELECTION`;
export const newCorrectionSelectionPost = createAction(
  POST_CORRECTION_SELECTION,
  props<{ correctionSelection: any[]; callback: string; workflowSubmissionId?: string }>()
);

//  Post workpackageSubmissionComplete
const WORKPACKAGE_SUBMISSION_COMPLETE_POST = `${CORRECTIONS_PREFIX} POST_WORKPACKAGE_SUBMISSION_CORRECTION_SELECTION`;
export const workpackageSubmissionsCompletePost = createAction(
  WORKPACKAGE_SUBMISSION_COMPLETE_POST,
  props<{ workPackageRef: string; correctionStatusPatch: CorrectionStatusPatch }>()
);

//  Patch Correction Workpackage Status
const WORKPACKAGE_SUBMISSION_COMPLETE_PATCH = `${CORRECTIONS_PREFIX} PATCH_WORKPACKAGE_SUBMISSION_COMPLETE`;
export const correctionWorkpackageStatusPatch = createAction(
  WORKPACKAGE_SUBMISSION_COMPLETE_PATCH,
  props<{ workPackageRef: string; correctionStatusPatch: CorrectionStatusPatch }>()
);

//  Patch Correction Selection Status and Correction Type
const PATCH_CORRECTION_SELECTION_STATUS_AND_TYPE = `${CORRECTIONS_PREFIX} PATCH_CORRECTION_SELECTION_STATUS_AND_TYPE`;
export const correctionSelectionStatusTypePatch = createAction(
  PATCH_CORRECTION_SELECTION_STATUS_AND_TYPE,
  props<{ etag: string; id: string; correctionSelectionPatch: CorrectionSelectionPatch; workPackageRef: string }>()
);

// Set correction selection content from post response
const SET_CORRECTION_SELECTION_POST_CONTENT = `${CORRECTIONS_PREFIX} SET_CORRECTION_SELECTION_POST_CONTENT`;
export const setCorrectionSelectionPostContent = createAction(
  SET_CORRECTION_SELECTION_POST_CONTENT,
  props<{ content: string }>()
);

// Set correction submission post response
const SET_CORRECTION_SUBMISSION_POST = `${CORRECTIONS_PREFIX} SET_CORRECTION_SUBMISSION_POST`;
export const domainApiCorrectionSubmissionPost = createAction(
  SET_CORRECTION_SUBMISSION_POST,
  props<{
    correctionSignings: CorrectionSignings;
    warningCodeList?: string[];
  }>()
);

// Patch statusBySubmission api
const PATCH_STATUS_BY_SUBMISSION = `${CORRECTIONS_PREFIX} PATCH_STATUS_BY_SUBMISSION`;
export const patchStatusBySubmission = createAction(
  PATCH_STATUS_BY_SUBMISSION,
  props<{
    submissionId: string;
    status: SubmissionStatuses;
    workPackageRef?: string;
  }>()
);

// Delete
// Patch statusBySubmission api
const DELETE_COLLECTION_SELECTION = `${CORRECTIONS_PREFIX} DELETE_COLLECTION_SELECTION`;
export const deleteCollectionSelection = createAction(
  DELETE_COLLECTION_SELECTION,
  props<{ etag: string; id: string; workPackageRef: string }>()
);

// Set Return to WorkFlow
const SET_RETURN_TO_WORKFLOW = `${CORRECTIONS_PREFIX} SET_RETURN_TO_WORKFLOW`;
export const setReturnToWorkflow = createAction(SET_RETURN_TO_WORKFLOW, props<{ isReturnToWorkflowOn: boolean }>());

// Set new submission id
const SET_NEW_SUBMISSION_ID = `${CORRECTIONS_PREFIX} SET_NEW_SUBMISSION_ID`;
export const setNewSubmissionIds = createAction(
  SET_NEW_SUBMISSION_ID,
  props<{ submissionIds: NewSubmssionIdsByPremiumId }>()
);

// Delete
// Clear All
const CLEAR_ALL_SELECTION = `${CORRECTIONS_PREFIX} CLEAR_ALL_SELECTION`;
export const clearAllSelection = createAction(CLEAR_ALL_SELECTION, props<{ workPackageRef: string }>());

// Remove item from store

const DELETE_ITEM_SELECTION = `${CORRECTIONS_PREFIX} DELETE_ITEM_SELECTION`;
export const removeItem = createAction(DELETE_ITEM_SELECTION, props<{ id: string }>());

const UPDATE_CORRECTION_SELECTIONS = `${CORRECTIONS_PREFIX} UPDATE_CORRECTION_SELECTIONS`;
export const updateCorrectionSelections = createAction(
  UPDATE_CORRECTION_SELECTIONS,
  props<{ updateCorrectionSelections: CorrectionSelectionUpdateRec[]; workPackageRef: string }>()
);

const WARNINGS_STATUS = `${CORRECTIONS_PREFIX} SET_WARNINGS`;
export const setWarningDetails = createAction(WARNINGS_STATUS, props<{ warningDetails: Http400Warning }>());
