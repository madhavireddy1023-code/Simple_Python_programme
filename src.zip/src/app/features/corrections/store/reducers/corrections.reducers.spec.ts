import { Action } from '@ngrx/store';
import { CorrectionsReducer, initialState } from './corrections.reducers';
import * as actions from '../actions/corrections.action';
import { mockCorrectionSelectionRecs } from '../../const/corrections-table.consts';
import { CorrectionSelectionRecs } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';

describe('CorrectionsReducers', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = CorrectionsReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should update the state of [correctionSelectionResult]', () => {
    const expectedState: CorrectionSelectionRecs = mockCorrectionSelectionRecs;
    const action = actions.setCorrectionSelectionResult({ correctionSelectionResult: expectedState });
    const newState = CorrectionsReducer(initialState, action);
    expect(newState.correctionSelectionResult).toEqual(expectedState);
  });

  it('should update the state of [isReturnToWorkflowOn]', () => {
    const expectedState = true;
    const action = actions.setReturnToWorkflow({ isReturnToWorkflowOn: expectedState });
    const newState = CorrectionsReducer(initialState, action);
    expect(newState.isReturnToWorkflowOn).toEqual(expectedState);
  });

  it('should update the state of [submissionId]', () => {
    const expectedState = { 123: '123' };
    const action = actions.setNewSubmissionIds({ submissionIds: expectedState });
    const newState = CorrectionsReducer(initialState, action);
    expect(newState.submissionIds).toEqual(expectedState);
  });
});
