import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/corrections.action';
import * as _ from 'lodash';
import { NewCorrectionSelectionState } from '@features/corrections/models/corrections.model';

export const initialState: NewCorrectionSelectionState = {
  correctionSelectionResult: null,
  isReturnToWorkflowOn: false,
  submissionIds: null,
  warningDetails: null,
};

export const CorrectionsReducer: ActionReducer<NewCorrectionSelectionState, Action> = createReducer(
  initialState,

  on(actions.setCorrectionSelectionResult, (state: NewCorrectionSelectionState, action) =>
    _.setWith(_.clone(state), 'correctionSelectionResult', action.correctionSelectionResult, _.clone)
  ),

  on(actions.setReturnToWorkflow, (state: NewCorrectionSelectionState, action) =>
    _.setWith(_.clone(state), 'isReturnToWorkflowOn', action.isReturnToWorkflowOn, _.clone)
  ),

  on(actions.setNewSubmissionIds, (state: NewCorrectionSelectionState, action) =>
    _.setWith(_.clone(state), 'submissionIds', action.submissionIds, _.clone)
  ),

  on(actions.removeItem, (state: NewCorrectionSelectionState, action) =>
    _.setWith(
      _.clone(state),
      'correctionSelectionResult',
      state.correctionSelectionResult.filter((item) => item.id !== action.id),
      _.clone
    )
  ),

  on(actions.setWarningDetails, (state: NewCorrectionSelectionState, { warningDetails }) => ({
    ...state,
    warningDetails,
  }))
);
