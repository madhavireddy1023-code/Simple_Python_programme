import * as selectors from './corrections.selectors';
import { mockCorrectionPost } from '../../const/corrections-table.consts';

describe('CorrectionSelector', () => {
  const state = {
    correctionSelectionResult: mockCorrectionPost,
    isReturnToWorkflowOn: true,
    submissionIds: { 123: '123' },
  };

  it('should select selectCorrectionSelectionResult', () => {
    const expectedData = mockCorrectionPost;
    const selectCorrectionSelectionResult = selectors.selectCorrectionSelectionResult.projector(state);
    expect(selectCorrectionSelectionResult).toEqual(expectedData);
  });

  it('should select isReturnToWorkflowOn', () => {
    const expectedData = true;
    const selectIsReturnToWorkflowOnResult = selectors.selectIsReturnToWorkflowOn.projector(state);
    expect(selectIsReturnToWorkflowOnResult).toEqual(expectedData);
  });

  it('should select selectSubmissionId', () => {
    const expectedData = { 123: '123' };
    const selectSubmissionIdResult = selectors.selectSubmissionIds.projector(state);
    expect(selectSubmissionIdResult).toEqual(expectedData);
  });
});
