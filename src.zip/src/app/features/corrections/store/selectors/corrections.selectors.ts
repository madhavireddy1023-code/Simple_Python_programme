import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.corrections;

// Select correction selection
export const selectCorrectionSelectionResult = createSelector(selectState, (state) => state?.correctionSelectionResult);

// Select is return to work flow on
export const selectIsReturnToWorkflowOn = createSelector(selectState, (state) => state?.isReturnToWorkflowOn);

// Select is new submission Id
export const selectSubmissionIds = createSelector(selectState, (state) => state?.submissionIds);

// Select warning status
export const select400WarningDetails = createSelector(selectState, (state) => state?.warningDetails);
