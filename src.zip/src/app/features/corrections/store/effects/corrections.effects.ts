import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SubmissionIdsAndTransType, SubmissionIdsAndTransTypes } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { CORRECTIONS_URL } from '@shared/consts/shared.consts';
import { Observable, from, of } from 'rxjs';
import { catchError, concatMap, switchMap, mergeMap, tap, delay } from 'rxjs/operators';
import { TechnicianPortalCorrectionService } from 'src/app/api/technician-portal-correction';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import * as actions from '../actions/corrections.action';
import { DomainAPITechnicianPortalWorkpageService } from 'src/app/api/domain-api-technician-portal-workpage';
import { isArray } from 'rxjs/internal-compatibility';
import { ScrollUp, TransactionTypesValues } from 'src/app/utils/helper/helper';
import { TechnicianPortalCorrectionsExperienceService } from 'src/app/api/premium-technician-experience-corrections/premium-technician-experience-corrections.service';
import { CORRECTION_WARNING } from '@features/corrections/const/corrections-table.enum';
import { NewSubmssionIdsByPremiumId } from '@features/corrections/models/corrections.model';

@Injectable()
export class CorrectionsEffects {
  constructor(
    private actions$: Actions,
    private technicianPortalCorrectionService: TechnicianPortalCorrectionService,
    private domainAPITechnicianPortalWorkpageService: DomainAPITechnicianPortalWorkpageService,
    private router: Router,
    private technicianPortalCorrectionsExperienceService: TechnicianPortalCorrectionsExperienceService
  ) {}

  // get selected correction
  newCorrectionSelectionGet$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.newCorrectionSelectionGet),
      switchMap((action) => {
        return this.technicianPortalCorrectionService
          .apiV1CorrectionSelectionsGet(action.workPackageRef, 'response')
          .pipe(
            switchMap((response) => {
              return of(actions.setCorrectionSelectionResult({ correctionSelectionResult: response?.body }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                      isAuthAlert: true,
                      isVisible: false,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  // post selected enquiry to correction
  newCorrectionSelectionPost$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.newCorrectionSelectionPost),
      concatMap((action) => {
        const correctionSelectionPostRes = this.technicianPortalCorrectionsExperienceService
          .apiV1CorrectionSelectionsPost(action.correctionSelection, 'response')
          .pipe(
            concatMap((response) => {
              // TODO: will be fixed the content information when BE complete the content response
              return of(actions.setCorrectionSelectionPostContent({ content: '' }));
            }),
            tap(() => {
              const queryParams = {
                queryParams: {
                  callback: action.callback ? action.callback : undefined,
                  workflowSubmissionId: action.workflowSubmissionId ? action.workflowSubmissionId : undefined,
                },
              };
              this.router.navigate([CORRECTIONS_URL], queryParams);
            }),
            catchError((errorResponse) => {
              ScrollUp(0, 0);
              const errReserr = JSON.parse(errorResponse?.error) || undefined;
              if (errorResponse?.status === 400 && isArray(errReserr)) {
                const errorRes = errReserr?.map((error: any) => {
                  return loadGlobalAlert({
                    response: {
                      errorResponse,
                      responseMessage: error?.detail,
                      status: 400,
                      isGlobalAlert: true,
                      isMultiple: true,
                    },
                  });
                });
                return from([...errorRes]);
              } else {
                return of(loadGlobalAlert({ response: { ...errorResponse, isGlobalAlert: true } }));
              }
            })
          );
        return correctionSelectionPostRes.pipe(mergeMap((errorRes) => of(errorRes).pipe(delay(100))));
      })
    )
  );

  // Post WorkpackageSubmissionsComplete api
  workpackageSubmissionsCompletePost$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.workpackageSubmissionsCompletePost),
      switchMap((action) => {
        return this.domainAPITechnicianPortalWorkpageService
          .apiV2WorkpackageSubmissionsCompletePost(action.workPackageRef, 'response')
          .pipe(
            concatMap(() =>
              of(
                actions.correctionWorkpackageStatusPatch({
                  workPackageRef: action.workPackageRef,
                  correctionStatusPatch: action.correctionStatusPatch,
                })
              )
            ),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  // Patch WorkpackageSubmissionsComplete api
  correctionWorkpackageStatusPatch$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.correctionWorkpackageStatusPatch),
      switchMap((action) => {
        return this.technicianPortalCorrectionService
          .apiV1CorrectionWorkpackageStatusPatch(action.workPackageRef, action.correctionStatusPatch)
          .pipe(
            concatMap(() =>
              of(
                actions.setReturnToWorkflow({ isReturnToWorkflowOn: false }),
                actions.newCorrectionSelectionGet({ workPackageRef: action.workPackageRef })
              )
            ),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  // Patch CorrectionSelectionStatusType api
  correctionSelectionStatusTypePatch$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.correctionSelectionStatusTypePatch),
      mergeMap((action) => {
        return this.technicianPortalCorrectionService
          .apiV1CorrectionSelectionsPatch(action?.etag, action?.id, action?.correctionSelectionPatch, 'response')
          .pipe(
            mergeMap((response) => {
              return of(actions.newCorrectionSelectionGet({ workPackageRef: action.workPackageRef }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  // post CorrectionSubmissionPost api
  domainApiCorrectionSubmissionPost$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.domainApiCorrectionSubmissionPost),
      concatMap((action) => {
        const correctionSubmissionResponse = this.technicianPortalCorrectionsExperienceService
          .apiV1CorrectionSubmissionPost(action.correctionSignings, action.warningCodeList, 'response')
          .pipe(
            concatMap((response) => {
              const submissionIds: NewSubmssionIdsByPremiumId = {};

              response?.body?.forEach(
                (submissionIdsAndTransType: SubmissionIdsAndTransType) =>
                  (submissionIds[submissionIdsAndTransType?.directPremiumId] = submissionIdsAndTransType.submissionId)
              );
              return of(actions.setNewSubmissionIds({ submissionIds }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 400) {
                const errorRes = error?.error?.map((item) => {
                  if (item?.detail?.includes(CORRECTION_WARNING.WARNING)) {
                    return actions.setWarningDetails({
                      warningDetails: {
                        warningStatus: true,
                        warningDetail: item?.detail,
                        warningErrorCode: item?.errorCode,
                      },
                    });
                  }

                  return loadGlobalAlert({
                    response: {
                      error,
                      responseMessage: item?.detail,
                      status: 400,
                      isGlobalAlert: true,
                      isMultiple: true,
                    },
                  });
                });
                return from([...errorRes]);
              } else if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              } else {
                return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
              }
            })
          );

        return correctionSubmissionResponse.pipe(mergeMap((errorRes) => of(errorRes).pipe(delay(50))));
      })
    )
  );

  // patch statusBySubmission api
  patchStatusBySubmission$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.patchStatusBySubmission),
      switchMap((action) => {
        return this.technicianPortalCorrectionService
          .apiV1StatusBySubmissionPatch(action.submissionId, action.status, 'response')
          .pipe(
            concatMap(() =>
              of(
                actions.setCorrectionSelectionPostContent({ content: '' }),
                actions.newCorrectionSelectionGet({ workPackageRef: action.workPackageRef })
              )
            ),
            // switchMap((response) => {
            //   // TODO: will be fixed the content information when BE complete the content response
            //   return of(actions.setCorrectionSelectionPostContent({ content: '' }));
            // }),
            // TODO: will be fixed of(error) when BE complete the content response
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  // delete collection selection api
  deleteCollectionSelection$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.deleteCollectionSelection),
      switchMap((action) => {
        return this.technicianPortalCorrectionService
          .apiV1CorrectionSelectionsDelete(action.id, action.etag, 'response')
          .pipe(
            switchMap((response) => {
              return of(
                actions.newCorrectionSelectionGet({ workPackageRef: action.workPackageRef }),
                actions.removeItem({ id: action.id })
              );
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  clearCollectionSelection$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.clearAllSelection),
      switchMap((action) => {
        return this.technicianPortalCorrectionService
          .apiV1ClearAllSelectionsDelete(action.workPackageRef, 'response')
          .pipe(
            switchMap((response) => {
              return of(actions.newCorrectionSelectionGet({ workPackageRef: action.workPackageRef }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  updateCorrectionSelections$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.updateCorrectionSelections),
      switchMap((action) => {
        return this.technicianPortalCorrectionService
          .apiV1UpdateCorrectionSelectionsPatch(action.updateCorrectionSelections, 'response')
          .pipe(
            switchMap((response) => {
              return of(actions.newCorrectionSelectionGet({ workPackageRef: action.workPackageRef }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 400) {
                const errorRes = error?.error?.map((item) => {
                  if (item?.detail?.includes(CORRECTION_WARNING.WARNING)) {
                    return actions.setWarningDetails({
                      warningDetails: {
                        warningStatus: true,
                        warningDetail: item?.detail,
                        warningErrorCode: item?.errorCode,
                      },
                    });
                  }
                  return loadGlobalAlert({
                    response: {
                      error,
                      responseMessage: item.detail,
                      status: 400,
                      isGlobalAlert: true,
                      isMultiple: true,
                    },
                  });
                });
                return from([...errorRes]);
              } else if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthalert: true,
                      isVisible: true,
                    },
                  })
                );
              } else {
                return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
              }
            })
          );
      })
    )
  );
}
