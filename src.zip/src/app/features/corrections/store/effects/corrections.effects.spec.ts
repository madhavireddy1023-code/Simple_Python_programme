import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CorrectionsEffects } from './corrections.effects';
import { provideMockStore } from '@ngrx/store/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { initialState } from '../reducers/corrections.reducers';
import { Observable, of, throwError } from 'rxjs';
import * as action from '../actions/corrections.action';
import { HttpResponse } from '@angular/common/http';
import { take } from 'rxjs/operators';
import { MainCorrectionsComponent } from '@features/corrections/main/main-corrections.component';
import { TechnicianPortalCorrectionService } from 'src/app/api/technician-portal-correction';
import {
  CorrectionSelectionPatch,
  CorrectionSelectionUpdateRec,
  CorrectionStatusPatch,
  CorrectionTypeEnum,
  SubmissionStatuses,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { DomainAPITechnicianPortalCorrectionService } from 'src/app/api/domain-api-technician-portal-correction';
import { CorrectionSignings, TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { DomainAPITechnicianPortalWorkpageService } from 'src/app/api/domain-api-technician-portal-workpage';
import { TechnicianPortalCorrectionsExperienceService } from 'src/app/api/premium-technician-experience-corrections';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';

describe('CorrectionsEffects', () => {
  let actions$: Observable<any>;
  let effects: CorrectionsEffects;
  let technicianPortalCorrectionsService: jasmine.SpyObj<TechnicianPortalCorrectionService>;
  let domainAPITechnicianPortalWorkpageService: jasmine.SpyObj<DomainAPITechnicianPortalWorkpageService>;
  let domainTechnicianPortalCorrectionService: jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;

  beforeEach(() => {
    const technicianPortalCorrectionsServiceSpy = jasmine.createSpyObj('TechnicianPortalService', [
      'apiV1CorrectionSelectionsGet',
      'apiV1CorrectionSelectionsTextPost',
      'apiV1CorrectionWorkpackageStatusPatch',
      'apiV1CorrectionSelectionsPatch',
      'apiV1StatusBySubmissionPatch',
      'apiV1CorrectionSelectionsDelete',
      'apiV1ClearAllSelectionsDelete',
    ]);

    const domainAPITechnicianPortalWorkpageServiceSpy = jasmine.createSpyObj(
      'DomainAPITechnicianPortalWorkpageService',
      ['apiV2WorkpackageSubmissionsCompletePost']
    );

    const domainAPITechnicianPortalCorrectionServiceSpy = jasmine.createSpyObj(
      'DomainAPITechnicianPortalCorrectionService',
      ['apiV1CorrectionSubmissionPost']
    );

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([{ path: 'corrections', component: MainCorrectionsComponent }]),
      ],
      providers: [
        CorrectionsEffects,
        { provide: TechnicianPortalCorrectionService, useValue: technicianPortalCorrectionsServiceSpy },
        { provide: DomainAPITechnicianPortalWorkpageService, useValue: domainAPITechnicianPortalWorkpageServiceSpy },
        {
          provide: DomainAPITechnicianPortalCorrectionService,
          useValue: domainAPITechnicianPortalCorrectionServiceSpy,
        },
        provideMockStore({ initialState }),
        provideMockActions(() => actions$),
        TechnicianPortalCorrectionsExperienceService,
        Configuration,
      ],
    });
    effects = TestBed.inject(CorrectionsEffects);
    technicianPortalCorrectionsService = TestBed.inject(
      TechnicianPortalCorrectionService
    ) as jasmine.SpyObj<TechnicianPortalCorrectionService>;
    domainAPITechnicianPortalWorkpageService = TestBed.inject(
      DomainAPITechnicianPortalWorkpageService
    ) as jasmine.SpyObj<DomainAPITechnicianPortalWorkpageService>;
    domainTechnicianPortalCorrectionService = TestBed.inject(
      DomainAPITechnicianPortalCorrectionService
    ) as jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;
  });

  it('should test newCorrectionSelectionGet$ effect', () => {
    actions$ = of(action.newCorrectionSelectionGet({ workPackageRef: '123456' }));
    technicianPortalCorrectionsService.apiV1CorrectionSelectionsGet.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.newCorrectionSelectionGet$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setCorrectionSelectionResult.type);
    });
  });

  it('should test newCorrectionSelectionPost$ effect', () => {
    actions$ = of(action.newCorrectionSelectionPost({ correctionSelection: [], callback: '' }));
    technicianPortalCorrectionsService.apiV1CorrectionSelectionsTextPost.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.newCorrectionSelectionPost$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setCorrectionSelectionPostContent.type);
    });
  });

  // Test for error response scenario
  it('should dispatch loadGlobalAlert on error with errorCode 6003', () => {
    actions$ = of(action.newCorrectionSelectionPost({ correctionSelection: [], callback: '' }));
    const mockError = {
      status: 400,
      error: [
        {
          type: 'https://dxc.com/typerror/premium/2470',
          title: 'title example',
          detail: 'Signing already added to work package',
          domain: 'PREMIUM',
          errorCode: 6003,
        },
      ],
    };
    // Mocking the service call to throw an error
    technicianPortalCorrectionsService.apiV1CorrectionSelectionsTextPost.and.returnValue(throwError(mockError));
    effects.newCorrectionSelectionPost$.pipe(take(1)).subscribe((result) => {
      expect(result).toEqual(
        loadGlobalAlert({
          response: {
            error: mockError,
            responseMessage: 'Signing already added to work package',
            status: 400,
            isGlobalAlert: true,
            isMultiple: true,
          },
        })
      );
    });
  });

  it('should dispatch loadGlobalAlert on error with errorCode 6006', () => {
    actions$ = of(action.newCorrectionSelectionPost({ correctionSelection: [], callback: '' }));
    const mockError = {
      status: 400,
      error: [
        {
          type: 'https://dxc.com/typerror/premium/2470',
          title: 'title example',
          detail: 'Endorsement Signing is in progress by user name',
          domain: 'PREMIUM',
          errorCode: 6006,
        },
      ],
    };
    // Mocking the service call to throw an error
    technicianPortalCorrectionsService.apiV1CorrectionSelectionsTextPost.and.returnValue(throwError(mockError));
    effects.newCorrectionSelectionPost$.pipe(take(1)).subscribe((result) => {
      expect(result).toEqual(
        loadGlobalAlert({
          response: {
            error: mockError,
            responseMessage: 'Endorsement Signing is in progress by user name',
            status: 400,
            isGlobalAlert: true,
            isMultiple: true,
          },
        })
      );
    });
  });

  it('should dispatch loadGlobalAlert on error with errorCode 6007', () => {
    actions$ = of(action.newCorrectionSelectionPost({ correctionSelection: [], callback: '' }));
    const mockError = {
      status: 400,
      error: [
        {
          type: 'https://dxc.com/typerror/premium/2470',
          title: 'title example',
          detail: 'Associated Original Signing is being corrected',
          domain: 'PREMIUM',
          errorCode: 6007,
        },
      ],
    };
    // Mocking the service call to throw an error
    technicianPortalCorrectionsService.apiV1CorrectionSelectionsTextPost.and.returnValue(throwError(mockError));
    effects.newCorrectionSelectionPost$.pipe(take(1)).subscribe((result) => {
      expect(result).toEqual(
        loadGlobalAlert({
          response: {
            error: mockError,
            responseMessage: 'Associated Original Signing is being corrected',
            status: 400,
            isGlobalAlert: true,
            isMultiple: true,
          },
        })
      );
    });
  });

  it('should test WorkpackageSubmissionsCompletePost$ effect', () => {
    const correctionStatusPatch: CorrectionStatusPatch = {
      status: SubmissionStatuses.PortalComplete,
    };
    actions$ = of(action.workpackageSubmissionsCompletePost({ workPackageRef: '123456', correctionStatusPatch }));
    domainAPITechnicianPortalWorkpageService.apiV2WorkpackageSubmissionsCompletePost.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.workpackageSubmissionsCompletePost$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.correctionWorkpackageStatusPatch.type);
    });
  });

  it('should test patchCorrectionWorkpackageStatus$ effect', () => {
    const correctionStatusPatch: CorrectionStatusPatch = {
      status: SubmissionStatuses.PortalComplete,
    };
    actions$ = of(action.correctionWorkpackageStatusPatch({ workPackageRef: '123456', correctionStatusPatch }));
    technicianPortalCorrectionsService.apiV1CorrectionWorkpackageStatusPatch.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.correctionWorkpackageStatusPatch$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setReturnToWorkflow.type);
    });
  });

  it('should test correctionSelectionStatusTypePatch$ effect', () => {
    const correctionSelectionPatch: CorrectionSelectionPatch = {
      submissionId: '123',
      correctionType: CorrectionTypeEnum.C,
      status: SubmissionStatuses.InProgress,
    };
    actions$ = of(
      action.correctionSelectionStatusTypePatch({
        etag: '123',
        id: '123',
        correctionSelectionPatch,
        workPackageRef: '234',
      })
    );
    technicianPortalCorrectionsService.apiV1CorrectionSelectionsPatch.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.correctionSelectionStatusTypePatch$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.newCorrectionSelectionGet.type);
    });
  });

  it('should test domainApiCorrectionSubmissionPost$ effect', () => {
    const correctionSignings: CorrectionSignings = {
      premiumSigningList: null,
      correctionType: CorrectionTypeEnum.C,
      workPackageRef: '1231231',
    };
    actions$ = of(action.domainApiCorrectionSubmissionPost({ correctionSignings }));
    domainTechnicianPortalCorrectionService.apiV1CorrectionSubmissionPost.and.returnValue(
      of(
        new HttpResponse({
          status: 200,
          body: [
            {
              submissionId: '123123',
            },
          ],
        })
      )
    );

    effects.domainApiCorrectionSubmissionPost$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setNewSubmissionIds.type);
    });
  });

  it('should test patchStatusBySubmission$ effect', () => {
    actions$ = of(action.patchStatusBySubmission({ submissionId: '123', status: SubmissionStatuses.Signed }));
    technicianPortalCorrectionsService.apiV1StatusBySubmissionPatch.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.patchStatusBySubmission$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setCorrectionSelectionPostContent.type);
    });
  });

  it('should test deleteCorrectionSubmission$ effect', () => {
    actions$ = of(action.deleteCollectionSelection({ id: '123', etag: '123', workPackageRef: '123' }));
    technicianPortalCorrectionsService.apiV1CorrectionSelectionsDelete.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.deleteCollectionSelection$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.newCorrectionSelectionGet.type);
    });
  });

  it('should test deleteCorrectionSubmission$ effect', () => {
    actions$ = of(action.clearAllSelection({ workPackageRef: '123' }));
    technicianPortalCorrectionsService.apiV1ClearAllSelectionsDelete.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.clearCollectionSelection$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.newCorrectionSelectionGet.type);
    });
  });

  it('should dispatch loadGlobalAlert on 400 error', () => {
    const errorsArray = [
      loadGlobalAlert({
        response: { responseMessage: 'Invalid input1', status: 400, isGlobalAlert: true, isMultiple: true },
      }),
      loadGlobalAlert({
        response: { responseMessage: 'Invalid input2', status: 400, isGlobalAlert: true, isMultiple: true },
      }),
    ];
    const expectedResult = errorsArray;

    actions$ = of(action);

    effects.domainApiCorrectionSubmissionPost$.subscribe((result) => {
      expect(result).toEqual(expectedResult);
    });
  });
});
