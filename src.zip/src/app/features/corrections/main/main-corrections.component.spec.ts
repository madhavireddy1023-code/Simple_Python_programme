import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainCorrectionsComponent } from './main-corrections.component';

import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { CorrectionStoreService } from '../services/corrections.store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';

describe('MainCorrectionsComponent', () => {
  let component: MainCorrectionsComponent;
  let fixture: ComponentFixture<MainCorrectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainCorrectionsComponent],
      imports: [TranslateModule.forRoot(), RouterModule.forRoot([]), RouterTestingModule.withRoutes([])],
      providers: [
        MockStore,
        provideMockStore(),
        InfoHeaderStoreService,
        GlobalAlertStoreService,
        CorrectionStoreService,
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainCorrectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
