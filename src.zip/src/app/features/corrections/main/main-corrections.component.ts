import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { CorrectionStoreService } from '../services/corrections.store.service';
import { CorrectionSelectionRecs } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { Http400Warning } from '@shared/interfaces/http-warning.model';
import { NewSubmssionIdsByPremiumId } from '../models/corrections.model';

@Component({
  selector: 'app-main-corrections',
  templateUrl: './main-corrections.component.html',
  styleUrls: ['./main-corrections.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MainCorrectionsComponent implements OnInit {
  isCorrections: boolean;
  queryParams$: Observable<Params>;
  infoHeaderDetails$: Observable<TechnicianSVDetails>;
  responseData$: Observable<any>;
  dataTable$: Observable<CorrectionSelectionRecs>;
  isReturnToWorkflow$: Observable<boolean>;
  newSubmissionIds$: Observable<NewSubmssionIdsByPremiumId>;
  warningStatus$: Observable<Http400Warning>;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private infoHeaderStoreService: InfoHeaderStoreService,
    private globalAlertStoreService: GlobalAlertStoreService,
    private correctionStoreService: CorrectionStoreService
  ) {}

  ngOnInit(): void {
    this.checkCorrectionsUrl();
    this.queryParams$ = this.route.queryParams;
    this.infoHeaderDetails$ = this.infoHeaderStoreService.selectInfoHeaderDetails();
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.dataTable$ = this.correctionStoreService.selectCorrectionSelectionResult();
    this.isReturnToWorkflow$ = this.correctionStoreService.selectIsReturnToWorkOn();
    this.newSubmissionIds$ = this.correctionStoreService.selectSubmissionIds();
    this.warningStatus$ = this.correctionStoreService.selectHttp400WarningDetails();
    this.globalAlertStoreService.clearGlobalResponse();
  }

  checkCorrectionsUrl(): void {
    this.isCorrections = this.router.url.substring(1) === 'corrections' ? true : false;
  }
}
