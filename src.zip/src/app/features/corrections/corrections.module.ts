import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CorrectionsRoutingModule } from './corrections-routing.module';
import { CorrectionsTableComponent } from './components/corrections-table/corrections-table.component';
import { SharedModule } from '@shared/shared.module';
import { TypeOptionsButtonComponent } from './components/type-options-button/type-options-button.component';
import { CorrectionsComponent } from './components/corrections/corrections.component';
import { MainCorrectionsComponent } from './main/main-corrections.component';

@NgModule({
  declarations: [MainCorrectionsComponent, TypeOptionsButtonComponent, CorrectionsComponent, CorrectionsTableComponent],
  imports: [CommonModule, CorrectionsRoutingModule, SharedModule],
})
export class CorrectionsModule {}
