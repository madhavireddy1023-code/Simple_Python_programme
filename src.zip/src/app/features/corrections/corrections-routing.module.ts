import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainCorrectionsComponent } from './main/main-corrections.component';

const routes: Routes = [{ path: '', component: MainCorrectionsComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CorrectionsRoutingModule {}
