import {
  CorrectionSelectionRecs,
  CorrectionTypeEnum,
  NewCorrectionSelection,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { SubmissionStatuses } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

export const CORRECTIONS_TABLE_HEADER = [
  {
    id: 1,
    key: 'transactiontypeKey',
    label: 'CORRECTIONS.TABLE.TRANSACTION_TYPE',
    value: '',
    chip: false,
  },
  {
    id: 2,
    key: 'settlementCurrencypremiumNet',
    label: 'CORRECTIONS.TABLE.SETT',
    value: '',
    chip: false,
  },
  {
    id: 3,
    key: 'bsnd',
    label: 'CORRECTIONS.TABLE.BSND',
    value: '',
    chip: false,
  },
  {
    id: 4,
    key: 'csnd',
    label: 'CORRECTIONS.TABLE.CSND',
    value: '',
    chip: false,
  },

  {
    id: 5,
    key: 'delinkReleased',
    label: 'CORRECTIONS.TABLE.DELINKED_RELEASE',
    value: '',
    chip: false,
  },

  {
    id: 6,
    key: 'status',
    label: 'CORRECTIONS.TABLE.TRANSACTION_STATUS',
    value: '',
    chip: true,
  },
  {
    id: 7,
    key: 'correctionType',
    label: 'CORRECTIONS.TABLE.CORRECTIONS_TYPE',
    value: '',
    chip: true,
  },
];

export const mockCorrectionPost: NewCorrectionSelection[] = [
  {
    premiumid: '510fea6d-92cd-415f-a513-8e9e0c990019',
    umr: 'B1234POL123BB',
    workPackageRef: 'ABCDEF123',
    transactiontype: {
      refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
      typeOfTransactionType: 'Premium',
    },
  },
];

export const mockCorrectionSelectionRecs: CorrectionSelectionRecs = [
  {
    version: 1,
    id: '3ea85f64-5717-4562-b3fc-2c963f66afa6',
    workPackageRef: 'string',
    premiumid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    umr: 'string',
    settlementCurrency: {
      refTypeCurrencyId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfCurrency: 'GBP',
    },
    bureau: 'LLOYDS',
    transactiontype: {
      refTypeOfTransactionTypeId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfTransactionType: 'Premium',
    },
    premiumNet: 0,
    bsnd: 'string',
    csnd: 'string',
    submissionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    correctionType: 'RA',
    delinkReleased: 'string',
    status: 'Draft',
  },
  {
    version: 1,
    id: '3fa85f64-5717-4562-b3fc-2c963f66afa7',
    workPackageRef: 'string',
    premiumid: '3fa85f64-5717-4562-b3fc-2c963f66afa7',
    umr: 'string',
    settlementCurrency: {
      refTypeCurrencyId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfCurrency: 'GBP',
    },
    bureau: 'ILU',
    transactiontype: {
      refTypeOfTransactionTypeId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfTransactionType: 'Premium',
    },
    premiumNet: 0,
    bsnd: 'string',
    csnd: 'string',
    submissionId: '5bb85f64-5717-4562-b3fc-2c963f66afa6',
    correctionType: 'CR',
    delinkReleased: 'string',
    status: 'In Progress',
  },
];

export const CORRECTIONS_TYPE_OPTIONS: { label: string; value: CorrectionTypeEnum }[] = [
  {
    label: 'CORRECTIONS.TYPE_OPTIONS.C_OPTION',
    value: 'C',
  },
  {
    label: 'CORRECTIONS.TYPE_OPTIONS.C&R_OPTION',
    value: 'CR',
  },
  {
    label: 'CORRECTIONS.TYPE_OPTIONS.R&A_OPTION',
    value: 'RA',
  },
];

/**
 * Generate a random premium net value.
 */
const generateRandomPremiumNet = () => (Math.random() * 100000).toFixed(1);

/**
 * Generate a random bsnd value based on the given index.
 */
const generateRandomBsnd = (i) =>
  i % 2 === 0
    ? i > 3
      ? '36926 20112023'
      : `PMX${(Math.random() * 10000000).toFixed(0)}`
    : i > 5
    ? `APX${(Math.random() * 10000000).toFixed(0)}`
    : `RPX${(Math.random() * 10000000).toFixed(0)}`;

/**
 * Generate a random typeOfTransactionType value based on the given index.
 */
const typeOfTransactionType = ['Premium', 'Adjustment AP', 'Adjustment RP', 'Additional Premium (AP)'];

const generateRandomTypeOfTransactionType = (i) =>
  i % 2 === 0
    ? i > 3
      ? typeOfTransactionType[0]
      : typeOfTransactionType[1]
    : i > 5
    ? typeOfTransactionType[2]
    : typeOfTransactionType[3];

/**
 * Generate an array of correction table data.
 */
export const CORRECTIONS_TABLE_DATA = new Array(20).fill(0).map((_, i) => {
  const isEven = i % 2 === 0;
  const isGreaterThanThree = i > 3;

  return {
    version: 1,
    id: i,
    workPackageRef: 'string',
    premiumid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    umr: 'string',
    settlementCurrency: {
      refTypeCurrencyId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfCurrency: isEven ? 'USD' : 'ABC',
    },
    bureau: 'LLOYDS',
    transactiontype: {
      refTypeOfTransactionTypeId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfTransactionType: generateRandomTypeOfTransactionType(i),
    },
    premiumNet: generateRandomPremiumNet(),
    bsnd: generateRandomBsnd(i),
    csnd: generateRandomBsnd(i),
    submissionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    correctionType: isEven ? (isGreaterThanThree ? 'R&A' : 'C only') : 'C&R',
    delinkReleased: isEven ? 'No' : 'Yes',
    status: 'Draft',
  };
});

export const mockData = [
  {
    version: 1,
    id: '5be98218-be57-423f-bd3f-1fb704fef449',
    workPackageRef: 'WP001',
    premiumid: 'PRM001',
    umr: 'UMR001',
    premiumNet: 10000,
    bsnd: 'BSND001',
    csnd: 'CSND001',
    submissionId: 'SUB001',
    delinkReleased: 'N',
    status: SubmissionStatuses.Draft,
  },
  {
    version: 2,
    id: '002',
    workPackageRef: 'WP002',
    premiumid: 'PRM002',
    umr: 'UMR002',
    premiumNet: 5000,
    bsnd: 'BSND002',
    csnd: 'CSND002',
    submissionId: 'SUB002',
    delinkReleased: 'Y',
    status: SubmissionStatuses.PortalComplete,
  },
  {
    version: 3,
    id: '003',
    workPackageRef: 'WP003',
    premiumid: 'PRM003',
    umr: 'UMR003',
    premiumNet: 7500,
    bsnd: 'BSND003',
    csnd: 'CSND003',
    submissionId: 'SUB003',
    delinkReleased: 'N',
    status: SubmissionStatuses.Cancelled,
  },
  {
    version: 4,
    id: '004',
    workPackageRef: 'WP004',
    premiumid: 'PRM004',
    umr: 'UMR004',
    premiumNet: 12000,
    bsnd: 'BSND004',
    csnd: 'CSND004',
    submissionId: 'SUB004',
    delinkReleased: 'Y',
    status: SubmissionStatuses.InProgress,
  },
  {
    version: 5,
    id: '005',
    workPackageRef: 'WP005',
    premiumid: 'PRM005',
    umr: 'UMR005',
    premiumNet: 15000,
    bsnd: 'BSND005',
    csnd: 'CSND005',
    submissionId: 'SUB005',
    delinkReleased: 'N',
    status: SubmissionStatuses.Draft,
  },
];
