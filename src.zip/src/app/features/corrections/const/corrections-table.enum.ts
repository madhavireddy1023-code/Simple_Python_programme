export enum CORRECTION_TYPE_LABEL {
  RA = 'Record and Amend',
  CR = 'Cancel and Replace',
  UWREF = 'Underwriting Reference',
  C = 'Cancel Only',
}

export enum CORRECTION_WARNING {
  WARNING = 'Warning: ',
}
