import { Component, OnInit, ViewEncapsulation, Input, AfterViewInit, ViewChildren, QueryList } from '@angular/core';
import { TableColumn, PaginationModel } from '@shared/models/interfaces';
import * as _ from 'lodash';
import { SORT_TYPES } from '@shared/consts/shared.enums';
import { sortTable } from 'src/app/utils/helper/helper';
import {
  CorrectionSelectionPatch,
  CorrectionSelectionRecs,
  CorrectionTypeEnum,
  SubmissionStatuses,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { DxcCheckboxComponent } from '@dxc-technology/halstack-angular';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { CorrectionStoreService } from '../../services/corrections.store.service';
import { CorrectionSignings, TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { Params, Router } from '@angular/router';
import { getBureau, getBureauObj } from '@features/corrections/utils/helper/corrections.helper';
import {
  InProgressRedirectData,
  NewSubmssionIdsByPremiumId,
  QueryParams,
  QueryParamsResult,
  SigningQueryParams,
  SummaryQueryParams,
} from '@features/corrections/models/corrections.model';
import { Builder } from 'builder-pattern';
import { SIGNING_URL, SUMMARY_URL } from '@shared/consts/shared.consts';
import { CORRECTION_TYPE_LABEL } from '@features/corrections/const/corrections-table.enum';
import { SidePanelStoreService } from '@shared/services/side-panel/side-panel.store.service';
import { Observable } from 'rxjs';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { Http400Warning } from '@shared/interfaces/http-warning.model';

@Component({
  selector: 'app-corrections-table',
  templateUrl: './corrections-table.component.html',
  styleUrls: ['./corrections-table.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CorrectionsTableComponent implements OnInit, AfterViewInit {
  readonly sortTypes = SORT_TYPES;
  readonly submissionStatuses = SubmissionStatuses;
  readonly correctionTypeLabel = CORRECTION_TYPE_LABEL;
  allTableData: any = [];
  currentAscDesc: string;
  currentSortedColumn: string;
  enableSorting = true;
  isColumnIconShown: string[] = [];
  paginatedTableData = [];
  tableColumnsValue: TableColumn[];
  tableDataCopy = [];
  checkedRows = [];
  isChecked = false;
  dataTableRef: CorrectionSelectionRecs;
  newSubmissionIdRef: string;
  inProgressRedirectData: InProgressRedirectData;
  isInDataProgress = false;
  selectAll: boolean;
  draftStatus = [];
  correctionTypeRef: CorrectionTypeEnum;
  workflowSubmissionId: string;
  responseData$: Observable<any>;

  showDialog: boolean;
  rowSelected: any;

  isInProgress: boolean;
  isClearAll: boolean;

  @Input() callback: string;
  @Input() infoHeaderDetails: TechnicianSVDetails;
  @Input() navigateUrl: string;
  @Input() http400Warnings: Http400Warning[] = [];

  @Input() set queryParams(params: Params) {
    if (params) {
      this.callback = params?.callback;
      this.workflowSubmissionId = params?.workflowSubmissionId;
    }
  }

  @Input() set newSubmissionIds(newSubmissionIds: NewSubmssionIdsByPremiumId) {
    if (newSubmissionIds) {
      const correctionSelectionsPatch = this.checkedRows?.map((row) => {
        return {
          premiumId: row?.premiumid,
          status: SubmissionStatuses.InProgress,
          version: row?.version,
          correctionType: this.correctionTypeRef,
          submissionId: newSubmissionIds[row?.premiumid],
        };
      });
      this.correctionStoreService.updateCorrectionSelections(
        correctionSelectionsPatch,
        this.infoHeaderDetails?.workPackageRef
      );
      this.newSubmissionIdRef = this.getFirstSubmissionIdValue(newSubmissionIds);
      this.navigateTo();
    }
  }

  @Input() set dataTable(value: CorrectionSelectionRecs) {
    if (value) {
      this.allTableData = value.map((item) => ({
        ...item,
        settlementCurrencypremiumNet: `${item?.settlementCurrency?.typeOfCurrency} ${item.premiumNet}`,
        transactiontypeKey: item.transactiontype?.typeOfTransactionType,
        checkboxChecked: item.status !== this.submissionStatuses.Draft ? true : false,
        checkboxDisabled: item.status !== this.submissionStatuses.Draft ? true : false,
        isSelected: false,
      }));
      this.tableDataCopy = _.cloneDeep(this.allTableData);
      this.dataTableRef = value;
      this.checkIsDataInProgress();
    }
  }

  @Input() set correctionType(correctionType: CorrectionTypeEnum) {
    if (correctionType) {
      this.correctionTypeRef = correctionType;
      this.checkIsDataInProgress();
    }
  }

  @Input() set tableColumns(tableColumns: TableColumn[]) {
    if (tableColumns) {
      this.tableColumnsValue = tableColumns;
      this.isColumnIconShown = this.tableColumnsValue.map((column) => 'default');
    }
  }

  @ViewChildren('correctionRowCheckbox') correctionRowCheckboxes: QueryList<DxcCheckboxComponent>;

  constructor(
    private router: Router,
    private correctionStoreService: CorrectionStoreService,
    private sidePanelStoreService: SidePanelStoreService,
    private globalAlertStoreService: GlobalAlertStoreService
  ) {}

  ngOnInit(): void {
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.globalAlertStoreService.clearGlobalResponse();
  }

  ngAfterViewInit(): void {
    if (this.tableColumnsValue) {
      this.isColumnIconShown = this.tableColumnsValue.map((column) => 'default');
    }
  }

  getPaginatedItems(event: PaginationModel): void {
    this.paginatedTableData = event.paginatedItems;
    const table = document.getElementById('divTable');
    if (table) {
      table.scrollTop = 0;
    }
  }

  sortByColumn(column: [string, string]): void {
    this.currentSortedColumn = column[0];
    this.currentAscDesc = column[1];

    const sortParams = this.currentAscDesc === SORT_TYPES.DEFAULT ? ['dateCreated', 'asc'] : column;
    this.allTableData = sortTable(sortParams, this.tableDataCopy);
  }

  selectedSortColumn(colName: string, sortType: string, colIndex: number): void {
    const icons = { asc: 'asc', desc: 'desc', default: 'default' };
    this.isColumnIconShown = this.tableColumnsValue?.map(() => icons.default);
    this.isColumnIconShown[colIndex] = icons[sortType];
    this.sortByColumn([colName, sortType]);
  }

  onClickOfCheckBox(value: boolean, id: string, index?: number): void {
    this.allTableData?.filter((data) => data?.id === id).forEach((data) => (data.checkboxChecked = value));
    this.allTableData?.filter((item) => item.id === id).map((item) => (item.isSelected = value));
    this.draftStatus = this.allTableData?.filter((item) => item.status === 'Draft');
    this.selectAll = this.draftStatus?.every((item) => item.isSelected === true);
    this.checkedRows = this.draftStatus?.filter((item) => item.isSelected === true);
    if (this.checkedRows?.length !== 0) {
      this.isChecked = true;
    } else {
      this.isChecked = false;
    }
  }

  checkAllBtns(checked): void {
    this.selectAll = !this.selectAll;
    this.allTableData
      .filter((item) => item.status === 'Draft')
      .map((item) => {
        item.isSelected = checked;
        item.checkboxChecked = checked;
      });
    this.checkedRows = this.allTableData.filter((item) => item.isSelected === true);
    if (this.checkedRows.length !== 0) {
      this.isChecked = true;
    } else {
      this.isChecked = false;
    }
  }

  submitCorrectionsSubmission(): void {
    const payload: CorrectionSignings = this.createCorrectionSignings();
    const http400WarningErrorCodes = this.http400Warnings?.map(
      (http400WarningItem) => http400WarningItem?.warningErrorCode
    );
    this.correctionStoreService.setCorrectionSubmissionPost(
      payload,
      this.http400Warnings ? http400WarningErrorCodes : undefined
    );
  }

  getDataFilter(): CorrectionSelectionRecs {
    return this.dataTableRef.filter(
      (item) =>
        item?.status === SubmissionStatuses.InProgress &&
        item?.submissionId &&
        item?.correctionType === this.correctionTypeRef
    );
  }

  checkIsDataInProgress(): void {
    if (this.dataTableRef) {
      const dataFiltered = this.getDataFilter();

      this.isInDataProgress = false;
      if (dataFiltered.length > 0) {
        this.isInDataProgress = true;
        const firstDataInProgress = dataFiltered.find((element, index) => !index);
        const inProgressRedirectDataBuilder = Builder<InProgressRedirectData>();
        inProgressRedirectDataBuilder
          .submissionId(firstDataInProgress?.submissionId)
          .bureau(firstDataInProgress?.bureau);
        this.inProgressRedirectData = inProgressRedirectDataBuilder.build();
      }
    }
  }

  onInProgressClick(): void {
    const dataFiltered = this.getDataFilter();

    if (dataFiltered.length === 0 || !this.dataTableRef) {
      return;
    }

    const firstDataInTable = dataFiltered[0];
    const isCorrectionTypeC = firstDataInTable.correctionType === CorrectionTypeEnum.C;
    this.newSubmissionIdRef = firstDataInTable?.submissionId;
    const queryParams = {
      queryParams: {
        market_no: isCorrectionTypeC ? '0' : null,
        submissionId: isCorrectionTypeC ? this.inProgressRedirectData.submissionId : null,
        bureau: this.inProgressRedirectData.bureau
          ? this.inProgressRedirectData.bureau
          : getBureau(this.infoHeaderDetails),
        callback: this.callback ?? null,
        corrSubmissionId: isCorrectionTypeC ? null : this.newSubmissionIdRef,
        workflowSubmissionId: this.workflowSubmissionId ? this.workflowSubmissionId : undefined,
      },
    };

    const navigateUrl = isCorrectionTypeC ? SIGNING_URL : SUMMARY_URL;

    this.router.navigate([navigateUrl], queryParams);
  }

  onDeleteClick(data: any): void {
    this.showDialog = true;
    this.rowSelected = data;
    if (this.rowSelected.status === SubmissionStatuses.InProgress) {
      this.isInProgress = true;
    }
  }

  deleteRowPrompt(data: any): void {
    if (data.status === SubmissionStatuses.Draft) {
      this.correctionStoreService.deleteCorrectionSubmission(
        data?.version?.toString(),
        data?.id,
        this.infoHeaderDetails?.workPackageRef
      );
    }
  }

  clearAll(): void {
    this.isClearAll = true;
    this.showDialog = true;
  }

  yesClicked(): void {
    if (this.isClearAll !== true) {
      this.deleteRowPrompt(this.rowSelected);
    } else {
      this.correctionStoreService.clearAllSelection(this.infoHeaderDetails?.workPackageRef);
    }
    this.resetPromptBehavior();
  }

  noClicked(): void {
    this.resetPromptBehavior();
  }

  resetPromptBehavior(): void {
    this.showDialog = false;
    this.isInProgress = false;
    this.isClearAll = false;
    this.rowSelected = {};
  }

  removeItemFromStore(id: string): void {
    this.correctionStoreService.removeItemFromStore(id);
  }

  isDeleteButtonDisabled(draftStatus: SubmissionStatuses): boolean {
    if (this.getDisableDeleteButtonStatus().includes(draftStatus)) {
      return true;
    }

    // default enable delete button
    return false;
  }

  navigateTo(): void {
    this.sidePanelStoreService.getSidePanelDataItem(this.newSubmissionIdRef);
    this.router.navigate([this.navigateUrl], this.buildQueryParams(this.correctionTypeRef));
  }

  buildQueryParams(correctionType: CorrectionTypeEnum): QueryParamsResult {
    const bureau = this.getSelectedFirstBureau();

    const queryParams: QueryParams = {
      bureau: bureau ? bureau : getBureau(this.infoHeaderDetails),
      callback: this.callback ? this.callback : undefined,
      workflowSubmissionId: this.workflowSubmissionId ? this.workflowSubmissionId : undefined,
    };

    const signingQueryParams: SigningQueryParams = {
      queryParams: {
        market_no: '0',
        submissionId: this.newSubmissionIdRef,
        ...queryParams,
        bureau: bureau ? bureau : getBureau(this.infoHeaderDetails),
        callback: this.callback ? this.callback : undefined,
      },
    };

    const summaryQueryParams: SummaryQueryParams = {
      queryParams: {
        ...queryParams,
        corrSubmissionId: this.newSubmissionIdRef,
      },
    };

    return correctionType === CorrectionTypeEnum.C ? signingQueryParams : summaryQueryParams;
  }

  private createCorrectionSignings(): CorrectionSignings {
    const bureau = this.getSelectedFirstBureau();
    return {
      premiumSigningList: this.checkedRows?.map((row) => ({
        premiumId: row?.premiumid,
        transactionType: row?.transactiontype,
        bureau: row?.bureau,
      })),
      correctionType: this.correctionTypeRef,
      // TODO: will work when
      // grossAmount: 2,
      // replacementDelinkIndicator: 'Cash',

      highValuePremium: this.infoHeaderDetails?.highValuePremium,
      brokerPseudonym: this.infoHeaderDetails?.brokerPseudonym,
      contractClassification: this.infoHeaderDetails?.slipType,
      brokerEmail: this.infoHeaderDetails?.brokerEmail,
      brokerName: this.infoHeaderDetails?.brokerName,
      brokerNumber: this.infoHeaderDetails?.brokerNumber,
      workPackageRef: this.infoHeaderDetails?.workPackageRef,
      brokerPhone: this.infoHeaderDetails?.brokerPhone,
      classOfBusiness: this.infoHeaderDetails?.classOfBusiness,
      umr: this.infoHeaderDetails?.umr,
      workflowSubmissionId: this.infoHeaderDetails?.workflowSubmissionId,
    };
  }

  private getSelectedFirstBureau(): TechnicianPortalBureauEnum {
    return this.checkedRows?.find((element, i) => !i)?.bureau;
  }

  private getDisableDeleteButtonStatus(): SubmissionStatuses[] {
    return [
      SubmissionStatuses.Cancelled,
      SubmissionStatuses.PortalComplete,
      SubmissionStatuses.Signed,
      SubmissionStatuses.WorkpackageComplete,
    ];
  }

  private getFirstSubmissionIdValue(data: NewSubmssionIdsByPremiumId): any {
    const keys = Object.keys(data);
    return keys.length > 0 ? data[keys[0]] : null;
  }
}
