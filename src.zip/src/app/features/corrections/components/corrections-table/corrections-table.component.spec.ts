import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { CorrectionsTableComponent } from './corrections-table.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  CORRECTIONS_TABLE_DATA,
  CORRECTIONS_TABLE_HEADER,
  mockCorrectionSelectionRecs,
} from '@features/corrections/const/corrections-table.consts';
import { SORT_TYPES } from '@shared/consts/shared.enums';
import { Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { InProgressRedirectData } from '@features/corrections/models/corrections.model';
import * as _ from 'lodash';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CorrectionStoreService } from '@features/corrections/services/corrections.store.service';
import { CorrectionTypeEnum, SubmissionStatuses } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { PaginationModel } from '@shared/models/interfaces';
import { SidePanelStoreService } from '@shared/services/side-panel/side-panel.store.service';

describe('CorrectionsTableComponent', () => {
  let component: CorrectionsTableComponent;
  let fixture: ComponentFixture<CorrectionsTableComponent>;
  let correctionStoreService: CorrectionStoreService;
  let sidePanelStoreService: SidePanelStoreService;
  const router = {
    navigate: jasmine.createSpy('navigate'),
  };

  let correctionStoreServiceMock: jasmine.SpyObj<CorrectionStoreService>;

  beforeEach(async () => {
    correctionStoreServiceMock = jasmine.createSpyObj('CorrectionStoreService', ['deleteCorrectionSubmission']);

    await TestBed.configureTestingModule({
      declarations: [CorrectionsTableComponent],
      imports: [TranslateModule.forRoot(), RouterModule.forRoot([]), RouterTestingModule.withRoutes([])],
      providers: [
        MockStore,
        provideMockStore(),
        { provide: CorrectionStoreService, useValue: correctionStoreServiceMock },

        CorrectionStoreService,
        { provide: Router, useValue: router },
        SidePanelStoreService,
      ],
    }).compileComponents();
    correctionStoreService = TestBed.inject(CorrectionStoreService) as jasmine.SpyObj<CorrectionStoreService>;

    sidePanelStoreService = TestBed.inject(SidePanelStoreService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CorrectionsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should render section details in the Corrections data ', waitForAsync(() => {
    const dataTableSpay = CORRECTIONS_TABLE_DATA;
    component.paginatedTableData = dataTableSpay;
    fixture.detectChanges();
    expect(component.paginatedTableData).toEqual(dataTableSpay);
  }));

  it('should set currentSortedColumn and currentAscDesc when sortByColumn is called with SORT_TYPES.DEFAULT', () => {
    component.sortByColumn(['someColumn', SORT_TYPES.DEFAULT]);

    expect(component.currentSortedColumn).toEqual('someColumn');
    expect(component.currentAscDesc).toEqual(SORT_TYPES.DEFAULT);
  });

  it('should update allTableData when sortByColumn is called with a non-default column', () => {
    const initialTableData: Array<any> = CORRECTIONS_TABLE_DATA;
    component.tableDataCopy = initialTableData;
    component.allTableData = initialTableData;
    component.tableColumnsValue = CORRECTIONS_TABLE_HEADER;
    component.selectedSortColumn('123', '123', 1);
    component.sortByColumn(['someColumn', SORT_TYPES.ASC]);

    expect(component.allTableData).toEqual(initialTableData);
  });

  it('should isInDataProgress be true and data mapped correctly when checkIsDataInProgress triggered with In Progress data', () => {
    component.dataTable = mockCorrectionSelectionRecs;
    component.correctionType = CorrectionTypeEnum.CR;
    const expected: InProgressRedirectData = {
      submissionId: '5bb85f64-5717-4562-b3fc-2c963f66afa6',
      bureau: 'ILU',
    };
    component.checkIsDataInProgress();
    expect(component.isInDataProgress).toBeTruthy();
    expect(component.inProgressRedirectData).toEqual(expected);
  });

  it('should isInDataProgress be false when checkIsDataInProgress triggered without In Progress data', () => {
    const mockData = _.cloneDeep(mockCorrectionSelectionRecs);
    mockData[1].status = 'Draft';
    component.dataTable = mockData;
    component.checkIsDataInProgress();
    expect(component.isInDataProgress).toBeFalsy();
    expect(component.inProgressRedirectData).not.toBeDefined();
  });

  it('should isInDataProgress be false when checkIsDataInProgress triggered with In Progress data but no submissionId existing', () => {
    const mockData = _.cloneDeep(mockCorrectionSelectionRecs);
    mockData[1].submissionId = undefined;
    component.dataTable = mockData;
    component.checkIsDataInProgress();
    expect(component.isInDataProgress).toBeFalsy();
    expect(component.inProgressRedirectData).not.toBeDefined();
  });

  it('should signing-detail be call when onInProgressClick clicked', () => {
    component.dataTable = mockCorrectionSelectionRecs;
    component.correctionType = CorrectionTypeEnum.CR;
    component.checkIsDataInProgress();
    component.onInProgressClick();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('should submissionRef be set', () => {
    const expected = '123123';
    const checkedRows = [
      {
        submissionId: expected,
        correctionType: CorrectionTypeEnum.C,
        status: SubmissionStatuses.InProgress,
      },
    ];
    component.infoHeaderDetails = {
      workPackageRef: '123',
    };
    spyOn(correctionStoreService, 'updateCorrectionSelection');
    component.checkedRows = checkedRows;
    component.newSubmissionIds = { 123123: '123123' };
    expect(component.newSubmissionIdRef).toEqual(expected);
  });

  it('should submissionRef be set', () => {
    const expected = '123123';
    const checkedRows = [
      {
        submissionId: expected,
        correctionType: CorrectionTypeEnum.C,
        status: SubmissionStatuses.InProgress,
      },
    ];
    component.infoHeaderDetails = {
      workPackageRef: '123',
    };
    spyOn(correctionStoreService, 'updateCorrectionSelection');
    component.checkedRows = checkedRows;
    component.newSubmissionIds = { 123123: '123123' };
    expect(component.newSubmissionIdRef).toEqual(expected);
  });

  it('should tableColumnsValue be set', () => {
    const expected = CORRECTIONS_TABLE_HEADER;
    component.tableColumns = expected;
    expect(component.tableColumnsValue).toEqual(expected);
  });

  it('should paginatedTableData be set', () => {
    const expected: PaginationModel = {
      paginatedItems: [
        {
          field: '123',
        },
      ],
    };
    component.getPaginatedItems(expected);
    expect(component.paginatedTableData).toEqual(expected.paginatedItems);
  });

  it('should isChecked be false', () => {
    component.allTableData = mockCorrectionSelectionRecs;
    component.onClickOfCheckBox(false, '3ea85f64-5717-4562-b3fc-2c963f66afa6');
    expect(component.isChecked).toBeFalsy();
  });

  it('should isChecked be true', () => {
    component.allTableData = mockCorrectionSelectionRecs;
    component.onClickOfCheckBox(true, '3ea85f64-5717-4562-b3fc-2c963f66afa6');
    expect(component.isChecked).toBeTruthy();
  });

  it('should isChecked be false when checkAllBtns is false', () => {
    component.allTableData = mockCorrectionSelectionRecs;
    component.checkAllBtns(false);
    expect(component.isChecked).toBeFalsy();
  });

  it('should isChecked be true when checkAllBtns is true', () => {
    component.allTableData = mockCorrectionSelectionRecs;
    component.checkAllBtns(true);
    expect(component.isChecked).toBeTruthy();
  });

  it('should setCorrectionSubmissionPost be called', () => {
    spyOn(correctionStoreService, 'setCorrectionSubmissionPost');
    component.submitCorrectionsSubmission();
    expect(correctionStoreService.setCorrectionSubmissionPost).toHaveBeenCalled();
  });

  it('should navigate be call', () => {
    spyOn(sidePanelStoreService, 'getSidePanelDataItem');
    component.navigateTo();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('should queryParamResult return', () => {
    const expected = {
      queryParams: {
        market_no: '0',
        submissionId: undefined,
        bureau: 'ILU',
        callback: undefined,
        workflowSubmissionId: undefined,
      },
    };
    component.checkedRows = [
      {
        bureau: 'ILU',
      },
    ];
    const result = component.buildQueryParams(CorrectionTypeEnum.C);

    expect(result).toEqual(expected);
  });

  it('should return true when status is Cancelled', () => {
    const result = component.isDeleteButtonDisabled(SubmissionStatuses.Cancelled);
    expect(result).toBe(true);
  });

  it('should return true when status is PortalComplete', () => {
    const result = component.isDeleteButtonDisabled(SubmissionStatuses.PortalComplete);
    expect(result).toBe(true);
  });

  it('should return true when status is Signed', () => {
    const result = component.isDeleteButtonDisabled(SubmissionStatuses.Signed);
    expect(result).toBe(true);
  });

  it('should return true when status is WorkpackageComplete', () => {
    const result = component.isDeleteButtonDisabled(SubmissionStatuses.WorkpackageComplete);
    expect(result).toBe(true);
  });

  it('should return false when status is Draft', () => {
    const result = component.isDeleteButtonDisabled(SubmissionStatuses.Draft);
    expect(result).toBe(false);
  });

  it('should reset showDialog to false', () => {
    component.showDialog = true;
    component.resetPromptBehavior();
    expect(component.showDialog).toBe(false);
  });

  it('should reset isInProgress to false', () => {
    component.isInProgress = true;
    component.resetPromptBehavior();
    expect(component.isInProgress).toBe(false);
  });

  it('should reset isClearAll to false', () => {
    component.isClearAll = true;
    component.resetPromptBehavior();
    expect(component.isClearAll).toBe(false);
  });

  it('should reset rowSelected to an empty object', () => {
    component.rowSelected = { someKey: 'someValue' };
    component.resetPromptBehavior();
    expect(component.rowSelected).toEqual({});
  });

  it('should call deleteCorrectionSubmission when data status is Draft', () => {
    const correctionSpy = spyOn(correctionStoreService, 'deleteCorrectionSubmission');

    const data = {
      status: SubmissionStatuses.Draft,
      workPackageRef: 'WP123',
      version: 1,
      id: '123',
    };
    component.infoHeaderDetails = { workPackageRef: 'WP123' };

    component.deleteRowPrompt(data);

    expect(correctionSpy).toHaveBeenCalledWith('1', '123', 'WP123');
  });

  it('should not call deleteCorrectionSubmission when data status is not Draft', () => {
    const data = {
      status: SubmissionStatuses.InProgress,
      version: 1,
      id: '123',
    };

    component.deleteRowPrompt(data);

    expect(correctionStoreServiceMock.deleteCorrectionSubmission).not.toHaveBeenCalled();
  });

  it('should set showDialog to true', () => {
    const data = { status: SubmissionStatuses.Draft };

    component.onDeleteClick(data);

    expect(component.showDialog).toBe(true);
  });

  it('should set rowSelected to the passed data', () => {
    const data = { status: SubmissionStatuses.Draft };

    component.onDeleteClick(data);

    expect(component.rowSelected).toBe(data);
  });

  it('should set isInProgress to true if status is InProgress', () => {
    const data = { status: SubmissionStatuses.InProgress };

    component.onDeleteClick(data);

    expect(component.isInProgress).toBe(true);
  });

  it('should set isClearAll to true', () => {
    component.clearAll();

    expect(component.isClearAll).toBe(true);
  });

  it('should set showDialog to true', () => {
    component.clearAll();

    expect(component.showDialog).toBe(true);
  });

  it('should call resetPromptBehavior when noClicked is called', () => {
    spyOn(component, 'resetPromptBehavior');

    component.noClicked();

    expect(component.resetPromptBehavior).toHaveBeenCalled();
  });
});
