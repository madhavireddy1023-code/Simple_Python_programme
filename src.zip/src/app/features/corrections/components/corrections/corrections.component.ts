import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { CORRECTIONS_TABLE_HEADER } from '@features/corrections/const/corrections-table.consts';
import { TableColumn } from '@shared/models/interfaces';
import { ENQUIRY_URL, SIGNING_URL, SUMMARY_URL } from '@shared/consts/shared.consts';
import { Params, Router } from '@angular/router';
import { CorrectionStoreService } from '@features/corrections/services/corrections.store.service';
import {
  CorrectionSelectionRecs,
  CorrectionTypeEnum,
  SubmissionStatuses,
} from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { InProgressRedirectData, NewSubmssionIdsByPremiumId } from '@features/corrections/models/corrections.model';
import { TechnicianPortalIcosService } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { Http400Warning } from '@shared/interfaces/http-warning.model';
import { CorrectionsTableComponent } from '../corrections-table/corrections-table.component';

@Component({
  selector: 'app-corrections',
  templateUrl: './corrections.component.html',
  styleUrls: ['./corrections.component.scss'],
})
export class CorrectionsComponent implements OnInit {
  tableColumns: TableColumn[];
  callback: string;
  isInDataProgress = false;
  workPackageRef: string;
  inProgressRedirectData: InProgressRedirectData;
  dataTableRef: CorrectionSelectionRecs;
  isReturnToWorkflowRef = false;
  isWorkflowOn = true;
  infoHeaderDetailsSubmission: TechnicianSVDetails;
  correctionType: CorrectionTypeEnum;
  workflowSubmissionId: string;
  queryParamsRef: Params;
  errorBanner = false;
  errorMsg: string;
  isExistingCorrectionWarning: boolean;
  http400Warnings: Http400Warning[] = [];

  @Input() isCorrections = false;
  @Input() newSubmissionIds: NewSubmssionIdsByPremiumId;

  @Input() set warningStatus(warningStatus: Http400Warning) {
    if (warningStatus) {
      this.isExistingCorrectionWarning = warningStatus.warningStatus;
      if (this.isExistingCorrectionWarning) {
        this.http400Warnings.push(warningStatus);
      }
    }
  }

  @Input() set queryParams(params: Params) {
    if (params) {
      this.queryParamsRef = params;
      this.callback = params?.callback;
      this.workflowSubmissionId = params?.workflowSubmissionId;
    }
  }

  @Input() set infoHeaderDetails(infoHeaderDetails: TechnicianSVDetails) {
    if (infoHeaderDetails) {
      this.infoHeaderDetailsSubmission = infoHeaderDetails;
      this.workPackageRef = infoHeaderDetails.workPackageRef;
      this.correctionStoreService.newCorrectionSelectionGet(this.workPackageRef);
    }
  }

  @Input() set dataTable(data: CorrectionSelectionRecs) {
    if (data) {
      this.dataTableRef = data;
      // TODO: will uncomment when update signed status to correction table ready
      // this.checkIsDataSigned();
    }
  }

  @Input() set isReturnToWorkflow(isReturnToWorkflowOn: boolean) {
    this.isReturnToWorkflowRef = false;
    if (isReturnToWorkflowOn) {
      this.isReturnToWorkflowRef = isReturnToWorkflowOn;
    }
  }

  @ViewChild(CorrectionsTableComponent) correctionsTableComponent: CorrectionsTableComponent;

  constructor(private router: Router, private correctionStoreService: CorrectionStoreService) {}

  ngOnInit(): void {
    this.isExistingCorrectionWarning = false;
    this.tableColumns = CORRECTIONS_TABLE_HEADER;
  }

  moveToEnquiryPage(): void {
    const queryParams = {
      queryParams: {
        callback: this.callback ? this.callback : undefined,
        isfromCorrection: true,
        workflowSubmissionId: this.workflowSubmissionId ? this.workflowSubmissionId : undefined,
      },
    };
    this.router.navigate([ENQUIRY_URL], queryParams);
    this.isExistingCorrectionWarning = false;
  }

  onWorkpackageCompleteClick(): void {
    const isRecordbyShowErrorStatus = this.dataTableRef?.filter(
      (item) => item.status === 'In Progress' || item.status === 'Draft'
    );
    if (isRecordbyShowErrorStatus?.length > 0) {
      this.errorBanner = true;
      this.errorMsg = 'CORRECTIONS.ERROR_MSG';
    } else {
      this.errorBanner = false;
      this.correctionStoreService.workpackageSubmissionsCompletePost(this.workPackageRef);
    }
  }

  onReturnToWorkflowClick(): void {
    if (this.callback) {
      window.location.href = this.callback;
    }
  }

  checkIsDataSigned(): void {
    if (this.dataTableRef) {
      this.dataTableRef.filter((item) => item?.status === SubmissionStatuses.Signed).length > 0
        ? (this.isWorkflowOn = true)
        : (this.isWorkflowOn = false);
    }
  }

  selectedTypeOptionValue(type: CorrectionTypeEnum): void {
    this.correctionType = type;
  }

  getNavigateUrl(): string {
    return this.correctionType === CorrectionTypeEnum.C ? SIGNING_URL : SUMMARY_URL;
  }

  closeExistingCorrectionWarning(proceed = false): void {
    this.isExistingCorrectionWarning = false;
    if (proceed) {
      this.http400Warnings = [];
      this.correctionsTableComponent.submitCorrectionsSubmission();
      this.correctionStoreService.setWarningStatus({});
    } else {
      this.http400Warnings = [];
      this.correctionStoreService.setWarningStatus({});
    }
  }
}
