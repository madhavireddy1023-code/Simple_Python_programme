import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TranslateModule } from '@ngx-translate/core';
import { CorrectionsComponent } from './corrections.component';

import { Params, Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { CorrectionStoreService } from '@features/corrections/services/corrections.store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { mockCorrectionSelectionRecs } from '@features/corrections/const/corrections-table.consts';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { CorrectionTypeEnum } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';

describe('CorrectionsComponent', () => {
  let component: CorrectionsComponent;
  let fixture: ComponentFixture<CorrectionsComponent>;
  const router = {
    navigate: jasmine.createSpy('navigate'),
  };
  let correctionStoreService: CorrectionStoreService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CorrectionsComponent],
      imports: [TranslateModule.forRoot(), RouterModule.forRoot([]), RouterTestingModule.withRoutes([])],
      providers: [MockStore, provideMockStore(), CorrectionStoreService, { provide: Router, useValue: router }],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CorrectionsComponent);
    correctionStoreService = TestBed.inject(CorrectionStoreService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be false of isReturnToWorkflow and workpackageSubmissionsCompletePost when onWorkpackageCompleteClick triggered', () => {
    spyOn(correctionStoreService, 'workpackageSubmissionsCompletePost');
    component.onWorkpackageCompleteClick();
    expect(correctionStoreService.workpackageSubmissionsCompletePost).toHaveBeenCalled();
  });

  it('should show error banner if status is In Progress or Draft in corrections table', () => {
    component.dataTable = mockCorrectionSelectionRecs;
    component.onWorkpackageCompleteClick();
    expect(component.errorBanner).toBeTruthy();
  });

  it('should be false of isWorkflowOn when checkIsDataSigned without Signed Data', () => {
    component.dataTable = mockCorrectionSelectionRecs;
    component.checkIsDataSigned();
    expect(component.isWorkflowOn).toBeFalsy();
  });

  it('should be callback set', () => {
    const params: Params = {
      callback: '123',
    };
    const expected = '123';
    component.queryParams = params;
    expect(component.callback).toEqual(expected);
  });

  it('should be workPackageRef set', () => {
    const infoHeaderDetails: TechnicianSVDetails = {
      workPackageRef: '123',
    };
    spyOn(correctionStoreService, 'newCorrectionSelectionGet');
    component.infoHeaderDetails = infoHeaderDetails;
    const expected = '123';
    expect(component.workPackageRef).toEqual(expected);
  });

  it('should be navigate called when moveToEnquiryPage invoked', () => {
    component.moveToEnquiryPage();
    component.onReturnToWorkflowClick();
    expect(router.navigate).toHaveBeenCalled();
  });

  it('should corrtionType change to C', () => {
    component.selectedTypeOptionValue(CorrectionTypeEnum.C);
    expect(component.correctionType).toEqual(CorrectionTypeEnum.C);
  });

  it('should isReturnToWorkflowRef be true', () => {
    component.isReturnToWorkflow = true;
    expect(component.isReturnToWorkflowRef).toBeTruthy();
  });
});
