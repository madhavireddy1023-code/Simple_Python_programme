import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CorrectionTypeEnum } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { CORRECTIONS_TYPE_OPTIONS } from '@features/corrections/const/corrections-table.consts';

@Component({
  selector: 'app-type-options-button',
  templateUrl: './type-options-button.component.html',
  styleUrls: ['./type-options-button.component.scss'],
})
export class TypeOptionsButtonComponent implements OnInit {
  TypeOptions: { label: string; value: CorrectionTypeEnum }[];
  selectedOption: CorrectionTypeEnum;
  @Output() emitTypeOptionsValue = new EventEmitter<CorrectionTypeEnum>();

  constructor() {}

  ngOnInit(): void {
    this.TypeOptions = CORRECTIONS_TYPE_OPTIONS;
    this.selectedOption = this.TypeOptions[0].value; // Set a default selected option
    this.emitTypeOptionsValue.emit(this.selectedOption);
  }

  onRadioButtonChange(option: { label: string; value: CorrectionTypeEnum }): void {
    this.selectedOption = option.value;
    this.emitTypeOptionsValue.emit(this.selectedOption);
  }
}
