import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TypeOptionsButtonComponent } from './type-options-button.component';
import { TranslateModule } from '@ngx-translate/core';
import { CorrectionTypeEnum } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';

describe('TypeOptionsButtonComponent', () => {
  let component: TypeOptionsButtonComponent;
  let fixture: ComponentFixture<TypeOptionsButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TypeOptionsButtonComponent],
      imports: [TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeOptionsButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should selectedOption be C', () => {
    component.onRadioButtonChange({
      label: 'C',
      value: CorrectionTypeEnum.C,
    });
    expect(component.selectedOption).toBe('C');
  });
});
