import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketDetailsComponent } from './market-details.component';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { MarketDetailsStoreService } from '@features/market-details/services/market-details.store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { marketId, sectionShowAtLevel } from '@features/market-details/consts/market-details.consts';
import {
  CSND,
  ENQUIRY_SUBMISSION_ID,
  MARKET_URL,
  PREMIUM_ID,
  PREMIUM_URL,
  STATUS_SECTION_NO,
  SUBMISSION_ID,
  SUBMIT_TYPES,
} from '@shared/consts/shared.consts';
import { SummaryStoreService } from '@features/summary/services/summary.store.service';
import { mockPremiumData, mockSectionDetail } from '@features/section-details/consts/mock-premium-details.consts';
import {
  CorrectionTypeEnum,
  MarketRecord,
  TechnicianPortalBureauEnum,
  TypeOfPremium,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { SidePanelStoreService } from '@shared/services/side-panel/side-panel.store.service';
import { PREMIUM_SCREEN_VIEW } from '@features/section-details/consts/section-details.consts';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { of } from 'rxjs';
import { Router, RouterModule } from '@angular/router';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { UserInfoService } from '@shared/services/user-info/user-info.service';
import { mockSummaryData } from '@features/summary/consts/mock-summary-details.consts';
import { mockInfoHeaderData } from '@features/signing-details/consts/mock-signing-details.const';
import { AlertWithLinkComponent } from '@shared/components/alert-with-link/alert-with-link.component';
import { MultiMsgAlertService } from '@shared/services/multi-msg-alert/multi-msg-alert.service';
import { MarketDetailsBusinessRulesService } from '@features/market-details/services/market-details-business-rules.service';
import { SortPipe } from '@shared/pipes/sort.pipe';
import { mockSectionData } from '@features/section-details/consts/mock-section-details.consts';
import { mockMarketData, mockMarketDataSyndicates } from '@features/market-details/consts/mock-market-details.consts';

describe('MarketDetailsComponent', () => {
  let component: MarketDetailsComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<MarketDetailsComponent>;
  let formBuilder: FormBuilder;
  let sectionDetailsStoreService: SectionDetailsStoreService;
  let marketDetailsStoreService: MarketDetailsStoreService;
  let summaryStoreService: SummaryStoreService;
  let userInfoMock: any;
  let marketDetailsBusinessRulesService: MarketDetailsBusinessRulesService;
  let translateService: TranslateService;
  let multiMsgAlertService: MultiMsgAlertService;

  const router = {
    navigate: jasmine.createSpy('navigate'),
    navigateByUrl: jasmine.createSpy('navigateByUrl'),
  };

  // Mock services
  const marketDetailsBusinessRulesMock = {
    validationErrors$: of([]),
    validate: jasmine.createSpy('validate').and.returnValue([]),
  };

  const multiMsgAlertServiceMock = {
    buildMultiMsgAlert: jasmine.createSpy('buildMultiMsgAlert'),
  };

  const translateServiceMock = {
    get: jasmine.createSpy('get').and.returnValue(of('translated text')),
    instant: jasmine.createSpy('instant').and.returnValue('translated text'),
    onLangChange: of(null),
    onTranslationChange: of(null),
    onDefaultLangChange: of(null),
  };
  beforeEach(async () => {
    userInfoMock = {
      getScreenViewType: jasmine.createSpy().and.returnValue('test'),
    };
    await TestBed.configureTestingModule({
      declarations: [MarketDetailsComponent, AlertWithLinkComponent, SortPipe],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
      ],
      providers: [
        MockStore,
        provideMockStore(),
        MarketDetailsStoreService,
        SummaryStoreService,
        SidePanelStoreService,
        SectionDetailsStoreService,
        GlobalAlertStoreService,
        SummaryStoreService,
        FormBuilder,
        { provide: Router, useValue: router },
        { provide: UserInfoService, useValue: userInfoMock },
        { provide: MarketDetailsBusinessRulesService, useValue: marketDetailsBusinessRulesMock },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: MultiMsgAlertService, useValue: multiMsgAlertServiceMock },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketDetailsComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    formBuilder = TestBed.inject(FormBuilder);
    component.marketDetails = mockMarketData;
    sectionDetailsStoreService = TestBed.inject(SectionDetailsStoreService);
    marketDetailsStoreService = TestBed.inject(MarketDetailsStoreService);
    summaryStoreService = TestBed.inject(SummaryStoreService);
    marketDetailsBusinessRulesService = TestBed.inject(MarketDetailsBusinessRulesService);
    translateService = TestBed.inject(TranslateService);
    multiMsgAlertService = TestBed.inject(MultiMsgAlertService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call initMarketDetailsForm after setting marketDetails data', () => {
    spyOn(component, 'initMarketDetailsForm');
    component.marketDetails = mockMarketData;
    fixture.detectChanges();
    expect(component.initMarketDetailsForm).toHaveBeenCalled();
  });

  it('should set market section option length to sectionShowAtLevel when marketData applied', () => {
    component.marketDetails = mockMarketData;
    fixture.detectChanges();
    expect(component.sectionNo).toEqual(sectionShowAtLevel);
  });

  it('should show Market Details for Lloyds OP , Company OP and Company XL', () => {
    userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
    component.screenView =
      component.premiumScreenView.LLOYDS_OP ||
      component.premiumScreenView.COMPANY_OP ||
      component.premiumScreenView.COMPANY_XL;
    component.marketDetails = mockMarketData;
    fixture.detectChanges();
    const marketDetails = el.query(By.css('#marketDetailsContainer')).nativeElement;
    expect(marketDetails).toBeTruthy();
  });

  it('should create a new syndicate to the form array', () => {
    component.initSyndicateForm();
    expect(component.marketDetailsFormArray.length).toBeGreaterThan(0);
  });

  it('should add a new row in marketDetailsFormArray when click on Add row button', () => {
    component.rowNum = 1;
    userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
    spyOn(component, 'onAddRow').and.callThrough();
    component.screenView =
      component.premiumScreenView.LLOYDS_OP ||
      component.premiumScreenView.COMPANY_OP ||
      component.premiumScreenView.COMPANY_XL;
    fixture.detectChanges();
    const addMarketDetailsBtn = el.query(By.css('#addMarketDetailsBtn')).nativeElement;
    addMarketDetailsBtn.click();
    fixture.detectChanges();
    expect(component.onAddRow).toHaveBeenCalled();
    const marketDetailsAdded = el.query(By.css('#marketDetailsRow-2'));
    expect(component.marketDetailsFormArray.length).toEqual(11);
    expect(marketDetailsAdded).toBeTruthy();
  });

  it('should remove row in marketDetailsFormArray when click on delete row button', () => {
    component.marketDetailsFormArray.push(component.initSyndicateForm());
    expect(component.marketDetailsFormArray.length).toEqual(11);
    component.onDeleteRow('syndicates', 1, component.deleteRowBtn.MARKET_DETAILS);
    expect(component.marketDetailsFormArray.length).toEqual(10);
  });

  xit('should call configureInitSyndicateForm when calling intiMarketSyndicateForm with no syndicate details', () => {
    spyOn(component, 'initSyndicateForm').and.returnValues(formBuilder.group({}));
    component.configureInitSyndicateForm(mockMarketDataSyndicates);
    expect(component.initSyndicateForm).toHaveBeenCalledWith();
  });

  it('should populate year of account if period from in section details already populated', () => {
    userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
    component.screenView = PREMIUM_SCREEN_VIEW.LLOYDS_OP;
    component.yearOfAccount = 2020;
    spyOn(component, 'initMarketDetailsForm');
    component.marketDetails = mockMarketData;
    fixture.detectChanges();
    expect(component.initMarketDetailsForm).toHaveBeenCalled();
    expect(component.marketDetailsControls?.yearOfAccount?.value).toEqual(component.yearOfAccount);
  });

  it(' year of account should equal populated yearOfAccount in  Market details even if year of account populated from section details, it shouldnt override.', () => {
    userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
    component.screenView = PREMIUM_SCREEN_VIEW.LLOYDS_OP;
    component.yearOfAccount = 2020;
    spyOn(component, 'initMarketDetailsForm');
    component.marketDetails = { ...mockMarketData, yearOfAccount: 2024 };

    const marketDetails = { ...mockMarketData, yearOfAccount: 2024 };
    fixture.detectChanges();
    expect(component.initMarketDetailsForm).toHaveBeenCalled();
    expect(component.marketDetailsControls?.yearOfAccount?.value).toEqual(marketDetails.yearOfAccount);
  });

  describe('Year of account deprication check', () => {
    beforeEach(() => {
      component.infoHeaderDetails = { workPackageRef: 'kaq8857' };
      component.referenceRiskCodes = [
        {
          riskCode: 'e2',
          deprecatedDate: '2020-10-12',
        },
      ];
    });

    it('should populate ref data and info header data', () => {
      expect(component.referenceRiskCodes[0]).toEqual({ riskCode: 'e2', deprecatedDate: '2020-10-12' });
      expect(component.infoHeaderDetails).toEqual({ workPackageRef: 'kaq8857' });
    });

    it('should compare year of account and deprecated date', () => {
      spyOn(component, 'onCheckScreenView').and.callFake(() => 'LLOYDS');
      component.sectionData = { riskCode: 'e2' } as any;

      expect(component.isYearOfAccountDeprecated('2023')).toBeTruthy();
      expect(component.isYearOfAccountDeprecated('2020')).toBeFalsy();
    });

    it('should not check if workPackageRef starts from "E"', () => {
      spyOn(component, 'onCheckScreenView').and.callFake(() => 'LLOYDS');
      component.sectionData = { riskCode: 'e2' } as any;
      component.infoHeaderDetails = { workPackageRef: 'elr7629' };
    });

    it('should check year of account only for lloyds', () => {
      component.sectionData = { riskCode: 'e2' } as any;

      expect(component.isYearOfAccountDeprecated('2023')).toBeFalsy();
    });

    it('should not check year of account if it is empty', () => {
      spyOn(component, 'onCheckScreenView').and.callFake(() => 'LLOYDS');
      component.sectionData = { riskCode: 'e2' } as any;

      expect(component.isYearOfAccountDeprecated('')).toBeFalsy();
    });

    it('should not check year of account if risk code is empty or not exists', () => {
      spyOn(component, 'onCheckScreenView').and.callFake(() => 'LLOYDS');

      expect(component.isYearOfAccountDeprecated('2023')).toBeFalsy();

      component.sectionData = { riskCode: 'fake risk code' } as any;
      expect(component.isYearOfAccountDeprecated('2023')).toBeFalsy();
    });

    it('should validate form field', () => {
      spyOn(component, 'submit').and.callFake(() => {});
      spyOn(component, 'setNextStepUrl').and.callFake(() => {});
      spyOn(component, 'onCheckScreenView').and.callFake(() => 'LLOYDS');
      component.sectionData = { riskCode: 'e2' } as any;

      component.marketDetailsControls.yearOfAccount.setValue('2022');
      component.saveDraftNext(SUBMIT_TYPES.NEXT);
      expect(component.marketDetailsControls.yearOfAccount.errors?.deprecatedYearOfAccount).toBeTruthy();
    });

    it('should validate display validation error', () => {
      spyOn(component, 'submit').and.callFake(() => {});
      spyOn(component, 'setNextStepUrl').and.callFake(() => {});
      spyOn(component, 'onCheckScreenView').and.callFake(() => 'LLOYDS');
      component.sectionData = { riskCode: 'e2' } as any;

      component.marketDetailsControls.yearOfAccount.setValue('2022');
      component.saveDraftNext(SUBMIT_TYPES.NEXT);
      fixture.detectChanges();
      expect(el.query(By.css('#deprecatedDateError'))).toBeTruthy();
    });
  });

  it('should get from policyPeriod date from section details populated data and splitting year from it ', () => {
    component.sectionDetails = mockSectionData;
    const yearOfAccount = +mockSectionData.contractDetails.policyPeriod.from.split(/[-]/)[0];
    fixture.detectChanges();
    expect(component.yearOfAccount).toEqual(yearOfAccount);
  });

  // it('should get from partyMarketDetails date ', () => {
  //   component.partyMarketDetails = mockPartyMarketDetails;
  //   if (!component.invalidSyndicateNumbers?.includes(+mockPartyMarketDetails[1].partyReference)) {
  //     component.invalidSyndicateNumbers.push(+mockPartyMarketDetails[1].partyReference);
  //   }
  //   fixture.detectChanges();
  //   expect(component.invalidSyndicateNumbers).toEqual([2]);
  // });

  describe('marketDetailsForm controls validations', () => {
    let formControls;
    let formArrayControls;

    beforeEach(() => {
      component.initMarketDetailsForm(mockMarketData);
      component.marketDetailsFormArray?.push(component.initSyndicateForm());
      formControls = component.marketDetailsControls;
      component.infoHeaderDetails = { slipType: 'D' };
      const key = 'controls';
      formArrayControls = formControls.syndicates[key][0]?.controls;
      fixture.detectChanges();
    });

    const callNextBtn = () => {
      spyOn(component, 'saveDraftNext').and.callThrough();
      spyOn(component, 'setNextStepUrl').and.callFake(() => {});
      component.signedTransactionStatus = false;
      component.saveDraftNext(SUBMIT_TYPES.NEXT);
      expect(component.saveDraftNext).toHaveBeenCalled();
      expect(component.saveDraftStatus).toBeFalsy();
    };

    xit('should  display the error banner if The total percentage cannot exceed 100%', () => {
      component.screenView = PREMIUM_SCREEN_VIEW.COMPANY_AP_RP;
      formArrayControls.syndicatePercentage.setValue('120');
      callNextBtn();
      expect(component.totalSyndicatePercentage).toBe(120);
      expect(component.isSyndicatePercentExceeds100).toBeTruthy();
      fixture.detectChanges();
      const netValuesNotEqualErrorBanner = el.query(By.css('#syndicatePercentagePremium'));
      expect(netValuesNotEqualErrorBanner).toBeTruthy();
    });

    describe('marketDetailsForm controls required validations', () => {
      it('should bureauLinePercent has required error if entered empty value IN AP_RP', () => {
        component.screenView = PREMIUM_SCREEN_VIEW.COMPANY_AP_RP;
        callNextBtn();
        formControls.bureauLinePercent.setValue('');
        expect(formControls.bureauLinePercent.hasError('required')).toBeTruthy();
      });

      it('should not bureauLinePercent has required error if entered empty value IN OP', () => {
        component.screenView = PREMIUM_SCREEN_VIEW.LLOYDS_OP;
        callNextBtn();
        formControls.bureauLinePercent.setValue('');
        expect(formControls.bureauLinePercent.hasError('required')).toBeFalsy();
      });

      it('should yearOfAccount has required error if entered empty value and Screen view is Lloyds ', () => {
        userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
        component.screenView = component.premiumScreenView.LLOYDS_OP;
        callNextBtn();
        formControls.yearOfAccount.setValue('');
        expect(formControls.yearOfAccount.hasError('required')).toBeTruthy();
      });

      it('should sectionLead has required error if entered empty value, Screen view is COMPANY', () => {
        userInfoMock.getScreenViewType.and.returnValue('COMPANY_OP');
        component.screenView = component.premiumScreenView.COMPANY_OP || component.premiumScreenView.COMPANY_XL;

        callNextBtn();
        formControls.sectionLead.setValue('');
        expect(formControls.sectionLead.hasError('required')).toBeTruthy();
      });

      xit('should syndicateNumber has required error if entered empty value  ', () => {
        callNextBtn();
        fixture.detectChanges();
        formArrayControls.syndicateNumber.setValue('');
        expect(formArrayControls.syndicateNumber.hasError('required')).toBeTruthy();
      });

      it('should syndicatePseudonym has required error if entered empty value and Screen view is Lloyds', () => {
        userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
        component.screenView = component.premiumScreenView.LLOYDS_OP;
        callNextBtn();
        formArrayControls.syndicatePseudonym.setValue('');
        expect(formArrayControls.syndicatePseudonym.hasError('required')).toBeTruthy();
      });

      xit('should syndicatePercentage has required error if entered empty value', () => {
        callNextBtn();
        formArrayControls.syndicatePercentage.setValue('');
        expect(formArrayControls.syndicatePercentage.hasError('required')).toBeFalsy();
      });

      it('should display warning banner based on displayWarninngBanner flag', () => {
        expect(fixture?.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
        component.displayWarninngBanner = true;
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeTruthy();
      });

      it('should displayWarninngBanner is true and warning banner displayed when lloyds,syndicatePercentage, correctionType is RA and control has a value ', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.LLOYDS;
        component.checkWarningBanner('syndicatePercentage', '1');
        expect(component.displayWarninngBanner).toBeTruthy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeTruthy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when no bureau value', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.checkWarningBanner('syndicateNumber', '1');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when formcontrol is not syndicateNumber or syndicatePercentage', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.LLOYDS;
        component.checkWarningBanner('test', '1');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when formcontrol do not have value', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.LLOYDS;
        component.checkWarningBanner('syndicateNumber', '');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when formcontrol is syndicateNumber and bureau is not lloyds', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.LIRMA;
        component.checkWarningBanner('syndicateNumber', '1');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when formcontrol is syndicateNumber and bureau is not lloyds', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.ILU;
        component.checkWarningBanner('syndicateNumber', '1');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when no bureau value', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.checkWarningBanner('syndicatePercentage', '1');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when formcontrol is not syndicateNumber or syndicatePercentage', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.LIRMA;
        component.checkWarningBanner('test', '1');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when formcontrol not have value', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.ILU;
        component.checkWarningBanner('syndicatePercentage', '');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is false and warning banner not displayed when correction type is not RA', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.bureau = TechnicianPortalBureauEnum.ILU;
        component.checkWarningBanner('syndicatePercentage', '1');
        expect(component.displayWarninngBanner).toBeFalsy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeFalsy();
      });

      it('should displayWarninngBanner is true and warning banner displayed when ILU or LIRMA, syndicatePercentage, correctionType is RA and control has a value ', () => {
        expect(component.displayWarninngBanner).toBeFalsy();
        component.correctionType = CorrectionTypeEnum.RA;
        component.bureau = TechnicianPortalBureauEnum.LIRMA;
        component.checkWarningBanner('syndicatePercentage', '1');
        expect(component.displayWarninngBanner).toBeTruthy();
        fixture.detectChanges();
        expect(fixture.nativeElement?.querySelector('#updateNAPremium')).toBeTruthy();
      });

      it('should syndicateReference has required error if entered empty value', () => {
        callNextBtn();
        formArrayControls.syndicateReference.setValue('');
        expect(formArrayControls.syndicateReference.hasError('required')).toBeTruthy();
      });

      it('should syndicateSecondaryReference be optional if entered empty value and Screen view is COMPANY', () => {
        userInfoMock.getScreenViewType.and.returnValue('COMPANY_OP');
        component.screenView = component.premiumScreenView.COMPANY_OP || component.premiumScreenView.COMPANY_XL;
        callNextBtn();
        formArrayControls.syndicateSecondaryReference.setValue('');
        expect(formArrayControls.syndicateSecondaryReference.hasError('required')).toBeFalsy();
      });
    });

    const callNextBtnWithSignedTransaction = () => {
      spyOn(component, 'saveDraftNext').and.callThrough();
      spyOn(component, 'setNextStepUrl').and.callFake(() => {});
      component.signedTransactionStatus = true;
      component.saveDraftNext(SUBMIT_TYPES.NEXT);
      expect(component.saveDraftNext).toHaveBeenCalled();
      expect(component.saveDraftStatus).toBeFalsy();
    };

    it('should not call patch api when submit to next for signed transactions', () => {
      const marketDetailStoreService: MarketDetailsStoreService = TestBed.inject(MarketDetailsStoreService);
      callNextBtnWithSignedTransaction();
      spyOn(marketDetailStoreService, 'updateMarketData').and.callFake(() => {});
      expect(marketDetailStoreService.updateMarketData).not.toHaveBeenCalled();
    });

    it('should marketDetailsForm to be invalid form  when bureauLinePercent control has whitespaces', () => {
      formControls.bureauLinePercent.setValue('     ');
      expect(component.marketDetailsForm.invalid).toBeTruthy();
      expect(formControls.bureauLinePercent.hasError('noWhiteSpacePercentage')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when bureauLinePercent control has letter', () => {
      formControls.bureauLinePercent.setValue('p');
      expect(component.marketDetailsForm.invalid).toBeTruthy();
      expect(formControls.bureauLinePercent.hasError('integer')).toBeTruthy();
    });

    it('should marketDetailsForm to be valid form  when bureauLinePercent control has more than 2 decimals', () => {
      formControls.bureauLinePercent.setValue('1.888');
      expect(component.marketDetailsForm.valid).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when yearOfAccount control has whitespaces', () => {
      formControls.yearOfAccount.setValue('     ');
      expect(component.marketDetailsForm.invalid).toBeTruthy();
      expect(formControls.yearOfAccount.hasError('noWhiteSpaceIntegerNumbers')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when yearOfAccount control has letter', () => {
      formControls.yearOfAccount.setValue('p');
      expect(component.marketDetailsForm.invalid).toBeTruthy();
      expect(formControls.yearOfAccount.hasError('integerNum')).toBeTruthy();
    });

    it('should marketDetailsForm to be valid form  when yearOfAccount control has year from 4 digits', () => {
      formControls.yearOfAccount.setValue('2023');
      expect(component.marketDetailsForm.valid).toBeTruthy();
    });

    xit('should marketDetailsForm to be invalid form  when syndicateNumber control has whitespaces', () => {
      formArrayControls?.syndicateNumber.setValue('     ');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateNumber.hasError('noWhiteSpaceIntegerNumbers')).toBeFalsy();
    });

    it('should marketDetailsForm to be valid form  when syndicateNumber control has more than 7 numbers', () => {
      component.marketDetails = mockMarketData;
      component.bureau = 'ILU';
      userInfoMock.getScreenViewType.and.returnValue('COMPANY_OP');
      component.screenView = component.premiumScreenView.COMPANY_OP;

      fixture.detectChanges();

      formArrayControls?.syndicateNumber.setValue('123467458');
      expect(formArrayControls?.syndicateNumber.hasError('maxlength')).toBeTruthy();
      expect(formArrayControls?.syndicateNumber?.errors?.maxlength?.requiredLength).toEqual(7);
    });
    it('should marketDetailsForm to be invalid form  when syndicatePseudonym control has whitespaces', () => {
      formArrayControls?.syndicatePseudonym.setValue('     ');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicatePseudonym.hasError('noWhiteSpace')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicatePseudonym control has non ascii character', () => {
      formArrayControls?.syndicatePseudonym.setValue('«');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicatePseudonym.hasError('alphanumeric_ascii')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicatePseudonym control has more than 3 characters', () => {
      formArrayControls?.syndicatePseudonym.setValue('12345678');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicatePseudonym.hasError('maxlength')).toBeTruthy();
    });

    xit('should marketDetailsForm to be invalid form  when syndicatePercentage control has whitespaces', () => {
      formArrayControls?.syndicatePercentage.setValue('     ');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicatePercentage.hasError('noWhiteSpacePercentage')).toBeFalsy();
    });

    it('should marketDetailsForm to be invalid form  when syndicatePercentage control has letter', () => {
      formArrayControls?.syndicatePercentage.setValue('p');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicatePercentage.hasError('integer')).toBeTruthy();
    });

    it('should marketDetailsForm to be valid form  when syndicatePercentage control has more than 2 decimals', () => {
      formArrayControls?.syndicatePercentage.setValue('1.888');
      expect(component?.marketDetailsForm.valid).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicateReference control has whitespaces', () => {
      formArrayControls?.syndicateReference.setValue('     ');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateReference.hasError('noWhiteSpace')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicateReference control has non ascii character', () => {
      formArrayControls?.syndicateReference.setValue('«');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateReference.hasError('alphabets_numbers_only')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicateReference control has more than 13 characters', () => {
      formArrayControls?.syndicateReference.setValue('123456789012345');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateReference.hasError('maxlength')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicateReference control has more than 12 characters', () => {
      component.bureau = 'LLOYDS';
      fixture.detectChanges();

      formArrayControls?.syndicateReference.setValue('123456789012345');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateReference.hasError('maxlength')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicateSecondaryReference control has whitespaces', () => {
      formArrayControls?.syndicateSecondaryReference.setValue('     ');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateSecondaryReference.hasError('noWhiteSpace')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicateSecondaryReference control has non ascii character', () => {
      formArrayControls?.syndicateSecondaryReference.setValue('«');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateSecondaryReference.hasError('alphanumeric_ascii')).toBeTruthy();
    });

    it('should marketDetailsForm to be invalid form  when syndicateSecondaryReference control has more than 13 characters', () => {
      formArrayControls?.syndicateSecondaryReference.setValue('123456781234567812345678');
      expect(component?.marketDetailsForm.invalid).toBeTruthy();
      expect(formArrayControls?.syndicateSecondaryReference.hasError('maxlength')).toBeTruthy();
    });
  });

  it('should call selectSubmissionSummaries onInit', () => {
    spyOn(component, 'selectSubmissionSummaries');
    component.ngOnInit();
    expect(component.selectSubmissionSummaries).toHaveBeenCalled();
  });

  it('should set the value of submissionSummaries on selectSubmissionSummaries', () => {
    const mockSubmissionSumaaries = [mockSummaryData];
    spyOn(summaryStoreService, 'selectSummaryData').and.returnValue(of(mockSubmissionSumaaries));
    component.selectSubmissionSummaries();
    expect(component.submissionSummaries).toEqual(mockSubmissionSumaaries);
  });

  describe('marketDetails Validation', () => {
    let formControls;
    let formArrayControls;

    beforeEach(() => {});

    const callInitSyndicateForm = () => {
      component.initMarketDetailsForm(mockMarketData);
      component.marketDetailsFormArray?.push(component.initSyndicateForm());
      formControls = component.marketDetailsControls;
      const key = 'controls';
      formArrayControls = formControls.syndicates[key][0]?.controls;

      fixture.detectChanges();
    };

    it('should marketDetailsForm to be valid form  when syndicateNumber control has more than 5 numbers for LIRMA && this.syndicateNumberFieldName === MARKET_DETAILS.COMPANY_CODE', () => {
      spyOn(component, 'onCheckScreenView').and.returnValue(component.premiumScreenView.COMPANY);
      const result = component.syndicateNumberFieldName;
      component.marketDetails = mockMarketData;
      component.bureau = 'LIRMA';
      userInfoMock.getScreenViewType.and.returnValue('COMPANY_OP');
      component.screenView = component.premiumScreenView.COMPANY_XL || component.premiumScreenView.COMPANY_OP;
      callInitSyndicateForm();

      formArrayControls?.syndicateNumber.setValue('1234678');
      expect(component.syndicateNumberFieldName).toEqual(result);
      expect(formArrayControls?.syndicateNumber.hasError('maxlength')).toBeTruthy();
      expect(formArrayControls?.syndicateNumber?.errors?.maxlength?.requiredLength).toEqual(5);
    });

    it('should marketDetailsForm to be valid form  when syndicateNumber control has more than 4 numbers for Lloyds', () => {
      spyOn(component, 'onCheckScreenView').and.returnValue(component.premiumScreenView.LLOYDS);
      const result = component.syndicateNumberFieldName;
      component.marketDetails = mockMarketData;
      userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
      component.screenView = component.premiumScreenView.LLOYDS_OP;

      callInitSyndicateForm();

      formArrayControls?.syndicateNumber.setValue('12345');
      expect(component.syndicateNumberFieldName).toEqual(result);
      expect(formArrayControls?.syndicateNumber.hasError('maxlength')).toBeTruthy();
      expect(formArrayControls?.syndicateNumber?.errors?.maxlength?.requiredLength).toEqual(4);
    });

    it('should change YOASND format to be YYYY-MM-DD-NNNNN', () => {
      const result = component.getFacilityNumberAndDateFormat(mockMarketData);
      expect(result).toEqual('2024-06-17-20000');
    });
  });

  it('should submit to save draft', () => {
    spyOn(component, 'saveDraftNext');
    component.saveDraftNext(SUBMIT_TYPES.SAVE);
    expect(component.saveDraftNext).toHaveBeenCalled();
  });

  it('should submit to next', () => {
    spyOn(component, 'saveDraftNext');
    component.saveDraftNext(SUBMIT_TYPES.NEXT);
    expect(component.saveDraftNext).toHaveBeenCalled();
  });

  it('should set nextStepUrl to the next market id url if the current marekt id is not the last one on the submission details', () => {
    component.marketData = { marketId: '123', bureauLinePercent: 1, submissionId: '012' };
    component.submissionMarketsIds = ['123', '456', '789'];
    component.currentMarketIdIndex = 0;
    component.marketAccordionIndex = 0;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.setNextStepUrl();
    expect(component.nextStepUrl).toBe(
      `market-details?status=opened&market_no=0&marketId=456&submissionId=012&bureau=LLOYDS`
    );
  });

  it('should set nextStepUrl to the next market id url if the current marekt id is not the last one on the submission details and have enquiry and csnd query param', () => {
    component.marketData = { marketId: '123', bureauLinePercent: 1, submissionId: '012' };
    component.submissionMarketsIds = ['123', '456', '789'];
    component.currentMarketIdIndex = 0;
    component.marketAccordionIndex = 0;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.isFromEnquiry = true;

    component.setNextStepUrl();
    expect(component.nextStepUrl).toBe(
      `market-details?status=opened&market_no=0&marketId=456&submissionId=012&bureau=LLOYDS&${ENQUIRY_SUBMISSION_ID}=${component.marketData.submissionId}&${CSND}=${component.csnd}`
    );
  });

  it('should set nextStepUrl to the signing details url if the current marekt id is the last one on the submission details and have enquiry and csnd query param', () => {
    component.marketData = { marketId: '123', bureauLinePercent: 1, submissionId: '012' };
    component.submissionMarketsIds = ['123'];
    component.currentMarketIdIndex = 0;
    component.marketAccordionIndex = 0;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.isFromEnquiry = true;
    component.marketId = '3d209d8b-b504-4eed-a9f3-d7b0df25327b';
    component.premiumId = 'c1f7d1ca-615c-4d41-a662-d4e0bb9902d3';
    component.transactionType = 'Premium';

    component.setNextStepUrl();
    expect(component.nextStepUrl).toBe(
      `signing-details?submissionId=012&bureau=LLOYDS&market_no=0&marketsId=${component.marketId}&transactionType=Premium&premiumsId=${component.premiumId}&enquirySubmissionId=${component.marketData.submissionId}&csnd=${component.csnd}`
    );
  });

  it('should set nextStepUrl to the signing details url if the current marekt id is the last one on the submission details', () => {
    component.marketData = { marketId: '123', bureauLinePercent: 1, submissionId: '012' };
    component.submissionMarketsIds = ['123'];
    component.currentMarketIdIndex = 0;
    component.marketAccordionIndex = 0;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.marketId = '3d209d8b-b504-4eed-a9f3-d7b0df25327b';
    component.premiumId = 'c1f7d1ca-615c-4d41-a662-d4e0bb9902d3';
    component.transactionType = 'Premium';

    component.setNextStepUrl();
    expect(component.nextStepUrl).toBe(
      `signing-details?submissionId=012&bureau=LLOYDS&market_no=0&marketsId=3d209d8b-b504-4eed-a9f3-d7b0df25327b&transactionType=Premium&premiumsId=c1f7d1ca-615c-4d41-a662-d4e0bb9902d3`
    );
  });

  it('should call submit method after saveDraftNext if it is not a signed transaction', () => {
    spyOn(component, 'submit');
    component.signedTransactionStatus = false;
    component.submissionMarketsIds = ['123'];
    component.saveDraftNext(SUBMIT_TYPES.NEXT);
    expect(component.submit).toHaveBeenCalled();
  });

  it('should call selectSectionData and updateMarketDataParties after submit if bureau is LLoyds and not saveDraftStatus', () => {
    spyOn(sectionDetailsStoreService, 'selectSectionData').and.returnValue(of(mockSectionDetail));
    spyOn(marketDetailsStoreService, 'updateMarketDataParties');
    component.signedTransactionStatus = false;
    component.submissionMarketsIds = ['123'];
    component.bureau = PREMIUM_SCREEN_VIEW.LLOYDS;
    component.screenView = PREMIUM_SCREEN_VIEW.LLOYDS_OP;
    component.saveDraftStatus = false;
    component.infoHeaderDetails = { slipType: 'D' };
    component.submit();
    expect(sectionDetailsStoreService.selectSectionData).toHaveBeenCalled();
    expect(marketDetailsStoreService.updateMarketDataParties).toHaveBeenCalled();
  });

  it('should call updateMarketData after submit if bureau is not LLoyds or it is a saveDraftStatus', () => {
    spyOn(marketDetailsStoreService, 'updateMarketData');
    component.infoHeaderDetails = { slipType: 'D' };
    component.signedTransactionStatus = false;
    component.submissionMarketsIds = ['123'];
    component.bureau = TechnicianPortalBureauEnum.ILU;
    component.saveDraftStatus = true;
    component.submit();
    expect(marketDetailsStoreService.updateMarketData).toHaveBeenCalled();
  });

  it('should go back to previous market id if the current market id is not the first one on the submission markets ids', () => {
    spyOn(component, 'marketDetailsUrl').and.callThrough();
    const prevMarketId = '100';
    component.marketData = { marketId: '101', bureauLinePercent: 1, submissionId: '123' };
    component.submissionMarketsIds = ['100', '101'];
    component.currentMarketIdIndex = 1;
    component.marketAccordionIndex = 0;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.back();
    expect(component.marketDetailsUrl).toHaveBeenCalledWith(prevMarketId);
    expect(component.marketDetailsUrl(prevMarketId)).toContain(
      `${MARKET_URL}${component.marketAccordionIndex}&${marketId}=${prevMarketId}&${SUBMISSION_ID}=${component.marketData.submissionId}&bureau=LLOYDS`
    );
  });
  it('should go back to previous market id if the current market id is not the first one on the submission markets ids and have enquiry and csnd query param', () => {
    spyOn(component, 'marketDetailsUrl').and.callThrough();
    const prevMarketId = '100';
    component.marketData = { marketId: '101', bureauLinePercent: 1, submissionId: '123' };
    component.submissionMarketsIds = ['100', '101'];
    component.currentMarketIdIndex = 1;
    component.marketAccordionIndex = 0;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.isFromEnquiry = true;
    component.back();
    expect(component.marketDetailsUrl).toHaveBeenCalledWith(prevMarketId);
    expect(component.marketDetailsUrl(prevMarketId)).toBe(
      `${MARKET_URL}${component.marketAccordionIndex}&${marketId}=${prevMarketId}&${SUBMISSION_ID}=${component.marketData.submissionId}&bureau=LLOYDS&${ENQUIRY_SUBMISSION_ID}=${component.marketData.submissionId}&${CSND}=${component.csnd}`
    );
  });

  it('should go back to to last premium in last section if the current market id is the first one on the submission markets ids', () => {
    spyOn(component, 'lastPremiumDetailsUrl').and.callThrough();
    component.marketData = { marketId: '101', bureauLinePercent: 1, submissionId: '123' };
    component.currentMarketIdIndex = 0;
    component.marketAccordionIndex = 0;
    component.lastSectionLastPremium = mockPremiumData;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.back();
    expect(component.lastPremiumDetailsUrl).toHaveBeenCalledWith(TypeOfPremium.OriginalPremium);
    expect(component.lastPremiumDetailsUrl(TypeOfPremium.OriginalPremium)).toBe(
      `${PREMIUM_URL}${component.bureau}/${TypeOfPremium.OriginalPremium}?${STATUS_SECTION_NO}${component.marketAccordionIndex}&${PREMIUM_ID}=${component.lastSectionLastPremium?.premiumId}&${SUBMISSION_ID}=${component.marketData.submissionId}&bureau=LLOYDS`
    );
  });

  it('should go back to to last premium in last section if the current market id is the first one on the submission markets ids and have enquiry and csnd query param', () => {
    spyOn(component, 'lastPremiumDetailsUrl').and.callThrough();
    component.marketData = { marketId: '101', bureauLinePercent: 1, submissionId: '123' };
    component.currentMarketIdIndex = 0;
    component.marketAccordionIndex = 0;
    component.lastSectionLastPremium = mockPremiumData;
    component.bureau = 'LLOYDS';
    component.csnd = '80874 2017012024';
    component.isFromEnquiry = true;
    component.back();
    expect(component.lastPremiumDetailsUrl).toHaveBeenCalledWith(TypeOfPremium.OriginalPremium);
    expect(component.lastPremiumDetailsUrl(TypeOfPremium.OriginalPremium)).toBe(
      `${PREMIUM_URL}${component.bureau}/${TypeOfPremium.OriginalPremium}?${STATUS_SECTION_NO}${component.marketAccordionIndex}&${PREMIUM_ID}=${component.lastSectionLastPremium?.premiumId}&${SUBMISSION_ID}=${component.marketData.submissionId}&bureau=LLOYDS&${ENQUIRY_SUBMISSION_ID}=${component.marketData.submissionId}&${CSND}=${component.csnd}`
    );
  });

  it('should show year of account warning when yearOfAccountWarning and yearOfAccountChangedError has a value', () => {
    userInfoMock.getScreenViewType.and.returnValue('LLOYDS_OP');
    component.screenView = PREMIUM_SCREEN_VIEW.LLOYDS_OP;
    component.yearOfAccountWarning = 'MARKET_DETAILS.YEAR_OF_ACCOUNT_WARNING';
    component.displayYOAChangedWarning = 'MARKET_DETAILS.YEAR_OF_ACCOUNT_CHANGED_WARNING';
    fixture.detectChanges();
    const yearOfAccountWarning = fixture.debugElement.query(By.css('#yearOfAccountWarning'));
    const yearOfAccountChangedError = fixture.debugElement.query(By.css('#yearOfAccountChangedError'));
    expect(yearOfAccountChangedError).toBeTruthy();
    expect(yearOfAccountWarning).toBeTruthy();
  });

  it('should set yearOfAccountWarning and yearOfAccountChangedError correctly if marketYearOfAccount not equal sectionPolicyFromDateYear and screenView is LloydsOpScreenView', () => {
    component.screenView = PREMIUM_SCREEN_VIEW.LLOYDS_OP;
    component.sectionDataContractFromDate = '2025-02-18';
    const marketYearOfAccount = '2026';
    component.getYearOfAccountWarning(marketYearOfAccount, '');
    expect(component.yearOfAccountWarning).toBe('MARKET_DETAILS.YEAR_OF_ACCOUNT_WARNING');
    expect(component.displayYOAChangedWarning).toBe('MARKET_DETAILS.YEAR_OF_ACCOUNT_CHANGED_WARNING');
  });

  describe('yesClicked', () => {
    it('should navigate to the Corrections_URL with query parameters', () => {
      const CORRECTIONS_URL = '/corrections';
      const callback = 'someCallback';
      component.callback = callback;

      const queryParams = {
        queryParams: {
          callback: component.callback ? component.callback : undefined,
          workflowSubmissionId: component.workflowSubmissionId ?? undefined,
        },
      };
      component.yesClicked();

      expect(router.navigate).toHaveBeenCalledWith([CORRECTIONS_URL], queryParams);
    });
  });

  describe('Corrections R/A validations', () => {
    it('should open warning alert if isValidCorrectionRAValidations, saveDraftStatus and overrideCorrectionRAWarning are false', () => {
      spyOn(component.correctionRAWarningAlert, 'openAlert').and.callFake(() => {});
      spyOn(component, 'isValidCorrectionRAValidations').and.returnValue(false);

      component.infoHeaderDetails = mockInfoHeaderData;
      component.saveDraftStatus = false;
      component.overrideCorrectionRAWarning = false;

      component.submit();
      expect(component.correctionRAWarningAlert.openAlert).toHaveBeenCalled();
    });

    describe('isValidCorrectionRAValidations', () => {
      it('should be called on submit if not save draft', () => {
        spyOn(component, 'isValidCorrectionRAValidations');
        spyOn(component.correctionRAWarningAlert, 'openAlert').and.callFake(() => {});
        component.infoHeaderDetails = mockInfoHeaderData;
        component.saveDraftStatus = true;
        component.submit();
        expect(component.isValidCorrectionRAValidations).toHaveBeenCalledTimes(0);

        component.saveDraftStatus = false;
        component.submit();
        expect(component.isValidCorrectionRAValidations).toHaveBeenCalled();
      });

      it('should return true if the correction type is not RA', () => {
        const marketRecord = {} as MarketRecord;
        component.correctionType = CorrectionTypeEnum.CR;
        const result = component.isValidCorrectionRAValidations(marketRecord);
        expect(result).toBe(true);
      });

      it('should return true if correctionType is RA and isAnySyndicateRefChanged returns false', () => {
        component.correctionType = component.correctionTypeEnum.RA;
        spyOn(component, 'isAnySyndicateRefChanged').and.returnValue(false);
        spyOn(component, 'hasAnyAssociatedSignings').and.returnValue(true);
        const marketRecord = {} as MarketRecord;
        const result = component.isValidCorrectionRAValidations(marketRecord);
        expect(result).toBe(true);
      });

      it('should return true if correctionType is RA and hasAnyAssociatedSignings returns false', () => {
        component.correctionType = component.correctionTypeEnum.RA;
        spyOn(component, 'isAnySyndicateRefChanged').and.returnValue(true);
        spyOn(component, 'hasAnyAssociatedSignings').and.returnValue(false);
        const marketRecord = {} as MarketRecord;
        const result = component.isValidCorrectionRAValidations(marketRecord);
        expect(result).toBe(true);
      });

      it('should return false if correctionType is RA and both isAnySyndicateRefChanged and hasAnyAssociatedSignings return true', () => {
        component.correctionType = component.correctionTypeEnum.RA;
        spyOn(component, 'isAnySyndicateRefChanged').and.returnValue(true);
        spyOn(component, 'hasAnyAssociatedSignings').and.returnValue(true);
        const marketRecord = {} as MarketRecord;
        const result = component.isValidCorrectionRAValidations(marketRecord);
        expect(result).toBe(false);
      });
    });

    describe('isAnySyndicateRefChanged', () => {
      it('should return true if any syndicate reference has changed', () => {
        const syndicateObject = { syndicateReference: 'test', syndicatePercentage: 1, syndicateNumber: '1' };
        component.marketData = { ...mockMarketData, syndicates: [syndicateObject] };

        const marketRecord: MarketRecord = {
          ...mockMarketData,
          syndicates: [{ ...syndicateObject, syndicateReference: '3' }],
        };

        const result = component.isAnySyndicateRefChanged(marketRecord);
        expect(result).toBe(true);
      });

      it('should return false if syndicate references have not changed', () => {
        const syndicateObject = { syndicateReference: 'test', syndicatePercentage: 1, syndicateNumber: '1' };
        component.marketData = { ...mockMarketData, syndicates: [syndicateObject] };

        const marketRecord: MarketRecord = component.marketData;

        const result = component.isAnySyndicateRefChanged(marketRecord);
        expect(result).toBe(false);
      });
    });

    describe('hasAnyAssociatedSignings', () => {
      it('should return false if sidePanelDataItemData or opItems is undefined or empty', () => {
        component.sidePanelDataItemData = { opItems: [] };
        component.marketData = { ...mockMarketData, sectionId: '2' };

        expect(component.hasAnyAssociatedSignings()).toBe(false);

        component.sidePanelDataItemData = undefined;
        expect(!!component.hasAnyAssociatedSignings()).toBe(false);
      });

      it('should return true if there are associated signings', () => {
        component.submissionSummaries = [
          {
            aprps: [
              { originalPremiumId: '123', originalCurrency: null },
              { originalPremiumId: '456', originalCurrency: null },
            ],
          },
          { aprps: [{ originalPremiumId: '789', originalCurrency: null }] },
        ];

        component.sidePanelDataItemData = {
          opItems: [{ sectionId: '2', premiums: [{ replacesId: '123' }] }],
        };
        component.marketData = { ...mockMarketData, sectionId: '2' };

        expect(component.hasAnyAssociatedSignings()).toBe(true);
      });

      it('should return false if there are no associated signings', () => {
        component.submissionSummaries = [
          {
            aprps: [
              { originalPremiumId: '333', originalCurrency: null },
              { originalPremiumId: '456', originalCurrency: null },
            ],
          },
          { aprps: [{ originalPremiumId: '789', originalCurrency: null }] },
        ];

        component.sidePanelDataItemData = {
          opItems: [{ sectionId: '2', premiums: [{ replacesId: '123' }] }],
        };
        component.marketData = { ...mockMarketData, sectionId: '2' };

        expect(component.hasAnyAssociatedSignings()).toBe(false);
      });
    });

    it('should set overrideCorrectionRAWarning to true and call saveDraftNext with submitTypes.NEXT', () => {
      spyOn(component, 'saveDraftNext');
      component.onClickCorrectionAlertLink();

      expect(component.overrideCorrectionRAWarning).toBe(true);
      expect(component.saveDraftNext).toHaveBeenCalledWith(component.submitTypes.NEXT);
    });
  });

  afterEach(() => {
    fixture.destroy();
  });
});
