import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import {
  ADD_ROW_BTN,
  DELETE_ROW_BTN,
  marketId,
  sectionShowAtLevel,
  signingDetails,
  submissionId,
} from '@features/market-details/consts/market-details.consts';
import { PREMIUM_SCREEN_VIEW, SECTION, SELECT } from '@features/section-details/consts/section-details.consts';
import {
  ScrollToElement,
  isPositiveNumInteger,
  transctionType,
  onSelectChange,
  hasEnquirySubmissionId,
  addEnquiryQueryParam,
  navigateToCorrection,
  ScrollUp,
  onlyAlphabetsNumbers,
  hasAnyAssociatedSignings,
  getYearFromDate,
} from 'src/app/utils/helper/helper';
import { DxcSelectComponent, DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { Option } from '@dxc-technology/halstack-angular';
import { INPUT_TYPES } from '@shared/consts/shared.enums';
import {
  ValidationInputStatus,
  ValidationSelectStatus,
  isPercentage,
  isYear,
  LimitCharacters,
  isString,
} from 'src/app/utils/helper/helper';
import { v4 as uuid } from 'uuid';
import {
  MARKET_URL,
  PREMIUM_ID,
  PREMIUM_URL,
  STATUS_SECTION_NO,
  SUBMISSION_ID,
  SUBMIT_TYPES,
  TRANSACTION_TYPE_PREMIUM_FDO_VALUE,
  TRANSACTION_TYPE_PREMIUM_VALUE,
} from '@shared/consts/shared.consts';
import { Params, Router } from '@angular/router';
import {
  MarketRecord,
  MarketSyndicate,
  SubmissionNavRec,
  TechnicianPortalBureauEnum,
  PremiumNavRec,
  TypeOfPremium,
  PartyRequest,
  SubmissionStatuses,
  TechnicianSVDetails,
  SectionDetail,
  TypeOfTransactionType,
  PremiumGetRec,
  SubmissionSummaryRec,
  MarketSyndicates,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { MarketDetailsStoreService } from '@features/market-details/services/market-details.store.service';
import { find, map, last } from 'lodash';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { SidePanelStoreService } from '@shared/services/side-panel/side-panel.store.service';
import { getSignedStatusForSubmission } from '@features/signing-details/consts/signing-details.const';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { take, takeUntil, tap } from 'rxjs/operators';
import { removeCommaSeparator } from 'src/app/utils/helper/number.helper';
import { CorrectionTypeEnum } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import { UserInfoService } from '@shared/services/user-info/user-info.service';
import { CheckScreenView } from '@features/market-details/consts/market-details.helper';
import { MarketDetailsInput, ValidateSyndicateNumbersInput } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';
import { DatePipe, formatDate } from '@angular/common';
import { NumberDateInputComponent } from '@shared/components/number-date-input/number-date-input.component';
import { NumberDateInputComponentValidator } from '@shared/components/number-date-input/number-date-input.validator';
import { FacilityMarketsInfo, RefSlipType } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { SummaryStoreService } from '@features/summary/services/summary.store.service';
import { FacilityNumberDateRangeValidator } from '@shared/components/number-date-input/number-date-range.validator';
import { AppState } from 'src/app/store/app.reducer';
import { Store } from '@ngrx/store';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { AlertWithLinkComponent } from '@shared/components/alert-with-link/alert-with-link.component';
import { PartyMarketSyndicate } from '@shared/models';
import * as marketValidationFunctions from './../../helper/market-business-rules';
import { MarketDetailsBusinessRulesService } from '@features/market-details/services/market-details-business-rules.service';
import { isFdoAndMarketLloyds, isLloydsOpScreenView } from '@features/section-details/helper/screenView.helper';
import { TranslateService } from '@ngx-translate/core';
import { MultiMsgAlertService } from '@shared/services/multi-msg-alert/multi-msg-alert.service';

@Component({
  selector: 'app-market-details',
  templateUrl: './market-details.component.html',
  styleUrls: ['./market-details.component.scss'],
})
export class MarketDetailsComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  readonly addRowBtn = ADD_ROW_BTN;
  readonly deleteRowBtn = DELETE_ROW_BTN;
  readonly inputTypes = INPUT_TYPES;
  readonly premiumScreenView = PREMIUM_SCREEN_VIEW;
  readonly submitTypes = SUBMIT_TYPES;
  readonly correctionTypeEnum = CorrectionTypeEnum;
  readonly bureauView = TechnicianPortalBureauEnum;
  readonly transactionTypePremiumValue = TRANSACTION_TYPE_PREMIUM_VALUE;
  readonly transactionTypePremiumFdoValue = TRANSACTION_TYPE_PREMIUM_FDO_VALUE;
  bureau: TechnicianPortalBureauEnum;
  currentMarketIdIndex: number;
  csnd: string;
  displayWarninngBanner: boolean;
  isFirstSection: boolean;
  isFromEnquiry: boolean;
  lastSectionLastPremium: PremiumNavRec;
  nextSectionNextPremium: PremiumNavRec;
  marketAccordionIndex: number;
  marketData: MarketRecord;
  marketDetailsForm: FormGroup;
  marketId: string;
  marketSectionOptions: Option[] = [];
  nextStepUrl: string;
  noOfSections: number;
  screenView: string;
  sectionDataContractFromDate: string;
  sectionData: SectionDetail;
  saveDraftStatus: boolean;
  sectionLoadedFirstClick: boolean;
  sectionNo: number;
  sectionShowLevel = sectionShowAtLevel;
  signedTransactionStatus = false;
  transactiontype: TypeOfTransactionType;
  submissionMarketsIds: string[];
  submitted: boolean;
  invalidSyndicateNumbers: number[] = [];
  yearOfAccount: number;
  yearOfAccountWarning: string;
  responseData$: Observable<any>;
  callback: string;
  isBackToCorrection = false;
  correctionType: CorrectionTypeEnum;
  corrSubmissionId: string;
  workflowSubmissionId: string;
  totalLineNo = 0;
  isSyndicatePercentExceeds100: boolean;
  totalSyndicatePercentage: number;
  partialMarketFlag: boolean;
  amendedCarrierRef: boolean;
  amendedAndPartial: boolean;
  isFacilityNumberAndDate = false;
  isPseudonymDisabled: boolean[] = [];
  syndicates: any;
  checkModify: BehaviorSubject<boolean>;
  partialMarketId: string;
  premiumId: string;
  transactionType: string;
  removedFromPartialCheck = false;
  marketTable;

  isFirstLogicDisabled = false;

  isConsortiumS: boolean;
  isConsortiumFlage: boolean;

  readOnlySyndicateReference: boolean;

  selectPartyMarketData$;
  statusOfApiCall$;
  linesNum: Option[] = [
    { label: '1', value: '1' },
    { label: '2', value: '2' },
    { label: '3', value: '3' },
    { label: '4', value: '4' },
    { label: '5', value: '5' },
    { label: '6', value: '6' },
    { label: '7', value: '7' },
    { label: '8', value: '8' },
    { label: '9', value: '9' },
    { label: '10', value: '10' },
  ];
  rowNum = 0;
  isExpanded: boolean[] = [];
  datePipe = new DatePipe('en-UK');
  transactionTypeVal: TypeOfTransactionType;
  disableField: boolean;
  isChecked: boolean[] = [];
  isCheckedFromResponse: boolean[] = [];
  isPopulateClicked = false;
  sidePanelDataItemData: SubmissionNavRec;
  isAPRP: boolean;
  slipTypeString: string;
  premiumDataRef: PremiumGetRec;
  syndRef: string;
  syndRefIndex: number;
  isEmpty: boolean;
  submissionRef: SubmissionNavRec[];
  submissionSummaries: SubmissionSummaryRec[];
  isSecondFdoOn: boolean;
  overrideCorrectionRAWarning = false;

  objectDisplayer$ = new BehaviorSubject<boolean>(false);
  syndicateNumberIndex: number;
  isEditMode: boolean;
  isHeritageRecord = false;
  showDialog: boolean;
  description = 'SUMMARY_DETAILS.CONFIRMATION_MESSAGE';
  yoaChanged: boolean;
  displayYOAChangedWarning: string;

  @Input() infoHeaderDetails: TechnicianSVDetails;
  @Input() referenceRiskCodes: any;
  @Input() submissionId: string;

  @Input() set partyMarketDetails(partyMarketDetails: MarketSyndicates) {
    this.setInvalidSyndicateNumbers(partyMarketDetails);
    if (!partyMarketDetails) {
      return;
    }

    partyMarketDetails.forEach((party: MarketSyndicate) => {
      this.processConsortiumSyndicates(party);
    });
  }

  @Input() set marketDetails(marketDetails: MarketRecord) {
    this.initFirstFdoPermission();
    if (marketDetails) {
      this.isHeritageRecord = marketDetails?.isHeritageRecord;
      this.displayWarninngBanner = false;
      this.marketData = marketDetails;
      this.sectionNo = this.getSectionNumber(marketDetails?.marketTitle);
      const currentMarketId = this.marketData?.marketId;
      this.currentMarketIdIndex = this.submissionMarketsIds?.indexOf(currentMarketId);
      this.initMarketDetailsForm(marketDetails);

      const yearOfAccount = marketDetails?.yearOfAccount || this.yearOfAccount;
      if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS && yearOfAccount) {
        this.marketDetailsForm.patchValue({ yearOfAccount });
      }

      this.configureInitSyndicateForm(marketDetails);
      this.isFacilityNumberAndDate =
        marketDetails?.facilityNumberAndDate?.length > 0 || marketDetails?.facilityNumberAndDate === 'undefined';
      this.disableEnableSyndicateReference();
      this.disableCheckboxAPRP();
    } else {
      this.totalLineNo = 0;
      this.initMarketDetailsForm();
      this.marketDetailsFormArray?.push(this.initSyndicateForm());
    }
  }

  @Input() set queryParams(params: Params) {
    // market id is the id of premium 'section id' from the previous step.
    if (params) {
      this.marketId = params?.marketId;
      this.submissionId = params?.submissionId;
      // this prams in partial market yes only
      this.partialMarketFlag = params?.partialMarketFlag;
      this.amendedCarrierRef = params?.amendedCarrierRef;
      this.partialMarketId = params?.partialMarketId;
      this.premiumId = params?.premiumId;
      if (params?.transactionType) {
        this.transactionType = params?.transactionType;
      }

      //
      this.csnd = params?.csnd;
      if (!this.partialMarketFlag) {
        this.sectionDetailsStoreService.getSectionData(this.marketId, false);
      }
      if (this.partialMarketFlag && this.amendedCarrierRef) {
        this.amendedAndPartial = false;
      }

      this.isFromEnquiry = hasEnquirySubmissionId(params);
      this.corrSubmissionId = params.corrSubmissionId;
      this.workflowSubmissionId = params?.workflowSubmissionId;
      this.isEditMode = params?.editMode;
      this.resetSubmissionData();
      this.marketDetailsBusinessRulesService.reset();
    }
    this.marketAccordionIndex = +params?.market_no;
  }

  @Input() set sidePanelDataItem(sidePanelDataItem: SubmissionNavRec) {
    if (sidePanelDataItem) {
      this.sidePanelDataItemData = sidePanelDataItem;
      const isAuditFlow = sidePanelDataItem.status === SubmissionStatuses.AuditFailed;
      this.isBackToCorrection = sidePanelDataItem?.correctionType && !isAuditFlow;
      this.correctionType = sidePanelDataItem?.correctionType;
      this.transactionTypeVal = sidePanelDataItem?.transactionType;
    }
  }

  @Input() set sectionDetails(sectionData: SectionDetail) {
    // get from policyPeriod date and splitting year from it
    this.sectionData = sectionData;
    this.sectionDataContractFromDate = sectionData?.contractDetails?.policyPeriod?.from;
    this.yearOfAccount = +this.sectionDataContractFromDate?.split(/[-]/)[0];
    this.selectPremiumDataItems();
    if (!this.partialMarketFlag) {
      this.marketDetailsStoreService.getMarketData(this.marketId, false);
      return;
    }
  }

  @Input() set submissionData(submissions: SubmissionNavRec[]) {
    if (submissions?.length) {
      this.submissionRef = submissions;
      this.resetSubmissionData();
    }

    if (this.submissionId) {
      this.summaryStoreService
        ?.getSelectedSummaryById(this.submissionId)
        ?.pipe(takeUntil(this.destroy$))
        .subscribe((res) => {
          this.transactionType = res?.submission?.transactionType?.typeOfTransactionType;
          const slipType = res?.submission?.slipType as RefSlipType;
          this.slipTypeString = slipType?.refSlipTypeValue;
        });
    }
  }

  @Input() set validationErrors(validationErrors: ValidationErrors) {
    const messages = validationErrors?.map((message) => this.translate.instant(message));

    if (messages.length) {
      this.multiMsgAlertService.buildMultiMsgAlert(messages);
      ScrollUp(0, 0);
    }
  }
  @Output() searchMarketByMarketIdEvent = new EventEmitter<string>();

  @ViewChild('facilityNumberAndDate') facilityNumberAndDate: NumberDateInputComponent;
  @ViewChild('correctionRAWarningAlert') correctionRAWarningAlert: AlertWithLinkComponent;

  constructor(
    private formBuilder: FormBuilder,
    private marketDetailsStoreService: MarketDetailsStoreService,
    private router: Router,
    private globalAlertStoreService: GlobalAlertStoreService,
    private sidePanelStoreService: SidePanelStoreService,
    private sectionDetailsStoreService: SectionDetailsStoreService,
    private userInfo: UserInfoService,
    private summaryStoreService: SummaryStoreService,
    private store: Store<AppState>,
    private marketDetailsBusinessRulesService: MarketDetailsBusinessRulesService,
    private translate: TranslateService,
    private multiMsgAlertService: MultiMsgAlertService
  ) {}

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  ngOnInit(): void {
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.isSecondFdoOn = false;
    this.selectSubmissionSummaries();
    this.checkIfGetMarketInfosAlreadyCalled();
  }

  selectSubmissionSummaries(): void {
    this.summaryStoreService
      .selectSummaryData()
      .pipe(takeUntil(this.destroy$))
      .subscribe((res) => {
        this.submissionSummaries = res;
      });
  }

  updateQueryParams(newMarketId: string, newPartialMarketId: string): void {
    // Get the current URL tree
    const urlTree = this.router.parseUrl(this.router.url);
    // Update the query params
    urlTree.queryParams = { ...urlTree.queryParams, marketId: newMarketId, partialMarketId: newPartialMarketId };
    // Navigate to the updated URL
    this.router.navigateByUrl(urlTree);
  }

  selectPremiumDataItems(): void {
    this.sectionDetailsStoreService
      .selectPremiumData()
      .pipe(takeUntil(this.destroy$))
      .subscribe((premiumData) => {
        this.premiumDataRef = premiumData;
        if (premiumData) {
          this.marketDetailsControls?.lineslipInstruction?.setValue(this.premiumDataRef?.lineSlipInstructions);
        }

        if (premiumData?.partialMarketId && this.partialMarketFlag) {
          this.updateQueryParams(premiumData?.sectionId, premiumData?.partialMarketId);

          if (typeof this.partialMarketFlag === 'string') {
            this.marketDetailsStoreService.getMarketData(premiumData?.partialMarketId, this.partialMarketFlag);
          } else {
            this.marketDetailsStoreService.getMarketData(premiumData?.partialMarketId, this.partialMarketFlag[0]);
          }
        }
      });
  }

  // get form controls
  get marketDetailsControls(): any {
    return this.marketDetailsForm?.controls;
  }

  get marketDetailsFormArray(): FormArray {
    return this.marketDetailsForm?.get('syndicates') as FormArray;
  }
  set marketDetailsFormArray(formArray: FormArray) {
    this.marketDetailsForm.setControl('syndicates', formArray);
  }

  get syndicateNumberFieldName(): string {
    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS) {
      return 'MARKET_DETAILS.SYNDICATE_NO';
    }
    return 'MARKET_DETAILS.COMPANY_CODE';
  }

  get syndicatePercentageFieldName(): string {
    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS) {
      return 'MARKET_DETAILS.SYNDICATE';
    }
    return 'MARKET_DETAILS.COMPANY_PER';
  }

  get syndicateReferenceFieldName(): string {
    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS) {
      return 'MARKET_DETAILS.SYNDICATE_REFERENCE';
    }
    return 'MARKET_DETAILS.COMPANY_REF_ONE';
  }

  isYearOfAccountDeprecated(yearOfAccount: string = ''): boolean {
    if (this.onCheckScreenView() !== PREMIUM_SCREEN_VIEW.LLOYDS) {
      return false;
    }

    if (this.infoHeaderDetails?.workPackageRef?.toLowerCase()?.startsWith('e')) {
      return false;
    }

    const sectionRiskCode = this.sectionData?.riskCode;
    if (!sectionRiskCode || !yearOfAccount || yearOfAccount.length < 4) {
      return false;
    }

    const riskCode = this.referenceRiskCodes?.find(
      (code) => code.riskCode.toLowerCase() === sectionRiskCode.toLowerCase()
    );

    if (!riskCode || !riskCode.deprecatedDate) {
      return false;
    }

    const effectiveDate = new Date(yearOfAccount + '-01-01');
    const deprecatedDate = new Date(riskCode.deprecatedDate);

    return effectiveDate.getTime() >= deprecatedDate.getTime();
  }

  effectiveDateValidator(): ValidatorFn {
    return (control: AbstractControl) => {
      return (this.isYearOfAccountDeprecated(control.value) && { deprecatedYearOfAccount: true }) || null;
    };
  }

  back(): void {
    // navigate to last premium in last section if the current market id is the first one on the submission markets ids.
    if (this.currentMarketIdIndex === 0) {
      const transactionType = transctionType(this.lastSectionLastPremium?.transactionType?.typeOfTransactionType);
      this.router.navigateByUrl(this.lastPremiumDetailsUrl(transactionType));
    } else {
      if (this.partialMarketFlag && this.currentMarketIdIndex !== 0) {
        const transactionType = transctionType(this.lastSectionLastPremium?.transactionType?.typeOfTransactionType);
        this.router.navigateByUrl(this.lastPremiumDetailsUrl(transactionType));
      } else {
        // navigate to previous market id if the current market id is not the first one on the submission markets ids.
        const prevMarketId = this.submissionMarketsIds[this.currentMarketIdIndex - 1];
        this.router.navigateByUrl(this.marketDetailsUrl(prevMarketId));
      }
    }
  }

  configureInitSyndicateForm(marketDetails?: MarketRecord): void {
    this.totalLineNo = 0;
    if (this.marketData?.syndicates?.length) {
      marketDetails?.syndicates?.forEach((syndicate: MarketSyndicate, i) => {
        this.isChecked[i] = syndicate?.modifySyndicateReference;
        this.isCheckedFromResponse[i] = syndicate?.modifySyndicateReference;
        this.isPseudonymDisabled[this.totalLineNo] = false;
        if (syndicate?.isConsortium) {
          this.isPseudonymDisabled[this.totalLineNo] = true;
        }
        this.marketDetailsFormArray?.push(this.initSyndicateForm(syndicate));
      });
    } else {
      for (let i = 0; i < 10; i++) {
        this.marketDetailsFormArray?.push(this.initSyndicateForm());
      }
    }
  }

  copySection(id: string): void {
    // retrieve the market data
    if (id.trim()) {
      this.marketDetailsStoreService.getMarketData(id, false, true, this.marketData);
    }
  }

  getFacilityNumberAndDateFormat(marketDetails?: MarketRecord): string {
    return marketDetails?.facilityNumberAndDate?.replace(/(\d{4})(\d{2})(\d{2})(\d{5})/, '$1-$2-$3-$4');
  }
  // initiate MarketDetails Form
  initMarketDetailsForm(marketDetails?: MarketRecord): void {
    this.marketDetailsForm = this.formBuilder.group({
      marketId: [marketDetails?.marketId],
      submissionId: [marketDetails?.submissionId],
      sectionId: [marketDetails?.sectionId],
      marketTitle: [marketDetails?.marketTitle],
      lineslipInstruction: [this.premiumDataRef?.lineSlipInstructions],
      bureauLinePercent: [
        {
          value: marketDetails?.bureauLinePercent,
          disabled:
            this.screenView === PREMIUM_SCREEN_VIEW.LLOYDS_OP ||
            this.screenView === PREMIUM_SCREEN_VIEW.COMPANY_OP ||
            this.screenView === PREMIUM_SCREEN_VIEW.COMPANY_XL,
        },
        isPercentage(),
      ],
      yearOfAccount: [marketDetails?.yearOfAccount || null, isYear()],
      sectionLead: [marketDetails?.sectionLead || ''],
      syndicates: this.formBuilder.array([]),
      createdDate: [marketDetails?.createdDate],
      lastUpdatedDate: [new Date()],
      facilityNumberAndDate: [marketDetails?.facilityNumberAndDate],
      modifyRef: [false],
    });
    this.yearOfAccountWarning = '';
  }

  getErrorMessage(errors: ValidationErrors): string {
    if (errors?.invalidNumberDate || errors?.invalidNumber || errors?.invalidDate) {
      return 'MARKET_DETAILS.YOA_NUMBER_DATE_ERROR_MESSAGE';
    } else if (errors?.invalidDateRange) {
      return 'MARKET_DETAILS.YOA_RANGE_VALIDATION_MSG';
    }
  }
  // initiate syndicateForm
  initSyndicateForm(syndicate?: MarketSyndicate): FormGroup {
    const syndicateNumber = syndicate?.syndicateNumber || '';
    const syndicateNumberControl = this.formBuilder.control(syndicateNumber);

    syndicateNumberControl.setValidators([...this.validateSyndicateNumber()]);
    syndicateNumberControl.updateValueAndValidity();
    return this.formBuilder.group({
      marketSyndicateId: [syndicate?.marketSyndicateId ?? uuid()],
      lineNumber: [++this.totalLineNo],
      marketId: [this.marketData?.marketId],
      partyId: [syndicate?.partyId || ''],
      partyMarketId: [syndicate?.partyMarketId || ''],
      syndicateNumber: syndicateNumberControl,
      syndicatePseudonym: [syndicate?.syndicatePseudonym || '', isString(0, 3)],
      syndicatePercentage: [syndicate?.syndicatePercentage || '', isPercentage()],
      syndicateReference: [
        syndicate?.syndicateReference || '',
        this.syndicateReferenceFieldName === 'MARKET_DETAILS.SYNDICATE_REFERENCE'
          ? onlyAlphabetsNumbers(0, 12)
          : onlyAlphabetsNumbers(0, 13),
      ],
      syndicateSecondaryReference: [syndicate?.syndicateSecondaryReference || '', isString(0, 13)],
      syndicateSpecialInstructions: [syndicate?.syndicateSpecialInstructions],
      commuted: syndicate?.commuted ? syndicate?.commuted : false,
      removedFromPartial: syndicate?.removedFromPartial ? syndicate?.removedFromPartial : false,
      modifySyndicateReference: syndicate?.modifySyndicateReference || '',
      consortiumSyndicates: [syndicate?.consortiumSyndicates],
      isConsortium: [syndicate?.isConsortium],
    });
  }

  validateSyndicateNumber(): any {
    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS) {
      return isPositiveNumInteger(0, 4);
    } else if (this.bureau === 'LIRMA') {
      return isString(0, 5);
    }
    return isPositiveNumInteger(0, 7);
  }

  // this function was return party validation
  checkValidation(value: string): boolean {
    return this.invalidSyndicateNumbers?.includes(+removeCommaSeparator(value));
  }

  // Set Required For All Controls When Click On Next Btn
  setRequiredForAllControls(): void {
    // bureauLinePercent should be required only in all transaction types except OP

    if (
      !(
        this.screenView === PREMIUM_SCREEN_VIEW.LLOYDS_OP ||
        this.screenView === PREMIUM_SCREEN_VIEW.COMPANY_OP ||
        this.screenView === PREMIUM_SCREEN_VIEW.COMPANY_XL ||
        this.screenView === PREMIUM_SCREEN_VIEW.LLOYDS_FDO_OP
      )
    ) {
      this.marketDetailsControls.bureauLinePercent?.setValidators([Validators.required, ...isPercentage()]);
      this.marketDetailsControls.bureauLinePercent.updateValueAndValidity();
    }

    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS) {
      // yearOfAccount
      this.marketDetailsControls.yearOfAccount.setValidators([...isYear(true), this.effectiveDateValidator()]);
      this.marketDetailsControls.yearOfAccount.markAsTouched();
      this.marketDetailsControls.yearOfAccount.updateValueAndValidity();
    }

    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS && !this.partialMarketFlag) {
      this.marketDetailsControls.sectionLead.setValidators([this.sectionLeadSyndicateNumbersValidator()]);
      this.marketDetailsControls.sectionLead.updateValueAndValidity();
    }

    if (this.onCheckScreenView() === this.premiumScreenView.COMPANY && !this.partialMarketFlag) {
      this.marketDetailsControls.sectionLead.setValidators([
        Validators.required,
        this.sectionLeadSyndicateNumbersValidator(),
      ]);
      this.marketDetailsControls.sectionLead.updateValueAndValidity();
    }

    this.marketDetailsFormArray?.controls?.forEach((ctrl: any, i) => {
      const controls = ctrl.controls;

      // syndicateNumber
      controls.syndicateNumber.setValidators([Validators.required, ...this.validateSyndicateNumber()]);
      controls.syndicateNumber.updateValueAndValidity();
      if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS && !this.isPseudonymDisabled[i]) {
        // syndicatePseudonym
        controls.syndicatePseudonym.setValidators([Validators.required, ...isString(0, 3)]);
        controls.syndicatePseudonym.updateValueAndValidity();
      }

      // syndicatePercentage
      controls.syndicatePercentage.setValidators([Validators.required, ...isPercentage()]);
      controls.syndicatePercentage.updateValueAndValidity();

      // syndicateReference
      const isSyndicateReferenceRequired = this.isChecked[i] === undefined || !this.isChecked[i] ? true : false;
      controls.syndicateReference.setValidators(onlyAlphabetsNumbers(0, 13, isSyndicateReferenceRequired));
      controls.syndicateReference.updateValueAndValidity();
    });
  }

  // Remove Required For FormArray Controls When Click On Add Row Btn
  removeRequiredForAllControls(): void {
    const formArray = this.marketDetailsForm.get('syndicates') as FormArray;
    const idx = formArray?.controls?.length - 1;
    const control = formArray.at(idx) as any;

    // syndicateNumber
    control.controls.syndicateNumber.setValidators([...this.validateSyndicateNumber()]);
    control.controls.syndicateNumber.updateValueAndValidity();

    // syndicatePseudonym
    control.controls.syndicatePseudonym.setValidators(isString(0, 3));
    control.controls.syndicatePseudonym.updateValueAndValidity();

    // syndicatePercentage
    control.controls.syndicatePercentage.setValidators(isPercentage());
    control.controls.syndicatePercentage.updateValueAndValidity();

    // syndicateReference
    control.controls.syndicateReference.setValidators(onlyAlphabetsNumbers(0, 13));
    control.controls.syndicateReference.updateValueAndValidity();
  }

  // Reset All Controls When Click On Save Btn

  resetAllControls(): void {
    // bureauLinePercent
    this.marketDetailsControls.bureauLinePercent?.setValidators([...isPercentage()]);
    this.marketDetailsControls.bureauLinePercent.updateValueAndValidity();

    // yearOfAccount
    this.marketDetailsControls.yearOfAccount.setValidators([...isYear()]);
    this.marketDetailsControls.yearOfAccount.updateValueAndValidity();

    this.marketDetailsControls.sectionLead.clearValidators();
    this.marketDetailsControls.sectionLead.updateValueAndValidity();
    const formArray = this.marketDetailsForm.get('syndicates') as FormArray;

    formArray.controls.forEach((ctrl: any) => {
      // syndicateNumber
      ctrl.controls.syndicateNumber.setValidators([...this.validateSyndicateNumber()]);
      ctrl.controls.syndicateNumber.updateValueAndValidity();

      // syndicatePseudonym
      ctrl.controls.syndicatePseudonym.setValidators(isString(0, 3));
      ctrl.controls.syndicatePseudonym.updateValueAndValidity();

      // syndicatePercentage
      ctrl.controls.syndicatePercentage.setValidators(isPercentage());
      ctrl.controls.syndicatePercentage.updateValueAndValidity();

      // syndicateReference
      ctrl.controls.syndicateReference.setValidators(isString(0, 13));
      ctrl.controls.syndicateReference.updateValueAndValidity();
    });
  }

  onCheckScreenView(): string {
    const screenViewType = this.userInfo.getScreenViewType();
    if (screenViewType) {
      this.screenView = screenViewType;
      return CheckScreenView(this.screenView);
    }
  }

  onExpectedBureauScreenView(bureauValue: TechnicianPortalBureauEnum): boolean {
    return this.onCheckScreenView() === this.premiumScreenView.COMPANY && this.bureau === bureauValue;
  }

  getSectionNumber(marketTitle: string): number {
    const splitExpression = marketTitle?.split(':');
    return splitExpression?.length ? parseInt(splitExpression[0].toLocaleLowerCase().replace('s', ''), 0) : 0;
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.submitted, formControl, input);
  }

  getValidationSelectStatus(formControl: AbstractControl, select: DxcSelectComponent): boolean {
    return ValidationSelectStatus(this.submitted, formControl, select);
  }

  // get next Premium
  nextPremiumDetailsUrl(transactionType: TypeOfPremium): string {
    const premiumId = this.nextSectionNextPremium?.premiumId;
    return this.getPremiumDetailsUrl(transactionType, premiumId);
  }

  //  get last Premium
  lastPremiumDetailsUrl(transactionType: TypeOfPremium): string {
    const premiumId = this.lastSectionLastPremium?.premiumId ? this.lastSectionLastPremium?.premiumId : this.premiumId;
    return this.getPremiumDetailsUrl(transactionType, premiumId);
  }

  getPremiumDetailsUrl(transactionType: TypeOfPremium, premiumId: string): string {
    const transactionTypeData = transactionType ? transactionType : this.transactionType;
    let url = `${PREMIUM_URL}${this.bureau}/${transactionTypeData}?${STATUS_SECTION_NO}${this.marketAccordionIndex}&${PREMIUM_ID}=${premiumId}&${SUBMISSION_ID}=${this.marketData?.submissionId}&bureau=${this.bureau}`;
    if ((this.isFromEnquiry && !this.partialMarketFlag) || this.isEditMode) {
      url = addEnquiryQueryParam(url, this.marketData?.submissionId, this.csnd);
    }
    if (this.isEditMode) {
      url += `&editMode=${this.isEditMode}`;
    }
    if (this.corrSubmissionId) {
      url += `&corrSubmissionId=${this.corrSubmissionId}`;
    }
    if (this.workflowSubmissionId) {
      url += `&workflowSubmissionId=${this.workflowSubmissionId}`;
    }
    return url;
  }

  limitCharacters(event: KeyboardEvent, value: number, limit: number): void {
    LimitCharacters(event, +value, limit);
  }

  marketDetailsUrl(marketIdValue: string): string {
    let url = `${MARKET_URL}${this.marketAccordionIndex}&${marketId}=${marketIdValue}&${submissionId}=${this.marketData.submissionId}&bureau=${this.bureau}`;

    if (this.isFromEnquiry || this.isEditMode) {
      url = addEnquiryQueryParam(url, this.marketData.submissionId, this.csnd);
    }
    if (this.isEditMode) {
      url += `&editMode=${this.isEditMode}`;
    }
    if (this.corrSubmissionId) {
      url += `&corrSubmissionId=${this.corrSubmissionId}`;
    }
    if (this.workflowSubmissionId) {
      url += `&workflowSubmissionId=${this.workflowSubmissionId}`;
    }
    if (this.partialMarketFlag) {
      url += `&partialMarketFlag=true&}&partialMarketId=${this.partialMarketId}&premiumId=${this.premiumId}&transactionType=${this.transactionType}`;
    }
    return url;
  }

  getSelectValue(value): void {
    this.rowNum = Number(value);
  }

  onAddRow(formArrayName: FormArray, formGroupName: FormGroup, btnId: string): void {
    const previousTotalRows = formArrayName.length;

    for (let i = 0; i < this.rowNum; i++) {
      formArrayName?.push(this.initSyndicateForm());
      this.isExpanded[previousTotalRows + i] = false;
    }
    ScrollToElement(btnId, { block: 'nearest', inline: 'nearest' });
    this.removeRequiredForAllControls();
  }

  onDeleteRow(formArrayName: string, index: number, btnId: string): void {
    const marketDetailsFormArray = this.marketDetailsForm.get(formArrayName) as FormArray;
    const checkboxIndex = index - 1;
    marketDetailsFormArray.removeAt(index);
    this.isPseudonymDisabled = this.isPseudonymDisabled.filter((item, i) => i !== index);
    this.isChecked = this.isChecked.filter((item, i) => i !== checkboxIndex);
    ScrollToElement(btnId, { block: 'nearest', inline: 'nearest' });
  }

  checkRemovedFromPartial(value: boolean, removedFromPartialControl?: AbstractControl, indexItem?: number): void {
    const marketDetailsFormArrayFiltered = this.marketDetailsFormArray.controls.filter(
      (element) => element.value.removedFromPartial !== true
    );
    if (marketDetailsFormArrayFiltered.length > 1 || value === false) {
      this.removedFromPartialCheck = value;
      removedFromPartialControl.setValue(value);
      let accumulatorValueBureauLinePercent = 0;
      if (marketDetailsFormArrayFiltered.length > 0) {
        accumulatorValueBureauLinePercent = 0;
        marketDetailsFormArrayFiltered.forEach((element) => {
          accumulatorValueBureauLinePercent += +element.value.syndicatePercentage;
        });
      } else {
        accumulatorValueBureauLinePercent = 0;
      }
      this.marketDetailsControls?.bureauLinePercent.setValue(accumulatorValueBureauLinePercent);
      const marketPayload: MarketRecord = {
        ...this.marketDetailsForm.value,
        bureauLinePercent: this.marketDetailsControls.bureauLinePercent.value,
        recordValid: true,
      };
      this.marketDetailsStoreService.updateMarketData(marketPayload, true, '', this.partialMarketFlag);
    } else {
      this.displayWarninngBanner = true;
      ScrollUp(0, 0);
    }
  }

  isBusinessRulesValid(payload: MarketRecord): boolean {
    const validators = { ...marketValidationFunctions };
    const validationErrors = this.marketDetailsBusinessRulesService.validate(
      {
        slipType: this.slipTypeString,
        payload,
        bureau: this.bureau,
        premiumPayload: this.premiumDataRef,
        marketData: this.marketData,
        transalateService: this.translate,
        transactionType: this.transactionType,
        sidePanelDataItemData: this.sidePanelDataItemData,
      },
      Object.values(validators)
    );

    return !validationErrors?.length;
  }

  saveDraftNext(submitType: SUBMIT_TYPES): void {
    this.saveDraftStatus = submitType === SUBMIT_TYPES.SAVE;
    this.setNextStepUrl();
    if (this.isFromEnquiry) {
      this.router.navigateByUrl(this.nextStepUrl);
      return;
    }
    if (!this.saveDraftStatus) {
      this.removeEmptyFormGroups();

      // calculate syndicatePercentage values on next btn clicking
      this.totalSyndicatePercentage = this.marketDetailsFormArray?.controls.reduce(
        (acc, control) => acc + +removeCommaSeparator(control?.get('syndicatePercentage').value),
        0
      );
      this.isSyndicatePercentExceeds100 = this.totalSyndicatePercentage > 100;
      this.setRequiredForAllControls();
    } else if (this.saveDraftStatus) {
      this.resetAllControls();
    }
    this.currentMarketIdIndex = this.submissionMarketsIds?.indexOf(this.marketId);
    if (this.signedTransactionStatus && !this.isEditMode) {
      this.router.navigateByUrl(this.nextStepUrl);
      return;
    }

    this.submit();
  }

  submit(): void {
    this.patchSyndicateForm(this.syndicates, this.syndicateNumberIndex, this.syndRef, true, true);
    const facilityNumberAndDate = this.marketDetailsControls?.facilityNumberAndDate?.value;
    const marketPayload: MarketRecord = {
      ...this.marketDetailsForm.value,
      bureauLinePercent: this.marketDetailsControls.bureauLinePercent.value,
      recordValid: this.isHeritageRecord
        ? this.saveDraftStatus
          ? this.marketData?.recordValid === undefined
            ? false
            : this.marketData?.recordValid
          : true
        : !this.saveDraftStatus,
      facilityNumberAndDate:
        facilityNumberAndDate?.replaceAll !== undefined ? facilityNumberAndDate?.replaceAll('-', '') : null,
      yoaChanged: this.yoaChanged,
    };

    // Business Rules Validations Check
    if (!this.saveDraftStatus && !this.isBusinessRulesValid(marketPayload)) {
      ScrollUp(0, 0);
      return;
    }

    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const payloadMarketXis: MarketDetailsInput = {
      bureau: this.bureau,
      bureauLinePercent: this.marketDetailsControls?.bureauLinePercent?.value,
      midTermMarketChangeIndicator: this.marketData?.midTermMarketChangeIndicator?.toString(),
      slipType: this.infoHeaderDetails.slipType,
      currentYearNo: currentYear,
      marketSyndicates: this.marketDetailsFormArray.controls.map((group) => ({
        syndicateReference: group.get('syndicateReference').value,
        percentage: group.get('syndicatePercentage').value,
        pseudonym: group.get('syndicatePseudonym').value,
        syndicateNumber: group.get('syndicateNumber').value,
        syndicateSecondaryReference: group.get('syndicateSecondaryReference').value,
      })),
    };
    if (this.marketDetailsForm.invalid || this.isSyndicatePercentExceeds100) {
      this.submitted = true;
      return;
    } else {
      this.submitted = false;
    }
    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS) {
      const yearOfAccountFormValue = this.marketDetailsControls?.yearOfAccount?.value;
      payloadMarketXis.yearOfAccount = yearOfAccountFormValue ? yearOfAccountFormValue : this.yearOfAccount;
    }

    // Correction R & A Validation
    if (
      !this.saveDraftStatus &&
      !this.overrideCorrectionRAWarning &&
      !this.isValidCorrectionRAValidations(marketPayload)
    ) {
      this.correctionRAWarningAlert.openAlert();
      ScrollUp(0, 0);
      return;
    }

    const payloadPartsValidation = this.buildPartyRequest();
    if (
      this.bureau === this.premiumScreenView.LLOYDS &&
      (this.screenView === this.premiumScreenView.LLOYDS_OP ||
        this.screenView === this.premiumScreenView.LLOYDS_FDO_OP) &&
      !this.saveDraftStatus
    ) {
      if (this.partialMarketFlag) {
        this.sectionDetailsStoreService
          .selectSectionData()
          .pipe(
            take(1),
            tap((sectionDetail) => {
              const payloadMarketRI = this.buildDmnRequest(sectionDetail?.eeaRiskFlag);
              this.marketDetailsStoreService.updateMarketDataRI(
                payloadMarketRI,
                marketPayload,
                this.saveDraftStatus,
                this.nextStepUrl,
                payloadMarketXis,
                this.partialMarketFlag
              );
            })
          )
          .subscribe();
      } else {
        this.sectionDetailsStoreService
          .selectSectionData()
          .pipe(
            take(1),
            tap((sectionDetail) => {
              const payloadMarketRI = this.buildDmnRequest(sectionDetail?.eeaRiskFlag);
              this.marketDetailsStoreService.updateMarketDataParties(
                this.bureau,
                payloadPartsValidation,
                payloadMarketRI,
                marketPayload,
                this.saveDraftStatus,
                this.nextStepUrl,
                payloadMarketXis
              );
            })
          )
          .subscribe();
      }
    } else if (!this.saveDraftStatus) {
      if (this.partialMarketFlag) {
        this.sectionDetailsStoreService
          .selectSectionData()
          .pipe(
            take(1),
            tap((sectionDetail) => {
              const payloadMarketRI = this.buildDmnRequest(sectionDetail?.eeaRiskFlag);
              this.marketDetailsStoreService.updateMarketDataRI(
                payloadMarketRI,
                marketPayload,
                this.saveDraftStatus,
                this.nextStepUrl,
                payloadMarketXis,
                this.partialMarketFlag
              );
            })
          )
          .subscribe();
      } else {
        this.sectionDetailsStoreService
          .selectSectionData()
          .pipe(
            take(1),
            tap((sectionDetail) => {
              const payloadMarketRI = this.buildDmnRequest(sectionDetail?.eeaRiskFlag);
              this.marketDetailsStoreService.updateMarketDataParties(
                this.bureau,
                payloadPartsValidation,
                payloadMarketRI,
                marketPayload,
                this.saveDraftStatus,
                this.nextStepUrl,
                payloadMarketXis
              );
            })
          )
          .subscribe();
      }
    } else {
      this.marketDetailsStoreService.updateMarketData(
        marketPayload,
        this.saveDraftStatus,
        this.nextStepUrl,
        this.partialMarketFlag
      );
    }
  }

  isValidCorrectionRAValidations(marketRecord: MarketRecord): boolean {
    if (this.correctionType !== this.correctionTypeEnum.RA) {
      return true;
    }
    if (!this.isAnySyndicateRefChanged(marketRecord)) {
      return true;
    }
    if (!this.hasAnyAssociatedSignings()) {
      return true;
    }
    return false;
  }

  // Corrections RA Validation to check if the user changed any of the syndicate reference fields
  isAnySyndicateRefChanged(marketRecord: MarketRecord): boolean {
    const oldSyndicateRefs = this.marketData?.syndicates;
    const newSyndicateRefs = marketRecord?.syndicates;
    return newSyndicateRefs?.some(
      (newSyndicate) =>
        oldSyndicateRefs?.find((oldSyndicate) => oldSyndicate?.marketSyndicateId === newSyndicate?.marketSyndicateId)
          ?.syndicateReference !== newSyndicate?.syndicateReference
    );
  }

  // Check if OP Premium of the Correction Type RA has any Associated signings (APs/RPs)
  hasAnyAssociatedSignings(): boolean {
    return hasAnyAssociatedSignings(this.sidePanelDataItemData, this.marketData?.sectionId, this.submissionSummaries);
  }

  onClickCorrectionAlertLink(): void {
    this.overrideCorrectionRAWarning = true;
    this.saveDraftNext(this.submitTypes.NEXT);
  }

  removeEmptyFormGroups(): void {
    const formArray = this.marketDetailsFormArray as FormArray;
    for (let i = formArray.length - 1; i >= 1; i--) {
      const formGroup = formArray.at(i) as FormGroup;
      const control = formGroup.get('syndicateNumber');
      const controlSynPer = formGroup.get('syndicatePercentage');
      const controlSynRef = formGroup.get('syndicateReference');
      if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS) {
        const controlSynPseu = formGroup.get('syndicatePseudonym');
        this.isEmpty = !control.value && !controlSynPseu.value && !controlSynPer.value && !controlSynRef.value;
      } else {
        const ctrCompanyRef2 = formGroup.get('syndicateSecondaryReference');
        this.isEmpty = !control.value && !ctrCompanyRef2.value && !controlSynPer.value && !controlSynRef.value;
      }

      if (this.isEmpty) {
        formArray.removeAt(i);
      }
    }
  }

  clearValidators(formGroup: FormGroup): void {
    for (const controlName in formGroup.controls) {
      if (formGroup.controls.hasOwnProperty(controlName)) {
        const control = formGroup.controls[controlName];
        control.clearValidators();
        control.updateValueAndValidity();
      }
    }
  }

  private buildPartyRequest(): PartyRequest {
    const partySyndicateNumbers = [];
    this.marketDetailsForm.value.syndicates.forEach((element) => {
      partySyndicateNumbers.push({ partyReference: removeCommaSeparator(element?.syndicateNumber) });
    });
    const payloadPartsValidation: PartyRequest = {
      bureau: this.bureau,
      partyReferences: partySyndicateNumbers,
      effectiveDate: this.sectionDataContractFromDate || formatDate(new Date(), 'yyyy-MM-dd', 'en-US'),
      retrieveassociatedLMR: false,
    };
    return payloadPartsValidation;
  }

  private buildDmnRequest(eeaFlag: boolean = false): ValidateSyndicateNumbersInput {
    const syndicateNumber: string[] = map(this.marketDetailsFormArray.value, (value) => {
      return removeCommaSeparator(value.syndicateNumber);
    });
    return {
      eeaFlag: eeaFlag?.toString(),
      syndicateNumber,
    };
  }

  setMarketsCopyOptions(sections: string[]): void {
    const sectionsOptions = map(sections, (id: string, index: number) => ({
      value: id,
      label: `${SECTION} ${index + 1}`,
    }));
    this.marketSectionOptions = [{ label: SELECT, value: ' ' }, ...sectionsOptions];
  }

  setNextStepUrl(): void {
    // navigate to AP partial Market true.
    if (this.partialMarketFlag) {
      // get next item of array
      const currentAPRPItemIndex = this.sidePanelDataItemData.aprpItems?.findIndex(
        (market: PremiumNavRec) => market?.premiumId === this.premiumId
      );
      const nextAPRPItem = this.sidePanelDataItemData.aprpItems[currentAPRPItemIndex + 1];
      if (
        (this.sidePanelDataItemData.aprpItems.length === 1 &&
          this.submissionMarketsIds?.indexOf(this.marketId) === 0) ||
        nextAPRPItem?.premiumId === this.premiumId
      ) {
        this.nextStepUrl = this.signingDetailsUrl();
      } else {
        //  navigate to next AP/RP premium
        if (nextAPRPItem) {
          this.nextSectionNextPremium = nextAPRPItem;
          const transactionType = transctionType(this.nextSectionNextPremium?.transactionType?.typeOfTransactionType);
          this.nextStepUrl = this.nextPremiumDetailsUrl(transactionType);
        } else {
          // navigate to signing details
          this.nextStepUrl = this.signingDetailsUrl();
        }
      }
      return;
    } else {
      // navigate to signing details if the current market id is the last one on the submission markets ids.
      if (this.currentMarketIdIndex === this.submissionMarketsIds.length - 1) {
        this.nextStepUrl = this.signingDetailsUrl();
      } else {
        // navigate to next market id if the current market id is not the last one on the submission markets ids.
        this.currentMarketIdIndex = this.currentMarketIdIndex === undefined ? 0 : this.currentMarketIdIndex;
        const nextMarketId = this.submissionMarketsIds[this.currentMarketIdIndex + 1];
        this.nextStepUrl = this.marketDetailsUrl(nextMarketId);
      }
    }
  }

  setSelectValue(formControl: AbstractControl, value: string, refKey?: string): void {
    onSelectChange(formControl, value);
  }

  signingDetailsUrl(): string {
    let url = `${signingDetails}?submissionId=${this.marketData.submissionId}&bureau=${this.bureau}&market_no=${this.marketAccordionIndex}&marketsId=${this.marketId}&transactionType=${this.transactionType}`;

    if (this.premiumId) {
      url += `&premiumsId=${this.premiumId}`;
    }
    if (this.isFromEnquiry || this.isEditMode) {
      url = addEnquiryQueryParam(url, this.marketData.submissionId, this.csnd);
    }
    if (this.isEditMode) {
      url += `&editMode=${this.isEditMode}`;
    }
    if (this.corrSubmissionId) {
      url += `&corrSubmissionId=${this.corrSubmissionId}`;
    }
    if (this.workflowSubmissionId) {
      url += `&workflowSubmissionId=${this.workflowSubmissionId}`;
    }
    if (this.partialMarketFlag) {
      url += `&partialMarketFlag=true&partialMarketId=${this.partialMarketId}&premiumId=${this.premiumId}`;
    }

    return url;
  }

  onBackToCorrectionEvent(): void {
    this.showDialog = true;
  }

  yesClicked(): void {
    navigateToCorrection(this.router, this.workflowSubmissionId, this.callback);
  }

  noClicked(): void {
    this.showDialog = false;
  }

  checkWarningBanner(controlName?: string, controlValue?: string): void {
    if (this.correctionType === this.correctionTypeEnum.RA) {
      if (
        controlName === 'syndicatePercentage' &&
        controlValue &&
        (this.bureau === this.bureauView.ILU ||
          this.bureau === this.bureauView.LIRMA ||
          this.bureau === this.bureauView.LLOYDS)
      ) {
        this.displayWarninngBanner = true;
        return;
      }
    }
    this.displayWarninngBanner = false;
  }

  expandToggler(rowId): void {
    if (this.isExpanded[rowId] === undefined) {
      this.isExpanded[rowId] = false;
    }
    this.isExpanded[rowId] = !this.isExpanded[rowId];
  }

  runningSecondeFdo(): void {
    // reset to defaults
    this.marketDetailsStoreService.clearMarketOfFacility();
    this.globalAlertStoreService.clearGlobalResponse();

    const facilityNumberAndDate = this.marketDetailsControls?.facilityNumberAndDate?.value;
    this.marketDetailsStoreService.getMarketOfFacility(facilityNumberAndDate.toString().replace(/-/g, ''));
    this.selectPartyMarketData$ = this.marketDetailsStoreService.selectInfoOfMarketsOfFacility();
    this.selectPartyMarketData$.subscribe((result) => {
      // check date validations - section details period from against results period from and to dates
      // this.setFacilityNumberAndDateValidators(result);

      // if successful results response and no validation error
      if (result && !this.marketDetailsControls?.facilityNumberAndDate.errors?.invalidDateRange) {
        this.fillItemFromMarketInfos(result);
        this.isSecondFdoOn = true;
        this.checkIfGetMarketInfosAlreadyCalled();
        this.isPopulateClicked = true;
        this.collapseAllRows();

        // show successful alert, only if no validation error
        this.store.dispatch(
          loadGlobalAlert({
            response: {
              responseMessage: 'ALERTS.DATA_RETRIEVED',
              status: 200,
              isGlobalAlert: true,
            },
          })
        );
      }
    });
  }

  fillItemFromMarketInfos(result): void {
    this.marketDetailsControls?.sectionLead?.setValue(result?.sectionLead);
    this.marketDetailsFormArray = this.formBuilder.array([]);
    result?.marketSyndicates.map((syndicate, i) => {
      this.isChecked[i] = syndicate?.modifySyndicateReference;
      this.isCheckedFromResponse[i] = syndicate?.modifySyndicateReference;
      this.isPseudonymDisabled[i] = syndicate?.isConsortium ? true : false;
      if (syndicate?.modifySyndicateReference === undefined) {
        this.isChecked[i] = false;
      }
      if (syndicate?.isConsortium) {
        this.handleConsortium(i);
      }
      this.marketDetailsFormArray?.push(this.initSyndicateForm(syndicate));
    });

    if (!this.isConsortium(this.transactionType, this.bureau)) {
      this.disableField = true;
    } else {
      this.isConsortiumS = true;
    }
  }

  setFacilityNumberAndDateValidators(marketsOfFacilityData: FacilityMarketsInfo): void {
    if (marketsOfFacilityData && marketsOfFacilityData.policyPeriodFrom && marketsOfFacilityData.policyPeriodTo) {
      const facilityNumberAndDateControl = this.marketDetailsControls?.facilityNumberAndDate;
      facilityNumberAndDateControl.setValidators([
        NumberDateInputComponentValidator.NumberDateInput,
        FacilityNumberDateRangeValidator.DateRange(
          this.marketData.policyPeriodFrom,
          marketsOfFacilityData.policyPeriodFrom,
          marketsOfFacilityData.policyPeriodTo
        ),
      ]);
      facilityNumberAndDateControl.updateValueAndValidity();
    }
  }

  setPartyMarketDetails(index: number, syndicateNumber: string): void {
    if (this.bureau === 'LLOYDS') {
      this.syndicateNumberIndex = index;
      if (syndicateNumber) {
        const marketPartyPayLod = {
          bureau: this.bureau,
          partyReferences: [
            {
              partyReference: syndicateNumber,
            },
          ],
          effectiveDate: this.sectionDataContractFromDate || formatDate(new Date(), 'yyyy-MM-dd', 'en-US'),
          retrieveassociatedLMR: false,
        };
        this.marketDetailsStoreService.setPartyMarketDetails(marketPartyPayLod);
      }
    }
  }

  onChangeYearOfAccount(event: Event): void {
    const target = event.target as HTMLInputElement;
    // year value is removed or incomplete
    if (target.id === 'yearInput' && target.value.length !== 4) {
      const yearOfAccount = this.yearOfAccount;
      // revert year of account input to default
      if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS && yearOfAccount) {
        this.marketDetailsForm.patchValue({ yearOfAccount });
      }
    }
  }

  clearYearOfAccountRangeValidator(): void {
    // clear validator if YOA input changes
    this.marketDetailsControls?.facilityNumberAndDate.setValidators([
      NumberDateInputComponentValidator.NumberDateInput,
    ]);
    this.marketDetailsControls?.facilityNumberAndDate.updateValueAndValidity();
  }

  overRideYear(year: string): void {
    if (year) {
      this.marketDetailsForm.patchValue({
        yearOfAccount: year,
      });
    }
  }

  isModifySyndicateReferenceAvailable(index: number): boolean {
    return !!this.marketTable && !!this.marketTable[index] && !!this.marketTable[index].modifySyndicateReference;
  }

  checkIfGetMarketInfosAlreadyCalled(): void {
    this.statusOfApiCall$ = this.marketDetailsStoreService.selectStatusOfMarketsOfFacility();
    this.statusOfApiCall$?.pipe(takeUntil(this.destroy$)).subscribe((status) => {
      if (status && this.isSecondFdoOn) {
        this.disableField = true;
      }
    });
  }

  onModifyRefChange(event, index: number): void {
    this.isChecked[index] = event;
    const key = 'controls';
    this.marketDetailsFormArray.at(index)[key]?.modifySyndicateReference?.setValue(event);
    this.marketDetailsFormArray.at(index)[key]?.syndicateReference.setValidators(onlyAlphabetsNumbers(0, 13));
    this.marketDetailsFormArray.at(index)[key]?.syndicateReference.updateValueAndValidity();
  }

  collapseAllRows(): void {
    this.isExpanded = this.isExpanded.map(() => false);
  }

  disableEnableSyndicateReference(): void {
    if (!this.isPopulateClicked && this.isFacilityNumberAndDate) {
      this.isFirstLogicDisabled = true;
      this.disableField = true;
      this.isPopulateClicked = true;
    }
  }

  disableCheckboxAPRP(): void {
    if (
      this.transactionTypeVal?.typeOfTransactionType === 'Additional Premium (AP)' ||
      this.transactionTypeVal?.typeOfTransactionType === 'Return Premium (RP)'
    ) {
      this.disableCheckbox();
      this.isAPRP = true;
    }
  }

  disableCheckbox(): void {
    this.isFirstLogicDisabled = true;
    this.isPopulateClicked = false;
    this.isAPRP = false;
  }

  initFirstFdoPermission(): void {
    this.isSecondFdoOn = false;
    this.isFirstLogicDisabled = false;
    this.disableField = false;
    this.isPopulateClicked = false;
    this.isFacilityNumberAndDate = false;
    this.isPseudonymDisabled = this.isPseudonymDisabled?.map(() => false);
    this.isChecked = this.isChecked?.map(() => false);
  }

  getSyndRefVal(e, index): void {
    this.syndRef = e?.value;
    if (this.syndicateNumberIndex === undefined) {
      this.syndicateNumberIndex = index;
    }
  }

  isConsortium(transactionType, bureau): boolean {
    return isFdoAndMarketLloyds(transactionType, bureau);
  }

  getSyndicateSpecialInstruction(consortium: any): string {
    if (consortium && consortium.syndicateSpecialInstructions && consortium.syndicateSpecialInstructions.length > 0) {
      return consortium.syndicateSpecialInstructions.map((e) => e.specialInstruction || '-');
    }
    return 'No Instructions';
  }

  trackByFn(index: number, item: any): number {
    return item?.id ?? index; // Use a unique identifier if available, otherwise fallback to index
  }

  clearMarketDetailsData(): void {
    this.initMarketDetailsForm();
    this.marketDetailsForm.get('bureauLinePercent').setValue(this.marketData.bureauLinePercent);
    this.resetSyndicatesArray();
    this.facilityNumberAndDate.reset();
    const yearOfAccount = this.yearOfAccount;
    if (this.onCheckScreenView() === this.premiumScreenView.LLOYDS && yearOfAccount) {
      this.marketDetailsForm.patchValue({ yearOfAccount });
    }
    this.disableField = false;
  }

  resetSyndicatesArray(): void {
    const marketDetailsFormArray = this.marketDetailsForm.get('syndicates') as FormArray;
    marketDetailsFormArray.clear();
    this.isPseudonymDisabled = this.isPseudonymDisabled?.map(() => false);
    this.isConsortiumS = false;
    this.isPopulateClicked = false;
    this.isChecked = this.isChecked?.map(() => false);
    this.configureInitSyndicateForm();
  }

  private patchSyndicateForm(
    syndicate: any,
    i: number,
    syndRef?: string,
    modifySyndRef?: boolean,
    isSubmitAction: boolean = false
  ): void {
    this.isPseudonymDisabled[i] = syndicate?.isConsortium ? true : false;
    const formGroup = this.marketDetailsFormArray.at(i) as any;
    const key = 'controls';
    formGroup?.patchValue({
      ...syndicate,
      syndicatePercentage: formGroup[key]?.syndicatePercentage?.value
        ? formGroup[key]?.syndicatePercentage?.value
        : syndicate?.isConsortium
        ? 100
        : null,
      syndicatePseudonym: syndicate?.isConsortium && !isSubmitAction ? '' : formGroup[key]?.syndicatePseudonym?.value,
      isConsortium: syndicate?.isConsortium,
      syndicateSpecialInstructions: syndicate?.syndicateSpecialInstructions,
      consortiumSyndicates: syndicate?.consortiumSyndicates?.map((consortiumSynd) => {
        if (consortiumSynd.syndicateReference) {
          return consortiumSynd;
        } else {
          return {
            ...consortiumSynd,
            syndicateReference: syndRef,
            modifySyndicateReference: modifySyndRef,
          };
        }
      }),
    });

    // Additional logic to update the form based on the conditions
    this.isConsortiumFlage = syndicate?.isConsortium;
    if (this.isConsortiumFlage) {
      this.handleConsortium(i);
    }

    const syndicateReference = syndicate?.syndicateReference;
    if (this.isConsortiumFlage && (syndicateReference === null || syndicateReference === '>')) {
      this.onModifyRefChange(true, i);
    } else if (this.isConsortiumFlage) {
      this.onModifyRefChange(false, i);
    }
  }

  private processConsortiumSyndicates(syndicates: MarketSyndicate): void {
    this.syndicates = syndicates;
    this.patchSyndicateForm(syndicates, this.syndicateNumberIndex);
  }

  private handleConsortium(index: number): void {
    this.collapseAllRows();
    this.expandToggler(index);
  }

  private resetSubmissionData(): void {
    if (this.submissionRef?.length) {
      const submission = find(this.submissionRef, { submissionId: this.submissionId });
      this.sidePanelStoreService.setSidePanelDataItem(submission);
      if (submission && submission?.opItems?.length) {
        this.bureau = submission.bureau;
        this.transactionTypeVal = submission?.transactionType;
        // submission markets ids it's the same as submission sections ids. in opItems
        this.submissionId = submission.submissionId;
        this.submissionMarketsIds = submission.opItems.map((section) => section.sectionId);
        this.setMarketsCopyOptions(this.submissionMarketsIds);
        this.noOfSections = submission?.opItems?.length;
        const sectionPremiums = submission?.opItems?.find((section) => section?.sectionId === this.marketId)?.premiums;
        this.lastSectionLastPremium = last(sectionPremiums);
        this.signedTransactionStatus = getSignedStatusForSubmission(submission);
      } else if (submission && submission?.aprpItems?.length) {
        this.bureau = submission.bureau;
        // submission markets ids it's the same as submission sections ids. in aprpItems
        this.submissionId = submission.submissionId;
        this.submissionMarketsIds = submission.aprpItems.map((section) => section.sectionId);
        this.setMarketsCopyOptions(this.submissionMarketsIds);
        this.noOfSections = submission?.aprpItems?.length;
        const lastSectionPremiums = [
          submission?.aprpItems?.find(
            (section) =>
              (section?.section !== undefined && section?.sectionId === last(this.submissionMarketsIds)) ||
              section?.premiumId === this.premiumId
          ),
        ];
        this.lastSectionLastPremium = last(lastSectionPremiums);
        this.signedTransactionStatus = getSignedStatusForSubmission(submission);
      }
      if (this.lastSectionLastPremium) {
        this.sectionDetailsStoreService.getPremiumData(
          this.lastSectionLastPremium?.premiumId,
          transctionType(this.lastSectionLastPremium?.transactionType?.typeOfTransactionType)
        );
      }

      if (this.signedTransactionStatus) {
        this.disableCheckbox();
      }
    }
  }

  checkYOANumberVisibility(): boolean {
    return (
      this.amendedAndPartial === undefined &&
      (this.transactionTypeVal?.typeOfTransactionType === 'Premium FDO' ||
        this.transactionTypeVal?.typeOfTransactionType === 'Premium') &&
      this.bureau === 'LLOYDS'
    );
  }

  setInvalidSyndicateNumbers(partyMarketDetails: MarketSyndicates): void {
    this.invalidSyndicateNumbers = partyMarketDetails?.map(
      (party: PartyMarketSyndicate) => !party?.partyId && !party?.partyMarketId && +party?.partyReference
    );
  }

  sectionLeadSyndicateNumbersValidator(): ValidatorFn {
    return (control: AbstractControl) => {
      const syndicateNumbers = this.marketDetailsFormArray?.value?.map((value: MarketSyndicate) =>
        value?.syndicateNumber?.trim()?.toLowerCase()
      );
      const sectionLead = control?.value?.trim()?.toLowerCase();
      return (
        (sectionLead &&
          syndicateNumbers?.length &&
          !syndicateNumbers?.includes(sectionLead) && { invalidSectionLead: true }) ||
        null
      );
    };
  }

  getYearOfAccountWarning(marketYearOfAccount: string, facilityNumberAndDate: string): void {
    const sectionPolicyFromDateYear = this.getSectionPolicyFromDateYear();
    this.yearOfAccountWarning = '';
    if (
      marketYearOfAccount &&
      !facilityNumberAndDate &&
      sectionPolicyFromDateYear &&
      sectionPolicyFromDateYear !== +marketYearOfAccount &&
      isLloydsOpScreenView(this.screenView)
    ) {
      this.yearOfAccountWarning = 'MARKET_DETAILS.YEAR_OF_ACCOUNT_WARNING';
      this.displayYOAChangedWarning = 'MARKET_DETAILS.YEAR_OF_ACCOUNT_CHANGED_WARNING';
      this.yoaChanged = true;
    } else {
      this.yoaChanged = false;
      this.displayYOAChangedWarning = '';
    }
  }

  getSectionPolicyFromDateYear(): number {
    return getYearFromDate(this.sectionDataContractFromDate);
  }

  onBlurYearOfAccount(): void {
    this.marketDetailsControls?.yearOfAccount.markAsTouched();
    this.getYearOfAccountWarning(
      this.marketDetailsControls?.yearOfAccount?.value,
      this.marketDetailsControls?.facilityNumberAndDate?.value
    );
  }
}
