import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { MarketSyndicates } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import {
  MarketListRecs,
  MarketRecord,
  PartyMarketDetails,
  PartyResponse,
  SectionDetail,
  SubmissionNavRec,
  TechnicianSVDetails,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { MarketDetailsBusinessRulesService } from '@features/market-details/services/market-details-business-rules.service';
import { MarketDetailsStoreService } from '@features/market-details/services/market-details.store.service';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { ReferenceDataService } from '@shared/services/reference-data/reference-data.service';
import { SidePanelStoreService } from '@shared/services/side-panel/side-panel.store.service';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-main-market-details',
  templateUrl: './main-market-details.component.html',
  styleUrls: ['./main-market-details.component.scss'],
})
export class MainMarketDetailsComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  infoHeaderDetails$: Observable<TechnicianSVDetails>;
  marketDetails$: Observable<MarketRecord>;
  partyMarketDetails$: Observable<MarketSyndicates>;
  queryParams$: Observable<Params>;
  referenceRiskCodes$: Observable<any>;
  submissionData$: Observable<SubmissionNavRec[]>;
  sectionDetails$: Observable<SectionDetail>;
  sidePanelDataItem$: Observable<SubmissionNavRec>;
  reviewErrorsSource$: Observable<MarketRecord> = this.marketDetailsStoreService.selectMarketData();
  marketDetailsBusinessRules$: Observable<string[]>;
  transactionType: string = null;
  responseData$: Observable<any>;

  constructor(
    private marketDetailsStoreService: MarketDetailsStoreService,
    private marketDetailsBusinessRulesService: MarketDetailsBusinessRulesService,
    private sidePanelStoreService: SidePanelStoreService,
    private route: ActivatedRoute,
    private sectionDetailsStoreService: SectionDetailsStoreService,
    private referenceRiskCodesService: ReferenceDataService,
    private infoHeaderStoreService: InfoHeaderStoreService,
    private globalAlertStoreService: GlobalAlertStoreService
  ) {}

  ngOnInit(): void {
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.marketDetails$ = this.marketDetailsStoreService.selectMarketData();
    this.partyMarketDetails$ = this.marketDetailsStoreService.selectPartyMarketData();
    this.submissionData$ = this.sidePanelStoreService.selectSidePanelData();
    this.sidePanelDataItem$ = this.sidePanelStoreService.selectSidePanelDataItem();
    this.queryParams$ = this.route.queryParams;
    this.sectionDetails$ = this.sectionDetailsStoreService.selectSectionData();
    this.referenceRiskCodes$ = this.referenceRiskCodesService.getRefData('reflloydsriskcode');
    this.infoHeaderDetails$ = this.infoHeaderStoreService.selectInfoHeaderDetails();
    this.marketDetailsBusinessRules$ = this.marketDetailsBusinessRulesService.validationErrors$;

    this.submissionData$.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      if (data && data[0]) {
        this.transactionType = data[0].transactionType.typeOfTransactionType;
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
