import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MainMarketDetailsComponent } from './main-market-details.component';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { MarketDetailsStoreService } from '@features/market-details/services/market-details.store.service';
import { RouterTestingModule } from '@angular/router/testing';
import { SidePanelStoreService } from '@shared/services/side-panel/side-panel.store.service';
import { SectionDetail } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { of } from 'rxjs';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { ReferenceDataService } from '@shared/services/reference-data/reference-data.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TechnicianPortalReferenceDataService } from 'src/app/api/reference-data/technician-portal-reference-data.service';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

describe('MainMarketDetailsComponent', () => {
  const mockSectionData: SectionDetail = {
    sectionNumber: 0,
    sectionTitle: '',
    locationVoyage: '',
    eeaRiskFlag: false,
    riskCode: '',
    subjectivityIndicator: false,
    unsignedPolReport: false,
    bureauLinePercent: 10,
    contractDetails: {
      mrcType: 'test',
      interest: 'test',
      policyPeriod: {
        from: '2020-02-1',
      },
    },
  };

  let component: MainMarketDetailsComponent;
  let fixture: ComponentFixture<MainMarketDetailsComponent>;
  let sectionDetailsStoreService: SectionDetailsStoreService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainMarketDetailsComponent],
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [
        AuthenticationService,
        MockStore,
        provideMockStore(),
        MarketDetailsStoreService,
        SidePanelStoreService,
        ReferenceDataService,
        InfoHeaderStoreService,
        TechnicianPortalReferenceDataService,
        Configuration,
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainMarketDetailsComponent);
    component = fixture.componentInstance;
    sectionDetailsStoreService = TestBed.inject(SectionDetailsStoreService);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get market section details', () => {
    const spy = spyOn(sectionDetailsStoreService, 'selectSectionData').and.returnValue(of(mockSectionData));
    component.ngOnInit();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
});
