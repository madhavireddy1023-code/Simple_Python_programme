import { PREMIUM_SCREEN_VIEW } from '@features/section-details/consts/section-details.consts';
import { VALID_SYNDICATE_NUM } from './market-details.consts';
import { PremiumRulesResponses } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';

export const ValidSyndicates = (result: PremiumRulesResponses): boolean => {
  if (typeof result === 'string') {
    return isValidSyndicateNum(result);
  } else if (result instanceof Array) {
    return result.every((r) => isValidSyndicateNum(r?.validateResponse));
  }
  return false;
};

export const GetSyndicatestErrorMsg = (result: PremiumRulesResponses): string => {
  if (typeof result === 'string') {
    return result;
  } else if (result instanceof Array) {
    return result
      .filter((r) => !isValidSyndicateNum(r?.validateResponse))
      .map((r) => r?.validateResponse)
      .join(', ');
  }
};

const isValidSyndicateNum = (syndicateNum: string): boolean => {
  return syndicateNum.toLowerCase() === VALID_SYNDICATE_NUM;
};

export const CheckScreenView = (screenView: string): string => {
  const premiumScreenView = PREMIUM_SCREEN_VIEW;
  if (
    screenView === premiumScreenView.COMPANY_OP ||
    screenView === premiumScreenView.COMPANY_XL ||
    screenView === premiumScreenView.COMPANY_AP_RP ||
    screenView === premiumScreenView.COMPANY_XL_FDO ||
    screenView === premiumScreenView.COMPANY_FDO_OP ||
    screenView === premiumScreenView.COMPANY_XL_ADJUSTMENT_AP_RP
  ) {
    return premiumScreenView.COMPANY;
  }

  if (
    screenView === premiumScreenView.LLOYDS_OP ||
    screenView === premiumScreenView.LLOYDS_AP_RP ||
    screenView === premiumScreenView.LLOYDS_FDO_OP
  ) {
    return premiumScreenView.LLOYDS;
  }

  if (screenView === premiumScreenView.MIXED_OP) {
    return premiumScreenView.MIXED;
  }
};
