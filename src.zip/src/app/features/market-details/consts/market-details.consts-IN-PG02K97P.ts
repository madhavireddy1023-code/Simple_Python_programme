export enum ADD_ROW_BTN {
  MARKET_DETAILS = 'addMarketDetailsBtn',
}

export enum DELETE_ROW_BTN {
  MARKET_DETAILS = 'deleteMarketDetailsBtn',
}

export const VALID_SYNDICATE_NUM = 'valid';

export const signingDetails = 'signing-details';
export const submissionId = 'submissionId';
export const marketNo = 'market_no';
export const marketId = 'marketId';
export const marketDetailsInfo = 'market-details';
export const sectionShowAtLevel = 2;
