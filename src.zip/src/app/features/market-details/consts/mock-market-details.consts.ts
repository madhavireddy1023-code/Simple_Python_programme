import { FacilityMarketsInfo } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { MarketListRec, PartyRequest, Bureau } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { ValidateSyndicateNumbersInput, PremiumRulesResponses } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';
import { VALID_SYNDICATE_NUM } from './market-details.consts';

export const mockMarketData = {
  marketId: 'test-123',
  bureauLinePercent: 1,
  marketTitle: 's2: Test Market Title',
  recordValid: false,
  facilityNumberAndDate: '2024061720000',
  policyPeriodFrom: '2024-01-01',
  policyPeriodTo: '2024-12-31',
};

export const mockMarketSubmissions: MarketListRec[] = [
  {
    marketId: '211212',
    marketTitle: 'title',
    recordValid: false,
  },
];

export const mockMarketDataSyndicates = {
  ...mockMarketData,
  syndicates: [
    {
      syndicateNumber: '12345678',
      syndicatePercentage: 12,
      syndicateReference: '12345',
    },
  ],
};
export const mockPartyMarketDetails = [
  { partyReference: '1', partyId: '123', partyMarketId: '123' },
  { partyReference: '2', partyId: '', partyMarketId: '' },
];

export const mockSubmissionData = {
  submissionId: 'c8f6061d-ea9d-47e3-8574-2b6521b8e87f',
  bureau: 'LLOYDS',
  status: 'In Progress',
  transactionType: {
    refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
    typeOfTransactionType: 'Premium',
  },
  opItems: [
    {
      sectionId: 'dcbda6fb-7f68-4e2a-a88e-42111a39e451',
      submissionId: 'c8f6061d-ea9d-47e3-8574-2b6521b8e87f',
      sectionNumber: 1,
      sectionTitle: 'section 1',
      premiums: [
        {
          premiumId: 'af85df26-a039-4ddc-9638-a588187e5b64',
          sectionId: 'dcbda6fb-7f68-4e2a-a88e-42111a39e451',
          premiumNumber: 1,
          transactionType: {
            refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
            typeOfTransactionType: 'Premium',
          },
        },
      ],
    },
    {
      sectionId: '7385ab89-6cba-41d6-83e7-36af6abc3ed9',
      submissionId: 'c8f6061d-ea9d-47e3-8574-2b6521b8e87f',
      sectionNumber: 2,
      sectionTitle: 'section 2',
      premiums: [
        {
          premiumId: '6ff6b3cb-2302-422f-9568-04168713189c',
          sectionId: '7385ab89-6cba-41d6-83e7-36af6abc3ed9',
          premiumNumber: 1,
          transactionType: {
            refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
            typeOfTransactionType: 'Premium',
          },
        },
      ],
    },
    {
      sectionId: 'df712a12-d78b-4f6c-8326-19d95b2695a3',
      submissionId: 'c8f6061d-ea9d-47e3-8574-2b6521b8e87f',
      sectionNumber: 3,
      sectionTitle: 'section 3',
      premiums: [
        {
          premiumId: '527f7f99-b5bc-4ef3-b70a-3841481d300d',
          sectionId: 'df712a12-d78b-4f6c-8326-19d95b2695a3',
          premiumNumber: 1,
          transactionType: {
            refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
            typeOfTransactionType: 'Premium',
          },
        },
      ],
    },
    {
      sectionId: '8e608664-8b98-4fcf-8b44-ecec6fb93b9f',
      submissionId: 'c8f6061d-ea9d-47e3-8574-2b6521b8e87f',
      sectionNumber: 4,
      sectionTitle: 'section 4',
      premiums: [
        {
          premiumId: 'ad07e894-6976-453d-9dd7-d8c29d5dec75',
          sectionId: '8e608664-8b98-4fcf-8b44-ecec6fb93b9f',
          premiumNumber: 1,
          transactionType: {
            refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
            typeOfTransactionType: 'Premium',
          },
        },
      ],
    },
    {
      sectionId: '6e402ea9-f84a-45af-9ec7-750d2664db11',
      submissionId: 'c8f6061d-ea9d-47e3-8574-2b6521b8e87f',
      sectionNumber: 5,
      sectionTitle: 'section 5',
      premiums: [
        {
          premiumId: 'c8863c71-202b-4c12-9c89-509dcf07b35b',
          sectionId: '6e402ea9-f84a-45af-9ec7-750d2664db11',
          premiumNumber: 1,
          transactionType: {
            refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
            typeOfTransactionType: 'Premium',
          },
        },
      ],
    },
  ],
};

export const mockMarketDataRI: ValidateSyndicateNumbersInput = {
  eeaFlag: 'true',
  syndicateNumber: ['555', '555', '5555'],
};

export const mockMarketDataRIResponseInValid: PremiumRulesResponses = [
  { validateResponse: VALID_SYNDICATE_NUM },
  { validateResponse: '5555 is invalid' },
];

export const mockMarketDataRIResponseValid: PremiumRulesResponses = [
  { validateResponse: VALID_SYNDICATE_NUM },
  { validateResponse: VALID_SYNDICATE_NUM },
];

export const mockPartyRequest: PartyRequest = {
  bureau: Bureau.LIRMA,
  partyReferences: [],
  effectiveDate: '1-1-2023',
  retrieveassociatedLMR: true,
};

export const mockDataResponseForGetMarketOfFacility: FacilityMarketsInfo = {
  yearofAccount: 2023,
  slipType: {
    refSlipTypeId: '6b5304aa-bd33-4c01-bc6c-a0219d8b5e4f',
    refSlipTypeValue: 'Non Bulking Lineslip',
  },
  lineSlipInstructions: 'testLineSlip',
  marketSyndicates: [
    {
      marketSyndicateId: 'a2f69a0a-dbb9-4562-8099-4e7695730655',
      marketId: '7111c0e0-8422-4b61-8186-50df88b745b0',
      partyId: '0ecdb169-9f84-4bae-b3e8-3e3cd2370d05',
      partyMarketId: '92de3522-3283-4ebf-810c-638cc19f529c',
      facilityNumberAndDate: 'FacilityTest2',
      syndicateNumber: 'LloydsSyndicate5',
      syndicatePseudonym: 'string',
      syndicatePercentage: 35,
      syndicateReference: 'SyndicateRef4388',
      syndicateSecondaryReference: 'SecondarySyndicateRef4388',
      removedFromPartial: false,
      modifySyndicateReference: false,
    },
    {
      marketSyndicateId: '0e0db769-fd1c-40cd-9fa5-b5363400b65d',
      marketId: '7111c0e0-8422-4b61-8186-50df88b745b0',
      partyId: '7dacb5ed-2227-4fe5-b174-ffb77846ce3d',
      partyMarketId: 'fe327e39-f658-40e5-b3d0-44f4fde6c6d1',
      facilityNumberAndDate: 'FacilityTest2',
      syndicateNumber: 'LloydsSyndicate9',
      syndicatePseudonym: 'string',
      syndicatePercentage: 65,
      syndicateReference: 'SyndicateRef4388',
      syndicateSecondaryReference: 'SecondarySyndicateRef4388',
      modifySyndicateReference: true,
    },
    {
      marketSyndicateId: '0e0db769-fd1c-40cd-9fa5-b5363400b65d',
      marketId: '7111c0e0-8422-4b61-8186-50df88b745b0',
      partyId: '7dacb5ed-2227-4fe5-b174-ffb77846ce3d',
      partyMarketId: 'fe327e39-f658-40e5-b3d0-44f4fde6c6d1',
      facilityNumberAndDate: 'FacilityTest2',
      syndicateNumber: 'LloydsSyndicate9',
      syndicatePseudonym: 'string',
      syndicatePercentage: 69,
      syndicateReference: 'SyndicateRef4388',
      syndicateSecondaryReference: 'SecondarySyndicateRef4388',
    },
  ],
};

export function generateMockData(): any {
  return {
    marketDetails: [
      {
        partyReference: 'string',
        partyId: 'string',
        partyMarketId: 'string',
        pseudonym: 'ABC',
        syndicateSpecialInstructions: [
          {
            specialInstructionType: 'Premiums',
            specialInstruction: 'If pseud ABC amend to ABD',
          },
        ],
        regulatoryJurisdiction: 'LBS',
        isConsortium: true,
        consortiumSyndicates: [
          {
            consortiummarketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            partyId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            partyMarketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            syndicateNumber: '1919',
            syndicatePseudonym: 'CVS',
            syndicatePercentage: Math.random() * 9,
            syndicateReference: 'HP2949499991',
            syndicateSecondaryReference: '4345345',
            syndicateSpecialInstructions: [
              {
                specialInstructionType: 'Premiums',
                specialInstruction: 'If Pseudonym CVS amend to CDS',
              },
            ],
            isConsortiumLead: true,
            modifySyndicateReference: true,
          },
        ],
        associatedMarketDetails: {
          partyReference: 'string',
          partyId: 'string',
          partyMarketId: 'string',
          pseudonym: 'string',
          syndicateSpecialInstructions: [
            {
              specialInstructionType: 'Premiums',
              specialInstruction: 'If pseud ABC amend to ABD',
            },
          ],
          regulatoryJurisdiction: 'LBS',
          isConsortium: true,
          consortiumSyndicates: [
            {
              consortiummarketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              partyId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              partyMarketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              syndicateNumber: 'string',
              syndicatePseudonym: 'string',
              syndicatePercentage: 0,
              syndicateReference: 'string',
              syndicateSecondaryReference: 'string',
              syndicateSpecialInstructions: [
                {
                  specialInstructionType: 'Premiums',
                  specialInstruction: 'If pseud ABC amend to ABD',
                },
              ],
              isConsortiumLead: true,
              modifySyndicateReference: true,
            },
          ],
        },
      },
    ],
  };
}
