import { ReleaseFlagEnum, TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { MarketDetailsRuleValidator } from '@shared/consts/shared.types';
import { find } from 'lodash';

export const validateYearOfAccountForDeLinkedIndicator: MarketDetailsRuleValidator = (formData, context) => {
  const transactionType = formData.transactionType;
  const bureau = formData?.bureau;
  const yearOfAccount = formData.payload?.yearOfAccount;
  const deLinkedReleaseArray = formData.marketData.premiumDetails;
  const currentYear = new Date().getFullYear();
  const marketTitle = formData.marketData.marketTitle;
  const marketTitleMatch = marketTitle.match(/^[^\s]+:/); // Matches everything up to the first space that ends with a colon
  const formattedMarketTitle = marketTitleMatch ? marketTitleMatch[0] : null; // Check if match exists
  const errorMssg = formData.transalateService.instant(
    'MARKET_DETAILS.YEAR_OF_ACCOUNT_MUST_BE_LESS_THAN_CURRENT_YEAR_IF_DE_LINKED_INDICATOR_NOT_DELINK'
  );

  const premiumsFilterd = deLinkedReleaseArray?.map((item) => {
    const premium = find(formData.sidePanelDataItemData?.opItems, (opItem) =>
      find(opItem?.premiums, { premiumId: item?.premiumId })
    );
    const premiumNumber = premium ? find(premium?.premiums, { premiumId: item?.premiumId })?.premiumNumber : null;
    return { ...item, premiumNumber };
  });

  // Find all indices of premiums with releaseFlag === 'Delink'
  const delinkedIndices = Array.isArray(premiumsFilterd)
    ? premiumsFilterd
        .map((delinkItem) =>
          delinkItem?.releaseFlag !== ReleaseFlagEnum.Delink ? 'Premium:' + delinkItem?.premiumNumber : -1
        )
        .filter((index) => index !== -1) // Filter out -1 (non-matching items)
    : [];

  if (
    delinkedIndices.length > 0 &&
    transactionType !== 'Premium FDO' &&
    bureau === TechnicianPortalBureauEnum.LLOYDS &&
    yearOfAccount > currentYear
  ) {
    return {
      messages: [
        `${errorMssg}  ${formattedMarketTitle} ( ${
          delinkedIndices.length === 1 ? delinkedIndices : delinkedIndices.join(', ')
        })`,
      ],
    };
  }
};
