import { TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { provideMockStore } from '@ngrx/store/testing';
import { MarketDetailsBusinessRulesService } from './market-details-business-rules.service';
import { MarketDetailsRuleValidator } from '@shared/consts/shared.types';
import { MarketRecord, PremiumGetRec } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

const mockMarketValidationData = {
  slipType: 'X',
  payload: {
    yearOfAccount: 2020,
  } as MarketRecord,
  bureau: 'Bureau A',
  premiumPayload: {
    delink: {
      releaseFlag: 'Cash',
    },
  } as PremiumGetRec,
};
describe('MarketDetailsBusinessRulesService', () => {
  let service: MarketDetailsBusinessRulesService;
  let globalAlertStoreService: GlobalAlertStoreService;
  let mockActivatedRoute: jasmine.SpyObj<ActivatedRoute>;

  beforeEach(() => {
    mockActivatedRoute = jasmine.createSpyObj('ActivatedRoute', [], {
      queryParams: new BehaviorSubject({}),
    });

    TestBed.configureTestingModule({
      providers: [
        MarketDetailsBusinessRulesService,
        GlobalAlertStoreService,
        provideMockStore(),
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
      ],
    });

    service = TestBed.inject(MarketDetailsBusinessRulesService);
    globalAlertStoreService = TestBed.inject(GlobalAlertStoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('validate', () => {
    it('should return empty array when no rules are provided', () => {
      const result = service.validate({});
      expect(result).toEqual([]);
      expect(service.validationErrors$.value).toEqual([]);
    });

    it('should return empty array when no form data is provided', () => {
      const result = service.validate({});
      expect(result).toEqual([]);
      expect(service.validationErrors$.value).toEqual([]);
    });

    it('should collect and return error messages from failed validations', () => {
      const mockRule1: MarketDetailsRuleValidator = () => ({
        messages: ['Error 1'],
      });
      const mockRule2: MarketDetailsRuleValidator = () => ({
        messages: ['Error 2', 'Error 3'],
      });

      const result = service.validate({}, [mockRule1, mockRule2]);

      expect(result).toEqual(['Error 1', 'Error 2', 'Error 3']);
      expect(service.validationErrors$.value).toEqual(['Error 1', 'Error 2', 'Error 3']);
    });

    it('should handle rules that return no errors', () => {
      const mockRule1: MarketDetailsRuleValidator = () => null;
      const mockRule2: MarketDetailsRuleValidator = () => ({
        messages: ['Error 1'],
      });

      const result = service.validate({}, [mockRule1, mockRule2]);

      expect(result).toEqual(['Error 1']);
      expect(service.validationErrors$.value).toEqual(['Error 1']);
    });

    it('should pass form data and service instance to rules', () => {
      const mockRule: MarketDetailsRuleValidator = jasmine.createSpy('mockRule').and.returnValue(null);

      service.validate(mockMarketValidationData, [mockRule]);

      expect(mockRule).toHaveBeenCalledWith(mockMarketValidationData, service);
    });
  });

  describe('reset', () => {
    it('should clear validation errors', () => {
      // Set some initial errors
      service.validationErrors$.next(['Error 1', 'Error 2']);
      spyOn(globalAlertStoreService, 'clearMultiMessagesResponse');

      service.reset();

      expect(service.validationErrors$.value).toEqual([]);
      expect(globalAlertStoreService.clearMultiMessagesResponse).toHaveBeenCalled();
    });
  });
});
