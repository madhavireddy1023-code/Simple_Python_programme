import { TestBed } from '@angular/core/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import * as actions from '../store/actions/market-details.action';
import { MarketDetailsStoreService } from './market-details.store.service';
import * as selectors from '../store/selectors/market-details.selector';
import { PartyRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { mockMarketDataRI } from '../consts/mock-market-details.consts';
import { MarketDetailsInput } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';

describe('MarketDetailsStoreService', () => {
  let service: MarketDetailsStoreService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockStore, provideMockStore()],
    });
    service = TestBed.inject(MarketDetailsStoreService);
    store = TestBed.inject(MockStore);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should getEtag to be called', () => {
    spyOn(service, 'getEtag');
    service.getEtag();
    expect(service.getEtag).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectEtag);
    expect(store.select).toHaveBeenCalled();
  });

  it('should updateMarketData to be called', () => {
    const mockMarketData = { marketId: 'test-123', bureauLinePercent: 1 };
    spyOn(service, 'updateMarketData');
    service.updateMarketData(mockMarketData, true, 'signing-details?type=signing0');
    expect(service.updateMarketData).toHaveBeenCalled();
    spyOn(store, 'dispatch');
    store.dispatch(
      actions.updateMarketData({
        marketDetails: mockMarketData,
        saveDraftStatus: true,
        nextStepUrl: 'signing-details?type=signing0',
      })
    );
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should updateMarketDataParties to be called', () => {
    const mockMarketData = { marketId: 'test-123', bureauLinePercent: 1 };
    const marketXISPayload: MarketDetailsInput = {
      bureau: 'ILU',
      slipType: 'X',
      currentYearNo: 2020,
      yearOfAccount: 2020,
      marketSyndicates: [{ syndicateReference: '3543' }],
    };
    const mockPartyReferencesData: PartyRequest = {
      bureau: 'LLOYDS',
      partyReferences: [{ partyReference: '1' }],
      effectiveDate: '20-12-2023',
      retrieveassociatedLMR: false,
    };
    spyOn(service, 'updateMarketDataParties');
    service.updateMarketDataParties(
      'LLOYDS',
      mockPartyReferencesData,
      mockMarketDataRI,
      mockMarketData,
      true,
      '',
      marketXISPayload
    );
    expect(service.updateMarketDataParties).toHaveBeenCalled();
    spyOn(store, 'dispatch');
    store.dispatch(
      actions.updateMarketDataParties({
        bureau: 'LLOYDS',
        updateMarketParties: mockPartyReferencesData,
        marketRi: mockMarketDataRI,
        marketDetails: mockMarketData,
        saveDraftStatus: true,
        nextStepUrl: 'signing-details?type=signing0',
        marketDetailsInput: marketXISPayload,
      })
    );
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should dispatch updateMarketDataRI action', () => {
    const mockMarketData = { marketId: 'test-123', bureauLinePercent: 1 };
    const marketXISPayload: MarketDetailsInput = {
      bureau: 'ILU',
      slipType: 'X',
      currentYearNo: 2020,
      yearOfAccount: 2020,
      marketSyndicates: [{ syndicateReference: '3543' }],
    };
    spyOn(service, 'updateMarketDataRI');
    spyOn(store, 'dispatch');
    service.updateMarketDataRI(mockMarketDataRI, mockMarketData, true, '', marketXISPayload);
    store.dispatch(
      actions.updateMarketDataRI({
        marketRi: mockMarketDataRI,
        marketDetails: mockMarketData,
        saveDraftStatus: true,
        nextStepUrl: '',
        marketDetailsInput: marketXISPayload,
      })
    );
    expect(service.updateMarketDataRI).toHaveBeenCalled();
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should selectMarketData to be called', () => {
    spyOn(service, 'selectMarketData');
    service.selectMarketData();
    expect(service.selectMarketData).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectMarketData);
    expect(store.select).toHaveBeenCalled();
  });

  it('should dispatch getSubmissionMarkets action', () => {
    spyOn(service, 'getSubmissionMarkets');
    spyOn(store, 'dispatch');
    service.getSubmissionMarkets('123', false);
    store.dispatch(
      actions.getSubmissionMarkets({
        partialMarketFlag: false,
        submissionId: '123',
      })
    );
    expect(service.getSubmissionMarkets).toHaveBeenCalled();
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should selectMarketSubmissions to be called', () => {
    spyOn(service, 'selectMarketSubmissions');
    service.selectMarketSubmissions();
    expect(service.selectMarketSubmissions).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectMarketSubmissions);
    expect(store.select).toHaveBeenCalled();
  });

  it('should clearMarketOfFacility to be called', () => {
    spyOn(service, 'clearMarketOfFacility');
    service.clearMarketOfFacility();
    expect(service.clearMarketOfFacility).toHaveBeenCalled();
    spyOn(store, 'dispatch');
    store.dispatch(actions.clearMarketsOfFacility());
    expect(store.dispatch).toHaveBeenCalled();
  });
});
