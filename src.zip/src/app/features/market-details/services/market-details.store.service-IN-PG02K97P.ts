import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../store/app.reducer';
import { Bureau, MarketListRecs, MarketRecord, PartyRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import * as actions from '../store/actions/market-details.action';
import * as selectors from '../store/selectors/market-details.selector';
import { Observable } from 'rxjs';
import { SetEtag } from 'src/app/utils/helper/helper';
import { MarketDetailsInput, ValidateSyndicateNumbersInput } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';
import { FacilityMarketsInfo } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

@Injectable({
  providedIn: 'root',
})
export class MarketDetailsStoreService {
  constructor(private store: Store<AppState>) {}

  getEtag(): string {
    const selector = this.store.select(selectors.selectEtag);
    return SetEtag(selector);
  }

  getMarketData(
    marketId: string,
    partialMarketFlag?: boolean,
    isMarketCopied?: boolean,
    currentMarket?: MarketRecord
  ): void {
    this.store.dispatch(actions.getMarketData({ marketId, partialMarketFlag, isMarketCopied, currentMarket }));
  }

  getSubmissionMarkets(submissionId: string, partialMarketFlag: boolean): void {
    this.store.dispatch(actions.getSubmissionMarkets({ submissionId, partialMarketFlag }));
  }

  getMarketDataBySubmission(submissionId: string): void {
    this.store.dispatch(actions.getMarketDataBySubmission({ submissionId }));
  }

  updateMarketDataParties(
    bureau: Bureau,
    updateMarketParties: PartyRequest,
    marketRi: ValidateSyndicateNumbersInput,
    marketDetails: MarketRecord,
    saveDraftStatus: boolean,
    nextStepUrl: string,
    marketDetailsInput: MarketDetailsInput
  ): void {
    this.store.dispatch(
      actions.updateMarketDataParties({
        bureau,
        updateMarketParties,
        marketRi,
        marketDetails,
        saveDraftStatus,
        nextStepUrl,
        marketDetailsInput,
      })
    );
  }

  updateMarketData(
    marketDetails: MarketRecord,
    saveDraftStatus: boolean,
    nextStepUrl: string,
    partialMarketFlag?: boolean
  ): void {
    this.store.dispatch(actions.updateMarketData({ marketDetails, saveDraftStatus, nextStepUrl, partialMarketFlag }));
  }

  updateMarketDataRI(
    marketRi: ValidateSyndicateNumbersInput,
    marketDetails: MarketRecord,
    saveDraftStatus: boolean,
    nextStepUrl: string,
    marketDetailsInput: MarketDetailsInput,
    partialMarketFlag?: boolean
  ): void {
    this.store.dispatch(
      actions.updateMarketDataRI({
        marketRi,
        marketDetails,
        saveDraftStatus,
        nextStepUrl,
        partialMarketFlag,
        marketDetailsInput,
      })
    );
  }

  selectMarketData(): Observable<MarketRecord> {
    return this.store.select(selectors.selectMarketData);
  }

  selectMarketSubmissions(): Observable<MarketListRecs> {
    return this.store.select(selectors.selectMarketSubmissions);
  }

  selectPartyMarketData(): Observable<any> {
    return this.store.select(selectors.selectPartyMarketDetails);
  }

  getMarketOfFacility(yoaNumberAndDate: string): void {
    this.store.dispatch(actions.getMarketsOfFacility({ yoaNumberAndDate }));
  }

  selectStatusOfMarketsOfFacility(): Observable<boolean> {
    return this.store.pipe(select(selectors.selectStatusOfMarketsOfFacility));
  }

  selectInfoOfMarketsOfFacility(): Observable<FacilityMarketsInfo> {
    return this.store.pipe(select(selectors.selectInfoOfMarketsOfFacility));
  }
  setPartyMarketDetails(partyMarketDetails): void {
    this.store.dispatch(actions.setMarketParty({ partyMarketDetails }));
  }

  clearMarketOfFacility(): void {
    this.store.dispatch(actions.clearMarketsOfFacility());
  }
}
