import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MarketRecord, PremiumGetRec } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { MarketDetailsRuleValidator } from '@shared/consts/shared.types';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { BehaviorSubject } from 'rxjs';
import { MarketBusinessValidationData } from '../models/market-details.model';

@Injectable({
  providedIn: 'root',
})
export class MarketDetailsBusinessRulesService {
  validationErrors$: BehaviorSubject<string[]> = new BehaviorSubject([]);

  constructor(private globalAlertStoreService: GlobalAlertStoreService) {}

  validate(formData: MarketBusinessValidationData, rules: MarketDetailsRuleValidator[] = []): string[] {
    const errors = rules.reduce<string[]>((ruleErrors, rule) => {
      const error = rule(formData, this);

      if (error && error.messages) {
        error.messages.forEach((message) => {
          ruleErrors = [...ruleErrors, message];
        });
      }

      return ruleErrors;
    }, []);

    this.validationErrors$.next(errors);

    return errors;
  }

  reset(): void {
    this.globalAlertStoreService.clearMultiMessagesResponse();
    this.validationErrors$.next([]);
  }
}
