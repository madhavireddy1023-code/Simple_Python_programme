import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import { MarketDetailsState } from '..';
import * as actions from '../actions/market-details.action';
import * as _ from 'lodash';
import { MarketListRecs } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { FacilityMarketsInfo } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

export const initialState: MarketDetailsState = {
  etag: '',
  marketDetails: null,
  partyMarketDetails: null,
  marketSubmissions: null,
  status: null,
  facilityMarketsInfo: null,
};

export const MarketDetailsReducer: ActionReducer<MarketDetailsState, Action> = createReducer(
  initialState,
  // update state etag
  on(actions.setEtag, (state: MarketDetailsState, action) => _.setWith(_.clone(state), 'etag', action.etag, _.clone)),

  // update state market details
  on(actions.saveMarketData, (state: MarketDetailsState, action) =>
    _.setWith(_.clone(state), 'marketDetails', action.marketDetails, _.clone)
  ),

  // update set Party Market Details
  on(actions.setPartyMarketDetails, (state: MarketDetailsState, action) =>
    _.setWith(_.clone(state), 'partyMarketDetails', action.partyMarketDetails, _.clone)
  ),

  // update state section
  on(actions.setMarketData, (state: MarketDetailsState, action) =>
    _.setWith(_.clone(state), 'marketDetails', action.market, _.clone)
  ),

  // update state for market submissions
  on(actions.setMarketSubmissions, (state: MarketDetailsState, action) =>
    _.setWith(_.clone(state), 'marketSubmissions', action.marketSubmissions, _.clone)
  ),

  // set status to true
  on(actions.setStatusTrue, (state: MarketDetailsState) => _.setWith(_.clone(state), 'status', true, _.clone)),

  // set status to false
  on(actions.setStatusFalse, (state: MarketDetailsState) => _.setWith(_.clone(state), 'status', false, _.clone)),

  on(actions.setMarketFacilityInfo, (state: MarketDetailsState, action) =>
    _.setWith(_.clone(state), 'facilityMarketsInfo', action.marketFacilityInfo, _.clone)
  ),
  on(actions.clearMarketsOfFacility, (state) => ({
    ..._.clone(state),
    facilityMarketsInfo: null,
  })),

  // set record valid marketDetails
  on(actions.setRecordValidationMarket, (state: MarketDetailsState, action) => {
    if (!state.marketSubmissions) {
      return { ...state };
    }
    const marketSubmissionsArray = _.cloneDeep(state.marketSubmissions); // Copying state
    const marketSubmissionItem = marketSubmissionsArray.find((element) => element.marketId === action.marketId);
    if (marketSubmissionItem) {
      marketSubmissionItem.recordValid = action.recordValid;
    }
    return { ...state, marketSubmissions: marketSubmissionsArray };
  })
);
