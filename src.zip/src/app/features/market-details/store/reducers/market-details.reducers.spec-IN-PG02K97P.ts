import { Action } from '@ngrx/store';
import { MarketDetailsReducer, initialState } from './market-details.reducers';
import * as actions from '../actions/market-details.action';
import { mockMarketData, mockMarketSubmissions } from '@features/market-details/consts/mock-market-details.consts';

describe('SectionDetailsReducers', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = MarketDetailsReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should update the state of [etag]', () => {
    const expectedState = 'etag123';
    const action = actions.setEtag({ etag: expectedState });
    const newState = MarketDetailsReducer(initialState, action);
    expect(newState.etag).toEqual(expectedState);
  });

  it('should update the state of [marketDetails]', () => {
    const expectedState = mockMarketData;
    const action = actions.saveMarketData({ marketDetails: expectedState });
    const newState = MarketDetailsReducer(initialState, action);
    expect(newState.marketDetails).toEqual(expectedState);
  });

  it('should update the state of [marketDetails]', () => {
    const expectedState = mockMarketData;
    const action = actions.setMarketData({ market: expectedState });
    const newState = MarketDetailsReducer(initialState, action);
    expect(newState.marketDetails).toEqual(expectedState);
  });

  it('should update the state of [marketSubmissions]', () => {
    const expectedState = mockMarketSubmissions;
    const action = actions.setMarketSubmissions({ marketSubmissions: mockMarketSubmissions });
    const newState = MarketDetailsReducer(initialState, action);
    expect(newState.marketSubmissions).toEqual(expectedState);
  });

  it('should clear the state of [facilityMarketsInfo]', () => {
    const action = actions.clearMarketsOfFacility();
    const newState = MarketDetailsReducer(initialState, action);
    expect(newState.facilityMarketsInfo).toBeNull();
  });
});
