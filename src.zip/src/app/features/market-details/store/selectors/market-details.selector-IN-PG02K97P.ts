import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.marketDetails;

// get etag
export const selectEtag = createSelector(selectState, (state) => state?.etag);

// get market data
export const selectMarketData = createSelector(selectState, (state) => state?.marketDetails);

// get market submissions
export const selectMarketSubmissions = createSelector(selectState, (state) => state?.marketSubmissions);

// get party Market Details
export const selectPartyMarketDetails = createSelector(selectState, (state) => state?.partyMarketDetails);

// get status of markets Of facility
export const selectStatusOfMarketsOfFacility = createSelector(selectState, (state) => state?.status);

// get  markets Of facility info
export const selectInfoOfMarketsOfFacility = createSelector(selectState, (state) => state?.facilityMarketsInfo);
