import { mockMarketData, mockMarketSubmissions } from '@features/market-details/consts/mock-market-details.consts';
import * as selectors from './market-details.selector';

describe('MarketDetailsSelector', () => {
  const state = {
    etag: '12345',
    marketDetails: mockMarketData,
    partyMarketDetails: null,
    marketSubmissions: mockMarketSubmissions,
  };

  it('should select selectEtag', () => {
    const expectedData = '12345';
    const etagSelector = selectors.selectEtag.projector(state);
    expect(etagSelector).toEqual(expectedData);
  });

  it('should select market data', () => {
    const expectedData = mockMarketData;
    const marketDataSelector = selectors.selectMarketData.projector(state);
    expect(marketDataSelector).toEqual(expectedData);
  });

  it('should select market submissions', () => {
    const expectedData = mockMarketSubmissions;
    const marketSubmissionSelector = selectors.selectMarketSubmissions.projector(state);
    expect(marketSubmissionSelector).toEqual(expectedData);
  });
});
