import {
  getMarketData,
  getSubmissionMarkets,
  saveMarketData,
  setEtag,
  setMarketSubmissions,
  updateMarketData,
  updateMarketDataParties,
  updateMarketDataRI,
  validateMarketXis,
  clearMarketsOfFacility,
} from './market-details.action';

describe('Market Details Actions', () => {
  it('should return correct types', () => {
    // set etag
    expect(setEtag.type).toEqual('[MARKET_DETAILS] SET_ETAG');

    // get market data
    expect(getMarketData.type).toEqual('[MARKET_DETAILS] GET_MARKET_DATA');

    // update market data
    expect(updateMarketData.type).toEqual('[MARKET_DETAILS] UPDATE_MARKET_DATA');

    // update market dataRI
    expect(updateMarketDataRI.type).toEqual('[MARKET_DETAILS] UPDATE_MARKET_DATA_RI');

    // set section data Ri
    expect(updateMarketDataParties.type).toEqual('[MARKET_DETAILS] UPDATE_MARKET_DATA_PARTIES');

    // XIS validation (Rules)
    expect(validateMarketXis.type).toEqual('[MARKET_DETAILS] VALIDATE_MARKET_XIS');

    // save market data
    expect(saveMarketData.type).toEqual('[MARKET_DETAILS] SAVE_MARKET_DATA');

    expect(getSubmissionMarkets.type).toEqual('[MARKET_DETAILS] GET_MARKET_SUBMISSIONS');

    expect(setMarketSubmissions.type).toEqual('[MARKET_DETAILS] SET_MARKET_SUBMISSIONS');

    expect(clearMarketsOfFacility.type).toEqual('[MARKET_DETAILS] CLEAR_MARKET_OF_FACILITY');
  });
});
