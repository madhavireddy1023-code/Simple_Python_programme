import { FacilityMarketsInfo } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import {
  Bureau,
  MarketListRecs,
  MarketPatchRecord,
  MarketRecord,
  PartyRequest,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { MarketDetailsInput, ValidateSyndicateNumbersInput } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';
import { createAction, props } from '@ngrx/store';

const MARKET_DETAILS_PREFIX = '[MARKET_DETAILS]';

const GET_MARKET_OF_FACILITY = `${MARKET_DETAILS_PREFIX} GET_MARKET_OF_FACILITY`;
export const getMarketsOfFacility = createAction(GET_MARKET_OF_FACILITY, props<{ yoaNumberAndDate: string }>());

const CLEAR_MARKET_OF_FACILITY = `${MARKET_DETAILS_PREFIX} CLEAR_MARKET_OF_FACILITY`;
export const clearMarketsOfFacility = createAction(CLEAR_MARKET_OF_FACILITY);

// get market data
const GET_MARKET_DATA = `${MARKET_DETAILS_PREFIX} GET_MARKET_DATA`;
export const getMarketData = createAction(
  GET_MARKET_DATA,
  props<{ marketId: string; partialMarketFlag?: boolean; isMarketCopied?: boolean; currentMarket?: MarketRecord }>()
);

// set market data
const SET_MARKET_DATA = `${MARKET_DETAILS_PREFIX} SET_MARKET_DATA`;
export const setMarketData = createAction(SET_MARKET_DATA, props<{ market: MarketRecord }>());

// get market submissions
const GET_MARKET_SUBMISSIONS = `${MARKET_DETAILS_PREFIX} GET_MARKET_SUBMISSIONS`;
export const getSubmissionMarkets = createAction(
  GET_MARKET_SUBMISSIONS,
  props<{ submissionId: string; partialMarketFlag: boolean }>()
);

// set market submissions
const SET_MARKET_SUBMISSIONS = `${MARKET_DETAILS_PREFIX} SET_MARKET_SUBMISSIONS`;
export const setMarketSubmissions = createAction(
  SET_MARKET_SUBMISSIONS,
  props<{ marketSubmissions: MarketListRecs }>()
);

// get market data by section id
const GET_MARKET_DATA_BY_SUBMISSION = `${MARKET_DETAILS_PREFIX} GET_MARKET_DATA_BY_SUBMISSION`;
export const getMarketDataBySubmission = createAction(GET_MARKET_DATA_BY_SUBMISSION, props<{ submissionId: string }>());

// set section data Party
const SET_MARKET_DATA_PARTY = `${MARKET_DETAILS_PREFIX} SET_MARKET_DATA_PARTY`;
export const setPartyMarketDetails = createAction(SET_MARKET_DATA_PARTY, props<{ partyMarketDetails: any }>());

// set update Market Data Parties validation
const UPDATE_MARKET_DATA_PARTIES = `${MARKET_DETAILS_PREFIX} UPDATE_MARKET_DATA_PARTIES`;
export const updateMarketDataParties = createAction(
  UPDATE_MARKET_DATA_PARTIES,
  props<{
    bureau: Bureau;
    updateMarketParties: PartyRequest;
    marketRi: ValidateSyndicateNumbersInput;
    marketDetails: MarketRecord;
    saveDraftStatus: boolean;
    nextStepUrl: string;
    partialMarketFlag?: boolean;
    marketDetailsInput: MarketDetailsInput;
  }>()
);

// update market data
const UPDATE_MARKET_DATA = `${MARKET_DETAILS_PREFIX} UPDATE_MARKET_DATA`;
export const updateMarketData = createAction(
  UPDATE_MARKET_DATA,
  props<{
    marketDetails: MarketPatchRecord;
    saveDraftStatus: boolean;
    nextStepUrl: string;
    partialMarketFlag?: boolean;
  }>()
);

// XIS validation (Rules)
const VALIDATE_MARKET_XIS = `${MARKET_DETAILS_PREFIX} VALIDATE_MARKET_XIS`;
export const validateMarketXis = createAction(
  VALIDATE_MARKET_XIS,
  props<{
    marketDetailsInput: MarketDetailsInput;
    marketDetails: MarketRecord;
    saveDraftStatus: boolean;
    nextStepUrl: string;
    partialMarketFlag?: boolean;
  }>()
);

// update market data RI
const UPDATE_MARKET_DATA_RI = `${MARKET_DETAILS_PREFIX} UPDATE_MARKET_DATA_RI`;
export const updateMarketDataRI = createAction(
  UPDATE_MARKET_DATA_RI,
  props<{
    marketRi: ValidateSyndicateNumbersInput;
    marketDetails: MarketRecord;
    saveDraftStatus: boolean;
    nextStepUrl: string;
    partialMarketFlag?: boolean;
    marketDetailsInput: MarketDetailsInput;
  }>()
);

// save market data
const SAVE_MARKET_DATA = `${MARKET_DETAILS_PREFIX} SAVE_MARKET_DATA`;
export const saveMarketData = createAction(SAVE_MARKET_DATA, props<{ marketDetails: MarketRecord }>());

// set etag
const SET_ETAG = `${MARKET_DETAILS_PREFIX} SET_ETAG`;
export const setEtag = createAction(SET_ETAG, props<{ etag: string }>());

export const setStatusTrue = createAction('[Market Details] Set Status True');
export const setStatusFalse = createAction('[Market Details] Set Status False');

const SET_FACILITY_MARKET_INFO = `${MARKET_DETAILS_PREFIX} SET_FACILITY_MARKET_INFO`;
export const setMarketFacilityInfo = createAction(
  SET_FACILITY_MARKET_INFO,
  props<{ marketFacilityInfo: FacilityMarketsInfo }>()
);

const SET_MARKET_PARTY = `${MARKET_DETAILS_PREFIX} SET_MARKET_PARTY`;
export const setMarketParty = createAction(SET_MARKET_PARTY, props<{ partyMarketDetails: any }>());

const SET_RECORD_VALID_MARKET = `${MARKET_DETAILS_PREFIX} SET_RECORD_VALID_MARKET`;
export const setRecordValidationMarket = createAction(
  SET_RECORD_VALID_MARKET,
  props<{ marketId: string; recordValid: boolean }>()
);
