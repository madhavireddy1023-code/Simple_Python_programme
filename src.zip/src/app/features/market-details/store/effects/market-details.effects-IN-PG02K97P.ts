import { Injectable } from '@angular/core';
import { TechnicianPortalService } from 'src/app/api/technician-portal';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { catchError, switchMap, tap } from 'rxjs/operators';
import * as actions from '../actions/market-details.action';
import { GetEtag, ScrollUp } from 'src/app/utils/helper/helper';
import { MarketDetailsStoreService } from '@features/market-details/services/market-details.store.service';
import { Router } from '@angular/router';
import { loadGlobalAlert, loadMultiMessagesAlert } from 'src/app/store/actions/global-alert.action';
import { PREMIUM_SCREEN_VIEW } from '@features/section-details/consts/section-details.consts';
import { find, map } from 'lodash';
import { MarketRecord, MarketSyndicate, PartyMarketDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { GetSyndicatestErrorMsg, ValidSyndicates } from '@features/market-details/consts/market-details.helper';
import {
  allValidationsIsWarnings,
  nonSupervisoryErrors,
  nonSupervisoryWarnings,
  noValidationErrors,
  removeCommaSeparator,
  supervisoryValidationErrors,
} from 'src/app/utils';
import { WorkflowRulesService, WorkflowXisService } from 'src/app/api/workflow-rules-api';
import { PremiumRulesOutputs, PremiumRulesResponses } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';
import { TechnicianPortalPartyIntegrationService } from 'src/app/api/technician-portal-party-integration';
import { DomainAPITechnicianPortalLineSlipsService } from 'src/app/api/domain-api-technician-portal-lineslips';
import { GlobalAlertType } from '@shared/consts/global-alert.const';

@Injectable()
export class MarketDetailsEffects {
  constructor(
    private actions$: Actions,
    private technicianPortalService: TechnicianPortalService,
    private domainAPITechnicianPortalLineSlipsService: DomainAPITechnicianPortalLineSlipsService,
    private marketDetailsStoreService: MarketDetailsStoreService,
    private workflowRulesService: WorkflowRulesService,
    private technicianPortalPartyIntegrationService: TechnicianPortalPartyIntegrationService,
    private router: Router,
    private workflowXisService: WorkflowXisService
  ) {}

  // get market details data
  getMarketData$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getMarketData),
      switchMap((action) =>
        this.technicianPortalService.apiV1MarketDetailsGet(action.marketId, action.partialMarketFlag, 'response').pipe(
          switchMap((response) => {
            ScrollUp(0, 0);
            if (!action.isMarketCopied) {
              return of(
                actions.setEtag({ etag: GetEtag(response) }),
                actions.saveMarketData({ marketDetails: response?.body })
              );
            } else {
              // Check if the response contains a facility number and date
              const hasFacilityData = response?.body?.facilityNumberAndDate != null;

              // Create an error object if facility data exists, otherwise set to null
              const error = hasFacilityData
                ? {
                    errorTypeDmn: true,
                    message: 'MARKET_DETAILS.MARKET_LINKED_TO_FACILITY_ERROR',
                    isGlobalAlert: true,
                  }
                : null;

              // Copy market data only if there's no facility data
              const copiedMarketData = hasFacilityData ? action.currentMarket : { ...response?.body };
              const currentMarketData = action.currentMarket;

              return of(
                loadGlobalAlert({ response: { ...error } }),
                actions.setMarketData({
                  market: {
                    ...copiedMarketData,
                    sectionId: currentMarketData?.sectionId,
                    marketId: currentMarketData?.marketId,
                    createdDate: currentMarketData?.createdDate,
                    marketTitle: currentMarketData?.marketTitle,
                    submissionId: currentMarketData?.submissionId,
                  },
                })
              );
            }
          }),
          catchError((error) => {
            ScrollUp(0, 0);
            if (error?.status === 403) {
              return of(
                loadGlobalAlert({
                  response: {
                    ...error,
                    responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                    isAuthAlert: true,
                    isVisible: false,
                  },
                })
              );
            }
            return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
          })
        )
      )
    )
  );

  // get market submissions
  getSubmissionMarkets$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getSubmissionMarkets),
      switchMap((action) =>
        this.technicianPortalService
          .apiV1GetSubmissionMarketsGet(action.submissionId, action.partialMarketFlag, 'body')
          .pipe(
            switchMap((response) => {
              ScrollUp(0, 0);
              return of(actions.setMarketSubmissions({ marketSubmissions: response }));
            })
          )
      )
    )
  );

  // set market details data Parties
  setMarketDataParties$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.updateMarketDataParties),
      switchMap((action) => {
        return this.technicianPortalPartyIntegrationService
          .apiV1PartyMarketDetailsPost(action.updateMarketParties)
          .pipe(
            switchMap((response) => {
              // check all data was coming partyId and partyMarketId
              // call updateMarketDataRI when screen view is LLOYDS
              if (response?.marketDetails?.every((element) => element?.partyId && element?.partyMarketId)) {
                // // call api market details next btn in case of  screen view is Company
                if (action.bureau === PREMIUM_SCREEN_VIEW.LLOYDS) {
                  // For lloyds the partyMarketDetail post api is called at market screen when syndicate no. changed.
                  return of(
                    actions.updateMarketDataRI({
                      marketRi: {
                        ...action.marketRi,
                      },
                      marketDetails: this.getMarketDetailsPartiesPayload(action.marketDetails, null),
                      saveDraftStatus: action.saveDraftStatus,
                      nextStepUrl: action.nextStepUrl,
                      marketDetailsInput: action.marketDetailsInput,
                    })
                  );
                  // For company case.
                } else {
                  return of(
                    actions.validateMarketXis({
                      marketDetails: this.getMarketDetailsPartiesPayload(action.marketDetails, response?.marketDetails),
                      saveDraftStatus: action.saveDraftStatus,
                      nextStepUrl: action.nextStepUrl,
                      partialMarketFlag: action.partialMarketFlag,
                      marketDetailsInput: action.marketDetailsInput,
                    })
                  );
                }
              } else {
                return of(actions.setPartyMarketDetails({ partyMarketDetails: response?.marketDetails }));
              }
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  // XIS validation (Rules)
  validateMarketXis$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.validateMarketXis),
      switchMap((action) =>
        this.workflowXisService.marketlDetailsValidations(action.marketDetailsInput).pipe(
          switchMap((response: PremiumRulesOutputs) => {
            if (
              supervisoryValidationErrors(response)?.length ||
              noValidationErrors(response) ||
              allValidationsIsWarnings(response)
            ) {
              ScrollUp(0, 0);
              return of(
                loadMultiMessagesAlert({
                  alertData: { messages: nonSupervisoryWarnings(response), type: GlobalAlertType.ERROR },
                }),
                actions.updateMarketData({
                  marketDetails: {
                    ...action.marketDetails,
                    supervisoryWarnings: [...supervisoryValidationErrors(response)],
                  },
                  saveDraftStatus: action.saveDraftStatus,
                  nextStepUrl: action.nextStepUrl,
                  partialMarketFlag: action.partialMarketFlag,
                })
              );
            } else {
              ScrollUp(0, 0);
              const errorMessage = nonSupervisoryErrors(response);
              return of(
                loadMultiMessagesAlert({
                  alertData: { messages: errorMessage, type: GlobalAlertType.ERROR },
                })
              );
            }
          }),
          catchError((error) => {
            ScrollUp(0, 0);
            return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
          })
        )
      )
    )
  );

  // update market dataRI
  updateMarketDataRI$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.updateMarketDataRI),
      switchMap((action) =>
        this.workflowRulesService.checkSyndicateNumberRange(action.marketRi).pipe(
          switchMap((response: PremiumRulesResponses) => {
            const firstDecisionResult = response;
            if (ValidSyndicates(firstDecisionResult)) {
              // call Market XIS API
              return of(
                actions.validateMarketXis({
                  marketDetails: action.marketDetails,
                  saveDraftStatus: action.saveDraftStatus,
                  nextStepUrl: action.nextStepUrl,
                  partialMarketFlag: action.partialMarketFlag,
                  marketDetailsInput: action.marketDetailsInput,
                })
              );
            } else {
              ScrollUp(0, 0);
              const error = {
                errorTypeDmn: true,
                message: GetSyndicatestErrorMsg(firstDecisionResult),
              };
              return of(
                loadGlobalAlert({
                  response: { ...error, isGlobalAlert: true },
                })
              );
            }
          }),
          catchError((error) => {
            ScrollUp(0, 0);
            return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
          })
        )
      )
    )
  );

  // update market data
  updateMarketData$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.updateMarketData),
      switchMap((action) =>
        this.technicianPortalService
          .apiV1MarketDetailsPatch(
            this.marketDetailsStoreService?.getEtag(),
            action.marketDetails?.marketId,
            action.saveDraftStatus,
            action.marketDetails,
            action.partialMarketFlag
          )
          .pipe(
            switchMap(() => {
              ScrollUp(0, 0);
              return of(
                actions.getMarketData({
                  marketId: action.marketDetails.marketId,
                  partialMarketFlag: action.partialMarketFlag,
                }),
                actions.setRecordValidationMarket({
                  marketId: action.marketDetails.marketId,
                  recordValid: action?.marketDetails?.recordValid,
                }),
                loadGlobalAlert({
                  response: action.saveDraftStatus
                    ? { ...action.marketDetails, status: 200, isGlobalAlert: true }
                    : undefined,
                })
              ).pipe(
                tap(() => {
                  if (!action.saveDraftStatus) {
                    this.router.navigateByUrl(action.nextStepUrl);
                  }
                })
              );
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          )
      ),
      catchError((error) => {
        ScrollUp(0, 0);
        if (error?.status === 403) {
          return of(
            loadGlobalAlert({
              response: {
                ...error,
                responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                isAuthAlert: true,
                isVisible: true,
              },
            })
          );
        }
        return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
      })
    )
  );

  getMarketsOfFacility$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getMarketsOfFacility),
      switchMap((action) =>
        this.domainAPITechnicianPortalLineSlipsService.apiV1GetMarketsOfFacilityGet(action.yoaNumberAndDate).pipe(
          switchMap((response) => {
            /* 
              Successful loadGlobalAlert() has been moved to the component due additional checks
              If validation error, then successful banner is not shown
            */

            return of(actions.setStatusTrue(), actions.setMarketFacilityInfo({ marketFacilityInfo: response }));
          }),
          catchError((error) => {
            ScrollUp(0, 0);

            if (error.status === 404) {
              return of(
                loadGlobalAlert({
                  response: { ...error, responseMessage: 'No matching signing found', isGlobalAlert: true },
                }),
                actions.setStatusFalse()
              );
            } else if (error?.status === 403) {
              return of(
                loadGlobalAlert({
                  response: {
                    ...error,
                    responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                    isAuthAlert: true,
                    isVisible: false,
                  },
                })
              );
            } else {
              return of(
                loadGlobalAlert({
                  response: { ...error, responseMessage: error.status, isGlobalAlert: true },
                }),
                actions.setStatusFalse()
              );
            }
          })
        )
      )
    )
  );
  setMarketDataParty$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.setMarketParty),
      switchMap((action) =>
        this.technicianPortalPartyIntegrationService.apiV1PartyMarketDetailsPost(action.partyMarketDetails).pipe(
          switchMap((response: any) => {
            return of(actions.setPartyMarketDetails({ partyMarketDetails: response.marketDetails }));
          }),
          catchError((error) => {
            ScrollUp(0, 0);
            return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
          })
        )
      )
    )
  );
  getMarketDetailsPartiesPayload(
    marketDetailsPayload: MarketRecord,
    partiesResponse: PartyMarketDetails
  ): MarketRecord {
    const updatedSyndicates = map(marketDetailsPayload?.syndicates, (syndicate: MarketSyndicate) => {
      // remove comma from syndicate number
      const syndicateNumber = removeCommaSeparator(syndicate?.syndicateNumber?.toString());
      const matchingParty = find(partiesResponse, { partyReference: syndicateNumber });
      if (matchingParty) {
        // Return a new object with partyId and partyMarketId added to the matching syndicate
        return {
          ...syndicate,
          partyId: matchingParty?.partyId,
          partyMarketId: matchingParty?.partyMarketId,
        };
      }
      return syndicate; // Return the original syndicate if no match
    });

    // Update the marketDetailsPayload object with the new syndicates array
    marketDetailsPayload = { ...marketDetailsPayload, syndicates: updatedSyndicates };

    return marketDetailsPayload;
  }
}
