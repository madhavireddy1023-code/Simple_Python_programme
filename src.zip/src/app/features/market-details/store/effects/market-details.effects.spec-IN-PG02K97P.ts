import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable, of } from 'rxjs';
import { TechnicianPortalService } from 'src/app/api/technician-portal';
import { HttpResponse } from '@angular/common/http';
import { initialState } from '../reducers/market-details.reducers';
import { MarketDetailsEffects } from './market-details.effects';
import * as action from '../actions/market-details.action';
import { take } from 'rxjs/operators';
import { RouterTestingModule } from '@angular/router/testing';
import { SigningDetailsComponent } from '@features/signing-details/components/signing-details/signing-details.component';
import {
  mockMarketDataRI,
  mockMarketDataRIResponseInValid,
  mockMarketDataRIResponseValid,
} from '@features/market-details/consts/mock-market-details.consts';
import { WorkflowRulesService, WorkflowXisService } from 'src/app/api/workflow-rules-api';
import { TechnicianPortalPartyIntegrationService } from 'src/app/api/technician-portal-party-integration';
import { DomainAPITechnicianPortalLineSlipsService } from 'src/app/api/domain-api-technician-portal-lineslips';
import { MarketDetailsInput, PremiumRulesOutputs } from '@dxc.lm.sdk.angular/premiums-workflow-rules-api';
import { MarketRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

describe('MarketDetailsEffects', () => {
  let actions$: Observable<any>;
  let effects: MarketDetailsEffects;
  let technicianPortalService: jasmine.SpyObj<TechnicianPortalService>;
  let workflowRulesService: jasmine.SpyObj<WorkflowRulesService>;
  let technicianPortalPartyIntegrationService: jasmine.SpyObj<TechnicianPortalPartyIntegrationService>;
  let domainAPITechnicianPortalLineSlipsService: jasmine.SpyObj<DomainAPITechnicianPortalLineSlipsService>;
  let workFlowXisService: jasmine.SpyObj<WorkflowXisService>;
  beforeEach(() => {
    const technicianPortalServiceSpy = jasmine.createSpyObj('TechnicianPortalService', [
      'apiV1MarketDetailsPatch',
      'apiV1MarketDetailsGet',
      'apiV1GetSubmissionMarketsGet',
    ]);
    const workflowRulesServiceSpy = jasmine.createSpyObj('WorkflowRulesService', ['checkSyndicateNumberRange']);

    const technicianPortalPartyIntegrationServiceSpy = jasmine.createSpyObj('TechnicianPortalPartyIntegrationService', [
      'apiV1PartyMarketDetailsPost',
    ]);
    const domainAPITechnicianPortalLineSlipsServiceSpy = jasmine.createSpyObj(
      'DomainAPITechnicianPortalLineSlipsService',
      ['apiV1GetMarketsOfFacilityGet']
    );

    const workflowXisServiceSpy = jasmine.createSpyObj('WorkflowXisService', ['marketlDetailsValidations']);

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([{ path: 'signing-details?type=signing0', component: SigningDetailsComponent }]),
      ],
      providers: [
        MarketDetailsEffects,
        { provide: TechnicianPortalService, useValue: technicianPortalServiceSpy },
        { provide: WorkflowRulesService, useValue: workflowRulesServiceSpy },
        { provide: TechnicianPortalPartyIntegrationService, useValue: technicianPortalPartyIntegrationServiceSpy },
        { provide: DomainAPITechnicianPortalLineSlipsService, useValue: domainAPITechnicianPortalLineSlipsService },
        { provide: WorkflowXisService, useValue: workflowXisServiceSpy },
        provideMockStore({ initialState }),
        provideMockActions(() => actions$),
      ],
    });

    effects = TestBed.inject(MarketDetailsEffects);
    technicianPortalService = TestBed.inject(TechnicianPortalService) as jasmine.SpyObj<TechnicianPortalService>;
    workflowRulesService = TestBed.inject(WorkflowRulesService) as jasmine.SpyObj<WorkflowRulesService>;
    technicianPortalPartyIntegrationService = TestBed.inject(
      TechnicianPortalPartyIntegrationService
    ) as jasmine.SpyObj<TechnicianPortalPartyIntegrationService>;
    workFlowXisService = TestBed.inject(WorkflowXisService) as jasmine.SpyObj<WorkflowXisService>;
    domainAPITechnicianPortalLineSlipsService = TestBed.inject(
      DomainAPITechnicianPortalLineSlipsService
    ) as jasmine.SpyObj<DomainAPITechnicianPortalLineSlipsService>;
  });

  it('should test getMarketData$ effect', () => {
    actions$ = of(action.getMarketData({ marketId: '123456' }));
    technicianPortalService.apiV1MarketDetailsGet.and.returnValue(of(new HttpResponse({ status: 200 })));
    effects.getMarketData$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setEtag.type);
    });
  });

  it('should test getSubmissionMarkets$ effect', () => {
    actions$ = of(action.getSubmissionMarkets({ submissionId: '123456', partialMarketFlag: false }));
    technicianPortalService.apiV1GetSubmissionMarketsGet.and.returnValue(of(new HttpResponse({ status: 200 })));
    effects.getSubmissionMarkets$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setMarketSubmissions.type);
    });
  });

  it('should test updateMarketData$ effect', () => {
    const mockMarketData = { marketId: 'test-123', bureauLinePercent: 1 };
    actions$ = of(
      action.updateMarketData({
        marketDetails: mockMarketData,
        saveDraftStatus: true,
        nextStepUrl: 'signing-details?type=signing0',
      })
    );
    technicianPortalService.apiV1MarketDetailsPatch.and.returnValue(of(new HttpResponse({ status: 200 })));
    effects.updateMarketData$.subscribe(() => {
      expect(technicianPortalService.apiV1MarketDetailsPatch).toHaveBeenCalled();
    });
  });

  it('should dispatch updateMarketDataParties action if DMN response is valid', () => {
    const mockMarketData: MarketRecord = { marketId: 'test-123', bureauLinePercent: 1 };
    const props = {
      marketDetails: mockMarketData,
      saveDraftStatus: false,
      nextStepUrl: 'signing-details?type=signing0',
      partialMarketFlag: false,
    };
    const marketXISPayload: MarketDetailsInput = {
      bureau: 'ILU',
      slipType: 'X',
      currentYearNo: 2020,
      yearOfAccount: 2020,
      marketSyndicates: [{ syndicateReference: '3543' }],
    };
    const mockValidationResponse: PremiumRulesOutputs = [
      {
        decisionName: 'DecisionName1',
        validateResponse: 'Valid',
        supervisoryError: false,
      },
    ];
    actions$ = of(
      action.updateMarketDataRI({
        marketRi: { ...mockMarketDataRI, isConsortium: 'false' },
        ...props,
        marketDetailsInput: marketXISPayload,
      })
    );
    const response: any = mockMarketDataRIResponseValid;
    workflowRulesService.checkSyndicateNumberRange.and.returnValue(of(response));
    effects.updateMarketDataRI$.subscribe((val) => {
      actions$ = of(action.validateMarketXis({ marketDetailsInput: marketXISPayload, ...props }));
      workFlowXisService.marketlDetailsValidations.and.returnValue(
        of(new HttpResponse({ status: 200, body: mockValidationResponse }))
      );
      expect(val).toEqual(action.validateMarketXis({ marketDetailsInput: marketXISPayload, ...props }));
      expect(val.marketDetails).toEqual(props.marketDetails);
      expect(val.saveDraftStatus).toEqual(props.saveDraftStatus);
      expect(val.nextStepUrl).toEqual(props.nextStepUrl);
    });
  });

  it('should dipatch loadGlobalAlert action if DMN response is not valid', () => {
    const mockMarketData = { marketId: 'test-123', bureauLinePercent: 1 };
    const props = {
      marketDetails: mockMarketData,
      saveDraftStatus: false,
      nextStepUrl: 'signing-details?type=signing0',
    };
    const marketXISPayload: MarketDetailsInput = {
      bureau: 'ILU',
      slipType: 'X',
      currentYearNo: 2020,
      yearOfAccount: 2020,
      marketSyndicates: [{ syndicateReference: '3543' }],
    };
    actions$ = of(
      action.updateMarketDataRI({
        marketRi: { ...mockMarketDataRI, isConsortium: 'false' },
        ...props,
        marketDetailsInput: marketXISPayload,
      })
    );
    workflowRulesService.checkSyndicateNumberRange.and.returnValue(
      of(new HttpResponse({ body: mockMarketDataRIResponseInValid }))
    );
    effects.updateMarketDataRI$.subscribe((val) => {
      expect(val.type).toEqual('LOAD_GLOBAL_ALERT');
    });
  });
});
