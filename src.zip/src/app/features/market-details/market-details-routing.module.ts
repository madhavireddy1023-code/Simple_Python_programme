import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainMarketDetailsComponent } from './main/main-market-details/main-market-details.component';

const routes: Routes = [
  {
    path: '',
    component: MainMarketDetailsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MarketDetailsRoutingModule {}
