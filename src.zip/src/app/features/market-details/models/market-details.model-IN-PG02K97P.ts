import { FacilityMarketsInfo } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import {
  MarketRecord,
  MarketListRecs,
  PartyRequest,
  PremiumGetRec,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { TranslateService } from '@ngx-translate/core';
import { SubmissionNavRec } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
export interface MarketDetailsState {
  etag: string;
  marketDetails: MarketRecord;
  partyMarketDetails: PartyRequest;
  marketSubmissions: MarketListRecs;
  status?: boolean;
  facilityMarketsInfo: FacilityMarketsInfo;
}

export class MarketBusinessValidationData {
  slipType?: string;
  payload?: MarketRecord;
  bureau?: string;
  premiumPayload?: PremiumGetRec;
  marketData?: MarketRecord;
  transalateService?: TranslateService;
  transactionType?: string;
  sidePanelDataItemData?: SubmissionNavRec;
}
