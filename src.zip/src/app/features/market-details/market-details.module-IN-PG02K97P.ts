import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MarketDetailsRoutingModule } from './market-details-routing.module';
import { MainMarketDetailsComponent } from './main/main-market-details/main-market-details.component';
import { SharedModule } from '@shared/shared.module';
import { MarketDetailsComponent } from './components/market-details/market-details.component';
import { ReadOnlyModule } from '@shared/directives/read-only.module';

@NgModule({
  declarations: [MainMarketDetailsComponent, MarketDetailsComponent],
  imports: [CommonModule, MarketDetailsRoutingModule, SharedModule, ReadOnlyModule],
})
export class MarketDetailsModule {}
