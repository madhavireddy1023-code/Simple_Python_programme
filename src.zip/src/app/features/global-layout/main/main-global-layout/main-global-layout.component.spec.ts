import { TestBed, ComponentFixture } from '@angular/core/testing';
import { MainGlobalLayoutComponent } from './main-global-layout.component';
import { BehaviorSubject, of } from 'rxjs';
import { IdentityProviderService } from '@shared/services/identity-provider/identity-provider.service';
import { RolesType } from '@shared/models';

describe('MainGlobalLayoutComponent', () => {
  let component: MainGlobalLayoutComponent;
  let fixture: ComponentFixture<MainGlobalLayoutComponent>;
  let identityProviderService: jasmine.SpyObj<IdentityProviderService>;

  beforeEach(() => {
    const identityProviderSpy = jasmine.createSpyObj('IdentityProviderService', ['getRolesAuthorization']);

    TestBed.configureTestingModule({
      declarations: [MainGlobalLayoutComponent],
      providers: [{ provide: IdentityProviderService, useValue: identityProviderSpy }],
    });

    fixture = TestBed.createComponent(MainGlobalLayoutComponent);
    component = fixture.componentInstance;
    identityProviderService = TestBed.inject(IdentityProviderService) as jasmine.SpyObj<IdentityProviderService>;
  });

  it('should initialize landingPageRoles and call getRolesAuthorization', () => {
    const rolesData = { role1: true, role2: true, role3: false };
    const rolesSubject = new BehaviorSubject<RolesType>(rolesData);
    identityProviderService.roles = rolesSubject;
    fixture.detectChanges();
    expect(component.landingPageRoles).toEqual(rolesSubject);
    expect(identityProviderService.getRolesAuthorization).toHaveBeenCalled();
  });
});
