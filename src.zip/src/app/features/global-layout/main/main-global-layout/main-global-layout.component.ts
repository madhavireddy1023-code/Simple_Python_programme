import { Component, OnInit } from '@angular/core';
import { LandingPageRoles } from '@shared/consts/shared.consts';
import { RolesType } from '@shared/models';
import { IdentityProviderService } from '@shared/services/identity-provider/identity-provider.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-main-global-layout',
  templateUrl: './main-global-layout.component.html',
  styleUrls: ['./main-global-layout.component.scss'],
})
export class MainGlobalLayoutComponent implements OnInit {
  landingPageRoles: Observable<RolesType>;

  constructor(private identityProviderService: IdentityProviderService) {}

  ngOnInit(): void {
    this.landingPageRoles = this.identityProviderService.roles;
    this.identityProviderService.getRolesAuthorization(LandingPageRoles);
  }
}
