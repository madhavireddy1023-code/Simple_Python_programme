import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GlobalLayoutRoutingModule } from './global-layout-routing.module';
import { SharedModule } from '@shared/shared.module';
import { MainGlobalLayoutComponent } from './main/main-global-layout/main-global-layout.component';
import { GlobalLayoutComponent } from './components/global-layout/global-layout.component';

@NgModule({
  declarations: [MainGlobalLayoutComponent, GlobalLayoutComponent],
  imports: [CommonModule, GlobalLayoutRoutingModule, SharedModule],
})
export class GlobalLayoutModule {}
