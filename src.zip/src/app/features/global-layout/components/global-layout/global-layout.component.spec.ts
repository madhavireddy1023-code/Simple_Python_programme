import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { GlobalLayoutComponent } from './global-layout.component';
import { By } from '@angular/platform-browser';
import { Role } from '@shared/consts/shared.enums';
import { AppConfigService } from 'src/app/core/services/app-config/app-config.service';

describe('LayoutComponent', () => {
  let component: GlobalLayoutComponent;
  let fixture: ComponentFixture<GlobalLayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GlobalLayoutComponent],
      imports: [TranslateModule.forRoot()],
      providers: [AppConfigService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display IPOS Enquiry option when landingPageRoles includes AccountEnquiry.Screen', () => {
    component.landingPageRoles = { [Role.AccountEnquiry_Screen]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.IPOS_ENQUIRY');
  });

  it('should display Queries option when landingPageRoles includes query.search', () => {
    component.landingPageRoles = { [Role.PR_Premium_QueryPremium]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.QUERIES');
  });

  it('should display Release for settlement option when landingPageRoles includes process_portal_release.search', () => {
    component.landingPageRoles = { [Role.PROCESS_PORTAL_RELEASE_SEARCH]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.RELEASE_FOR_SETTLEMENT');
  });

  it('should display Company Ref Updates option when landingPageRoles includes process_uwref_corrections', () => {
    component.landingPageRoles = { [Role.PROCESS_UWREF_CORRECTIONS]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.COMPANY_REF_UPDATE');
  });

  it('should display Audit option when landingPageRoles includes process_audit', () => {
    component.landingPageRoles = { [Role.PROCESS_AUDIT]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.AUDIT');
  });

  it('should display Deferred option when landingPageRoles includes process_deferred_corrections', () => {
    component.landingPageRoles = { [Role.PROCESS_DEFERRED_CORRECTIONS]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.DEFERRED');
  });

  it('should display Workflow option when landingPageRoles includes process_workflow_app.view', () => {
    component.landingPageRoles = { [Role.PROCESS_WORKFLOW_APP_VIEW]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.WORKFLOW');
  });

  it('should display Global option when landingPageRoles includes PR.Premium.AllPremiums', () => {
    component.landingPageRoles = { [Role.PR_PREMIUM_ALL_PREMIUMS]: true };
    fixture.detectChanges();
    const option = fixture.debugElement.query(By.css('.view-query')).nativeElement as HTMLElement;
    expect(option.textContent.trim()).toBe('GLOBAL_LAYOUT.GLOBAL');
  });
});
