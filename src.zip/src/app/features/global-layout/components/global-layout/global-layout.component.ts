import { Component, Input, OnInit } from '@angular/core';
import { Role } from '@shared/consts/shared.enums';
import { RolesType } from '@shared/models';
import { AppConfigService } from 'src/app/core/services/app-config/app-config.service';

@Component({
  selector: 'app-global-layout',
  templateUrl: './global-layout.component.html',
  styleUrls: ['./global-layout.component.scss'],
})
export class GlobalLayoutComponent implements OnInit {
  readonly roles = Role;
  argoopsCommonUrl: string;
  globalUrl: string;
  workflowUrl: string;

  @Input() landingPageRoles: RolesType;

  constructor(private appConfigService: AppConfigService) {}

  ngOnInit(): void {
    this.argoopsCommonUrl = this.appConfigService.get('endPoints.argoopsBase');
    this.globalUrl = this.appConfigService.get('endPoints.iposBase');
    this.workflowUrl = this.appConfigService.get('endPoints.workflowBase');
  }

  navigateToArgoopsCommonUrl(): void {
    window.open(this.argoopsCommonUrl, '_self');
  }
}
