import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainGlobalLayoutComponent } from './main/main-global-layout/main-global-layout.component';

const routes: Routes = [{ path: '', component: MainGlobalLayoutComponent }];

@NgModule({
  declarations: [],
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GlobalLayoutRoutingModule {}
