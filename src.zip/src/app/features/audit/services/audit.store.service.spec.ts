import { TestBed } from '@angular/core/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { AuditStoreService } from './audit.store.service';
import * as actions from '../store/actions/audit.action';
import * as selectors from '../store/selectors/audit.selectors';
import { auditPayload } from '@features/audit/const/payloads.const';
import { PassOrFail } from '../models/audit.model';

describe('AuditStoreService', () => {
  let service: AuditStoreService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockStore, provideMockStore()],
    });
    service = TestBed.inject(AuditStoreService);
    store = TestBed.inject(MockStore);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should postPresigningAudit to be called', () => {
    const presigningAuditRecord = auditPayload;
    spyOn(store, 'dispatch');
    service.postPresigningAudit(presigningAuditRecord);
    expect(store.dispatch).toHaveBeenCalledWith(actions.postPresigningAudit({ presigningAuditRecord }));
  });

  it('should dispatch postPresigningAuditDecision with correct arguments', () => {
    const cnsd = 'some_cnsd_value';
    const decision = PassOrFail.Pass;
    spyOn(store, 'dispatch');
    service.postPresigningAuditDecision(cnsd, decision);
    expect(store.dispatch).toHaveBeenCalledWith(actions.presigningAuditDecision({ cnsd, decision }));
  });

  it('should selectAuditPass to be called', () => {
    spyOn(service, 'presigningAuditPass');
    service.presigningAuditPass();
    expect(service.presigningAuditPass).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectAuditPass);
    expect(store.select).toHaveBeenCalled();
  });

  it('should postSigningAuditFailButton to be called', () => {
    spyOn(service, 'postSigningAuditFailButton');
    service.postSigningAuditFailButton();
    expect(service.postSigningAuditFailButton).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.auditFailButton);
    expect(store.select).toHaveBeenCalled();
  });

  it('should selectAuditFail to be called', () => {
    spyOn(service, 'presigningAuditFail');
    service.presigningAuditFail();
    expect(service.presigningAuditFail).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectAuditFail);
    expect(store.select).toHaveBeenCalled();
  });
  it('should updateAuditStatus to be called', () => {
    const body = [{ version: 1, id: 'c7d33163-568a-4939-88b6-a4defaf7268d' }];
    spyOn(store, 'dispatch');
    service.updateAuditStatus(body);
    store.dispatch(actions.updateAuditStatus({ body }));
    expect(store.dispatch).toHaveBeenCalled();
  });
});
