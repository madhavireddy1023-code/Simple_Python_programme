import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../store/app.reducer';
import { PresigningAuditRecord, IdAndVersion } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import * as actions from '../store/actions/audit.action';
import * as selectors from '../store/selectors/audit.selectors';
import { Observable } from 'rxjs';
import { AuditFail, PassOrFail } from '../models/audit.model';

@Injectable({
  providedIn: 'root',
})
export class AuditStoreService {
  constructor(private store: Store<AppState>) {}

  postPresigningAudit(presigningAuditRecord: PresigningAuditRecord): void {
    this.store.dispatch(actions.postPresigningAudit({ presigningAuditRecord }));
  }

  postPresigningAuditDecision(cnsd: string, decision: PassOrFail): void {
    this.store.dispatch(actions.presigningAuditDecision({ cnsd, decision }));
  }

  presigningAuditPass(): Observable<string> {
    return this.store.select(selectors.selectAuditPass);
  }
  presigningAuditFail(): Observable<string> {
    return this.store.select(selectors.selectAuditFail);
  }

  postSigningAuditFailButton(): Observable<boolean> {
    return this.store.select(selectors.auditFailButton);
  }

  setPostSigningStatus(status: boolean): void {
    this.store.dispatch(actions.auditFailButton({ auditFailButton: status }));
  }

  updateAuditStatus(body: IdAndVersion[], bureau?, umr?: string, workPackageRef?: string): void {
    this.store.dispatch(actions.updateAuditStatus({ body, bureau, umr, workPackageRef }));
  }

  presigningCleaFail(): void {
    this.store.dispatch(actions.clearAuditError());
  }
}
