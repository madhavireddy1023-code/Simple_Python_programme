import { ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { auditPayload, iluRegex, lirmaRegex, lloydsRegex } from '@features/audit/const/payloads.const';
import { AuditStoreService } from '@features/audit/services/audit.store.service';

import {
  DxcTextInputComponent,
  DxcTextareaComponent,
  DxcSelectComponent,
  Option,
} from '@dxc-technology/halstack-angular';
import { FormControls } from '@shared/models';
import {
  ValidationInputStatus,
  ValidationSelectStatus,
  formatOption,
  isCommaSeparatedNum,
  removeCommaSeparator,
  setSelectValue,
} from 'src/app/utils';
import { Observable, Subject, Subscription } from 'rxjs';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { map, takeUntil } from 'rxjs/operators';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { PassOrFail } from '@features/audit/models/audit.model';
import { DateInputComponent } from '@shared/components/date-input/date-input.component';
import {
  TypeOfCurrency,
  TypeOfTransactionType,
  ReleaseFlagEnum,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-audit',
  templateUrl: './audit.component.html',
  styleUrls: ['./audit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AuditComponent implements OnInit, OnDestroy {
  isAudit: boolean;
  auditForm: FormGroup;
  isGoBtnClicked: boolean;
  refData: any;
  isoCurrencyOptions: Option[] = [];
  transactionTypeOptions: Option[] = [];
  responseData$: Observable<any>;
  isAuditPass: boolean;
  isAuditFail: boolean;
  customErrorMsg: boolean;
  isFormValid: string;
  formSubscription: Subscription;
  formValueSubscription: Subscription;
  presigningAuditPassValue: string;
  presigningAuditFailValue: string;
  showDialog: boolean;
  description = 'AUDIT.CONFIRMATION_MESSAGE';

  @Input() set referenceData(referenceData: any) {
    if (referenceData) {
      this.refData = referenceData;
      this.formatSelects(referenceData);
    }
  }

  @Input() set postSigningAuditFailButton(auditFailButton: boolean) {
    if (auditFailButton === false) {
      return;
    }
    this.isAuditFail = false;
  }

  @Input() set presigningAuditPass(presigningAuditPass: string) {
    if (presigningAuditPass) {
      this.presigningAuditPassValue = presigningAuditPass;
      this.isAuditPass = true;
      this.isAuditFail = false;
      this.auditForm.reset();
      this.plannedSettlementDate.resetDateForm();
      Object.keys(this.auditForm.controls).forEach((key) => {
        const control = this.auditForm.get(key);
        control.markAsUntouched();
        control.setErrors(null);
      });
    }
  }

  @Input() set presigningAuditFail(presigningAuditFail: string) {
    if (presigningAuditFail) {
      this.presigningAuditFailValue = presigningAuditFail;
      this.handleAuditFail(this.presigningAuditFailValue);
    }
  }
  @ViewChild('plannedSettlementDate') plannedSettlementDate: DateInputComponent;

  @ViewChild('settlementCurrency') settlementCurrency: DxcSelectComponent;

  constructor(
    private formBuilder: FormBuilder,
    private auditStoreService: AuditStoreService,
    private globalAlertStoreService: GlobalAlertStoreService,
    protected translate: TranslateService
  ) {}

  ngOnInit(): void {
    this.initAuditForm();
    this.isAuditPass = false;
    this.isAuditFail = false;
    this.isAudit = true;
    this.customErrorMsg = false;

    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();

    this.formSubscription = this.auditForm.statusChanges.subscribe((status) => {
      this.isFormValid = status;
    });

    this.formValueSubscription = this.auditForm.valueChanges.subscribe((formValue) => {
      this.validateCrDrInput(formValue);
    });
  }

  resumeClicked(): void {
    this.goBtnClicked();
  }

  okClicked(): void {
    this.showDialog = false;
  }

  checkSigningDate(): void {
    const signingNo = this.auditForm.get('csnd').value;

    const signingDateStr = this.extractSigningDate(signingNo);

    // Compare signing date with today's date
    if (!this.isToday(signingDateStr) && this.auditForm.valid) {
      this.showDialog = true;
    } else {
      this.goBtnClicked();
    }
  }

  extractSigningDate(signingNo: string): string | null {
    const currentYear = new Date().getFullYear().toString();
    const currentYear2Digits = currentYear.substring(2);

    const first4Digits = signingNo.substring(0, 4);
    const first2Digits = signingNo.substring(0, 2);

    if (first4Digits === currentYear && lloydsRegex.test(signingNo) && signingNo.length === 13) {
      return signingNo.substring(0, 8);
    }

    if (first2Digits === currentYear2Digits && lirmaRegex.test(signingNo) && signingNo.length === 13) {
      return '20' + signingNo.substring(0, 6);
    }

    if (iluRegex.test(signingNo)) {
      const year = '20' + signingNo.substring(3, 5);
      const dayMonth = signingNo.substring(11, 15);
      return year + dayMonth.substring(2, 4) + dayMonth.substring(0, 2);
    }

    this.auditForm.get('csnd')?.setErrors({ invalid: true });
    return null;
  }

  isToday(signingDateStr: string): boolean {
    const today = new Date();
    const todayDateStr = today.toISOString().split('T')[0].replace(/-/g, ''); // Format YYYYMMDD
    return signingDateStr === todayDateStr;
  }

  goBtnClicked(): void {
    this.auditStoreService.presigningCleaFail();
    this.isGoBtnClicked = true;
    this.showDialog = false;

    this.markAllAsTouched();
    const payload = { ...this.auditForm.value };
    if (this.plannedSettlementDate.formatDate()) {
      payload.plannedSettlementDate = this.plannedSettlementDate.formatDate();
    }
    if (this.isFormValid === 'VALID' && this.auditForm.touched) {
      payload.settlementCurrency = this.auditForm.get('settlementCurrency').value
        ? this.getLabelOfCurrecy(this.auditForm.get('settlementCurrency').value, this.isoCurrencyOptions)
        : undefined;
      payload.transactionType = this.assignIdtoTransactionTpe(
        this.auditForm.get('transactionType').value,
        this.transactionTypeOptions
      );
      payload.releaseFlag = this.convertReleaseFlagToEnumVal(this.auditForm.get('releaseFlag').value);
      this.auditStoreService.postPresigningAudit(payload);
    }

    this.globalAlertStoreService.clearGlobalResponse();
  }

  // initiate Audit Form
  //
  initAuditForm(): void {
    this.auditForm = this.formBuilder.group({
      csnd: [null, [Validators.required, this.validateSigningNo.bind(this)]],
      brokerNumber: [null, Validators.required],
      brokerReference1: [null, Validators.required],
      brokerReference2: [null],
      settlementCurrency: [null],
      deferred: [null],
      premiumNet: [null, this.validateNumbers],
      transactionType: [null, Validators.compose([Validators.required, this.validateStringTransactionType])],
      qualCatCode: this.formBuilder.group({
        refQualCatCodeId: [null],
        typeOfQualCatCode: [null],
      }),
      plannedSettlementDate: [null],
      releaseFlag: [null],
      ukIPTamount: [null, this.bigDecimalValidator],
      overseasAddedTax: [null, this.bigDecimalValidator],
      submissionId: [null],
      canOrRep: [null],
    });
  }

  formatSelects(refData: any): void {
    this.isoCurrencyOptions = formatOption('isoCurrency', 'code', 'id', refData);
    this.transactionTypeOptions = formatOption('transactionType', 'description', 'id', refData);
  }

  // get form controls of contract information form
  get auditFormControls(): FormControls {
    return this.auditForm?.controls;
  }
  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isGoBtnClicked, formControl, input);
  }

  getValidationSelectStatus(formControl: AbstractControl, select?: DxcSelectComponent): boolean {
    return ValidationSelectStatus(this.isGoBtnClicked, formControl, select);
  }

  setSelectValue(formControl: AbstractControl, value: string, refKey?: string, refData?: any, panel?: string): void {
    setSelectValue(formControl, value, refKey, this.refData);
  }

  onRestForm(): void {
    this.auditForm.reset();
    this.plannedSettlementDate.resetDateForm();
    this.isAuditPass = false;
    this.isAuditFail = false;
    this.globalAlertStoreService.clearGlobalResponse();
    if (this.auditForm.touched || this.auditForm.untouched) {
      Object.keys(this.auditForm.controls).forEach((key) => {
        const control = this.auditForm.get(key);
        control.markAsUntouched();
        control.setErrors(null);
      });
    }
  }

  auditPassButton(): void {
    const match = this.presigningAuditPassValue?.match(/'(.*?)'/);
    if (match && match[1]) {
      this.auditStoreService.postPresigningAuditDecision(match[1], PassOrFail.Pass);
    }
    this.globalAlertStoreService.clearGlobalResponse();
  }
  failAuditButton(): void {
    this.auditStoreService.postPresigningAuditDecision(this.auditForm.get('csnd').value, PassOrFail.Fail);
    this.globalAlertStoreService.clearGlobalResponse();
  }

  getLabelOfCurrecy(selectedLabel: string, arrayRef: Array<{ value: string; label: string }>): TypeOfCurrency {
    const selectedCurrency = arrayRef?.find((item) => item?.label === selectedLabel);
    if (!selectedCurrency) {
      return undefined;
    }

    const selectedTypedCurrency = {
      refTypeCurrencyId: selectedCurrency?.value,
      typeOfCurrency: selectedCurrency?.label,
    };
    return selectedTypedCurrency;
  }

  validateStringTransactionType(control: FormControl): { [key: string]: any } | null {
    const allowedStrings = ['PM', 'AP', 'RP', 'C', 'D', 'OP', 'FDO'];
    return allowedStrings.includes(control.value) ? null : { invalidString: { value: control.value } };
  }

  validateNumbers(control: FormControl): { [key: string]: any } | null {
    const value = control?.value;
    if (value && value.length > 0) {
      const isValid = /^\d+()?$/.test(value);
      return isValid ? null : { integerNum: { value: control.value } };
    }
    return null;
  }
  validateSigningNo(control: FormControl): { [key: string]: any } | null {
    const currentYear = new Date().getFullYear().toString();
    const currentYear2Digits = currentYear.substring(2);

    const signingNo = control.value;
    if (!signingNo) {
      return null;
    }

    const first4Digits = signingNo.substring(0, 4);
    const first2Digits = signingNo.substring(0, 2);

    if (
      (first4Digits === currentYear && lloydsRegex.test(signingNo) && signingNo.length === 13) ||
      (first2Digits === currentYear2Digits && lirmaRegex.test(signingNo) && signingNo.length === 13) ||
      iluRegex.test(signingNo)
    ) {
      return null;
    }

    this.customErrorMsg = true;

    return { invalidData: 'Invalid signing number' };
  }

  validateCrDrInput(formValue: any): void {
    const formGroup = this.auditForm as FormGroup;
    const invalidFields = ['releaseFlag', 'premiumNet', 'settlementCurrency'];

    if (formValue) {
      if (formValue.transactionType === 'FDO') {
        for (const controlName in formGroup.controls) {
          if (invalidFields.includes(controlName)) {
            const control = formGroup.controls[controlName];
            if (control.value) {
              this.customErrorMsg = true;
              control.setErrors({ invalidData: this.translate.instant('AUDIT.VALIDATIONS.INVALID_DATA') });
            } else {
              control.setErrors(null);
            }
          }
        }
      } else {
        for (const controlName of invalidFields) {
          const control = formGroup.controls[controlName];
          if (control) {
            const currentErrors = control.errors || {};
            // Remove only 'invalidData' error, keep others
            delete currentErrors.invalidData;
            control.setErrors(Object.keys(currentErrors).length > 0 ? currentErrors : null);
          }
        }
      }
    }
  }

  assignIdtoTransactionTpe(input: string, listOfValues: { value: string }[]): TypeOfTransactionType {
    let typeOfTransaction;
    switch (input) {
      case 'PM':
      case 'OP':
        typeOfTransaction = { refTypeOfTransactionTypeId: listOfValues[3].value, typeOfTransactionType: 'PM' };
        return typeOfTransaction;
      case 'AP':
      case 'C':
        typeOfTransaction = { refTypeOfTransactionTypeId: listOfValues[0].value, typeOfTransactionType: 'AP' };
        return typeOfTransaction;
      case 'RP':
      case 'D':
        typeOfTransaction = { refTypeOfTransactionTypeId: listOfValues[5].value, typeOfTransactionType: 'RP' };
        return typeOfTransaction;
      case 'FDO':
        typeOfTransaction = { refTypeOfTransactionTypeId: listOfValues[4].value, typeOfTransactionType: 'FDO' };
        return typeOfTransaction;
    }
  }

  convertReleaseFlagToEnumVal(input: string): ReleaseFlagEnum {
    let releaseFlag;
    switch (input) {
      case 'cash':
      case 'CASH':
        releaseFlag = ReleaseFlagEnum.Cash;
        return releaseFlag;
      case 'delink':
      case 'DELINK':
        releaseFlag = ReleaseFlagEnum.Delink;
        return releaseFlag;
      case 'nonCash':
      case 'noncash':
      case 'NONCASH':
        releaseFlag = ReleaseFlagEnum.NonCash;
        return releaseFlag;
    }
  }

  ngOnDestroy(): void {
    if (this.formSubscription) {
      this.formSubscription.unsubscribe();
    }
    if (this.formValueSubscription) {
      this.formValueSubscription.unsubscribe();
    }
  }

  bigDecimalValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const isValid = /^-?\d+(\.\d+)?$/.test(control.value);
      return isValid ? null : { bigDecimalInvalid: { value: control.value } };
    };
  }

  markAllAsTouched(): void {
    Object.keys(this.auditForm.controls).forEach((field) => {
      const control = this.auditForm.get(field);
      control.markAsTouched({ onlySelf: true });
      control.updateValueAndValidity();
    });
  }

  isSettlementCurrencyInvalid(): boolean {
    const settlementCurrency = this.auditForm.get('settlementCurrency') as FormGroup;
    return settlementCurrency.invalid && (settlementCurrency.dirty || settlementCurrency.touched);
  }

  handleAuditFail(res): void {
    if (res) {
      this.customErrorMsg = true;
      this.isAuditFail = true;
      this.isAuditPass = false;
      if (!res.includes('csnd') && !res.includes('releaseFlag')) {
        const fieldsName: string[] = res.split(',');
        fieldsName.forEach((fieldName) => {
          const control = this.auditForm.get(fieldName);
          if (control) {
            control.setErrors({ invalidData: 'data is invalid', required: true });
            control.markAsTouched();
          }
        });
        setTimeout(() => {
          this.customErrorMsg = false;
        }, 1000);
      } else if (res.includes('csnd')) {
        const control = this.auditForm.get('csnd');
        control.setErrors({ invalidData: 'data is invalid' });
      } else if (res.includes('releaseFlag')) {
        const control = this.auditForm.get('releaseFlag');
        control.setErrors({ invalidData: 'data is invalid' });
      }
    }
  }
}
