import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { AuditComponent } from './audit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { AuditStoreService } from '@features/audit/services/audit.store.service';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { PassOrFail } from '@features/audit/models/audit.model';
import { DateInputComponent } from '@shared/components/date-input/date-input.component';
import { formatOption, setSelectValue } from 'src/app/utils';

describe('AuditComponent', () => {
  let component: AuditComponent;
  let fixture: ComponentFixture<AuditComponent>;
  let formBuilder: FormBuilder;
  let auditStoreService: AuditStoreService;
  let globalAlertStoreServiceMock: GlobalAlertStoreService;
  const dateInputComponent = jasmine.createSpyObj('DateInputComponent', ['dateValue', 'formatDate']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, ReactiveFormsModule],
      declarations: [AuditComponent, DateInputComponent],
      providers: [MockStore, provideMockStore(), AuditStoreService],
    }).compileComponents();

    fixture = TestBed.createComponent(AuditComponent);
    auditStoreService = TestBed.inject(AuditStoreService);
    globalAlertStoreServiceMock = TestBed.inject(GlobalAlertStoreService);
    formBuilder = TestBed.inject(FormBuilder);
    component = fixture.componentInstance;
    fixture.detectChanges();
    spyOn(Date.prototype, 'getFullYear').and.returnValue(2024);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call Syndicate Number and Refernce Form on init', () => {
    spyOn(component, 'initAuditForm');
    component.ngOnInit();
    expect(component.initAuditForm).toHaveBeenCalled();
  });

  it('should initialize the audit form with default values', () => {
    expect(component.auditForm).toBeDefined();
    expect(component.auditForm.get('csnd')).toBeDefined();
    expect(component.auditForm.get('brokerNumber')).toBeDefined();
  });

  it('should validate custom bigDecimalValidator', () => {
    const ukIPTamount = component.auditForm.get('ukIPTamount');
    ukIPTamount.setValue('123.456');
    expect(ukIPTamount.valid).toBeTruthy();
  });

  it('should set isGoBtnClicked to true when goBtnClicked is called', () => {
    spyOn(globalAlertStoreServiceMock, 'clearGlobalResponse');

    component.goBtnClicked(); // Assuming the event argument isn't used in the method
    const expected = '2222-12-01';
    component.plannedSettlementDate = dateInputComponent;
    dateInputComponent.formatDate.and.returnValue(expected);
    const payload = { ...component.auditForm.value };

    expect((payload.plannedSettlementDate = component.plannedSettlementDate.formatDate()));
    expect(component.isGoBtnClicked).toBeTrue();
    expect(globalAlertStoreServiceMock.clearGlobalResponse).toHaveBeenCalled();
  });

  it('should call goBtnClicked() when resumeClicked() is called', () => {
    spyOn(component, 'goBtnClicked');
    component.resumeClicked();
    expect(component.goBtnClicked).toHaveBeenCalled();
  });

  it('should set showDialog to false when okClicked() is called', () => {
    component.showDialog = true;
    component.okClicked();
    expect(component.showDialog).toBeFalse();
  });

  it('should return the correct date for LLOYDS format', () => {
    const result = component.extractSigningDate('2024102187465');
    expect(result).toBe('20241021');
  });

  xit('should return the correct date for LIRMA format', () => {
    const result = component.extractSigningDate('2410217361983');
    expect(result).toBe('20241021');
  });

  it('should return the correct date for ILU format', () => {
    const result = component.extractSigningDate('PMA247635182110');
    expect(result).toBe('20241021');
  });

  it('should return null for invalid format', () => {
    const result = component.extractSigningDate('INVALID123');
    expect(result).toBeNull();
  });

  it('should reset the form when onRestForm is called', () => {
    spyOn(component.plannedSettlementDate, 'resetDateForm');
    component.onRestForm();
    component.plannedSettlementDate = dateInputComponent;
    // expect( component.plannedSettlementDate.resetDateForm).toHaveBeenCalled();
    expect(component.auditForm.pristine).toBeTrue();
    expect(component.isAuditPass).toBeFalse();
    expect(component.isAuditFail).toBeFalse();
  });

  it('should update presigningAuditFail ', () => {
    spyOn(component, 'handleAuditFail');
    const testValue = 'test de valeur';
    component.presigningAuditFail = testValue;

    expect(component.presigningAuditFailValue).toEqual(testValue);
    expect(component.handleAuditFail).toHaveBeenCalledWith(testValue);
  });

  it('should call postPresigningAuditDecision with extracted string and clear global response in passAuditButton', () => {
    spyOn(globalAlertStoreServiceMock, 'clearGlobalResponse');
    spyOn(auditStoreService, 'postPresigningAuditDecision');
    component.presigningAuditPassValue = `12'34'5`;
    fixture.detectChanges();
    component.auditPassButton();
    expect(auditStoreService.postPresigningAuditDecision).toHaveBeenCalledWith('34', PassOrFail.Pass);
    expect(globalAlertStoreServiceMock.clearGlobalResponse).toHaveBeenCalled();
  });

  it('should not call postPresigningAuditDecision with invalid string and clear global response', () => {
    spyOn(globalAlertStoreServiceMock, 'clearGlobalResponse');
    spyOn(auditStoreService, 'postPresigningAuditDecision');
    component.presigningAuditPassValue = '12345';
    fixture.detectChanges();
    component.auditPassButton();
    expect(auditStoreService.postPresigningAuditDecision).not.toHaveBeenCalled();
    expect(globalAlertStoreServiceMock.clearGlobalResponse).toHaveBeenCalled();
  });

  it('should not call postPresigningAuditDecision with invalid data and clear global response in failAuditButton', () => {
    spyOn(globalAlertStoreServiceMock, 'clearGlobalResponse');
    spyOn(auditStoreService, 'postPresigningAuditDecision');
    component.presigningAuditPassValue = '12345';
    fixture.detectChanges();
    component.failAuditButton();
    expect(auditStoreService.postPresigningAuditDecision).toHaveBeenCalled();
    expect(globalAlertStoreServiceMock.clearGlobalResponse).toHaveBeenCalled();
  });

  it(' should update  presigningAuditPass', () => {
    spyOn(component.auditForm, 'reset');
    spyOn(component.plannedSettlementDate, 'resetDateForm');
    const testValue = 'valid value';
    component.presigningAuditPass = testValue;
    expect(component.presigningAuditPassValue).toEqual(testValue);
    expect(component.isAuditPass).toBeTrue();
    expect(component.isAuditFail).toBeFalse();
    expect(component.auditForm?.reset).toHaveBeenCalled();
    expect(component.plannedSettlementDate.resetDateForm).toHaveBeenCalled();
    Object.keys(component.auditForm?.controls).forEach((key) => {
      const control = component.auditForm?.controls[key];
      control.markAsTouched();
      expect(control.errors).toBeNull();
    });
  });

  it(' it should set referenceData string reseponse', () => {
    spyOn(component, 'formatSelects');
    component.referenceData = 'fdfd';
    const expected = 'fdfd';
    expect(component.refData).toEqual(expected);
    expect(component.formatSelects).toHaveBeenCalledWith(expected);
  });

  it(' it should set presigningAuditFail string reseponse', () => {
    spyOn(component, 'handleAuditFail');
    component.presigningAuditFail = 'fdfd';
    const expected = 'fdfd';
    expect(component.presigningAuditFailValue).toEqual(expected);
    expect(component.handleAuditFail).toHaveBeenCalledWith(expected);
  });

  it('should mark all form controls as touched', () => {
    component.markAllAsTouched(); // Invoke your method
    let allTouched = true;

    // Check if all controls are marked as touched
    Object.keys(component.auditForm.controls).forEach((field) => {
      const control = component.auditForm.get(field);
      if (!control.touched) {
        allTouched = false;
      }
    });

    expect(allTouched).toBeTrue(); // Expect all controls to be marked as touched
  });

  ////////////////////////////////////////////////////////////////////

  it('should return false when settlementCurrency has no value and touched', () => {
    const settlementCurrency = component.auditForm.get('settlementCurrency');
    settlementCurrency.setValue(''); // Invalid value
    settlementCurrency.markAsTouched(); // Mimic touching the field

    expect(component.isSettlementCurrencyInvalid()).toBeFalse();
  });

  it('should return false when settlementCurrency is valid', () => {
    const settlementCurrency = component.auditForm.get('settlementCurrency');
    settlementCurrency.setValue('USD'); // Assuming 'USD' is a valid value
    settlementCurrency.markAsTouched();

    expect(component.isSettlementCurrencyInvalid()).toBeFalse();
  });

  it('should return false when settlementCurrency is invalid but not touched or dirty', () => {
    const settlementCurrency = component.auditForm.get('settlementCurrency');
    settlementCurrency.setValue(''); // Invalid value, not touched or dirty

    expect(component.isSettlementCurrencyInvalid()).toBeFalse();
  });

  it('should return false when settlementCurrency has no value and dirty', () => {
    const settlementCurrency = component.auditForm.get('settlementCurrency');
    settlementCurrency.setValue('');
    settlementCurrency.markAsDirty(); // Mimic editing the field

    expect(component.isSettlementCurrencyInvalid()).toBeFalse();
  });

  ////////////////////////////////////

  it('should handle audit fail with csnd', () => {
    const res = 'csnd';
    component.handleAuditFail(res);

    const control = component.auditForm.get('csnd');
    expect(control.errors).toEqual({ invalidData: 'data is invalid' });
    expect(component.customErrorMsg).toBeTrue();
    expect(component.isAuditFail).toBeTrue();
    expect(component.isAuditPass).toBeFalse();
  });

  it('should handle audit fail with releaseFlag', () => {
    const res = 'releaseFlag';
    component.handleAuditFail(res);
    const control = component.auditForm.get('releaseFlag');
    expect(control.errors).toEqual({ invalidData: 'data is invalid' });
    expect(component.customErrorMsg).toBeTrue();
    expect(component.isAuditFail).toBeTrue();
    expect(component.isAuditPass).toBeFalse();
  });

  it('correctly formats isoCurrency and transactionType options from refData', () => {
    spyOn(component, 'formatSelects');
    const refdata = {};
    expect(component.isoCurrencyOptions).toEqual(formatOption('isoCurrency', 'code', 'id', refdata));
    expect(component.transactionTypeOptions).toEqual(formatOption('transactionType', 'description', 'id', refdata));
  });

  const mockValues = [{ value: '1' }, { value: '2' }, { value: '3' }, { value: '4' }, { value: '5' }, { value: '6' }];

  it('assigns the correct ID for "PM" input', () => {
    const result = component.assignIdtoTransactionTpe('PM', mockValues);
    expect(result).toEqual({ refTypeOfTransactionTypeId: '4', typeOfTransactionType: 'PM' });
  });

  it('assigns the correct ID for "AP" input', () => {
    const result = component.assignIdtoTransactionTpe('AP', mockValues);
    expect(result).toEqual({ refTypeOfTransactionTypeId: '1', typeOfTransactionType: 'AP' });
  });

  it('assigns the correct ID for "C" input', () => {
    const result = component.assignIdtoTransactionTpe('C', mockValues);
    expect(result).toEqual({ refTypeOfTransactionTypeId: '1', typeOfTransactionType: 'AP' });
  });

  it('assigns the correct ID for "RP" input', () => {
    const result = component.assignIdtoTransactionTpe('RP', mockValues);
    expect(result).toEqual({ refTypeOfTransactionTypeId: '6', typeOfTransactionType: 'RP' });
  });

  it('assigns the correct ID for "D" input', () => {
    const result = component.assignIdtoTransactionTpe('D', mockValues);
    expect(result).toEqual({ refTypeOfTransactionTypeId: '6', typeOfTransactionType: 'RP' });
  });

  it('handles unknown input appropriately', () => {
    // This test depends on your function's expected behavior for unknown inputs
    const result = component.assignIdtoTransactionTpe('XYZ', mockValues);
    // Example expectation if function returns undefined for unknown inputs
    expect(result).toBeUndefined();
  });
});
