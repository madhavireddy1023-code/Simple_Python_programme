import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MainAuditComponent } from './main-audit.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';

describe('MainAuditComponent', () => {
  let component: MainAuditComponent;
  let fixture: ComponentFixture<MainAuditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainAuditComponent],
      providers: [MockStore, provideMockStore(), ReferenceDataStoreService],
      imports: [TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
