import { Component, OnInit } from '@angular/core';
import { AuditStoreService } from '@features/audit/services/audit.store.service';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-main-audit',
  templateUrl: './main-audit.component.html',
  styleUrls: ['./main-audit.component.scss'],
})
export class MainAuditComponent implements OnInit {
  referenceData$: Observable<any>;
  presigningAuditPass$: Observable<any>;
  presigningAuditFail$: Observable<any>;
  postSigningAuditFailButton$: Observable<boolean>;
  responseData$: Observable<any>;

  constructor(
    private referenceDataStoreService: ReferenceDataStoreService,
    private auditStoreService: AuditStoreService,
    private globalAlertStoreService: GlobalAlertStoreService
  ) {}

  ngOnInit(): void {
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.referenceData$ = this.referenceDataStoreService.selectSummaryDetails();
    this.presigningAuditPass$ = this.auditStoreService.presigningAuditPass();
    this.presigningAuditFail$ = this.auditStoreService.presigningAuditFail();
    this.postSigningAuditFailButton$ = this.auditStoreService.postSigningAuditFailButton();
  }
}
