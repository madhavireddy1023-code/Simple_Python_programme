import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';

import { AuditRoutingModule } from './audit-routing.module';
import { MainAuditComponent } from './main/main-audit/main-audit.component';
import { AuditComponent } from './components/audit/audit.component';

@NgModule({
  declarations: [MainAuditComponent, AuditComponent],
  imports: [CommonModule, SharedModule, AuditRoutingModule],
})
export class AuditModule {}
