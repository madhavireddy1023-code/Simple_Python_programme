export interface PresigningAuditState {
  content: string;
  error: any;
  auditFailButton: boolean;
}

export enum PassOrFail {
  Pass = 'PASS',
  Fail = 'FAIL',
}
export interface AuditFail {
  detail: string;
  domain: string;
  errorCode: number;
  title: string;
  type: string;
}
