import { PresigningAuditRecord } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

export const auditPayload: PresigningAuditRecord = {
  csnd: '99416 08032024',
  brokerNumber: 'B3485',
  brokerReference1: 'string',
  brokerReference2: 'string',
  settlementCurrency: {
    refTypeCurrencyId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
    typeOfCurrency: 'GBP',
  },
  premiumNet: 10,
  transactionType: {
    refTypeOfTransactionTypeId: 'e41ceeb2-cbe1-4565-8632-fe0bdcd1ac45',
    typeOfTransactionType: 'Premium',
  },
  releaseFlag: 'Cash',
  ukIPTamount: 112.76,
  overseasAddedTax: 112.76,
  submissionId: '16d832c0-4fce-4961-b2ce-cc4f5c3757d2',
};

export const lloydsRegex = /^\d{4}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])\d{5}$/; // YYYYMMDDNNNNN
export const lirmaRegex = /^\d{2}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])\d{7}$/; // YYMMDDNNNNNNN
export const iluRegex = /^[A-Z]{3}\d{2}\d{6}\d{4}$/; // AAAYYNNNNNNDDMM
