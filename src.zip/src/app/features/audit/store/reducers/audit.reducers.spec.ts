import { AuditReducer, initialState } from './audit.reducers';
import { Action } from '@ngrx/store';
import * as actions from '../actions/audit.action';

describe('AuditReducer', () => {
  it('should return the initial state', () => {
    const action = {} as Action;
    const state = AuditReducer(undefined, action);
    expect(state).toBe(initialState);
  });

  it('should update the state of PRESIGNING_AUDIT_PASS', () => {
    const content = 'mockSearchResult';
    const action = actions.presigningAuditPass({ content });
    const newState = AuditReducer(initialState, action);
    expect(newState.content).toEqual(content);
  });

  it('should update the state of PRESIGNING_AUDIT_PASS', () => {
    const error = 'mockSearchResult';
    const action = actions.presigningAuditFail({ error });
    const newState = AuditReducer(initialState, action);
    expect(newState.error).toEqual(error);
  });

  it('should update the state of PRESIGNING_AUDIT_PASS', () => {
    const auditFailButton = true;
    const action = actions.auditFailButton({ auditFailButton });
    const newState = AuditReducer(initialState, action);
    expect(newState.auditFailButton).toEqual(auditFailButton);
  });

  it('should up clear the error of PRESIGNING_AUDIT_PASS', () => {
    const action = actions.clearAuditError();
    const newState = AuditReducer(initialState, action);
    expect(newState.error).toEqual(null);
  });
});
