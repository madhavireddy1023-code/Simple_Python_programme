import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/audit.action';
import * as _ from 'lodash';
import { PresigningAuditState } from '@features/audit/models/audit.model';

export const initialState: PresigningAuditState = {
  content: '',
  error: '',
  auditFailButton: false,
};

export const AuditReducer: ActionReducer<PresigningAuditState, Action> = createReducer(
  initialState,

  on(actions.presigningAuditPass, (state: PresigningAuditState, action) =>
    _.setWith(_.clone(state), 'content', action.content, _.clone)
  ),

  on(actions.presigningAuditFail, (state: PresigningAuditState, action) =>
    _.setWith(_.clone(state), 'error', action.error, _.clone)
  ),
  on(actions.clearAuditError, (state) => ({
    ..._.clone(state),
    error: null,
  })),

  on(actions.auditFailButton, (state: PresigningAuditState, action) =>
    _.setWith(_.clone(state), 'auditFailButton', action.auditFailButton, _.clone)
  )
);
