import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, from, of } from 'rxjs';
import { catchError, concatMap, switchMap } from 'rxjs/operators';
import * as actions from '../actions/audit.action';
import { DomainAPITechnicianPortalCorrectionService } from 'src/app/api/domain-api-technician-portal-correction';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { ScrollUp } from 'src/app/utils';
import * as summaryActions from '@features/summary/store/actions/summary.action';
import * as sidePanelActions from '../../../../store/actions/side-panel.action';
import { PassOrFail } from '@features/audit/models/audit.model';
import { AuditStoreService } from '@features/audit/services/audit.store.service';

@Injectable()
export class AuditEffects {
  constructor(
    private actions$: Actions,
    private domainAPITechnicianPortalCorrectionService: DomainAPITechnicianPortalCorrectionService,
    private auditStoreService: AuditStoreService
  ) {}

  postPresigningAudit$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.postPresigningAudit),
      concatMap((action) => {
        return this.domainAPITechnicianPortalCorrectionService
          .apiV1PresigningAuditPost(action.presigningAuditRecord, 'response')
          .pipe(
            concatMap((response) => {
              ScrollUp(0, 0);
              const actionsArray = [
                actions.presigningAuditPass({ content: response.body.content }),
                loadGlobalAlert({
                  response: { response, status: 200, isGlobalAlert: true },
                }),
              ];
              return from(actionsArray);
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 400) {
                if (error?.error && Array.isArray(error?.error) && error?.error?.length > 0) {
                  if (error?.error[0].errorCode === 400) {
                    return from(this.auditErrorHandler400Code(error));
                  }

                  return from([...this.auditErrorHandlerNon400Code(error)]);
                }
              }
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              // Out of 400 http status code
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  postPresigningAuditDecision$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.presigningAuditDecision),
      switchMap((action) => {
        return this.domainAPITechnicianPortalCorrectionService
          .apiV1PresigningAuditDecisionPost(action.cnsd, action.decision, 'response')
          .pipe(
            switchMap((response) => {
              let message;
              let status;
              let presigningAudit;
              if (action.decision === PassOrFail.Fail) {
                message = 'Audit fail recorded successfully';
                status = 400;
                presigningAudit = actions.presigningAuditFail({ error: response.body.content });
              } else {
                message = 'Audit Pass recorded successfully';
                status = 200;
                presigningAudit = actions.presigningAuditPass({ content: response.body.content });
              }
              ScrollUp(0, 0);
              const actionsArray = [
                presigningAudit,
                loadGlobalAlert({
                  response: {
                    responseMessage: message,
                    status,
                    isGlobalAlert: true,
                  },
                }),
              ];
              return from(actionsArray);
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(
                loadGlobalAlert({
                  response: {
                    error,
                    responseMessage: 'Audit Fail recorded successfully',
                    status: 400,
                    isGlobalAlert: true,
                  },
                })
              );
            }) // Handle errors by returning them as an observable
          );
      })
    )
  );

  updateAuditStatus$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.updateAuditStatus),
      switchMap((action) => {
        return this.domainAPITechnicianPortalCorrectionService
          .apiV1PresingingAuditEditPatch(action?.body, 'response')
          .pipe(
            switchMap((response) => {
              return of(
                summaryActions.getSummarySubmissions({
                  bureau: action?.bureau,
                  umr: action?.umr,
                  workPackageRef: action?.workPackageRef,
                }),
                sidePanelActions.getSidePanelData({
                  bureau: action?.bureau,
                  umr: action?.umr,
                  workPackageRef: action?.workPackageRef,
                })
              );
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          );
      })
    )
  );

  auditErrorHandler400Code(error): any {
    let detailMessage;
    detailMessage = error.error[0].detail;
    const actionsArray = [
      actions.presigningAuditFail({ error: detailMessage }),
      loadGlobalAlert({
        response: { error, responseMessage: 'Invalid input', status: 400, isGlobalAlert: true },
      }),
    ];
    return actionsArray;
  }

  auditErrorHandlerNon400Code(error): any {
    const errorRes = error?.error?.map((item) => {
      if (item?.errorCode === 6015) {
        this.auditStoreService.setPostSigningStatus(true);
      }

      return loadGlobalAlert({
        response: {
          error,
          responseMessage: item?.detail,
          status: 400,
          isGlobalAlert: true,
          isMultiple: true,
        },
      });
    });
    return errorRes;
  }
}
