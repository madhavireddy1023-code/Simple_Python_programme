import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable, of, throwError } from 'rxjs';
import { take } from 'rxjs/operators';
import * as action from '../actions/audit.action';
import { initialState } from '../reducers/audit.reducers';
import { DomainAPITechnicianPortalCorrectionService } from 'src/app/api/domain-api-technician-portal-correction';
import { AuditEffects } from './audit.effects';
import { auditPayload } from '@features/audit/const/payloads.const';
import { MainAuditComponent } from '@features/audit/main/main-audit/main-audit.component';
import { PassOrFail } from '@features/audit/models/audit.model';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { getSummarySubmissions } from '@features/summary/store/actions/summary.action';

describe('AuditEffects', () => {
  let actions$: Observable<any>;
  let effects: AuditEffects;
  let domainTechnicianPortalCorrectionService: jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;

  beforeEach(() => {
    const domainAPITechnicianPortalCorrectionServiceSpy = jasmine.createSpyObj(
      'DomainAPITechnicianPortalCorrectionService',
      ['apiV1PresigningAuditPost', 'apiV1PresigningAuditDecisionPost', 'apiV1PresingingAuditEditPatch']
    );

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([{ path: 'audit', component: MainAuditComponent }]),
      ],
      providers: [
        AuditEffects,
        {
          provide: DomainAPITechnicianPortalCorrectionService,
          useValue: domainAPITechnicianPortalCorrectionServiceSpy,
        },
        provideMockStore({ initialState }),
        provideMockActions(() => actions$),
      ],
    });
    effects = TestBed.inject(AuditEffects);
    domainTechnicianPortalCorrectionService = TestBed.inject(
      DomainAPITechnicianPortalCorrectionService
    ) as jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;
  });

  it('should test postPresigningAudit$ effect', () => {
    const mockResponseContent = 'Success Content';
    actions$ = of(action.postPresigningAudit({ presigningAuditRecord: auditPayload }));
    domainTechnicianPortalCorrectionService.apiV1PresigningAuditPost.and.returnValue(
      of(new HttpResponse({ body: { content: mockResponseContent }, status: 200 }))
    );
    const expectedActions = [
      action.presigningAuditPass({ content: mockResponseContent }),
      loadGlobalAlert({
        response: { response: jasmine.anything(), status: 200, isGlobalAlert: true },
      }),
    ];
    const actionsEmitted = [];
    effects.postPresigningAudit$.subscribe({
      next: (actionEmitted) => {
        actionsEmitted.push(actionEmitted);
      },
      complete: () => {
        expect(actionsEmitted.length).toEqual(expectedActions.length);
        expect(actionsEmitted[0].type).toEqual(action.presigningAuditPass.type);
        expect(actionsEmitted[0].content).toEqual(mockResponseContent);
      },
    });
  });

  it('should dispatch the correct actions for a successful postPresigningAuditDecision', (done) => {
    const mockResponseContent = 'Success Content';
    actions$ = of(action.presigningAuditDecision({ cnsd: 'someCnsd', decision: PassOrFail.Pass }));
    domainTechnicianPortalCorrectionService.apiV1PresigningAuditDecisionPost.and.returnValue(
      of(new HttpResponse({ body: { content: mockResponseContent }, status: 200 }))
    );

    const expectedActions = [
      action.presigningAuditPass({ content: mockResponseContent }),

      loadGlobalAlert({
        response: { responseMessage: 'Audit pass recorded successfully', status: 200, isGlobalAlert: true }, // Adjust based on decision
      }),
    ];

    const actionsEmitted = [];
    effects.postPresigningAuditDecision$.subscribe({
      next: (actionEmitted) => {
        actionsEmitted.push(actionEmitted);
      },
      complete: () => {
        expect(actionsEmitted.length).toEqual(expectedActions.length);
        expect(actionsEmitted).toContain(
          jasmine.objectContaining({
            type: action.presigningAuditPass.type,
            content: mockResponseContent,
          })
        );

        done();
      },
    });
  });

  it('should dispatch the correct actions for a failed postPresigningAuditDecision', (done) => {
    const errorMessage = 'Error occurred';
    actions$ = of(action.presigningAuditDecision({ cnsd: 'someCnsd', decision: PassOrFail.Fail }));
    domainTechnicianPortalCorrectionService.apiV1PresigningAuditDecisionPost.and.returnValue(
      throwError({ error: [{ detail: errorMessage }] })
    );

    const expectedActions = [
      action.presigningAuditFail({ error: errorMessage }),

      loadGlobalAlert({
        response: { responseMessage: 'Audit Fail recorded successfully', status: 400, isGlobalAlert: true },
      }),
    ];

    const actionsEmitted = [];
    effects.postPresigningAuditDecision$.subscribe({
      next: (actionEmitted) => {
        actionsEmitted.push(actionEmitted);
      },
      error: done,
      complete: () => {
        expect(actionsEmitted.length).toBeGreaterThanOrEqual(expectedActions.length - 1);
        done();
      },
    });
  });

  it('should test updateAuditStatus$ effect', () => {
    const body = [{ version: 1, id: 'c7d33163-568a-4939-88b6-a4defaf7268d' }];
    actions$ = of(action.updateAuditStatus({ body }));
    domainTechnicianPortalCorrectionService.apiV1PresingingAuditEditPatch.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.updateAuditStatus$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(getSummarySubmissions.type);
    });
  });
});
