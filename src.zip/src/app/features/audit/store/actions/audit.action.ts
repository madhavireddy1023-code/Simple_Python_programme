import { createAction, props } from '@ngrx/store';
import { PresigningAuditRecord, IdAndVersion } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { AuditFail, PassOrFail } from '@features/audit/models/audit.model';
const AUDIT_PREFIX = '[AUDIT]';

// POST_PRESIGNING_AUDIT
const POST_PRESIGNING_AUDIT = `${AUDIT_PREFIX} POST_PRESIGNING_AUDIT`;
export const postPresigningAudit = createAction(
  POST_PRESIGNING_AUDIT,
  props<{ presigningAuditRecord: PresigningAuditRecord }>()
);

// PRESIGNING_AUDIT_PASS
const PRESIGNING_AUDIT_PASS = `${AUDIT_PREFIX} PRESIGNING_AUDIT_PASS`;
export const presigningAuditPass = createAction(PRESIGNING_AUDIT_PASS, props<{ content: string }>());

// PRESIGNING_AUDIT_FAIL
const PRESIGNING_AUDIT_FAIL = `${AUDIT_PREFIX} PRESIGNING_AUDIT_FAIL`;
export const presigningAuditFail = createAction(PRESIGNING_AUDIT_FAIL, props<{ error: string }>());

// PRESIGNING_AUDIT_DECISION_PATCH
const PRESIGNING_AUDIT_DECISION_PATCH = `${AUDIT_PREFIX} PRESIGNING_AUDIT_DECISION_PATCH`;
export const presigningAuditDecision = createAction(
  PRESIGNING_AUDIT_DECISION_PATCH,
  props<{ cnsd: string; decision: PassOrFail }>()
);

// UPDATE_AUDIT_STATUS
const UPDATE_AUDIT_STATUS = `${AUDIT_PREFIX} UPDATE_AUDIT_STATUS`;
export const updateAuditStatus = createAction(
  UPDATE_AUDIT_STATUS,
  props<{ body: IdAndVersion[]; bureau?; umr?; workPackageRef? }>()
);

// CLEAR_PRESIGNING_AUDIT
const CLEAR_PRESIGNING_AUDIT = `${AUDIT_PREFIX} CLEAR_PRESIGNING_AUDIT`;
export const clearAuditError = createAction(CLEAR_PRESIGNING_AUDIT);

// AUDIT_FAIL_BUTTON
const AUDIT_FAIL_BUTTON = `${AUDIT_PREFIX} AUDIT_FAIL_BUTTON`;
export const auditFailButton = createAction(AUDIT_FAIL_BUTTON, props<{ auditFailButton: boolean }>());
