import {
  postPresigningAudit,
  presigningAuditFail,
  presigningAuditPass,
  presigningAuditDecision,
  auditFailButton,
  clearAuditError,
  updateAuditStatus,
} from './audit.action';

describe('audit Actions', () => {
  it('should return correct types', () => {
    expect(postPresigningAudit.type).toEqual('[AUDIT] POST_PRESIGNING_AUDIT');

    expect(presigningAuditPass.type).toEqual('[AUDIT] PRESIGNING_AUDIT_PASS');

    expect(presigningAuditFail.type).toEqual('[AUDIT] PRESIGNING_AUDIT_FAIL');

    expect(presigningAuditDecision.type).toEqual('[AUDIT] PRESIGNING_AUDIT_DECISION_PATCH');
    expect(auditFailButton.type).toEqual('[AUDIT] AUDIT_FAIL_BUTTON');

    expect(clearAuditError.type).toEqual('[AUDIT] CLEAR_PRESIGNING_AUDIT');
    expect(updateAuditStatus.type).toEqual('[AUDIT] UPDATE_AUDIT_STATUS');
  });
});
