import { createSelector } from '@ngrx/store';

import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.audit;

export const selectAuditPass = createSelector(selectState, (state) => state?.content);

export const selectAuditFail = createSelector(selectState, (state) => state?.error);

// Select Audit failed button status
export const auditFailButton = createSelector(selectState, (state) => state?.auditFailButton);
