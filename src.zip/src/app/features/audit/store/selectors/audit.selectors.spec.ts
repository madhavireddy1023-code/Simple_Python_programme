import * as selectors from './audit.selectors';

describe('Audit selector', () => {
  const state = {
    content: 'Test content',
    error: null,
  };

  it('should select selectAuditContent', () => {
    const expectedData = 'Test content';
    const content = selectors.selectAuditPass.projector(state);
    expect(content).toEqual(expectedData);
  });
});
