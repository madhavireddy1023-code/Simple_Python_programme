import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainAuditComponent } from '@features/audit/main/main-audit/main-audit.component';

const routes: Routes = [{ path: '', component: MainAuditComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuditRoutingModule {}
