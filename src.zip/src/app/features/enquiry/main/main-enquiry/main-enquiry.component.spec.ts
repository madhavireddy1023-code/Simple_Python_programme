import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainEnquiryComponent } from './main-enquiry.component';
import { TranslateModule } from '@ngx-translate/core';
import {
  CreateEnquiryBrokerPayload,
  CreateEnquirySyndicateCompanyPayload,
  CreateEnquiryUMRPayload,
  CreateEnquiryWPRPayload,
  CreateFacilityPayload,
} from '@features/enquiry/const/payloads.const';
import { EnquiryService } from '@features/enquiry/services/enquiry.service';
import { UniqueMarketReferenceComponent } from '@features/enquiry/components/unique-market/unique-market-reference.component';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { WorkPackageReferenceComponent } from '@features/enquiry/components/work-package-reference/work-package-reference.component';
import { SyndicateComponent } from '@features/enquiry/components/syndicate/syndicate.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { IdentityProviderService } from '@shared/services/identity-provider/identity-provider.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Role } from '@shared/consts/shared.enums';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import {
  tableStandardColumns,
  tableStandardColumnsExpanded,
  tableModifiedColumns,
  tableModifiedColumnsExpanded,
} from '@features/enquiry/const/table-columns';
import { SortPipe } from '@shared/pipes/sort.pipe';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';

describe('MainEnquiryComponent', () => {
  let component: MainEnquiryComponent;
  let fixture: ComponentFixture<MainEnquiryComponent>;
  const enquiryServiceSpy = jasmine.createSpyObj('EnquiryService', [
    'getSearchPremiumEnquiry',
    'selectEnquiryDataSearch',
    'clearData',
  ]);
  beforeEach(async () => {
    const authMock = {
      roles$: of([
        Role.PROCESS_ENQUIRY_BROKER,
        Role.PROCESS_ENQUIRY_CARRIER,
        Role.PROCESS_TEAM_MANAGER,
        Role.All_Tech_Premiums,
      ]),
    };
    await TestBed.configureTestingModule({
      declarations: [
        MainEnquiryComponent,
        UniqueMarketReferenceComponent,
        WorkPackageReferenceComponent,
        SyndicateComponent,
        SortPipe,
      ],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule, HttpClientTestingModule],
      providers: [
        { provide: EnquiryService, useValue: enquiryServiceSpy },
        { provide: AuthenticationService, useValue: authMock },
        MockStore,
        provideMockStore(),
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: of({}),
          },
        },
        IdentityProviderService,
        GlobalAlertStoreService,
        ReferenceDataStoreService
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainEnquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create mainEnquiryComponent', () => {
    expect(component).toBeTruthy();
  });

  it('should set payload to UMR payload and call getSearchPremiumEnquiry', () => {
    const umrVal = '12345678';
    const umrComponentSpy = jasmine.createSpyObj('UniqueMarketReferenceComponent', [], {
      umrForm: new FormGroup({ umr: new FormControl(umrVal, Validators.required) }),
    });
    component.uniqueMarketReferenceComponentView = umrComponentSpy;
    const expectedPayload = CreateEnquiryUMRPayload(
      { umr: umrVal },
      component.isInProgress,
      component.signingDateRange?.startDate.formatDate(),
      component.signingDateRange?.endDate.formatDate()
    );
    fixture.detectChanges();
    component.onSearch();
    expect(enquiryServiceSpy.getSearchPremiumEnquiry).toHaveBeenCalledWith(expectedPayload);
  });

  it('should set payload to WPR payload and call getSearchPremiumEnquiry', () => {
    const wprVal = '12345678';
    const wprComponentSpy = jasmine.createSpyObj('WorkPackageReferenceComponent', [], {
      workPackageReferenceForm: new FormGroup({ workPackageReference: new FormControl(wprVal, Validators.required) }),
    });
    component.workPackageReferenceComponentView = wprComponentSpy;
    const expectedPayload = CreateEnquiryWPRPayload(
      { workPackageReference: wprVal },
      component.signingDateRange?.startDate.formatDate(),
      component.signingDateRange?.endDate.formatDate(),
      component.isInProgress
    );
    fixture.detectChanges();
    component.onSearch();
    expect(enquiryServiceSpy.getSearchPremiumEnquiry).toHaveBeenCalledWith(expectedPayload);
  });

  it('should set payload to syndicateComponent payload and call CreateEnquirySyndicateCompanyPayload', () => {
    const syndicateComponentSpy = jasmine.createSpyObj('SyndicateComponent', [], {
      syndicateNumberReferenceForm: new FormGroup({
        syndicateCompanyNumber: new FormControl('1', Validators.required),
        syndicateCompanyReference: new FormControl('22', Validators.required),
      }),
    });
    component.syndicateComponentView = syndicateComponentSpy;
    const expectedPayload = CreateEnquirySyndicateCompanyPayload(
      {
        syndicateCompanyNumber: '1',
        syndicateCompanyReference: '22',
      },
      component.signingDateRange?.startDate.formatDate(),
      component.signingDateRange?.endDate.formatDate(),
      component.isInProgress
    );
    fixture.detectChanges();
    component.onSearch();
    expect(enquiryServiceSpy.getSearchPremiumEnquiry).toHaveBeenCalledWith(expectedPayload);
  });

  it('should set payload to brokerNoReference payload and call CreateEnquiryBrokerPayload', () => {
    const brokerNoReference = jasmine.createSpyObj('brokerNoReference', [], {
      brokerNoReferenceForm: new FormGroup({
        brokerNumber: new FormControl('1', Validators.required),
        brokerReference: new FormControl('22', Validators.required),
      }),
    });
    component.brokerNoReferenceComponentView = brokerNoReference;
    const expectedPayload = CreateEnquiryBrokerPayload(
      {
        brokerNumber: '1',
        brokerReference: '22',
      },
      component.signingDateRange?.startDate.formatDate(),
      component.signingDateRange?.endDate.formatDate(),
      component.isInProgress
    );
    fixture.detectChanges();
    component.onSearch();
    expect(enquiryServiceSpy.getSearchPremiumEnquiry).toHaveBeenCalledWith(expectedPayload);
  });
  it('should set payload to FacilitySearchComponent payload and call CreateEnquiryFacilitySearchPayload', () => {
    const FacilitySearchComponentSpy = jasmine.createSpyObj('FacilitySearchComponent', [], {
      facilityForm: new FormGroup({
        YOANumberDate: new FormControl('1234567891012', Validators.required),
      }),
    });
    component.facilityComponentView = FacilitySearchComponentSpy;
    const expectedPayload = CreateFacilityPayload(
      {
        YOANumberDate: '1234567891012',
      },
      component.isInProgress
    );
    fixture.detectChanges();
    component.onSearch();
    expect(enquiryServiceSpy.getSearchPremiumEnquiry).toHaveBeenCalledWith(expectedPayload);
  });

  it('should update isInProgress when the "in progress" checkbox is changed', () => {
    component.inProgressChanged(true);
    expect(component.isInProgress).toBeTrue();

    component.inProgressChanged(false);
    expect(component.isInProgress).toBeFalse();
  });

  it('should reset signing dates when the "in progress" checkbox is changed', () => {
    const resetSigningDatesSpy = spyOn(component, 'resetSigningDates');
    component.inProgressChanged(true);
    expect(resetSigningDatesSpy).toHaveBeenCalled();
  });

  it('should reset the start and end dates of the signingDateRange', () => {
    const mockStartDate = { resetDateForm: jasmine.createSpy('resetDateForm') };
    const mockEndDate = { resetDateForm: jasmine.createSpy('resetDateForm') };

    component.signingDateRange = {
      startDate: mockStartDate,
      endDate: mockEndDate,
    } as any;

    component.resetSigningDates();

    expect(mockStartDate.resetDateForm).toHaveBeenCalled();
    expect(mockEndDate.resetDateForm).toHaveBeenCalled();
  });

  it('should show in progress indicator if user is broker or carrier and Technician', () => {
    component.checkProgressIndicatorUnAuthorizedRoles();
    expect(component.hideInProgressIndicator).toBeFalse();
  });
  it('should update table columns to standard view', () => {
    component.updateTableColumns('standard');
    expect(component.tableView).toBe('standard');
    expect(component.tableColumns).toEqual(tableStandardColumns);
    expect(component.tableExpandRow).toEqual(tableStandardColumnsExpanded);
  });
  it('should update table columns to modified view', () => {
    component.updateTableColumns('modified');
    expect(component.tableView).toBe('modified');
    expect(component.tableColumns).toEqual(tableModifiedColumns);
    expect(component.tableExpandRow).toEqual(tableModifiedColumnsExpanded);
  });
});
