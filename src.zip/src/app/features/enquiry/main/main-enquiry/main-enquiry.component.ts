import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import {
  PremiumEnquiryRecords,
  SearchCriteriaTechnicianPremiumsProcessor,
  TechnicianSVDetails,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { EnquiryService } from '@features/enquiry/services/enquiry.service';
import { SyndicateComponent } from '@features/enquiry/components/syndicate/syndicate.component';
import { BrokerNoReferenceComponent } from '@features/enquiry/components/broker-no-reference/broker-no-reference.component';
import { UniqueMarketReferenceComponent } from '@features/enquiry/components/unique-market/unique-market-reference.component';
import { WorkPackageReferenceComponent } from '@features/enquiry/components/work-package-reference/work-package-reference.component';
import { ENQUIRY_OPTIONS, SIGNING_OPTIONS } from '@features/enquiry/const/enquiry.const';
import { TableColumn } from '@shared/models/interfaces';
import { Observable, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { FormGroup } from '@angular/forms';
import { DateRangeComponent } from '@shared/components/date-range/date-range.component';
import {
  CreateEnquiryBrokerPayload,
  CreateEnquirySyndicateCompanyPayload,
  CreateEnquiryUMRPayload,
  CreateEnquiryVeloneticPayload,
  CreateEnquiryWPRPayload,
  CreateFacilityPayload,
} from '@features/enquiry/const/payloads.const';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { ActivatedRoute, Params } from '@angular/router';
import { EnquirySearchTableComponent } from '@features/enquiry/components/enquiry-search-table/enquiry-search-table.component';
import { SummaryStoreService } from '@features/summary/services/summary.store.service';
import { ChannelSubmission } from '@dxc.lm.sdk.angular/premiums-base-workflow-experience-api';
import { Role } from '@shared/consts/shared.enums';
import { AuthorizedStatusService } from '@shared/services/authorized-status/authorized-status.service';
import { SigningComponent } from '@features/enquiry/components/signing/signing.component';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { DefInstalmentService } from '@features/enquiry/services/def-instalment.service';
import { PremiumGetRec } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { Option } from '@dxc-technology/halstack-angular';
import { enquirySelectOptions } from './enquiry-select-options';
import {
  tableModifiedColumns,
  tableModifiedColumnsExpanded,
  tableStandardColumns,
  tableStandardColumnsExpanded,
} from '@features/enquiry/const/table-columns';
import { VeloneticComponent } from '@features/enquiry/components/velonetic/velonetic.component';
import { DatePipe } from '@angular/common';
import { FacilitySearchComponent } from '@features/enquiry/components/facility-search/facility-search.component';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
@Component({
  selector: 'app-main-enquiry',
  templateUrl: './main-enquiry.component.html',
  styleUrls: ['./main-enquiry.component.scss'],
})
export class MainEnquiryComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly signingOption = SIGNING_OPTIONS;
  readonly enquiryOption = ENQUIRY_OPTIONS;

  private destroy$ = new Subject<void>();
  mainEnquiryForm: FormGroup;
  searchEnquiryStatus: boolean;
  hideInProgressIndicator: boolean;
  isInProgress = false;
  searchEnquiryStatus$ = new Subject<boolean>();
  infoHeaderDetails$: Observable<TechnicianSVDetails>;
  umr: string;
  dataTable$: Observable<PremiumEnquiryRecords>;
  tableColumns: TableColumn[];
  tableExpandRow: TableColumn[];
  userName$: Observable<string>;
  recordCountAllItems: number;
  queryParams$: Observable<Params>;
  workflowSubmission$: Observable<ChannelSubmission>;
  premiumNavigation;
  responseData$: Observable<any>;
  instalmentDetails$: Observable<PremiumGetRec>;
  showCorrectionError: boolean;
  premiumDetail$: Observable<PremiumGetRec>;

  isAdvancedSearchVisible = false;

  @ViewChild('signingDateRange') signingDateRange: DateRangeComponent;
  @ViewChild(EnquirySearchTableComponent) enquirySearchTable: EnquirySearchTableComponent;
  @ViewChild(SyndicateComponent) syndicateComponentView: SyndicateComponent;
  @ViewChild(BrokerNoReferenceComponent) brokerNoReferenceComponentView: BrokerNoReferenceComponent;
  @ViewChild(UniqueMarketReferenceComponent) uniqueMarketReferenceComponentView: UniqueMarketReferenceComponent;
  @ViewChild(WorkPackageReferenceComponent) workPackageReferenceComponentView: WorkPackageReferenceComponent;
  @ViewChild(VeloneticComponent) VeloneticComponentView: VeloneticComponent;
  @ViewChild(FacilitySearchComponent) facilityComponentView: FacilitySearchComponent;
  roles$: Observable<string[]> = this.authorizedStatusService.roles$;
  @ViewChild(SigningComponent) signingComponentView: SigningComponent;
  datePipe = new DatePipe('en-UK');
  selectedEquiryOption: string = this.enquiryOption.SIGNING_NUMBER_AND_DATE;
  enquiryOptions!: Option[];
  tableView: 'standard' | 'modified' = 'standard';
  isUMRSearchSmallScreen = false;
  constructor(
    private enquiryService: EnquiryService,
    private authorizedStatusService: AuthorizedStatusService,
    private infoHeaderStoreService: InfoHeaderStoreService,
    private auth: AuthenticationService,
    private route: ActivatedRoute,
    private summaryStoreService: SummaryStoreService,
    private globalAlertStoreService: GlobalAlertStoreService,
    private defInstalmentService: DefInstalmentService,
    private referenceData: ReferenceDataStoreService
  ) {}

  ngOnInit(): void {
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.dataTable$ = this.enquiryService.selectEnquiryDataSearch();
    this.userName$ = this.auth.username$;
    this.infoHeaderDetails$ = this.infoHeaderStoreService.selectInfoHeaderDetails();
    this.premiumDetail$ = this.defInstalmentService.selectPremiumDetail();
    this.workflowSubmission$ = this.summaryStoreService.selectSummaryWorkflowSubmission();
    this.queryParams$ = this.route.queryParams;
    this.premiumNavigation = window.history.state?.premium;
    this.enquiryOptions = enquirySelectOptions;
    this.checkProgressIndicatorUnAuthorizedRoles();
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.globalAlertStoreService.clearGlobalResponse();
    this.tableColumns = tableStandardColumns;
    // table expanded rows
    this.tableExpandRow = tableStandardColumnsExpanded;
  }

  ngAfterViewInit(): void {
    this.searchWithUmr();
  }

  onSearch(): void {
    this.searchEnquiryStatus$.next();
    if (this.checkFormViewInvalidity()) {
      return;
    }

    let payload: SearchCriteriaTechnicianPremiumsProcessor;
    // UMR search
    if (this.uniqueMarketReferenceComponentView?.umrForm?.valid) {
      payload = CreateEnquiryUMRPayload(
        this.uniqueMarketReferenceComponentView?.umrForm?.value,
        this.isInProgress,
        this.signingDateRange?.startDate.formatDate(),
        this.signingDateRange?.endDate.formatDate()
      );
      // WPR search
    } else if (this.workPackageReferenceComponentView?.workPackageReferenceForm.valid) {
      payload = CreateEnquiryWPRPayload(
        this.workPackageReferenceComponentView.workPackageReferenceForm.value,
        this.signingDateRange?.startDate.formatDate(),
        this.signingDateRange?.endDate.formatDate(),
        this.isInProgress
      );
    }
    // Syndicate Company search
    else if (this.syndicateComponentView?.syndicateNumberReferenceForm.valid) {
      payload = CreateEnquirySyndicateCompanyPayload(
        this.syndicateComponentView.syndicateNumberReferenceForm.value,
        this.signingDateRange?.startDate.formatDate(),
        this.signingDateRange?.endDate.formatDate(),
        this.isInProgress
      );
    }
    // broker No Reference View
    else if (this.brokerNoReferenceComponentView?.brokerNoReferenceForm?.valid) {
      payload = CreateEnquiryBrokerPayload(
        this.brokerNoReferenceComponentView.brokerNoReferenceForm.value,
        this.signingDateRange?.startDate.formatDate(),
        this.signingDateRange?.endDate.formatDate(),
        this.isInProgress
      );
    } else if (
      // Velonetic View
      this.VeloneticComponentView?.veloneticFrom?.valid
    ) {
      const veloneticFromValue = this.VeloneticComponentView.veloneticFrom.value;
      const signingDate = new Date(veloneticFromValue.signingDate);
      const startDate = new Date();
      startDate.setDate(signingDate.getDate() - (+veloneticFromValue.days - 1));
      payload = CreateEnquiryVeloneticPayload(
        veloneticFromValue,
        this.datePipe.transform(startDate, 'yyyy-MM-dd'),
        veloneticFromValue.signingDate,
        this.isInProgress
      );
    } else if (this.facilityComponentView?.facilityForm?.valid) {
      if (this.isInProgress) {
        this.referenceData.getRefData();
        this.referenceData
          .selectAll()
          .pipe(take(1))
          .subscribe((data) => {
            const { transactionType } = data;
            const premiumIds = transactionType
              .filter((item) => item.description === 'Premium FDO' || item.description === 'Premium')
              .map((item) => item.id)
              .join(',');

            payload = CreateFacilityPayload(
              this.facilityComponentView.facilityForm.value,
              this.isInProgress,
              premiumIds
            );
          });
      } else {
        payload = CreateFacilityPayload(this.facilityComponentView.facilityForm.value, this.isInProgress);
      }
    }

    this.enquiryService.getSearchPremiumEnquiry(payload);
  }

  totalCountAlertShown(totalCount: number): void {
    this.recordCountAllItems = totalCount;
  }

  correctionTypeError(show): void {
    this.showCorrectionError = show;
  }

  handleUMROnSearchClick(payload: any): void {
    this.enquiryService.getSearchPremiumEnquiry(payload);
  }

  handleOnInProgressChange($event: any): void {
    this.inProgressChanged($event);
  }

  private checkFormViewInvalidity(): boolean {
    return (
      this.syndicateComponentView?.syndicateNumberReferenceForm?.invalid ||
      this.brokerNoReferenceComponentView?.brokerNoReferenceForm?.invalid ||
      this.uniqueMarketReferenceComponentView?.umrForm?.invalid ||
      this.workPackageReferenceComponentView?.workPackageReferenceForm?.invalid ||
      this.VeloneticComponentView?.veloneticFrom?.invalid ||
      this.facilityComponentView?.facilityForm?.invalid
    );
  }

  onSelectEnquiry(value): void {
    this.isInProgress = false;
    this.selectedEquiryOption = value;
    this.resetSigningDates();
    this.recordCountAllItems = 0;
  }

  inProgressChanged(event: boolean): void {
    this.isInProgress = event;
    this.resetSigningDates();
  }

  resetSigningDates(): void {
    this.signingDateRange?.startDate?.resetDateForm();
    this.signingDateRange?.endDate?.resetDateForm();
  }

  searchWithUmr(): void {
    this.route.queryParams.pipe(takeUntil(this.destroy$)).subscribe((params: Params) => {
      if (params?.umr) {
        this.selectedEquiryOption = this.enquiryOption.UNIQUE_MARKET_REFERENCE;
        this.umr = params?.umr;
        this.isInProgress = params?.isInProgress;
        const enquiryUMRPayload = CreateEnquiryUMRPayload({ umr: this.umr }, this.isInProgress);
        this.enquiryService.getSearchPremiumEnquiry(enquiryUMRPayload);
      }
    });
  }

  checkProgressIndicatorUnAuthorizedRoles(): void {
    this.auth.roles$.pipe(takeUntil(this.destroy$)).subscribe((roles: string[]) => {
      if (roles?.length) {
        this.hideInProgressIndicator =
          (roles.includes(Role.PROCESS_ENQUIRY_BROKER) || roles.includes(Role.PROCESS_ENQUIRY_CARRIER)) &&
          !roles.includes(Role.PROCESS_TEAM_MANAGER) &&
          !roles.includes(Role.All_Tech_Premiums);
        if (roles.includes(Role.PROCESS_ENQUIRY_BROKER) || roles.includes(Role.PROCESS_ENQUIRY_CARRIER)) {
          this.enquiryOptions = this.enquiryOptions.filter((option) => option.value !== this.enquiryOption.AUDIT);
        }
      }
    });
  }

  getSigningNumber(): string {
    return this.signingComponentView?.getSigningNumberValue();
  }

  setSelectedEquiryOption(selectedOption: string): void {
    this.inProgressChanged(false);
    this.selectedEquiryOption = selectedOption;
  }

  updateTableColumns(view: 'standard' | 'modified'): void {
    this.tableView = view;
    this.tableColumns = view === 'standard' ? tableStandardColumns : tableModifiedColumns;
    this.tableExpandRow = view === 'standard' ? tableStandardColumnsExpanded : tableModifiedColumnsExpanded;
  }

  onDateRangeChange(value: any): void {}

  onAdvancedSearchToggled(isVisible: boolean): void {
    this.isAdvancedSearchVisible = isVisible;
  }

  onScreenSizeChange(isSmall: any): void {
    this.isUMRSearchSmallScreen = isSmall;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.enquiryService.clearData();
  }
}
