import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { constants } from 'buffer';
import { MainDefInstHistoryComponent } from './main-def-inst-history.component';

describe('MainCompanyHistoryUpdateComponent', () => {
  let component: MainDefInstHistoryComponent;
  let fixture: ComponentFixture<MainDefInstHistoryComponent>;
  const routerSpy = jasmine.createSpyObj('Router', ['company-ref-history']);
  const activatedRouteSpy = {
    queryParams: of({ companyCode: '123', bureauSigningReference: 'ABC' }),
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainDefInstHistoryComponent],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
      ],
      providers: [
        MockStore,
        provideMockStore(),
        CompanyRefUpdateStoreService,
        FormBuilder,
        { provide: Router, useValue: routerSpy },
        { provide: ActivatedRoute, useValue: activatedRouteSpy },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainDefInstHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
