import { Component, OnInit } from '@angular/core';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Observable } from 'rxjs';
import {
  InstalmentHistory,
  UwRefCompanyHistory,
  UwRefCompanyHistoryRecords,
} from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { FormBuilder, FormGroup } from '@angular/forms';
import { debounceTime, distinctUntilChanged, last, takeLast } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { TableColumn } from '@shared/models';
import {
  DEF_INST_HIST_EXPAND_TABLE_HEADER,
  DEF_INST_HIST_TABLE_HEADER,
  InstalmentHistoryTableData,
} from '@features/enquiry/const/def-inst-hist.const';
import { DefInstalmentService } from '@features/enquiry/services/def-instalment.service';

@Component({
  selector: 'app-main-def-inst-history',
  templateUrl: './main-def-inst-history.component.html',
  styleUrls: ['./main-def-inst-history.component.scss'],
})
export class MainDefInstHistoryComponent implements OnInit {
  csndValue: string | null = null;
  premiumId: string;
  tableColumns: TableColumn[];
  tableExPandColumns: TableColumn[];
  defInstalmentData$: Observable<InstalmentHistory>;

  constructor(
    private route: ActivatedRoute,
    private location: Location,
    private defInstalmentService: DefInstalmentService
  ) {
    this.route.queryParams.subscribe({
      next: (params) => {
        this.csndValue = params.csnd;
        const premiumId = params.premiumId;
        if (premiumId) {
          this.defInstalmentService.getInstalmentHistory(premiumId);
        }
      },
    });
  }

  ngOnInit(): void {
    this.tableColumns = DEF_INST_HIST_TABLE_HEADER;
    this.tableExPandColumns = DEF_INST_HIST_EXPAND_TABLE_HEADER;
    this.defInstalmentData$ = this.defInstalmentService.selectInstalmentHistory();
  }

  navigateToSearch(): void {
    this.location.back();
  }
}
