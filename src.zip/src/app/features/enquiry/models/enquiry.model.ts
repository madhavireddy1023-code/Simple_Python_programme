import { InstalmentHistory } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { PremiumEnquiryRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

export interface EnquiryState {
  premiumEnquiry: PremiumEnquiryRecords;
}

export interface DefInstalementState {
  premiumDetails: any;
  instalmentHistory: InstalmentHistory;
  error: any;
}
