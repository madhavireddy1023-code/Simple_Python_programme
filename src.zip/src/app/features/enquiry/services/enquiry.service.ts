import { select, Store } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { AppState } from '../../../store/app.reducer';
import * as actions from '../store/actions/enquiry.action';
import * as selectors from '../store/selectors/enquiry.selector';
import { Observable } from 'rxjs';
import {
  PremiumEnquiryRecords,
  SearchCriteriaTechnicianPremiumsProcessor,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

@Injectable({
  providedIn: 'root',
})
export class EnquiryService {
  constructor(private store: Store<AppState>) {}

  getSearchPremiumEnquiry(premiumEnquiry: SearchCriteriaTechnicianPremiumsProcessor): void {
    this.store.dispatch(actions.getPremiumEnquiry({ premiumEnquiry }));
  }

  selectEnquiryDataSearch(): Observable<PremiumEnquiryRecords> {
    return this.store.pipe(select(selectors.selectPremiumEnquiry));
  }

  clearData(): void {
    return this.store.dispatch(actions.clearData());
  }
}
