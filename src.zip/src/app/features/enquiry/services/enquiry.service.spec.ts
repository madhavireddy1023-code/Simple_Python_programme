import { TestBed } from '@angular/core/testing';

import { EnquiryService } from './enquiry.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import * as actions from '../store/actions/enquiry.action';
import * as selectors from '../store/selectors/enquiry.selector';

describe('EnquiryService', () => {
  let service: EnquiryService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockStore, provideMockStore()],
    });
    service = TestBed.inject(EnquiryService);
    store = TestBed.inject(MockStore);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should selectPremiumEnquiry when selectEnquiryDataSearch is called', () => {
    service.selectEnquiryDataSearch();
    spyOn(store, 'select');
    store.select(selectors.selectPremiumEnquiry);
    expect(store.select).toHaveBeenCalled();
  });

  it('should dispatch getPremiumEnquiry action when getSearchPremiumEnquiry method is called', () => {
    const spy = spyOn(store, 'dispatch');
    service.getSearchPremiumEnquiry(null);
    expect(spy).toHaveBeenCalledWith(actions.getPremiumEnquiry({ premiumEnquiry: null }));
  });

  it('should dispatch clearData action when clearData method is called', () => {
    const spy = spyOn(store, 'dispatch');
    service.clearData();
    expect(spy).toHaveBeenCalledWith(actions.clearData());
  });
});
