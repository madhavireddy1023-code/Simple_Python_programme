import { select, Store } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { AppState } from '../../../store/app.reducer';
import * as actions from '../store/actions/def-instalment.action';
import * as selectors from '../store/selectors/def-instalment.selector';
import { Observable } from 'rxjs';
import { PremiumGetRec } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { InstalmentHistory } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

@Injectable({
  providedIn: 'root',
})
export class DefInstalmentService {
  constructor(private store: Store<AppState>) {}

  selectPremiumDetail(): Observable<any> {
    return this.store.pipe(select(selectors.selectPremiumDetails));
  }

  getPremiumDetails(workPackageRef: string, premiumId: string, typeOfPremium: string, umr: string, csnd: string): void {
    this.store.dispatch(actions.getPremiumDetails({ workPackageRef, premiumId, typeOfPremium, umr, csnd }));
  }

  selectInstalmentHistory(): Observable<InstalmentHistory> {
    return this.store.pipe(select(selectors.selectInstalmentHistory));
  }

  getInstalmentHistory(premiumId: string): void {
    this.store.dispatch(actions.getDeferredInstalments({ premiumId }));
  }
}
