import { TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { DefInstalmentService } from './def-instalment.service';
import * as actions from '../store/actions/def-instalment.action';
import * as selectors from '../store/selectors/def-instalment.selector';

describe('DefInstalmentService', () => {
  let service: DefInstalmentService;
  let store: MockStore;
  const initialState = {};

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DefInstalmentService, provideMockStore({ initialState })],
    });

    service = TestBed.inject(DefInstalmentService);
    store = TestBed.inject(MockStore);
  });

  it('should dispatch getpremiumDetails action with correct payload', () => {
    const dispatchSpy = spyOn(store, 'dispatch').and.callThrough();
    const workPackageRef = '123';
    const premiumId = 'premium123';
    const typeOfPremium = 'premium';

    const umr = 'UMR123';
    const csnd = 'CSND123';

    service.getPremiumDetails(workPackageRef, premiumId, typeOfPremium, umr, csnd);

    expect(dispatchSpy).toHaveBeenCalledWith(
      actions.getPremiumDetails({ workPackageRef, premiumId, typeOfPremium, umr, csnd })
    );
  });
  it('should dispatch getDeferredInstalments action with premiumId', () => {
    const dispatchSpy = spyOn(store, 'dispatch').and.callThrough();

    const premiumId = '12345';

    service.getInstalmentHistory(premiumId);

    expect(dispatchSpy).toHaveBeenCalledWith(actions.getDeferredInstalments({ premiumId }));
  });

  it('should return premium details when selector emits non-null data', (done: DoneFn) => {
    const premiumDetailsMock: any = { premiumId: 'mockDetails' };
    store.overrideSelector(selectors.selectPremiumDetails, premiumDetailsMock);

    service.getPremiumDetails('123', 'premium123', 'premium', 'UMR123', 'CSND123');

    service.selectPremiumDetail().subscribe((data) => {
      expect(data).toEqual(premiumDetailsMock);
      done();
    });

    store.refreshState(); // Forces the selector to emit the mocked value
  });

  it('should filter out null data from selector', (done: DoneFn) => {
    const premiumDetailsMock: any = { premiumId: 'mockDetails' };
    store.overrideSelector(selectors.selectPremiumDetails, null); // Emit null first
    store.overrideSelector(selectors.selectPremiumDetails, premiumDetailsMock); // Emit valid data later

    service.getPremiumDetails('123', 'premium123', 'premium', 'UMR123', 'CSND123');
    service.selectPremiumDetail().subscribe((data) => {
      expect(data).toEqual(premiumDetailsMock);
      done();
    });

    store.refreshState(); // Refresh state to emit values
  });
});
