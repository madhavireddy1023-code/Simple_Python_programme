import {
  SearchCriteriaTechnicianPremiumsProcessor,
  SearchObjectTechnicianPremiumProcessor
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { size } from 'lodash';
import { isCommaSeparatedNum, removeCommaSeparator } from 'src/app/utils';

// UMR PAYLOAD
export const enquiryBasePayload = (
  signingStartDate: string,
  signingEndDate: string,
  isInProgress: boolean,
  includeConnectionOperator = true
): SearchCriteriaTechnicianPremiumsProcessor => {
  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    size: 2000,
    inProgressRecords: isInProgress,
    sort: [
      {
        fieldName: 'csnd',
        ordering: 'ASC',
      },
    ],
  };
  if (includeConnectionOperator) {
    payload.connectorOperation = 'AND';
  }
  if (signingStartDate || signingEndDate) {
    payload.dateRange = {};
  }

  // adding start date if it has value
  if (signingStartDate) {
    payload.dateRange.startDate = {
      fieldName: 'csd',
      fieldType: 'DATE',
      operator: 'EQUALS',
      fieldValue: signingStartDate,
    };
  }
  // adding end date if it has value
  if (signingEndDate) {
    payload.dateRange.endDate = {
      fieldName: 'csd',
      fieldType: 'DATE',
      operator: 'EQUALS',
      fieldValue: signingEndDate,
    };
  }
  return payload;
};

// UMR PAYLOAD
export const CreateEnquiryUMRPayload = (
  umrFormValue: any,
  isInProgress: boolean,
  signingStartDate?: string,
  signingEndDate?: string,
  settlementCurrency?: string
): SearchCriteriaTechnicianPremiumsProcessor => {
  // Base payload
  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    ...enquiryBasePayload(signingStartDate, signingEndDate, isInProgress),
    and: [
      {
        fieldName: 'umr',
        fieldType: 'STRING',
        fieldValue: umrFormValue.umr,
        operator: 'CONTAINS',
      },
    ],
  };

  // Add bureau field if it exists each as seperate field
  if (umrFormValue?.bureau && umrFormValue?.bureau?.length > 0) {
    payload.and.push({
      fieldName: 'bureau',
      fieldType: 'LIST',
      fieldValue: umrFormValue?.bureau?.join(),
      operator: 'IN',
    });
  }

  // Add section field if it exists
  if (umrFormValue?.section && umrFormValue?.section?.length > 0) {
    payload.and.push({
      fieldName: 'sectionNumber',
      fieldType: 'LIST_NUMBER',
      fieldValue: umrFormValue?.section?.join(),
      operator: 'IN',
    });
  }

  // Add originalCurrency field if it exists
  if (umrFormValue?.originalCurrency && umrFormValue.originalCurrency.trim() !== '') {
    payload.and.push({
      fieldName: 'originalCurrency',
      fieldType: 'STRING',
      fieldValue: umrFormValue.originalCurrency,
      operator: 'EQUALS',
    });
  }

  if (settlementCurrency && settlementCurrency.trim() !== '') {
    payload.and.push({
      fieldName: 'typeOfCurrency',
      fieldType: 'STRING',
      fieldValue: settlementCurrency,
      operator: 'EQUALS',
    });
  }

  return payload;
};

// WPR PAYLOAD
export const CreateEnquiryWPRPayload = (
  wprFormValue: any,
  signingStartDate: string,
  signingEndDate: string,
  isInProgress: boolean
): SearchCriteriaTechnicianPremiumsProcessor => {
  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    ...enquiryBasePayload(signingStartDate, signingEndDate, isInProgress),
    and: [
      {
        fieldName: 'workPackageRef',
        fieldType: 'STRING',
        fieldValue: wprFormValue.workPackageReference,
        operator: 'CONTAINS',
      },
      {
        fieldName: 'status',
        fieldType: 'STRING',
        fieldValue: 'CORRECTED',
        operator: 'NOT_EQUALS',
      },
    ],
  };
  return payload;
};

// Syndicate Company PAYLOAD
export const CreateEnquirySyndicateCompanyPayload = (
  syndicateCompanyFormValue: any,
  signingStartDate: string,
  signingEndDate: string,
  isInProgress: boolean
): SearchCriteriaTechnicianPremiumsProcessor => {
  const orCriteria: SearchObjectTechnicianPremiumProcessor[] = [];
  const andCriteria: SearchObjectTechnicianPremiumProcessor[] = [
    {
      fieldName: 'syndicateNumber',
      fieldType: 'STRING',
      fieldValue: isCommaSeparatedNum(syndicateCompanyFormValue.syndicateCompanyNumber)
        ? removeCommaSeparator(syndicateCompanyFormValue.syndicateCompanyNumber)
        : syndicateCompanyFormValue.syndicateCompanyNumber,
      operator: getCompanyCodeSearchType(syndicateCompanyFormValue.syndicateCompanyNumber),
    },
    {
      fieldName: 'status',
      fieldType: 'STRING',
      fieldValue: 'CORRECTED',
      operator: 'NOT_EQUALS',
    },
  ];
  if (syndicateCompanyFormValue.syndicateCompanyReference) {
    orCriteria.push({
      fieldName: 'syndicateReference',
      fieldType: 'STRING',
      fieldValue: syndicateCompanyFormValue.syndicateCompanyReference,
      operator: 'CONTAINS',
    });
    orCriteria.push({
      fieldName: 'syndicateSecondaryReference',
      fieldType: 'STRING',
      fieldValue: syndicateCompanyFormValue.syndicateCompanyReference,
      operator: 'CONTAINS',
    });
  }

  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    ...enquiryBasePayload(signingStartDate, signingEndDate, isInProgress),
    and: andCriteria,
  };
  if (orCriteria.length > 0) {
    payload.or = orCriteria;
  }
  return payload;
};

// Broker number and reference PAYLOAD
export const CreateEnquiryBrokerPayload = (
  brokerNumberReference: any,
  signingStartDate: string,
  signingEndDate: string,
  isInProgress: boolean
): SearchCriteriaTechnicianPremiumsProcessor => {
  const orCriteria: SearchObjectTechnicianPremiumProcessor[] = [];
  const andCriteria: SearchObjectTechnicianPremiumProcessor[] = [
    {
      fieldName: 'brokerNumber',
      fieldType: 'STRING',
      fieldValue: brokerNumberReference.brokerNumber,
      operator: 'CONTAINS',
    },
    {
      fieldName: 'status',
      fieldType: 'STRING',
      fieldValue: 'CORRECTED',
      operator: 'NOT_EQUALS',
    },
  ];
  // Add the brokerRef1 field only if brokerReference has a value
  if (brokerNumberReference.brokerReference) {
    orCriteria.push({
      fieldName: 'brokerRef1',
      fieldType: 'STRING',
      fieldValue: brokerNumberReference.brokerReference,
      operator: 'CONTAINS',
    });

    orCriteria.push({
      fieldName: 'brokerRef2',
      fieldType: 'STRING',
      fieldValue: brokerNumberReference.brokerReference,
      operator: 'CONTAINS',
    });
  }

  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    ...enquiryBasePayload(signingStartDate, signingEndDate, isInProgress),
    and: andCriteria,
  };
  if (orCriteria.length > 0) {
    payload.or = orCriteria;
  }
  return payload;
};

// Signing number and date PAYLOAD
export const CreateSigningNumAndDatePayload = (
  signingNumber: string,
  originalCurrency: string,
  settlementCurrency: string,
  signingStartDate: string,
  signingEndDate: string,
  isInProgress: boolean
): SearchCriteriaTechnicianPremiumsProcessor => {
  const orCriteria: SearchObjectTechnicianPremiumProcessor[] = [
    {
      fieldName: 'csnd',
      operator: 'EQUALS',
      fieldValue: signingNumber,
      fieldType: 'STRING',
    },
    {
      fieldName: 'bsnd',
      operator: 'EQUALS',
      fieldValue: signingNumber,
      fieldType: 'STRING',
    },
    {
      fieldName: 'ocsnd',
      operator: 'EQUALS',
      fieldValue: signingNumber,
      fieldType: 'STRING',
    },
  ];
  const andCriteria: SearchObjectTechnicianPremiumProcessor[] = [];
  // Add the originalCurrency field only if originalCurrency has a value
  if (originalCurrency && originalCurrency.trim().length !== 0) {
    andCriteria.push({
      fieldName: 'originalCurrency',
      operator: 'EQUALS',
      fieldValue: originalCurrency,
      fieldType: 'STRING',
    });
  }
  // Add the settlementCurrency field only if settlementCurrency has a value
  if (settlementCurrency && settlementCurrency.trim().length !== 0) {
    andCriteria.push({
      fieldName: 'typeOfCurrency',
      operator: 'EQUALS',
      fieldValue: settlementCurrency,
      fieldType: 'STRING',
    });
  }
  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    ...enquiryBasePayload(signingStartDate, signingEndDate, isInProgress, false),
    or: orCriteria,
  };
  if (andCriteria.length > 0) {
    payload.and = andCriteria;
  }
  return payload;
};
export const CreateEnquiryVeloneticPayload = (
  veloneticFormValue: any,
  signingStartDate: string,
  signingEndDate: string,
  isInProgress: boolean
): SearchCriteriaTechnicianPremiumsProcessor => {
  const andCriteria: SearchObjectTechnicianPremiumProcessor[] = [
    {
      fieldName: 'status',
      fieldType: 'STRING',
      fieldValue: 'CORRECTED',
      operator: 'NOT_EQUALS',
    },
  ];
  if (veloneticFormValue?.workPackageReference) {
    andCriteria.push({
      fieldName: 'workPackageRef',
      fieldType: 'STRING',
      fieldValue: veloneticFormValue.workPackageReference,
      operator: 'CONTAINS',
    });
  }
  if (veloneticFormValue?.auditStatus && veloneticFormValue?.auditStatus !== 'Select') {
    const auditStatus: SearchObjectTechnicianPremiumProcessor = getAuditStatusField(veloneticFormValue.auditStatus);
    andCriteria.push(auditStatus);
  }
  if (veloneticFormValue?.signedBy) {
    andCriteria.push({
      fieldName: 'signedByUser',
      operator: 'EQUALS',
      fieldValue: veloneticFormValue.signedBy,
      fieldType: 'STRING',
    });
  }
  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    ...enquiryBasePayload(signingStartDate, signingEndDate, isInProgress),
    and: andCriteria,
  };
  return payload;
};
export const CreateFacilityPayload = (
  facilityCompanyFormValue: any,
  isInProgress: boolean,
  transactionTypeIds?: string
): SearchCriteriaTechnicianPremiumsProcessor => {

  const andCriteria: SearchObjectTechnicianPremiumProcessor[] = [
    {
      fieldName: 'facilityNumberAndDate',
      fieldType: 'STRING',
      fieldValue: facilityCompanyFormValue.YOANumberDate,
      operator: 'EQUALS',
    },
  ];

  if (isInProgress && transactionTypeIds) {
    const refTypeOfTransactionTypeId =
    {
      fieldName: 'refTypeOfTransactionTypeId',
      fieldType: 'LIST',
      fieldValue: transactionTypeIds,
      operator: 'IN',
    };
    andCriteria.push(refTypeOfTransactionTypeId as any);
  }

  const payload: SearchCriteriaTechnicianPremiumsProcessor = {
    ...enquiryBasePayload(null, null, isInProgress),
    and: andCriteria,
  };

  return payload;
};
export const premiumDetails = [
  {
    settlementDueDate: '2024-10-15',
    premiumNet: 2500.0,
    correctionNarrative: 'Premium adjustment for Q4 2024',
    actualPaymentDate: '2024-10-20',
    premiumNumber: 101,
  },
  {
    settlementDueDate: '2024-11-10',
    premiumNet: 3000.5,
    correctionNarrative: 'Correction due to policy amendment',
    actualPaymentDate: '2024-11-15',
    premiumNumber: 102,
  },
  {
    settlementDueDate: '2024-12-05',
    premiumNet: 4000.75,
    correctionNarrative: 'End of year premium settlement',
    actualPaymentDate: '2024-12-10',
    premiumNumber: 103,
  },
];

const getCompanyCodeSearchType = (syndicateCompanyNumber: string) => {
  return size(syndicateCompanyNumber) < 6 || size(syndicateCompanyNumber) <= 7 ? 'CONTAINS' : 'EQUALS';
};
const getAuditStatusField = (auditStatus: any): SearchObjectTechnicianPremiumProcessor => {
  if (auditStatus.includes('BLANK')) {
    return {
      fieldName: 'auditPassFail',
      operator: 'NOT_EXISTS',
      fieldValue: '',
      fieldType: 'STRING',
    };
  } else {
    return {
      fieldName: 'auditPassFail',
      operator: 'EQUALS',
      fieldValue: auditStatus,
      fieldType: 'STRING',
    };
  }
};
