import { PremiumEnquiryRecord, PremiumEnquiryRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

export enum ENQUIRY_OPTIONS {
  SIGNING_NUMBER_AND_DATE = 'Signing number and date',
  BROKER_NUMBER_AND_REFERENCE = 'Broker number and reference',
  SYNDICATE_NUMBER_AND_REFERENCE = 'Syndicate / Company number and reference',
  UNIQUE_MARKET_REFERENCE = 'Unique market reference',
  WORK_PACKAGE_REFERENCE = 'Work package reference',
  AUDIT = 'Audit',
  FACILITY_SEARCH = 'Facility search',
}

export type PremiumEnquiryRow = PremiumEnquiryRecord & { isExpanded: boolean; checkboxChecked: boolean };

export type TransactionStatusClasses = 'green-color' | 'red-color' | 'orange-color';

export const mockPremiumEnquiryData: PremiumEnquiryRecords = {
  recordCount: 2,
  signings: [],
  totalCount: 10,
};

export enum TransactionStatusValues {
  NEW = 'NEW',
  CAN = 'CAN',
  REP = 'REP',
}

export enum SIGNING_OPTIONS {
  LLOYDS = 'Lloyds',
  COMPANY = 'Company',
}

export enum SUBSEQUENT_TRANSACTION_OPTIONS {
  COMPLETE_HISTORY = 'Complete history',
  PREMIUM_PREVIOUS_YEAR = 'Premium and previous year',
  PREMIUM_PREVIOUS_SIX_MONTHS = 'Premium and previous 6 months',
  PREMIUM_PREVIOUS_TWO_MONTHS = 'Premium and previous 2 months',
  MONTH_ONLY = 'Premium and previous month only',
  RANGE = 'Select date range',
}

export enum PremiumSource {
  SchemeCanada = 'SchemeCanada',
  AutoRI = 'AutoRI',
  TechnicianPortal = 'TechnicianPortal',
}
