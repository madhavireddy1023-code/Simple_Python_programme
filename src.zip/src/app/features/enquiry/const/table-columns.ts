import { PassFailEnum } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { Bureau, PremiumEnquiryRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { reverseDate } from 'src/app/utils';

export const tableStandardColumns = [
  {
    id: 1,
    key: 'bureau',
    label: 'ENQUIRY.TABLE.BUREAU',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => setBureau(premiumEnquiryRecord?.bureau),
    chip: false,
  },
  {
    id: 2,
    key: 'umr', // soring key should match with the API object key
    label: 'ENQUIRY.TABLE.UMR',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.umr,
    chip: false,
  },
  {
    id: 3,
    key: 'workPackageRef',
    label: 'ENQUIRY.TABLE.WPR',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.workPackageRef,
    chip: false,
  },
  {
    id: 4,
    key: 'sectionNumber',
    label: 'ENQUIRY.TABLE.SECTION',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.sectionNumber,
    chip: false,
  },
  {
    id: 5,
    key: 'csnd',
    label: 'ENQUIRY.TABLE.CSND',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.csnd,
    chip: false,
  },
  {
    id: 6,
    key: 'bsnd',
    label: 'ENQUIRY.TABLE.BSND',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.bsnd,
    chip: false,
  },
  {
    id: 7,
    key: 'transactionType.typeOfTransactionType',
    label: 'ENQUIRY.TABLE.TRANSACTION_TYPE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.transactionType?.typeOfTransactionType,
    chip: false,
  },
  {
    id: 8,
    key: 'riskCode',
    label: 'ENQUIRY.TABLE.RISK_CODE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.riskCode,
    chip: false,
  },
  {
    id: 9,
    key: 'policyPeriodFrom',
    label: 'ENQUIRY.TABLE.POLICY_PERIOD_FROM_DATE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => reverseDate(premiumEnquiryRecord?.policyPeriodFrom),
    chip: false,
  },
  {
    id: 10,
    key: 'releaseFlag',
    label: 'ENQUIRY.TABLE.PAYMENT_MEANS',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
      premiumEnquiryRecord?.releaseFlag === 'Delink'
        ? premiumEnquiryRecord?.releasedForSettlement
        : premiumEnquiryRecord?.releaseFlag,
    chip: false,
  },
  {
    id: 11,
    key: 'warning',
    label: '',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
      premiumEnquiryRecord.hasErrors === true && premiumEnquiryRecord.isHeritageRecord === true,
    chip: false,
    icon: 'warning',
  },
  {
    id: 12,
    key: 'transactionStatus',
    label: 'ENQUIRY.TABLE.TRANSACTION_STATUS',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.transactionStatus,
    chip: true,
  },
  {
    id: 13,
    key: 'filCode1.typeOfFilCode',
    label: 'ENQUIRY.TABLE.FIL_CODE_1',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.filCode1?.typeOfFilCode,
    chip: false,
  },
  {
    id: 14,
    key: 'filCode2.typeOfFilCode',
    label: 'ENQUIRY.TABLE.FIL_CODE_2',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.filCode2?.typeOfFilCode,
    chip: false,
  },
  {
    id: 15,
    key: 'auditPassFail',
    label: 'ENQUIRY.TABLE.AUDIT',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => setAuditStatus(premiumEnquiryRecord?.auditPassFail),
    chip: false,
  },
];
export const tableStandardColumnsExpanded = [
  {
    id: 1,
    colNum: 1,
    key: 'brokerCode',
    label: 'ENQUIRY.TABLE.BROKER_CODE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.brokerNumber,
  },
  {
    id: 2,
    colNum: 1,
    key: 'slipType',
    label: 'ENQUIRY.TABLE.SLIP_TYPE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.slipType?.refSlipTypeValue,
  },
  {
    id: 3,
    colNum: 1,
    key: 'originalCurrency',
    label: 'ENQUIRY.TABLE.ORIGINAL_CURRENCY',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.originalCurrency?.typeOfCurrency,
  },
  {
    id: 4,
    colNum: 2,
    key: 'yoa',
    label: 'ENQUIRY.TABLE.YOA',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.yearOfAccount,
  },
  {
    id: 5,
    colNum: 2,
    key: 'policyHolder',
    label: 'ENQUIRY.TABLE.POLICYHOLDER_END',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.insuredName,
  },
  {
    id: 6,
    colNum: 2,
    key: 'settCcy',
    label: 'ENQUIRY.TABLE.SETT_CCY',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.settlementCurrency?.typeOfCurrency,
  },
  {
    id: 7,
    colNum: 3,
    key: 'narrative',
    label: 'ENQUIRY.TABLE.NARRATIVE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.premiumNarrative,
  },
  {
    id: 8,
    colNum: 3,
    key: 'periodfrom',
    label: 'ENQUIRY.TABLE.PERIOD_FROM',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => reverseDate(premiumEnquiryRecord?.policyPeriodFrom),
  },
  {
    id: 9,
    colNum: 3,
    key: 'periodto',
    label: 'ENQUIRY.TABLE.PERIOD_TO',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => reverseDate(premiumEnquiryRecord?.policyPeriodTo),
  },
  {
    id: 10,
    colNum: 4,
    key: 'obsnd',
    label: 'ENQUIRY.TABLE.OBSND',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.obsnd,
  },
  {
    id: 11,
    colNum: 4,
    key: 'reinsuredName',
    label: 'ENQUIRY.TABLE.REINSURED/RETROCEDENT',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.reinsuredName,
  },
];
export const tableModifiedColumns = [
  {
    id: 1,
    key: 'umr', // soring key should match with the API object key
    label: 'ENQUIRY.TABLE.UMR',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.umr,
    chip: false,
  },
  {
    id: 2,
    key: 'sectionNumber',
    label: 'ENQUIRY.TABLE.SECTION',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.sectionNumber,
    chip: false,
  },
  {
    id: 3,
    key: 'bsnd',
    label: 'ENQUIRY.TABLE.BSND',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.bsnd,
    chip: false,
  },
  {
    id: 4,
    key: 'yearOfAccount',
    label: 'ENQUIRY.TABLE.YOA',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.yearOfAccount,
    chip: false,
  },
  {
    id: 5,
    key: 'trustFundCode.typeOfTrustFundCode',
    label: 'ENQUIRY.TABLE.TF',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
      premiumEnquiryRecord?.trustFundCode?.typeOfTrustFundCode ?? '-',
    chip: false,
  },
  {
    id: 6,
    key: 'qualifyingCategoryCode.typeOfQualCatCode',
    label: 'ENQUIRY.TABLE.QQ',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
      premiumEnquiryRecord?.qualifyingCategoryCode?.typeOfQualCatCode ?? '-',
    chip: false,
  },
  {
    id: 7,
    key: 'dtiCode.typeOfDTICode',
    label: 'ENQUIRY.TABLE.DTI',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.dtiCode?.typeOfDTICode ?? '-',
    chip: false,
  },
  {
    id: 8,
    key: 'countryOfOrigin.typeOfCountry',
    label: 'ENQUIRY.TABLE.COO',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.countryOfOrigin?.typeOfCountry ?? '-',
    chip: false,
  },
  {
    id: 9,
    key: 'grossPremium',
    label: 'ENQUIRY.TABLE.GROSS_PREMIUM',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.grossPremium ?? '-',
    chip: false,
  },
  {
    id: 10,
    key: 'originalCurrency.typeOfCurrency',
    label: 'ENQUIRY.TABLE.ORIG_CCY',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.originalCurrency?.typeOfCurrency,
    chip: false,
  },
  {
    id: 11,
    key: 'settlementCurrency.typeOfCurrency',
    label: 'ENQUIRY.TABLE.SETT_CCY',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.settlementCurrency?.typeOfCurrency,
    chip: false,
  },

  {
    id: 12,
    key: 'filCode1.typeOfFilCode',
    label: 'ENQUIRY.TABLE.FIL_CODE_1',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.filCode1?.typeOfFilCode,
    chip: false,
  },
  {
    id: 13,
    key: 'filCode2.typeOfFilCode',
    label: 'ENQUIRY.TABLE.FIL_CODE_2',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.filCode2?.typeOfFilCode,
    chip: false,
  },
  {
    id: 14,
    key: 'insuredName',
    label: 'ENQUIRY.TABLE.POLICYHOLDER_END',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.insuredName,
    chip: false,
  },
  {
    id: 15,
    key: 'reinsuredName',
    label: 'ENQUIRY.TABLE.REINSURED/RETROCEDENT',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.reinsuredName,
    chip: false,
  },
];

export const tableModifiedColumnsExpanded = [
  {
    id: 1,
    key: 'csnd',
    colNum: 1,
    label: 'ENQUIRY.TABLE.CSND',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.csnd,
  },
  {
    id: 2,
    colNum: 1,
    key: 'slipType',
    label: 'ENQUIRY.TABLE.SLIP_TYPE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.slipType?.refSlipTypeValue,
  },
  {
    id: 3,
    colNum: 1,
    key: 'transactionType.typeOfTransactionType',
    label: 'ENQUIRY.TABLE.TRANSACTION_TYPE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.transactionType?.typeOfTransactionType,
  },
  {
    id: 4,
    colNum: 2,
    key: 'riskCode',
    label: 'ENQUIRY.TABLE.RISK_CODE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.riskCode,
  },
  {
    id: 5,
    colNum: 2,
    key: 'workPackageRef',
    label: 'ENQUIRY.TABLE.WPR',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.workPackageRef,
  },
  {
    id: 6,
    colNum: 2,
    key: 'narrative',
    label: 'ENQUIRY.TABLE.NARRATIVE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.premiumNarrative,
  },
  {
    id: 7,
    colNum: 3,
    key: 'periodFrom',
    label: 'ENQUIRY.TABLE.PERIOD_FROM',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => reverseDate(premiumEnquiryRecord?.policyPeriodFrom),
  },
  {
    id: 8,
    colNum: 3,
    key: 'periodTo',
    label: 'ENQUIRY.TABLE.PERIOD_TO',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => reverseDate(premiumEnquiryRecord?.policyPeriodTo),
  },
  {
    id: 9,
    colNum: 3,
    key: 'obsnd',
    label: 'ENQUIRY.TABLE.OBSND',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.obsnd,
  },
  {
    id: 10,
    key: 'releaseFlag',
    colNum: 4,
    label: 'ENQUIRY.TABLE.PAYMENT_MEANS',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
      premiumEnquiryRecord?.releaseFlag === 'Delink'
        ? premiumEnquiryRecord?.releasedForSettlement
        : premiumEnquiryRecord?.releaseFlag,
  },
  {
    id: 11,
    colNum: 4,
    key: 'transactionStatus',
    label: 'ENQUIRY.TABLE.TRANSACTION_STATUS',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => premiumEnquiryRecord?.transactionStatus,
    chip: true,
  },
  {
    id: 12,
    colNum: 4,
    key: 'midTermMarketChangeIndicator',
    label: 'ENQUIRY.TABLE.MARKET_CHANGE',
    value: (premiumEnquiryRecord: PremiumEnquiryRecord) => {
      const indicator = premiumEnquiryRecord?.midTermMarketChangeIndicator;
      return indicator === true ? 'Yes' : indicator === false ? 'No' : indicator;
    },
  },
];

function setBureau(bureau: Bureau): string {
  return bureau === Bureau.LIRMA ? 'LR' : bureau === Bureau.ILU ? 'IL' : bureau === Bureau.LLOYDS ? 'LL' : bureau;
}
function setAuditStatus(status: PassFailEnum): string {
  return status === PassFailEnum.PASS ? 'Pass' : status === PassFailEnum.FAIL ? 'Fail' : '-';
}
