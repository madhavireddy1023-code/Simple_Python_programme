import { TypeOfErrorDescription } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

export const DEF_INST_HIST_TABLE_HEADER = [
  {
    id: 1,
    key: 'instalmentType',
    label: 'ENQUIRY.DEF_INST.INSTALMENT_TYPE',
    value: '',
    chip: false,
  },
  {
    id: 2,
    key: 'instalmentNo',
    label: 'ENQUIRY.DEF_INST.INSTALMENT_NO',
    value: '',
    chip: false,
  },
  {
    id: 3,
    key: 'dueDateOriginal',
    label: 'ENQUIRY.DEF_INST.DUE_DATE_ORIGINAL',
    value: '',
    chip: false,
  },
  {
    id: 4,
    key: 'dueDateCurrent',
    label: 'ENQUIRY.DEF_INST.DUE_DATE_CURRENT',
    value: '',
    chip: false,
  },

  {
    id: 5,
    key: 'instalmentDueAmount',
    label: 'ENQUIRY.DEF_INST.INSTALMENT_DUE_AMOUNT',
    value: '',
    chip: false,
  },

  {
    id: 6,
    key: 'dateOfChange',
    label: 'ENQUIRY.DEF_INST.DATE_OF_CHANGE',
    value: '',
    chip: true,
  },
  {
    id: 7,
    key: 'changeBy',
    label: 'ENQUIRY.DEF_INST.CHANGE_BY',
    value: '',
    chip: true,
  },
];
export const DEF_INST_HIST_EXPAND_TABLE_HEADER = [
  {
    id: 8,
    key: 'errorMadeBy',
    label: 'ENQUIRY.DEF_INST.ERROR_MADE_BY',
    value: (InstalmentHistoryExpandRecord: InstalmentHistoryTableData) => InstalmentHistoryExpandRecord?.errorMadeBy,
    chip: false,
  },
  {
    id: 9,
    key: 'category',
    label: 'ENQUIRY.DEF_INST.CATEGORY',
    value: (InstalmentHistoryExpandRecord: InstalmentHistoryTableData) => InstalmentHistoryExpandRecord?.category,
    chip: false,
  },
  {
    id: 10,
    key: 'errorDescription',
    label: 'ENQUIRY.DEF_INST.ERROR_DESCRIPTION',
    value: (InstalmentHistoryExpandRecord: InstalmentHistoryTableData) =>
      InstalmentHistoryExpandRecord?.errorDescription?.typeOfErrorDescription,
    chip: false,
  },
  {
    id: 11,
    key: 'technicianName',
    label: 'ENQUIRY.DEF_INST.TECHNICIAN',
    value: (InstalmentHistoryExpandRecord: InstalmentHistoryTableData) => InstalmentHistoryExpandRecord?.technicianName,
    chip: false,
  },
  {
    id: 12,
    key: 'mistNarrative',
    label: 'ENQUIRY.DEF_INST.MIST_NARRATIVE',
    value: (InstalmentHistoryExpandRecord: InstalmentHistoryTableData) => InstalmentHistoryExpandRecord?.mistNarrative,
    chip: false,
  },
];
export const instalmentHistoryMockData: InstalmentHistoryTableData[] = [
  {
    instalmentId: '1',
    instalmentType: 'Monthly',
    instalmentNo: 1,
    dueDateOriginal: '2024-01-01',
    dueDateCurrent: '2024-01-01',
    instalmentDueAmount: 500.0,
    dateOfChange: new Date('2023-12-20'),
    changeBy: new Date('2023-12-20'),
    errorMadeBy: 'Broker',
    category: 'Code Changes',
    errorDescription: {
      refErrorDescriptionId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfErrorDescription: 'S03 Signed with incorrect PSD',
    },
    mistNarrative: 'string',
    technicianName: 'string',
  },
  {
    instalmentId: '2',
    instalmentType: 'Monthly',
    instalmentNo: 2,
    dueDateOriginal: '2024-02-01',
    dueDateCurrent: '2024-02-05',
    instalmentDueAmount: 500.0,
    dateOfChange: new Date('2024-01-15'),
    changeBy: new Date('2024-01-15'),
    errorMadeBy: 'Broker',
    category: 'Code Changes',
    errorDescription: {
      refErrorDescriptionId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfErrorDescription: 'S03 Signed with incorrect PSD',
    },
    mistNarrative: 'string',
    technicianName: 'string',
  },
  {
    instalmentId: '3',
    instalmentType: 'Quarterly',
    instalmentNo: 1,
    dueDateOriginal: '2024-03-01',
    dueDateCurrent: '2024-03-01',
    instalmentDueAmount: 1500.0,
    dateOfChange: new Date('2024-02-10'),
    changeBy: new Date('2024-02-10'),
    errorMadeBy: 'Broker',
    category: 'Code Changes',
    errorDescription: {
      refErrorDescriptionId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfErrorDescription: 'S03 Signed with incorrect PSD',
    },
    mistNarrative: 'string',
    technicianName: 'string',
  },
  {
    instalmentId: '4',
    instalmentType: 'Quarterly',
    instalmentNo: 2,
    dueDateOriginal: '2024-06-01',
    dueDateCurrent: '2024-06-10',
    instalmentDueAmount: 1500.0,
    dateOfChange: new Date('2024-05-25'),
    changeBy: new Date('2024-05-25'),
    errorMadeBy: 'Broker',
    category: 'Code Changes',
    errorDescription: {
      refErrorDescriptionId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfErrorDescription: 'S03 Signed with incorrect PSD',
    },
    mistNarrative: 'string',
    technicianName: 'string',
  },
  {
    instalmentId: '5',
    instalmentType: 'Monthly',
    instalmentNo: 3,
    dueDateOriginal: '2024-03-01',
    dueDateCurrent: '2024-03-01',
    instalmentDueAmount: 500.0,
    dateOfChange: new Date('2024-02-20'),
    changeBy: new Date('2024-02-20'),
    errorMadeBy: 'Broker',
    category: 'Code Changes',
    errorDescription: {
      refErrorDescriptionId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
      typeOfErrorDescription: 'S03 Signed with incorrect PSD',
    },
    mistNarrative: 'string',
    technicianName: 'string',
  },
];

export interface InstalmentHistoryTableData {
  instalmentId: string;
  instalmentType: string;
  instalmentNo: number;
  dueDateOriginal: string;
  dueDateCurrent: string;
  instalmentDueAmount: number;
  dateOfChange: Date;
  changeBy: Date;
  errorMadeBy: string;
  category: string;
  errorDescription: TypeOfErrorDescription;
  technicianName?: string;
  mistNarrative?: string;
}
