import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/def-instalment.action';
import * as _ from 'lodash';
import { DefInstalementState } from '@features/enquiry/models/enquiry.model';

export const initialState: DefInstalementState = {
  premiumDetails: null,
  error: null,
  instalmentHistory: null,
};

export const DefInstalementReducer: ActionReducer<DefInstalementState, Action> = createReducer(
  initialState,

  // get state premium details
  on(actions.setPremiumDetails, (state: DefInstalementState, action) =>
    _.setWith(_.clone(state), 'premiumDetails', action.premiumDetails, _.clone)
  ),
  // get state premium details
  on(actions.setDeferredInstalments, (state: DefInstalementState, action) =>
    _.setWith(_.clone(state), 'instalmentHistory', action.instalmentHistory, _.clone)
  )
);
