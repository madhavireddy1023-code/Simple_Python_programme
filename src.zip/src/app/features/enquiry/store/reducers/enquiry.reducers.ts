import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/enquiry.action';
import * as _ from 'lodash';
import { EnquiryState } from '@features/enquiry/models/enquiry.model';

export const initialState: EnquiryState = {
  premiumEnquiry: null,
};

export const PremiumEnquiryReducer: ActionReducer<EnquiryState, Action> = createReducer(
  initialState,

  // update state premiumEnquiry
  on(actions.setPremiumEnquiryRecords, (state: EnquiryState, action) =>
    _.setWith(_.clone(state), 'premiumEnquiry', action.premiumEnquiry, _.clone)
  ),

  on(actions.clearData, () => initialState)
);
