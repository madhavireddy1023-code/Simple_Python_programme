import { Action } from '@ngrx/store';
import * as actions from '../actions/def-instalment.action';
import { initialState, DefInstalementReducer } from './def-instalment.reducers';
import { mockPremiumDetails } from '../../../instalment-details/const/mock-premium-details.const';

describe('DefInstalmentyReducer', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = DefInstalementReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should update the state of [premiumEnquiry] When setPremiumEnquiryRecords is dipatched', () => {
    const expectedState = mockPremiumDetails;
    const action = actions.setPremiumDetails({ premiumDetails: mockPremiumDetails });
    const newState = DefInstalementReducer(initialState, action);
    expect(newState.premiumDetails).toEqual(expectedState);
  });

  it('should update the state of [instalmentHistory ] When setDeferredInstalments is dipatched', () => {
    const expectedState = [];
    const action = actions.setDeferredInstalments({ instalmentHistory: [] });
    const newState = DefInstalementReducer(initialState, action);
    expect(newState.instalmentHistory).toEqual(expectedState);
  });
});
