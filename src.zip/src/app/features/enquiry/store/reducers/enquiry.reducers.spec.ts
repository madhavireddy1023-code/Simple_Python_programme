import { Action } from '@ngrx/store';
import * as actions from '../actions/enquiry.action';
import { initialState, PremiumEnquiryReducer } from './enquiry.reducers';
import { mockPremiumEnquiryData } from '@features/enquiry/const/enquiry.const';

describe('PremiumEnquiryReducer', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = PremiumEnquiryReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should update the state of [premiumEnquiry] When setPremiumEnquiryRecords is dipatched', () => {
    const expectedState = mockPremiumEnquiryData;
    const action = actions.setPremiumEnquiryRecords({ premiumEnquiry: expectedState });
    const newState = PremiumEnquiryReducer(initialState, action);
    expect(newState.premiumEnquiry).toEqual(expectedState);
  });

  it('should return the initial state when clearData action is dispatched', () => {
    const action = actions.clearData();
    const newState = PremiumEnquiryReducer(initialState, action);
    expect(newState).toEqual(initialState);
  });
});
