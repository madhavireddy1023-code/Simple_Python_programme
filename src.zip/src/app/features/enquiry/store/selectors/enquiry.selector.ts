import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.premiumEnquiry;

// get premium Enquiry
export const selectPremiumEnquiry = createSelector(selectState, (state) => state?.premiumEnquiry);
