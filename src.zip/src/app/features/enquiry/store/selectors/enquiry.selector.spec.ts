import { mockPremiumEnquiryData } from '@features/enquiry/const/enquiry.const';
import * as selectors from './enquiry.selector';

describe('PremiumEnquirySelector', () => {
  const state = {
    premiumEnquiry: mockPremiumEnquiryData,
  };

  it('should select premiumEnquiry data', () => {
    const expectedData = mockPremiumEnquiryData;
    const premiumEnquirySelectror = selectors.selectPremiumEnquiry.projector(state);
    expect(premiumEnquirySelectror).toEqual(expectedData);
  });
});
