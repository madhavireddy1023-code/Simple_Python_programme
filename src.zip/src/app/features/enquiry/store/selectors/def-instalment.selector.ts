import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.defInstalment;

// get premium Details
export const selectPremiumDetails = createSelector(selectState, (state) => state?.premiumDetails);

export const selectInstalmentHistory = createSelector(selectState, (state) => state?.instalmentHistory);
