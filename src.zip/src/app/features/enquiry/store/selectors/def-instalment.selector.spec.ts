import { instalmentHistoryMockData } from '@features/enquiry/const/def-inst-hist.const';
import * as selectors from './def-instalment.selector';
import { InstalmentHistory } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

describe('def-instalment selectors', () => {
  const state = {
    instalmentHistory: [],
    premiumDetails: { premiumId: '123', amount: 500 },
  };

  it('should select selectInstalmentHistory', () => {
    const expectedData: InstalmentHistory = [];
    const content = selectors.selectInstalmentHistory.projector(state);
    expect(content).toEqual(expectedData);
  });

  it('should select selectPremiumDetails', () => {
    const expectedData = { premiumId: '123', amount: 500 };
    const content = selectors.selectPremiumDetails.projector(state);
    expect(content).toEqual(expectedData);
  });
});
