import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable, of } from 'rxjs';
import { initialState } from '../reducers/enquiry.reducers';
import { PremiumEnquiryEffects } from './enquiry.effects';
import * as actions from '../actions/enquiry.action';
import { RouterTestingModule } from '@angular/router/testing';
import { SigningDetailsComponent } from '@features/signing-details/components/signing-details/signing-details.component';
import { HttpResponse } from '@angular/common/http';
import { take, toArray } from 'rxjs/operators';
import { mockPremiumEnquiryData } from '@features/enquiry/const/enquiry.const';
import { TechnicianPortalEnquiryService } from 'src/app/api/technicianPortalEnquiry';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';

describe('PremiumEnquiryEffects', () => {
  let actions$: Observable<any>;
  let effects: PremiumEnquiryEffects;
  let technicianPortalEnquiryService: jasmine.SpyObj<TechnicianPortalEnquiryService>;

  beforeEach(() => {
    const technicianPortalServiceSpy = jasmine.createSpyObj('TechnicianPortalEnquiryService', [
      'apiV1PremiumEnquiryPost',
    ]);

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([{ path: 'signing-details?type=signing0', component: SigningDetailsComponent }]),
      ],
      providers: [
        PremiumEnquiryEffects,
        { provide: TechnicianPortalEnquiryService, useValue: technicianPortalServiceSpy },
        provideMockStore({ initialState }),
        provideMockActions(() => actions$),
      ],
    });

    effects = TestBed.inject(PremiumEnquiryEffects);
    technicianPortalEnquiryService = TestBed.inject(
      TechnicianPortalEnquiryService
    ) as jasmine.SpyObj<TechnicianPortalEnquiryService>;
  });

  it('should dispatch both loadGlobalAlert and setPremiumEnquiryRecords actions on success', (done) => {
    actions$ = of(actions.getPremiumEnquiry({ premiumEnquiry: 'test' }));
    technicianPortalEnquiryService.apiV1PremiumEnquiryPost.and.returnValue(
      of(new HttpResponse({ status: 200, body: mockPremiumEnquiryData }))
    );

    effects.getPremiumEnquiry$.pipe(take(2), toArray()).subscribe((emittedActions) => {
      expect(emittedActions).toEqual([
        loadGlobalAlert({
          response: {
            responseMessage: 'ALERTS.DATA_RETRIEVED',
            status: 200,
            isGlobalAlert: true,
          },
        }),
        actions.setPremiumEnquiryRecords({
          premiumEnquiry: mockPremiumEnquiryData,
        }),
      ]);
      done();
    });
  });
});
