import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable, of, throwError } from 'rxjs';

import { DefInstalmentEffects } from './def-instalment.effects';
import * as actions from '../actions/def-instalment.action';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';

import { TechnicianPortalCorrectionsExperienceService } from 'src/app/api/premium-technician-experience-corrections';
import { DomainAPITechnicianPortalCorrectionService } from 'src/app/api/domain-api-technician-portal-correction';
import { HttpResponse } from '@angular/common/http';
import { PremiumGetRec } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { InstalmentHistory } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

describe('DefInstalmentEffects', () => {
  let effects: DefInstalmentEffects;
  let actions$: Observable<any>;
  let technicianService: jasmine.SpyObj<TechnicianPortalCorrectionsExperienceService>;
  let domainService: jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;

  beforeEach(() => {
    const technicianSpy = jasmine.createSpyObj('TechnicianPortalCorrectionsExperienceService', [
      'apiV1InstalmentDetailsGet',
    ]);
    const domainSpy = jasmine.createSpyObj('DomainAPITechnicianPortalCorrectionService', [
      'apiV1DeferredInstalmentHistoryGet',
    ]);

    TestBed.configureTestingModule({
      providers: [
        DefInstalmentEffects,
        provideMockActions(() => actions$),
        { provide: TechnicianPortalCorrectionsExperienceService, useValue: technicianSpy },
        { provide: DomainAPITechnicianPortalCorrectionService, useValue: domainSpy },
      ],
    });

    effects = TestBed.inject(DefInstalmentEffects);
    technicianService = TestBed.inject(
      TechnicianPortalCorrectionsExperienceService
    ) as jasmine.SpyObj<TechnicianPortalCorrectionsExperienceService>;
    domainService = TestBed.inject(
      DomainAPITechnicianPortalCorrectionService
    ) as jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;
  });

  it('should dispatch setPremiumDetails on successful API response', (done) => {
    const action = actions.getPremiumDetails({
      workPackageRef: '123',
      premiumId: '456',
      typeOfPremium: 'example',
      umr: '789',
      csnd: 'CSND',
    });

    // Create a mock PremiumGetRec object with minimal data
    const mockPremiumGetRec: PremiumGetRec = {
      premiumId: '456',
      riskCode: 'RC001',
      premiumNumber: 12345,
      grossPremium: 1000,
    };

    const response = new HttpResponse<PremiumGetRec>({
      body: mockPremiumGetRec,
    });

    technicianService.apiV1InstalmentDetailsGet.and.returnValue(of(response));

    actions$ = of(action);

    effects.getPremiumData$.subscribe((result) => {
      expect(result).toEqual(actions.setPremiumDetails({ premiumDetails: mockPremiumGetRec }));
      done();
    });
  });

  it('should dispatch setDeferredInstalments on successful API response', (done) => {
    const action = actions.getDeferredInstalments({ premiumId: '123' });

    const mockInstalmentHistory: InstalmentHistory = [
      {
        instalmentHistoryNew: {
          chargeableIndicator: true,
          correctionSigningNarrative: 'Narrative for new instalment',
        },
        instalmentHistoryOld: {
          chargeableIndicator: false,
          correctionSigningNarrative: 'Narrative for old instalment',
        },
      },
    ];

    const response = new HttpResponse<InstalmentHistory>({
      body: mockInstalmentHistory,
    });

    // Mocking the service method to return the response
    domainService.apiV1DeferredInstalmentHistoryGet.and.returnValue(of(response));

    actions$ = of(action);

    effects.getDeferredInstalments$.subscribe((result) => {
      // Check that the correct action is dispatched with the mock instalmentHistory
      expect(result).toEqual(actions.setDeferredInstalments({ instalmentHistory: mockInstalmentHistory }));
      done();
    });
  });
});
