import { Injectable } from '@angular/core';

import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, forkJoin, from, of } from 'rxjs';
import { catchError, map, switchMap, withLatestFrom } from 'rxjs/operators';

import * as actions from '../actions/def-instalment.action';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';

import { WorkflowXisService } from 'src/app/api/workflow-rules-api';
import _ from 'lodash';
import { TechnicianPortalCorrectionsExperienceService } from 'src/app/api/premium-technician-experience-corrections';
import { premiumDetails } from '@features/enquiry/const/payloads.const';
import { ScrollUp } from 'src/app/utils';
import { DomainAPITechnicianPortalCorrectionService } from 'src/app/api/domain-api-technician-portal-correction';

@Injectable()
export class DefInstalmentEffects {
  constructor(
    private actions$: Actions,
    private technicianPortalCorrectionsExperienceService: TechnicianPortalCorrectionsExperienceService,
    private domainAPITechnicianPortalCorrectionService: DomainAPITechnicianPortalCorrectionService
  ) {}

  resp = premiumDetails;

  // getPremiumData
  getPremiumData$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getPremiumDetails),
      switchMap((action) =>
        this.technicianPortalCorrectionsExperienceService
          .apiV1InstalmentDetailsGet(
            action.workPackageRef,
            action.premiumId,
            action.typeOfPremium as any,
            action.umr,
            action.csnd,
            undefined,
            'response'
          )
          .pipe(
            switchMap((response) => {
              return of(actions.setPremiumDetails({ premiumDetails: response?.body }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 400) {
                const errorRes = error?.error?.map((item) => {
                  return loadGlobalAlert({
                    response: {
                      error,
                      responseMessage: item.detail,
                      status: 400,
                      isGlobalAlert: true,
                      isMultiple: true,
                    },
                  });
                });

                return from([...errorRes]);
              } else {
                return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
              }
            })
          )
      )
    )
  );

  getDeferredInstalments$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getDeferredInstalments),
      switchMap((action) =>
        this.domainAPITechnicianPortalCorrectionService
          .apiV1DeferredInstalmentHistoryGet(action.premiumId, 'response')
          .pipe(
            switchMap((response) => {
              return of(actions.setDeferredInstalments({ instalmentHistory: response?.body }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 400) {
                const errorRes = error?.error?.map((item) => {
                  return loadGlobalAlert({
                    response: {
                      error,
                      responseMessage: item.title,
                      status: 400,
                      isGlobalAlert: true,
                      isMultiple: true,
                    },
                  });
                });

                return from([...errorRes]);
              } else {
                return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
              }
            })
          )
      )
    )
  );
}
