import { Injectable } from '@angular/core';
import { PremiumEnquiryRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { of } from 'rxjs';
import { catchError, concatMap, mergeMap } from 'rxjs/operators';
import { TechnicianPortalEnquiryService } from 'src/app/api/technicianPortalEnquiry/technician-portal-enquiry.service';
import { clearGlobalResponse, loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import * as actions from '../actions/enquiry.action';
import { RESPONSE_CODES } from '@shared/consts/global-alert.const';

@Injectable()
export class PremiumEnquiryEffects {
  constructor(private actions$: Actions, private technicianPortalEnquiryService: TechnicianPortalEnquiryService) {}

  getPremiumEnquiry$ = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getPremiumEnquiry),
      concatMap((action) =>
        this.technicianPortalEnquiryService.apiV1PremiumEnquiryPost(action.premiumEnquiry, 'response').pipe(
          mergeMap((response: any) => {
            const premiumEnquiry: PremiumEnquiryRecords = response?.body;

            return [
              loadGlobalAlert({
                response: {
                  responseMessage: 'ALERTS.DATA_RETRIEVED',
                  status: 200,
                  isGlobalAlert: true,
                },
              }),
              actions.setPremiumEnquiryRecords({ premiumEnquiry }),
            ];
          }),
          catchError((error) => {
            const errorMsg: string = this.setupDefaultMsgs(error?.status);
            return of(
              loadGlobalAlert({
                response: {
                  responseMessage: errorMsg,
                  isGlobalAlert: true,
                },
              }) as Action
            );
          })
        )
      )
    )
  );

  private setupDefaultMsgs(status: number): string {
    switch (status) {
      case RESPONSE_CODES.OK:
      case RESPONSE_CODES.CREATED: {
        return 'ALERTS.200_MSG';
      }
      case RESPONSE_CODES.BAD_REQUEST:
      case RESPONSE_CODES.CONFLICT: {
        return 'ALERTS.400_MSG';
      }
      case RESPONSE_CODES.UNAUTHORIZED:
      case RESPONSE_CODES.FORBIDDEN: {
        return 'ALERTS.401_MSG';
      }
      case RESPONSE_CODES.SERVER_ERROR: {
        return 'ALERTS.500_MSG';
      }
      case RESPONSE_CODES.NOT_FOUND: {
        return 'ALERTS.404_MSG';
      }
      default: {
        return 'ALERTS.DEFAULT_ERROR_MSG';
      }
    }
  }
}
