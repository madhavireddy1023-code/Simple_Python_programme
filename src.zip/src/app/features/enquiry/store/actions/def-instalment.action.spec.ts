import {
  getDeferredInstalments,
  getPremiumDetails,
  setDeferredInstalments,
  setPremiumDetails,
} from './def-instalment.action';

describe('PremiumEnquiry Actions', () => {
  it('should return correct types', () => {
    // get PremiumEnquiry data
    expect(getPremiumDetails.type).toEqual('[DEF_INSTALMENT] GET_PREMIUM_INSTALMENTS_DATA');

    expect(setPremiumDetails.type).toEqual('[DEF_INSTALMENT] SET_PREMIUM_INSTALMENTS_DATA');
    expect(getDeferredInstalments.type).toEqual('[DEF_INSTALMENT] GET_DEFERRED_INSTALMENTS');
    expect(setDeferredInstalments.type).toEqual('[DEF_INSTALMENT] SET_DEFERRED_INSTALMENTS');
  });
});
