import { PremiumEnquiryRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { createAction, props } from '@ngrx/store';

const PREMIUM_ENQUIRY_PREFIX = '[PREMIUM_ENQUIRY]';

// get premiumEnquiry data
const GET_PREMIUM_ENQUIRY_DATA = `${PREMIUM_ENQUIRY_PREFIX} GET_PREMIUM_ENQUIRY_DATA`;
export const getPremiumEnquiry = createAction(GET_PREMIUM_ENQUIRY_DATA, props<{ premiumEnquiry }>());

// save premiumEnquiry data
const SET_PREMIUM_ENQUIRY = `${PREMIUM_ENQUIRY_PREFIX} SET_PREMIUM_ENQUIRY`;
export const setPremiumEnquiryRecords = createAction(
  SET_PREMIUM_ENQUIRY,
  props<{ premiumEnquiry: PremiumEnquiryRecords }>()
);

const CLEAR_DATA = `${PREMIUM_ENQUIRY_PREFIX} CLEAR_DATA`;
export const clearData = createAction(CLEAR_DATA);
