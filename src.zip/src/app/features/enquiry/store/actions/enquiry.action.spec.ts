import { clearData, getPremiumEnquiry, setPremiumEnquiryRecords } from './enquiry.action';

describe('PremiumEnquiry Actions', () => {
  it('should return correct types', () => {
    // get PremiumEnquiry data
    expect(getPremiumEnquiry.type).toEqual('[PREMIUM_ENQUIRY] GET_PREMIUM_ENQUIRY_DATA');

    // save PremiumEnquiry data
    expect(setPremiumEnquiryRecords.type).toEqual('[PREMIUM_ENQUIRY] SET_PREMIUM_ENQUIRY');

    // clear PremiumEnquiry data
    expect(clearData.type).toEqual('[PREMIUM_ENQUIRY] CLEAR_DATA');
  });
});
