import { createAction, props } from '@ngrx/store';

const DEF_INSTALMENT_PREFIX = '[DEF_INSTALMENT]';

// get premiuDEtails data
const GET_PREMIUM_DETAILS_DATA = `${DEF_INSTALMENT_PREFIX} GET_PREMIUM_INSTALMENTS_DATA`;
export const getPremiumDetails = createAction(
  GET_PREMIUM_DETAILS_DATA,
  props<{ workPackageRef: string; premiumId: string; typeOfPremium: any; umr: string; csnd: string }>()
);

// set premiuDEtails data
const SET_PREMIUM_DETAILS_DATA = `${DEF_INSTALMENT_PREFIX} SET_PREMIUM_INSTALMENTS_DATA`;
export const setPremiumDetails = createAction(SET_PREMIUM_DETAILS_DATA, props<{ premiumDetails }>());

const GET_DEFERRED_INSTALMENTS = `${DEF_INSTALMENT_PREFIX} GET_DEFERRED_INSTALMENTS`;
export const getDeferredInstalments = createAction(GET_DEFERRED_INSTALMENTS, props<{ premiumId: string }>());

const SET_DEFERRED_INSTALMENTS = `${DEF_INSTALMENT_PREFIX} SET_DEFERRED_INSTALMENTS`;
export const setDeferredInstalments = createAction(SET_DEFERRED_INSTALMENTS, props<{ instalmentHistory: any[] }>());
