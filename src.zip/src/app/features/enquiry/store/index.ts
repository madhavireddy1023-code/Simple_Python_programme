import { PremiumEnquiryEffects } from './effects/enquiry.effects';
import { DefInstalmentEffects } from './effects/def-instalment.effects';

import { DefInstalementReducer } from './reducers/def-instalment.reducers';

import { PremiumEnquiryReducer } from './reducers/enquiry.reducers';
import * as PremiumEnquiryActions from './actions/enquiry.action';
import * as EnquirySelectors from './selectors/enquiry.selector';

import * as DefInstalmentActions from './actions/def-instalment.action';
import * as DefInstalmentSelectors from './selectors/def-instalment.selector';

import { EnquiryState, DefInstalementState } from '../models/enquiry.model';

export {
  PremiumEnquiryActions,
  EnquirySelectors,
  EnquiryState,
  PremiumEnquiryEffects,
  PremiumEnquiryReducer,
  DefInstalementReducer,
  DefInstalmentEffects,
  DefInstalmentActions,
  DefInstalmentSelectors,
  DefInstalementState,
};
