import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { EnquiryRoutingModule } from './enquiry-routing.module';
import { SharedModule } from '@shared/shared.module';
import { SyndicateComponent } from './components/syndicate/syndicate.component';
import { MainEnquiryComponent } from './main/main-enquiry/main-enquiry.component';
import { BrokerNoReferenceComponent } from './components/broker-no-reference/broker-no-reference.component';
import { SigningComponent } from './components/signing/signing.component';
import { EnquirySearchTableComponent } from './components/enquiry-search-table/enquiry-search-table.component';
import { UniqueMarketReferenceComponent } from './components/unique-market/unique-market-reference.component';
import { WorkPackageReferenceComponent } from './components/work-package-reference/work-package-reference.component';
import { SigningFormComponent } from './components/signing/signing-form/signing-form.component';
import { MainDefInstHistoryComponent } from './main/main-enquiry-def-inst-history/main-def-inst-history.component';
import { CompanyDefInstHistoryTableComponent } from './components/Instalment-history-table/instalment-history-table.component';
import { VeloneticComponent } from './components/velonetic/velonetic.component';
import { FacilitySearchComponent } from './components/facility-search/facility-search.component';
@NgModule({
  declarations: [
    SyndicateComponent,
    MainEnquiryComponent,
    BrokerNoReferenceComponent,
    SigningComponent,
    EnquirySearchTableComponent,
    UniqueMarketReferenceComponent,
    WorkPackageReferenceComponent,
    SigningFormComponent,
    MainDefInstHistoryComponent,
    CompanyDefInstHistoryTableComponent,
    VeloneticComponent,
    FacilitySearchComponent,
  ],
  imports: [CommonModule, EnquiryRoutingModule, SharedModule],
  providers: [DatePipe],
})
export class EnquiryModule {}
