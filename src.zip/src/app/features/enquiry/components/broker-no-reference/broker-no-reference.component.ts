import { Component, OnInit, Input } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors } from '@angular/forms';
import { DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { FormControls } from '@shared/models/interfaces';
import { ValidationInputStatus, isPositiveEnquiryInteger, isString } from 'src/app/utils/helper/helper';
import { INPUT_TYPES } from '@shared/consts/shared.enums';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-broker-no-reference',
  templateUrl: './broker-no-reference.component.html',
  styleUrls: ['./broker-no-reference.component.scss'],
})
export class BrokerNoReferenceComponent implements OnInit {
  private destroyed$ = new Subject();
  readonly inputTypes = INPUT_TYPES;

  brokerNoReferenceForm: FormGroup;
  submitted: boolean;
  isSearchBtnClicked = false;
  isBrokerNumberSelected: boolean;

  @Input() set isSearchEnquiry(isSearchEnquiry: Subject<boolean>) {
    isSearchEnquiry?.pipe(takeUntil(this.destroyed$)).subscribe((value) => {
      this.isSearchBtnClicked = !value;
    });
  }

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.initBrokerNoReferenceFrom();
  }

  // initiate brokerNoReference
  initBrokerNoReferenceFrom(): void {
    this.brokerNoReferenceForm = this.formBuilder.group({
      brokerNumber: ['', isPositiveEnquiryInteger(0, 4)],
      brokerReference: ['', isString(0, 12)],
    });
  }

  // get form controls of brokerNoReference form
  get brokerNoReferenceFormControls(): FormControls {
    return this.brokerNoReferenceForm?.controls;
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }
}
