import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokerNoReferenceComponent } from './broker-no-reference.component';
import { DebugElement } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

describe('BrokerNoReferenceComponent', () => {
  let component: BrokerNoReferenceComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<BrokerNoReferenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BrokerNoReferenceComponent],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokerNoReferenceComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call Broker Number and Refernce Form on init', () => {
    spyOn(component, 'initBrokerNoReferenceFrom');
    component.ngOnInit();
    expect(component.initBrokerNoReferenceFrom).toHaveBeenCalled();
  });

  describe('Broker Number and Refernce Form controls validation', () => {
    let formControls;

    beforeEach(() => {
      component.initBrokerNoReferenceFrom();
      formControls = component.brokerNoReferenceForm.controls;
    });

    it('should brokerNoReferenceForm to be invalid when brokerNumber control has whitespaces', () => {
      formControls.brokerNumber.setValue('   ');
      expect(component.brokerNoReferenceForm.invalid).toBeTruthy();
      expect(formControls.brokerNumber.hasError('noWhiteSpace'));
    });

    it('should brokerNoReferenceForm to be invalid when brokerNumber control has more than 4 character', () => {
      formControls.brokerNumber.setValue('12345');
      expect(component.brokerNoReferenceForm.invalid).toBeTruthy();
      expect(formControls.brokerNumber.hasError('maxLength'));
    });

    it('should brokerNoReferenceForm to be invalid when brokerNumber control has letters and numbers', () => {
      formControls.brokerNumber.setValue('a345');
      expect(component.brokerNoReferenceForm.invalid).toBeTruthy();
      expect(formControls.brokerNumber.hasError('alphanumeric_ascii'));
    });

    it('should brokerNoReferenceForm to be invalid when brokerReference control has whitespaces', () => {
      formControls.brokerReference.setValue('   ');
      expect(component.brokerNoReferenceForm.invalid).toBeTruthy();
      expect(formControls.brokerReference.hasError('noWhiteSpace'));
    });

    it('should brokerNoReferenceForm to be invalid when brokerReference control has more than 12 character', () => {
      formControls.brokerReference.setValue('AB1234CD5678V4');
      expect(component.brokerNoReferenceForm.invalid).toBeTruthy();
      expect(formControls.brokerReference.hasError('maxLength'));
    });

    it('should brokerNoReferenceForm to be invalid when brokerReference control has non ascii character', () => {
      formControls.brokerReference.setValue('«');
      expect(component.brokerNoReferenceForm.invalid).toBeTruthy();
      expect(formControls.brokerReference.hasError('alphanumeric_ascii'));
    });
  });
});
