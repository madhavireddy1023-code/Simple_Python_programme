import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VeloneticComponent } from './velonetic.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

describe('VeloneticComponent', () => {
  let component: VeloneticComponent;
  let fixture: ComponentFixture<VeloneticComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VeloneticComponent],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        TranslateModule.forRoot({}),
        SharedModule,
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
      ],
      providers: [DatePipe, MockStore, provideMockStore()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VeloneticComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form with default values', () => {
    expect(component.veloneticFrom.value).toEqual({
      workPackageReference: '',
      signingDate: component.creationDateByToday,
      days: '1',
      signedBy: '',
      auditStatus: 'Select',
    });
  });

  it('should not emit setSearch event when onSearch is called and form is invalid', () => {
    spyOn(component.setSearch, 'emit');
    component.veloneticFrom.controls.workPackageReference.setValue('12');
    component.onSearch();
    expect(component.setSearch.emit).not.toHaveBeenCalled();
  });

  it('should call setSelectValue when setSelectValue is called', () => {
    spyOn(component, 'setSelectValue').and.callThrough();
    component.setSelectValue(component.veloneticFrom.controls.auditStatus, 'PASS');
    expect(component.setSelectValue).toHaveBeenCalled();
  });
});
