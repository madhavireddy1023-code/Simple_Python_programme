import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { DxcTextareaComponent, DxcTextInputComponent, Option } from '@dxc-technology/halstack-angular';
import { PassFailEnum } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { DateInputComponent } from '@shared/components/date-input/date-input.component';
import { isString, onMultiSelectChange, setSelectValue, ValidationInputStatus } from 'src/app/utils';

@Component({
  selector: 'app-velonetic',
  templateUrl: './velonetic.component.html',
  styleUrls: ['./velonetic.component.scss'],
})
export class VeloneticComponent implements OnInit {
  isInProgress = true;
  datePipe = new DatePipe('en-UK');
  dateCreation = new Date();
  creationDateByToday = this.datePipe.transform(this.dateCreation, 'yyyy-MM-dd');
  veloneticFrom: FormGroup = new FormGroup({
    workPackageReference: new FormControl('', isString(5, 7)),
    signingDate: new FormControl(this.creationDateByToday, Validators.required),
    days: new FormControl('1'),
    signedBy: new FormControl(''),
    auditStatus: new FormControl('Select'),
  });
  @Input() hideInProgressIndicator: boolean;
  @Output() setSearch = new EventEmitter<string>();
  @Output() inProgress = new EventEmitter<boolean>();
  @ViewChild('signingDate') signingDate: DateInputComponent;
  daysOPTIONS: Option[] = [
    {
      label: '1',
      value: '1',
    },
    {
      label: '2',
      value: '2',
    },
    {
      label: '3',
      value: '3',
    },
    {
      label: '4',
      value: '4',
    },
    {
      label: '5',
      value: '5',
    },
    {
      label: '6',
      value: '6',
    },
    {
      label: '7',
      value: '7',
    },
  ];
  auditStatusOPTIONS: Option[] = [
    {
      label: 'Select',
      value: 'Select',
    },
    {
      label: 'Pass',
      value: PassFailEnum.PASS,
    },
    {
      label: 'Fail',
      value: PassFailEnum.FAIL,
    },
    {
      label: 'Null',
      value: 'BLANK',
    },
  ];
  startDateValue = new Date();
  signingDateErrorMsg: string;
  isSearchBtnClicked: boolean;
  constructor() {}

  ngOnInit(): void {
    this.inProgressChanged(this.isInProgress);
  }
  inProgressChanged(event: boolean): void {
    this.isInProgress = event;
    this.inProgress.next(event);
  }

  onSearch(): void {
    this.isSearchBtnClicked = true;
    if (!this.signingDate.dateForm.valid) {
      this.signingDate.dateForm.setValidators([Validators.required]);
      this.signingDate.dateForm.updateValueAndValidity();
      return;
    }
    if (
      this.signingDate.dateForm.value.year &&
      this.signingDate.dateForm.value.month &&
      this.signingDate.dateForm.value.day
    ) {
      this.veloneticFrom.controls.signingDate.setValue(
        this.signingDate.dateForm.value.year +
          '-' +
          this.signingDate.dateForm.value.month +
          '-' +
          this.signingDate.dateForm.value.day
      );
    } else {
      this.veloneticFrom.controls.signingDate.setValue('');
    }

    if (this.veloneticFrom.valid) {
      this.setSearch.emit();
    }
  }
  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }
  setSelectValue(formControl: AbstractControl, value: string, refKey?: string, refData?: any): void {
    setSelectValue(formControl, value, refKey, refData);
  }
}
