import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule } from '@angular/forms';
import { SigningFormComponent } from './signing-form.component';
import { DateInputComponent } from '@shared/components/date-input/date-input.component';
import { SUBSEQUENT_TRANSACTION_OPTIONS } from '@features/enquiry/const/enquiry.const';
import { formatDate } from '@angular/common';

describe('SigningFormComponent', () => {
  let component: SigningFormComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<SigningFormComponent>;
  const signingDateComponent = jasmine.createSpyObj('DateInputComponent', ['formatDate']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SigningFormComponent, DateInputComponent],
      imports: [ReactiveFormsModule, TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SigningFormComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the signingForm', () => {
    expect(component.signingForm).toBeDefined();
  });

  it('should format selects by enum', () => {
    expect(component.enquirySigningOptions).toBeDefined();
  });

  it('should call initSigningDetailsForm and formatSelectsByEnum in oninit', () => {
    spyOn(component, 'initSigningDetailsForm');
    spyOn(component, 'formatSelectsByEnum');
    component.ngOnInit();
    expect(component.initSigningDetailsForm).toHaveBeenCalled();
    expect(component.formatSelectsByEnum).toHaveBeenCalled();
  });

  it('should be false called when getValidationSelectStatus triggered', () => {
    component.isSearchBtnClicked = true;
    const validationStatus = component.getValidationSelectStatus(null, null);
    expect(validationStatus).toBeFalsy();
  });

  it('should be false called when getValidationInputStatus triggered', () => {
    component.isSearchBtnClicked = true;
    const validationStatus = component.getValidationInputStatus(null, null);
    expect(validationStatus).toBeFalsy();
  });

  it('should be true on isSearchBtnClicked when onSearch triggered', () => {
    spyOn(component, 'setRequiredForAllControls');
    component.onSearch();
    expect(component.isSearchBtnClicked).toBeTruthy();
    expect(component.setRequiredForAllControls).toHaveBeenCalled();
  });

  it('should be options value set after formatSelectsByEnum', () => {
    const expected = [
      { label: 'Complete history', value: 'Complete history' },
      { label: 'Premium and previous 2 months', value: 'Premium and previous 2 months' },
      { label: 'Premium and previous 6 months', value: 'Premium and previous 6 months' },
      { label: 'Premium and previous month only', value: 'Premium and previous month only' },
      { label: 'Premium and previous year', value: 'Premium and previous year' },
      { label: 'Select date range', value: 'Select date range' },
    ];
    component.formatSelectsByEnum();
    expect(component.enquirySigningOptions).toEqual(expected);
  });

  it('should set start date to one year ago for PREMIUM_PREVIOUS_YEAR option', () => {
    const expectedStartDate = new Date();
    expectedStartDate.setFullYear(expectedStartDate.getFullYear() - 1);

    component.calculateDates(SUBSEQUENT_TRANSACTION_OPTIONS.PREMIUM_PREVIOUS_YEAR);

    expect(component.calculatedDates.startDate).toEqual(formatDate(expectedStartDate, 'yyyy-MM-dd', 'en-US'));
    expect(component.calculatedDates.endDate).toEqual(formatDate(new Date(), 'yyyy-MM-dd', 'en-US'));
  });

  it('should set start date to six months ago for PREMIUM_PREVIOUS_SIX_MONTHS option', () => {
    const expectedStartDate = new Date();
    expectedStartDate.setMonth(expectedStartDate.getMonth() - 6);

    component.calculateDates(SUBSEQUENT_TRANSACTION_OPTIONS.PREMIUM_PREVIOUS_SIX_MONTHS);

    expect(component.calculatedDates.startDate).toEqual(formatDate(expectedStartDate, 'yyyy-MM-dd', 'en-US'));
    expect(component.calculatedDates.endDate).toEqual(formatDate(new Date(), 'yyyy-MM-dd', 'en-US'));
  });

  it('should set start date to two months ago for PREMIUM_PREVIOUS_TWO_MONTHS option', () => {
    const expectedStartDate = new Date();
    expectedStartDate.setMonth(expectedStartDate.getMonth() - 2);

    component.calculateDates(SUBSEQUENT_TRANSACTION_OPTIONS.PREMIUM_PREVIOUS_TWO_MONTHS);

    expect(component.calculatedDates.startDate).toEqual(formatDate(expectedStartDate, 'yyyy-MM-dd', 'en-US'));
    expect(component.calculatedDates.endDate).toEqual(formatDate(new Date(), 'yyyy-MM-dd', 'en-US'));
  });

  it('should set start date to a month ago for MONTH_ONLY option', () => {
    const expectedStartDate = new Date();
    expectedStartDate.setMonth(expectedStartDate.getMonth() - 1);
    expectedStartDate.setDate(1);

    component.calculateDates(SUBSEQUENT_TRANSACTION_OPTIONS.MONTH_ONLY);

    expect(component.calculatedDates.startDate).toEqual(formatDate(expectedStartDate, 'yyyy-MM-dd', 'en-US'));
    expect(component.calculatedDates.endDate).toEqual(formatDate(new Date(), 'yyyy-MM-dd', 'en-US'));
  });

  it('should not set start date or end date', () => {
    component.calculateDates(null);

    expect(component.calculatedDates?.startDate).toEqual(undefined);
    expect(component.calculatedDates?.endDate).toEqual(undefined);
  });

  describe('initSigningDetailsForm controls validations', () => {
    let formControls;

    beforeEach(() => {
      component.initSigningDetailsForm();
      formControls = component.signingForm.controls;
    });

    it('should validator be null after removeRequiredForAllControls', () => {
      component.removeRequiredForAllControls();
      expect(component.signingFormControls.signingNumber.validator).toBeNull();
      expect(component.signingFormControls.transactionRestrict.validator).toBeNull();
    });

    it('should has value in validator after resetAllControls', () => {
      component.resetAllControls();
      expect(component.signingFormControls.signingNumber.validator).not.toBeNull();
    });

    it('should has value in validator after resetAllControls and isSigningSelected is Lloyds', () => {
      component.isSigningSelected = component.signingOption.LLOYDS;
      component.resetAllControls();
      expect(component.signingFormControls.signingNumber.validator).not.toBeNull();
    });

    it('should has value in validator after setRequiredForAllControls and isSigningSelected is Lloyds', () => {
      component.isSearchBtnClicked = true;
      signingDateComponent.formatDate.and.returnValue('2222-03-13');
      component.isSigningSelected = component.signingOption.LLOYDS;
      component.setRequiredForAllControls();
      expect(component.signingFormControls.signingNumber.validator).not.toBeNull();
      expect(component.signingFormControls.transactionRestrict.validator).not.toBeNull();
    });

    it('should has value in validator after setRequiredForAllControls', () => {
      component.isSearchBtnClicked = true;
      signingDateComponent.formatDate.and.returnValue('2222-03-13');
      component.isSigningSelected = component.signingOption.COMPANY;
      component.setRequiredForAllControls();
      expect(component.signingFormControls.signingNumber.validator).not.toBeNull();
      expect(component.signingFormControls.transactionRestrict.validator).not.toBeNull();
    });

    describe('SigningDetailsForm controls LLOYDS required validations', () => {
      beforeEach(() => {
        component.isSigningSelected = component.signingOption.LLOYDS;
        component.onSearch();
        expect(component.isSearchBtnClicked).toBe(true);
        component.setRequiredForAllControls();
      });
    });
  });
});
