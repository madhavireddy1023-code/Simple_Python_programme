import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators, ValidatorFn } from '@angular/forms';
import {
  ValidationInputStatus,
  ValidationSelectStatus,
  formatOption,
  getOptionsByEnum,
  isPositiveEnquiryInteger,
  isString,
  setSelectValue,
} from 'src/app/utils/helper/helper';
import {
  DxcSelectComponent,
  DxcTextInputComponent,
  DxcTextareaComponent,
  Option,
} from '@dxc-technology/halstack-angular';
import { SUBSEQUENT_TRANSACTION_OPTIONS, SIGNING_OPTIONS } from '@features/enquiry/const/enquiry.const';
import { FormControls } from '@shared/models/interfaces';
import { BehaviorSubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DateInputComponent } from '@shared/components/date-input/date-input.component';
import { formatDate } from '@angular/common';
import { SORT_TYPES } from '@shared/consts/shared.enums';

@Component({
  selector: 'app-signing-form',
  templateUrl: './signing-form.component.html',
  styleUrls: ['./signing-form.component.scss'],
})
export class SigningFormComponent implements OnInit {
  readonly signingOption = SIGNING_OPTIONS;
  readonly subsequentTransaction: string = SUBSEQUENT_TRANSACTION_OPTIONS.RANGE;
  private destroyed$ = new Subject();
  signingForm: FormGroup;
  enquirySigningOptions: Option[] = [];
  isSearchBtnClicked: boolean;
  hideSearchBtn: boolean;
  isSigningSelected: string;
  calculatedDates: { startDate: string; endDate: string };
  isInProgress = false;
  @Input() hideInProgressIndicator: boolean;

  @Output() searchInitiated = new EventEmitter();
  @Output() inProgress = new EventEmitter<boolean>();

  @Output() transactionRestrict = new EventEmitter<boolean>();
  @Input() set isSelected(value) {
    this.isSigningSelected = value;
    this.initSigningDetailsForm();
    this.removeRequiredForAllControls();
    this.resetAllControls();
  }

  @Input() set isSearchEnquiry(isSearchEnquiry: Subject<boolean>) {
    isSearchEnquiry?.pipe(takeUntil(this.destroyed$)).subscribe((value) => {
      this.isSearchBtnClicked = !value;
    });
  }

  @ViewChild('signingDate') signingDate: DateInputComponent;
  originalCurrencyOptions: Option[] = [];

  @Input() set referenceData(referenceData: any) {
    if (referenceData) {
      this.formatSelects(referenceData);
    }
  }

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.initSigningDetailsForm();
    this.formatSelectsByEnum();
  }

  get signingFormControls(): FormControls {
    return this.signingForm?.controls;
  }

  getValidationSelectStatus(formControl: AbstractControl, select: DxcSelectComponent): boolean {
    return ValidationSelectStatus(this.isSearchBtnClicked, formControl, select);
  }

  formatSelectsByEnum(): void {
    this.enquirySigningOptions = getOptionsByEnum(SUBSEQUENT_TRANSACTION_OPTIONS, {}, false, SORT_TYPES.ASC);
  }

  initSigningDetailsForm(): void {
    this.signingForm = this.formBuilder.group({
      transactionRestrict: [SUBSEQUENT_TRANSACTION_OPTIONS.COMPLETE_HISTORY],
      signingNumber: ['', isString(0, 15, true)],
      originalCurrency: [''],
    });
  }

  setSelectValue(formControl: AbstractControl, value: string, refKey?: string, refData?: any): void {
    setSelectValue(formControl, value, refKey, refData);
    this.calculateDates(value);
  }
  displayDates(option: string): void {
    if (option === SUBSEQUENT_TRANSACTION_OPTIONS.RANGE) {
      this.transactionRestrict.emit(true);
    } else {
      this.transactionRestrict.emit(false);
    }
  }

  calculateDates(option: string): void {
    const endDate = new Date(); // Today's date
    const startDate = new Date();

    const options = SUBSEQUENT_TRANSACTION_OPTIONS;
    switch (option) {
      case options.PREMIUM_PREVIOUS_YEAR:
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      case options.PREMIUM_PREVIOUS_SIX_MONTHS:
        startDate.setMonth(startDate.getMonth() - 6);
        break;
      case options.PREMIUM_PREVIOUS_TWO_MONTHS:
        startDate.setMonth(startDate.getMonth() - 2);
        break;
      case options.MONTH_ONLY:
        startDate.setMonth(startDate.getMonth() - 1);
        startDate.setDate(1);
        break;
      default:
        return;
    }

    // Format dates to 'yyyy-MM-DD'
    const formattedStartDate = formatDate(startDate, 'yyyy-MM-dd', 'en-US');
    const formattedEndDate = formatDate(endDate, 'yyyy-MM-dd', 'en-US');
    this.calculatedDates = { startDate: formattedStartDate, endDate: formattedEndDate };
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }

  onSearch(): void {
    this.isSearchBtnClicked = !(
      this.signingForm.controls?.transactionRestrict?.value && this.signingForm.controls?.signingNumber?.value
    )
      ? true
      : false;
    this.setRequiredForAllControls();
    this.searchInitiated.emit();
  }

  // Reset All Controls
  resetAllControls(): void {
    // signingNumber
    if (this.isSigningSelected === this.signingOption.LLOYDS) {
      this.signingForm?.controls?.signingNumber.setValidators([...isString(0, 15)] as ValidatorFn | ValidatorFn[]);
    } else {
      this.signingForm?.controls?.signingNumber.setValidators([...isString(0, 15)] as ValidatorFn | ValidatorFn[]);
    }
    this.signingForm?.controls?.signingNumber.updateValueAndValidity();
  }

  // Set Required For All Controls When Click On Search Btn
  setRequiredForAllControls(): void {
    // signingNumber and  signingDate
    if (this.isSigningSelected === this.signingOption.LLOYDS) {
      this.signingForm?.controls?.signingNumber.setValidators([
        this.isSearchBtnClicked && Validators.required,
        ...isString(0, 15),
      ] as ValidatorFn | ValidatorFn[]);
    } else {
      this.signingForm?.controls?.signingNumber.setValidators([
        this.isSearchBtnClicked && Validators.required,
        ...isString(0, 15),
      ] as ValidatorFn | ValidatorFn[]);
    }

    // transactionRestrict
    this.signingForm?.controls?.transactionRestrict.setValidators(this.isSearchBtnClicked && Validators.required);
    this.signingForm.updateValueAndValidity();
  }

  // Remove Required Validation
  removeRequiredForAllControls(): void {
    // signingNumber
    this.signingForm?.controls?.signingNumber.clearValidators();
    this.signingForm?.controls?.signingNumber.updateValueAndValidity();

    // transactionRestrict
    this.signingForm?.controls?.transactionRestrict.clearValidators();
    this.signingForm?.controls?.transactionRestrict.updateValueAndValidity();
  }
  formatSelects(refData: any): void {
    this.originalCurrencyOptions = formatOption('isoCurrency', 'code', 'code', refData, true);
  }
}
