import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { SigningComponent } from './signing.component';
import { DatePipe } from '@angular/common';
import { EnquiryService } from '@features/enquiry/services/enquiry.service';
import { provideMockStore } from '@ngrx/store/testing';
import { SIGNING_OPTIONS } from '@features/enquiry/const/enquiry.const';
import { CreateSigningNumAndDatePayload } from '@features/enquiry/const/payloads.const';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';

describe('SigningComponent', () => {
  let component: SigningComponent;
  let fixture: ComponentFixture<SigningComponent>;
  let enquiryService: EnquiryService;
  let referenceDataStoreService: ReferenceDataStoreService;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SigningComponent],
      imports: [TranslateModule.forRoot()],
      providers: [
        ReferenceDataStoreService,
        DatePipe,
        EnquiryService,
        provideMockStore(),
        provideMockStore({
          initialState: {
            referenceData: {
              transactionType: 'transactionType',
              vatApplicationMethodCode: 'vatApplicationMethodCode',
            },
          },
        }),
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SigningComponent);
    component = fixture.componentInstance;
    referenceDataStoreService = TestBed.inject(ReferenceDataStoreService);
    enquiryService = TestBed.inject(EnquiryService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the correct reference', () => {
    spyOn(component, 'resetDates').and.callFake(() => {});
    component.setWorkPackageReference('test');
    expect(component.isSelected).toBe('test');
  });

  it('should update signing start date and signing end date validation status', () => {
    component.isSearchBtnClicked = true;

    // Mock form dependencies
    component.signingDateRange = {
      startDate: { formatDate: () => '2024-01-01', resetDateForm: () => {} },
      endDate: { formatDate: () => '2024-01-10', resetDateForm: () => {} },
    } as any;

    component.signingFormComponentView = {
      signingForm: {
        controls: {
          originalCurrency: { value: 'USD' },
          signingNumber: { value: '12345', setValidators: () => {}, updateValueAndValidity: () => {} },
        },
      },
    } as any;

    spyOn(component.isStartDateFormRequired$, 'next');
    spyOn(component.isEndDateFormRequired$, 'next');

    component.onSearch();

    expect(component.isStartDateFormRequired$.next).toHaveBeenCalledWith(true);
    expect(component.isEndDateFormRequired$.next).toHaveBeenCalledWith(true);
  });

  it('should call resetDate on setWorkPackageReference', () => {
    const resetDatesSpy = spyOn(component, 'resetDates');
    component.setWorkPackageReference('test');
    expect(resetDatesSpy).toHaveBeenCalled();
  });

  it('should call resetDateForm on startDate, endDate and calculatedDates on resetDates', () => {
    component.signingDateRange = {
      startDate: { resetDateForm: jasmine.createSpy('resetDateForm') },
      endDate: { resetDateForm: jasmine.createSpy('resetDateForm') },
    } as any;
    component.signingFormComponentView = {
      calculatedDates: '2022-02-01',
    } as any;
    component.resetDates();

    expect(component.signingFormComponentView.calculatedDates).toEqual(null);
    expect(component.signingDateRange.startDate.resetDateForm).toHaveBeenCalled();
    expect(component.signingDateRange.endDate.resetDateForm).toHaveBeenCalled();
  });

  it('should call submit method on onSearch if the form is valid', () => {
    // Spy on methods and set their behavior
    spyOn(component, 'showSigningDates').and.returnValue(false);
    spyOn<any>(component, 'checkFormViewInvalidity').and.returnValue(true);
    const submitSpy = spyOn(component, 'submit');

    component.AdvanceSearch = {
      signingDateRange: { startDate: { formatDate: () => '2023-01-01' }, endDate: { formatDate: () => '2023-01-31' } },
    } as any;

    // Call onSearch without argument
    component.onSearch();
    expect(component.AdvanceSearch.hideAdvancedSearch).toBeTrue();
    expect(submitSpy).toHaveBeenCalledWith(true); // Because `isCalculatedDates` gets set to `true`
  });

  // it('should getSigningNumberValue return the value of the signing number if the selected option is company', () => {
  //   const singingNumber = '1234';
  //   component.signingFormComponentView = {
  //     signingForm: { controls: { signingNumber: { value: singingNumber } } },
  //   } as any;
  //   component.isSelected = SIGNING_OPTIONS.COMPANY;
  //   const expectedValue = component.getSigningNumberValue();
  //   expect(expectedValue).toEqual(singingNumber);
  // });

  it('should getSigningNumberValue return combined signing number and date if the selected option is lloyds', () => {
    const singingNumber = '202202011234';
    const date = '2022-02-01';
    component.signingFormComponentView = {
      signingForm: { controls: { signingNumber: { value: singingNumber } } },
      signingDate: { formatDate: () => {} },
    } as any;
    component.isSelected = SIGNING_OPTIONS.LLOYDS;

    const expectedValue = component.getSigningNumberValue();
    expect(expectedValue).toEqual('202202011234');
  });

  it('should call getSearchPremiumEnquiry with calculated dates when isCalculatedDates is true', () => {
    const singingNumber = '1234';
    const startDate = '2024-04-01';
    const endDate = '2024-04-10';
    const originalCurrency = '';
    const settlementCurrency = '';
    component.signingFormComponentView = {
      calculatedDates: {
        startDate,
        endDate,
      },
    } as any;

    component.isSelected = SIGNING_OPTIONS.COMPANY;
    component.isInProgress = true;

    spyOn(component, 'getSigningNumberValue').and.returnValue(singingNumber);
    spyOn(enquiryService, 'getSearchPremiumEnquiry');

    component.submit(true);

    const payload = CreateSigningNumAndDatePayload(
      singingNumber,
      originalCurrency,
      settlementCurrency,
      startDate,
      endDate,
      true
    );
    expect(enquiryService.getSearchPremiumEnquiry).toHaveBeenCalledWith(payload);
  });

  xit('should call getSearchPremiumEnquiry with formatted dates when isCalculatedDates is false', () => {
    const singingNumber = '1234';
    const startDate = '2024-04-01';
    const endDate = '2024-04-10';
    const originalCurrency = '';
    const settlementCurrency = '';
    component.signingDateRange = {
      startDate: { formatDate: () => startDate },
      endDate: { formatDate: () => endDate },
    } as any;

    component.isInProgress = true;

    spyOn(component, 'getSigningNumberValue').and.returnValue(singingNumber);
    spyOn(enquiryService, 'getSearchPremiumEnquiry');

    component.submit(false);

    const payload = CreateSigningNumAndDatePayload(
      singingNumber,
      originalCurrency,
      settlementCurrency,
      startDate,
      endDate,
      true
    );
    expect(enquiryService.getSearchPremiumEnquiry).toHaveBeenCalledWith(payload);
  });

  // it('should reset the signing dates on inProgressChanged', () => {
  //   const resetDatesSpy = spyOn(component, 'resetDates');
  //   component.inProgressChanged(true);
  //   expect(resetDatesSpy).toHaveBeenCalled();
  // });

  it('should remove required from the signing dates if in progress is checked', () => {
    spyOn(component, 'resetDates').and.callFake(() => {});
    spyOn(component, 'removeRequiredFromDates');
    component.inProgressChanged(true);
    expect(component.removeRequiredFromDates).toHaveBeenCalled();
  });

  xdescribe('removeRequiredFromDates', () => {
    it('should set isStartDateFormRequired$ to false', () => {
      component.removeRequiredFromDates();
      component.isStartDateFormRequired$.subscribe((value) => {
        expect(value).toBeFalse();
      });
    });

    it('should set isEndDateFormRequired$ to false', () => {
      component.removeRequiredFromDates();
      component.isEndDateFormRequired$.subscribe((value) => {
        expect(value).toBeFalse();
      });
    });
  });
  it('should call getSearchPremiumEnquiry with calculated dates when isCalculatedDates is true', () => {
    // Arrange
    const signingNumber = '1234';
    const startDate = '2024-04-01';
    const endDate = '2024-04-10';
    const originalCurrency = 'USD';
    const settlementCurrency = 'EUR';

    component.signingFormComponentView = {
      calculatedDates: {
        startDate,
        endDate,
      },
      signingForm: {
        controls: {
          originalCurrency: { value: originalCurrency },
        },
      },
    } as any;

    component.AdvanceSearch = {
      formGroup: {
        controls: {
          settlementCurrency: { value: settlementCurrency },
        },
      },
    } as any;

    component.isInProgress = true;

    spyOn(component, 'getSigningNumberValue').and.returnValue(signingNumber);
    spyOn(enquiryService, 'getSearchPremiumEnquiry');

    component.submit(true);

    const expectedPayload = CreateSigningNumAndDatePayload(
      signingNumber,
      originalCurrency,
      settlementCurrency,
      startDate,
      endDate,
      true
    );
    expect(enquiryService.getSearchPremiumEnquiry).toHaveBeenCalledWith(expectedPayload);
  });
  xit('should call getSearchPremiumEnquiry with formatted dates when isCalculatedDates is false', () => {
    // Arrange
    const signingNumber = '5678';
    const startDate = '2024-05-01';
    const endDate = '2024-05-15';
    const originalCurrency = 'GBP';
    const settlementCurrency = 'INR';

    component.signingDateRange = {
      startDate: { formatDate: () => startDate },
      endDate: { formatDate: () => endDate },
    } as any;

    component.signingFormComponentView = {
      signingForm: {
        controls: {
          originalCurrency: { value: originalCurrency },
        },
      },
    } as any;

    component.AdvanceSearch = {
      formGroup: {
        controls: {
          settlementCurrency: { value: settlementCurrency },
        },
      },
    } as any;

    component.isInProgress = false;

    spyOn(component, 'getSigningNumberValue').and.returnValue(signingNumber);
    spyOn(enquiryService, 'getSearchPremiumEnquiry');

    component.submit(false);

    const expectedPayload = CreateSigningNumAndDatePayload(
      signingNumber,
      originalCurrency,
      settlementCurrency,
      startDate,
      endDate,
      false
    );
    expect(enquiryService.getSearchPremiumEnquiry).toHaveBeenCalledWith(expectedPayload);
  });
});
