import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { SIGNING_OPTIONS, SUBSEQUENT_TRANSACTION_OPTIONS } from '@features/enquiry/const/enquiry.const';
import { SigningFormComponent } from '../signing/signing-form/signing-form.component';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { DateRangeComponent } from '@shared/components/date-range/date-range.component';
import { Validators, ValidatorFn } from '@angular/forms';
import { formatOption, isString } from 'src/app/utils/helper/helper';
import { CreateSigningNumAndDatePayload } from '@features/enquiry/const/payloads.const';
import { EnquiryService } from '@features/enquiry/services/enquiry.service';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { FieldConfig } from '@shared/consts/shared.consts';
import { Option } from '@dxc-technology/halstack-angular';
import { AdvanceSearchComponent } from '@shared/components/advance-search/advance-search.component';
@Component({
  selector: 'app-signing',
  templateUrl: './signing.component.html',
  styleUrls: ['./signing.component.scss'],
})
export class SigningComponent implements OnInit {
  readonly signingOption = SIGNING_OPTIONS;
  readonly subsequentTransaction: string = SUBSEQUENT_TRANSACTION_OPTIONS.RANGE;
  isSearchBtnClicked = false;
  isStartDateFormRequired$: Subject<boolean> = new Subject();
  isEndDateFormRequired$: Subject<boolean> = new Subject();
  isSelected: string;
  searchEnquiryStatus$ = new Subject<boolean>();
  isCheckSigningForm: boolean;
  isInProgress = false;

  @Input() hideInProgressIndicator: boolean;
  @Output() selectedEnquiryOption = new EventEmitter<string>();
  @Output() inProgress = new EventEmitter<boolean>();

  @ViewChild(SigningFormComponent) signingFormComponentView: SigningFormComponent;
  signingDateRange: DateRangeComponent;
  @ViewChild('advanceSearch') AdvanceSearch: AdvanceSearchComponent;

  referenceData$: Observable<{}>;
  fieldConfig: FieldConfig[] = [];
  private fieldConfigSubject = new BehaviorSubject<FieldConfig[]>([]);
  fieldConfig$: Observable<FieldConfig[]> = this.fieldConfigSubject.asObservable();
  isoSettlementCurrencyOptions: Option[] = [];
  constructor(private referenceDataStoreService: ReferenceDataStoreService, private enquiryService: EnquiryService) {
    this.isSelected = this.signingOption.LLOYDS;
  }
  ngOnInit(): void {
    this.referenceData$ = this.referenceDataStoreService.selectPremiumDetails();
    this.referenceData$.subscribe((refdata) => {
      this.formatSelects(refdata);
    });

    this.fieldConfig = [
      {
        type: 'select',
        name: 'settlementCurrency',
        label: 'ENQUIRY.SIGNING.SETTLEMENT_CURRENCY',
        value: '',
        options: this.isoSettlementCurrencyOptions,
        placeholder: 'INPUTS.SELECT',
      },
      {
        type: 'custom',
        name: 'dateRange',
        show:
          this.signingFormComponentView?.signingFormControls?.transactionRestrict?.value === this.subsequentTransaction,
        customProps: {
          component: 'date-range',
          disabled: this.isInProgress,
          startDateLabelKey: 'Signing start date',
          endDateLabelKey: 'Signing end date',
          endDateRequired: true,
          startDateRequired: true,
          isStartDateFormRequired$: this.isStartDateFormRequired$,
          isEndDateFormRequired$: this.isEndDateFormRequired$,
        },
      },
    ];

    this.fieldConfigSubject.next(this.fieldConfig);
  }

  setWorkPackageReference(value: any): void {
    this.isSelected = value;
    this.resetDates();
  }

  inProgressChanged(event: boolean): void {
    this.isInProgress = event;
    this.inProgress.next(event);
    if (this.isInProgress) {
      this.removeRequiredFromDates();
    }
    this.resetDates();
    this.fieldConfig[1].customProps.disabled = event;
    this.fieldConfigSubject.next(this.fieldConfig);
  }

  transactionRestrictChanged(event: boolean): void {
    this.fieldConfig[1].show = event;
    this.fieldConfigSubject.next(this.fieldConfig);
  }

  resetDates(): void {
    this.signingFormComponentView.calculatedDates = null;
    this.signingDateRange?.startDate.resetDateForm();
    this.signingDateRange?.endDate.resetDateForm();
  }

  removeRequiredFromDates(): void {
    this.isStartDateFormRequired$.next(false);
    this.isEndDateFormRequired$.next(false);
  }

  showSigningDates(): boolean {
    return (
      this.signingFormComponentView?.signingFormControls?.transactionRestrict?.value === this.subsequentTransaction
    );
  }

  onSearch(isCalculatedDates = false): void {
    isCalculatedDates = this.showSigningDates() ? false : true;
    if (this.AdvanceSearch) {
      this.signingDateRange = this.AdvanceSearch.signingDateRange;
    }
    this.searchEnquiryStatus$.next(this.checkFormViewInvalidity());
    this.isSearchBtnClicked = !(
      this.signingDateRange?.startDate.formatDate() &&
      this.signingDateRange?.endDate.formatDate() &&
      this.checkFormViewInvalidity()
    )
      ? true
      : false;
    this.isStartDateFormRequired$.next(
      !this.signingDateRange?.startDate.formatDate() && this.isSearchBtnClicked && !this.isInProgress
    );
    this.isEndDateFormRequired$.next(
      !this.signingDateRange?.endDate.formatDate() && this.isSearchBtnClicked && !this.isInProgress
    );
    // Check for validations
    if (!this.checkFormViewInvalidity()) {
      this.setRequiredForAllControls();
      return;
    }
    this.AdvanceSearch.hideAdvancedSearch = true;
    this.submit(isCalculatedDates);
  }

  submit(isCalculatedDates: boolean): void {
    const signingStartDate = isCalculatedDates
      ? this.signingFormComponentView.calculatedDates?.startDate
      : this.signingDateRange?.startDate.formatDate();
    const singingEndDate = isCalculatedDates
      ? this.signingFormComponentView.calculatedDates?.endDate
      : this.signingDateRange?.endDate.formatDate();
    const signingNumber = this.getSigningNumberValue();
    const originalCurrency = this.signingFormComponentView?.signingForm?.controls?.originalCurrency.value;
    const settlementCurrency = this.AdvanceSearch?.formGroup?.controls?.settlementCurrency.value;
    const payload = CreateSigningNumAndDatePayload(
      signingNumber,
      originalCurrency,
      settlementCurrency,
      signingStartDate,
      singingEndDate,
      this.isInProgress
    );
    this.enquiryService.getSearchPremiumEnquiry(payload);
  }

  getSigningNumberValue(): string {
    const signingNum = this.signingFormComponentView?.signingForm?.controls?.signingNumber.value;

    return signingNum;
  }

  // Set Required For All Controls When Click On Search Btn
  setRequiredForAllControls(): void {
    if (this.isSelected === this.signingOption.LLOYDS) {
      this.signingFormComponentView?.signingForm?.controls?.signingNumber.setValidators([
        this.isSearchBtnClicked && Validators.required,
        ...isString(0, 15),
      ] as ValidatorFn | ValidatorFn[]);
    } else {
      this.signingFormComponentView?.signingForm?.controls?.signingNumber.setValidators([
        this.isSearchBtnClicked && Validators.required,
        ...isString(0, 15),
      ] as ValidatorFn | ValidatorFn[]);
    }
    this.signingFormComponentView?.signingForm?.controls?.signingNumber.updateValueAndValidity();
  }

  private checkFormViewInvalidity(): boolean {
    // Check signing start and end dates validation
    if (
      this.showSigningDates() &&
      !this.isInProgress &&
      (!this.signingDateRange?.startDate.formatDate() || !this.signingDateRange?.endDate.formatDate())
    ) {
      this.AdvanceSearch.hideAdvancedSearch = false;
      return false;
    }

    if (this.isSelected === this.signingOption.LLOYDS) {
      this.isCheckSigningForm = this.signingFormComponentView?.signingForm?.invalid;
    } else {
      this.isCheckSigningForm = this.signingFormComponentView?.signingForm?.invalid;
    }
    this.AdvanceSearch.hideAdvancedSearch = true;
    return this.isCheckSigningForm === true ? false : true;
  }

  formatSelects(refData: any): void {
    this.isoSettlementCurrencyOptions = formatOption('isoSettlementCurrency', 'code', 'code', refData, true);
  }
}
