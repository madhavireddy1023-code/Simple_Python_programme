import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DebugElement } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { WorkPackageReferenceComponent } from './work-package-reference.component';

describe('WorkPackageReferenceComponent', () => {
  let component: WorkPackageReferenceComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<WorkPackageReferenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WorkPackageReferenceComponent],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkPackageReferenceComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call Workpackage reference and Reference Form on init', () => {
    spyOn(component, 'initWorkPackageReferenceForm');
    component.ngOnInit();
    expect(component.initWorkPackageReferenceForm).toHaveBeenCalled();
  });

  describe('Workpackage reference and Refernce Form controls validation', () => {
    let formControls;

    beforeEach(() => {
      component.initWorkPackageReferenceForm();
      formControls = component.workPackageReferenceForm?.controls;
    });

    it('should workPackageReferenceForm to be invalid when workPackageReference control has whitespaces', () => {
      formControls.workPackageReference.setValue('   ');
      expect(component.workPackageReferenceForm.invalid).toBeTruthy();
      expect(formControls.workPackageReference.hasError('noWhiteSpace'));
    });

    it('should workPackageReferenceForm to be invalid when workPackageReference control has more than 7 character', () => {
      formControls.workPackageReference.setValue('12345678');
      expect(component.workPackageReferenceForm.invalid).toBeTruthy();
      expect(formControls.workPackageReference.hasError('maxLength'));
    });

    it('should workPackageReferenceForm to be invalid when workPackageReference control has less than 5 characters', () => {
      formControls.workPackageReference.setValue('a345');
      expect(component.workPackageReferenceForm.invalid).toBeTruthy();
      expect(formControls.workPackageReference.hasError('minLength'));
    });

    it('should workPackageReferenceForm to be invalid when workPackageReference control has non ascii character', () => {
      formControls.workPackageReference.setValue('«');
      expect(component.workPackageReferenceForm.invalid).toBeTruthy();
      expect(formControls.workPackageReference.hasError('alphanumeric_ascii'));
    });
  });
});
