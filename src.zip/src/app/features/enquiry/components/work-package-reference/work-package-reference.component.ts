import { Component, OnInit, Input } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors } from '@angular/forms';
import { DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { FormControls } from '@shared/models/interfaces';
import { ValidationInputStatus, isPositiveNumbers, isString } from 'src/app/utils/helper/helper';
import { INPUT_TYPES } from '@shared/consts/shared.enums';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-work-package-reference',
  templateUrl: './work-package-reference.component.html',
  styleUrls: ['./work-package-reference.component.scss'],
})
export class WorkPackageReferenceComponent implements OnInit {
  private destroyed$ = new Subject();
  readonly inputTypes = INPUT_TYPES;

  isSearchBtnClicked = false;
  isWorkPackageReferenceSelected: boolean;
  workPackageReferenceForm: FormGroup;

  @Input() set isSearchEnquiry(isSearchEnquiry: Subject<boolean>) {
    isSearchEnquiry?.pipe(takeUntil(this.destroyed$)).subscribe((value) => {
      this.isSearchBtnClicked = !value;
    });
  }

  constructor(private formBuilder: FormBuilder) {}

  // get form controls of workPackageReferenceForm
  get workPackageReferenceControls(): FormControls {
    return this.workPackageReferenceForm?.controls;
  }

  ngOnInit(): void {
    this.initWorkPackageReferenceForm();
  }

  // initiate workPackageReferenceForm
  initWorkPackageReferenceForm(): void {
    this.workPackageReferenceForm = this.formBuilder.group({
      workPackageReference: ['', isString(5, 7)],
    });
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }
}
