import { Component, OnInit, Input } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors } from '@angular/forms';
import { DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { FormControls } from '@shared/models/interfaces';
import { ValidationInputStatus, isPositiveEnquiryInteger, isString } from 'src/app/utils/helper/helper';
import { INPUT_TYPES } from '@shared/consts/shared.enums';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-syndicate',
  templateUrl: './syndicate.component.html',
  styleUrls: ['./syndicate.component.scss'],
})
export class SyndicateComponent implements OnInit {
  private destroyed$ = new Subject();
  readonly inputTypes = INPUT_TYPES;

  syndicateNumberReferenceForm: FormGroup;
  submitted: boolean;
  isSearchBtnClicked: boolean;
  isSyndicateNoReferenceSelected: boolean;

  @Input() set isSearchEnquiry(isSearchEnquiry: Subject<boolean>) {
    isSearchEnquiry?.pipe(takeUntil(this.destroyed$)).subscribe((value) => {
      this.isSearchBtnClicked = !value;
    });
  }

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.initSyndicateNumberReferenceForm();
  }

  // initiate syndicateNumberReferenceForm
  initSyndicateNumberReferenceForm(): void {
    this.syndicateNumberReferenceForm = this.formBuilder.group({
      syndicateCompanyNumber: ['', isString(4, 7)],
      syndicateCompanyReference: ['', isString(0, 13)],
    });
  }

  // get form controls of syndicateNumberReferenceForm
  get syndicateNumberReferenceControls(): FormControls {
    return this.syndicateNumberReferenceForm?.controls;
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }
}
