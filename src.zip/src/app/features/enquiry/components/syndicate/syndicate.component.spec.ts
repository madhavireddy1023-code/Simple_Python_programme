import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SyndicateComponent } from './syndicate.component';
import { DebugElement } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

describe('SyndicateComponent', () => {
  let component: SyndicateComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<SyndicateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SyndicateComponent],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SyndicateComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call Syndicate Number and Refernce Form on init', () => {
    spyOn(component, 'initSyndicateNumberReferenceForm');
    component.ngOnInit();
    expect(component.initSyndicateNumberReferenceForm).toHaveBeenCalled();
  });

  describe('Syndicate Number and Refernce Form controls validation', () => {
    let formControls;

    beforeEach(() => {
      component.initSyndicateNumberReferenceForm();
      formControls = component.syndicateNumberReferenceForm?.controls;
    });

    it('should syndicateNumberReferenceForm to be invalid when syndicateCompanyNumber control has whitespaces', () => {
      formControls.syndicateCompanyNumber.setValue('    ');
      expect(component.syndicateNumberReferenceForm.invalid).toBeTruthy();
      expect(formControls.syndicateCompanyNumber.hasError('noWhiteSpace'));
    });

    it('should syndicateNumberReferenceForm to be invalid when syndicateCompanyNumber control has more than 7 character', () => {
      formControls.syndicateCompanyNumber.setValue('12345678');
      expect(component.syndicateNumberReferenceForm.invalid).toBeTruthy();
      expect(formControls.syndicateCompanyNumber.hasError('maxLength'));
    });

    it('should syndicateNumberReferenceForm to be invalid when syndicateCompanyNumber control has non ascii character', () => {
      formControls.syndicateCompanyNumber.setValue('«');
      expect(component.syndicateNumberReferenceForm.invalid).toBeTruthy();
      expect(formControls.syndicateCompanyNumber.hasError('alphanumeric_ascii'));
    });

    it('should syndicateNumberReferenceForm to be invalid when syndicateCompanyReference control has whitespaces', () => {
      formControls.syndicateCompanyReference.setValue('   ');
      expect(component.syndicateNumberReferenceForm.invalid).toBeTruthy();
      expect(formControls.syndicateCompanyReference.hasError('noWhiteSpace'));
    });

    it('should syndicateNumberReferenceForm to be invalid when syndicateCompanyReference control has more than 13 character', () => {
      formControls.syndicateCompanyReference.setValue('AB1234CD5678V4X');
      expect(component.syndicateNumberReferenceForm.invalid).toBeTruthy();
      expect(formControls.syndicateCompanyReference.hasError('maxLength'));
    });

    it('should syndicateNumberReferenceForm to be invalid when syndicateCompanyReference control has non ascii character', () => {
      formControls.syndicateCompanyReference.setValue('«');
      expect(component.syndicateNumberReferenceForm.invalid).toBeTruthy();
      expect(formControls.syndicateCompanyReference.hasError('alphanumeric_ascii'));
    });
  });
});
