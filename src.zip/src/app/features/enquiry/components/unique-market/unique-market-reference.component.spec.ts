import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

import { UniqueMarketReferenceComponent } from './unique-market-reference.component';

import { DomainAPITechnicianPortalEnquiryService } from 'src/app/api/domain-api-technician-portal-enquiry/domain-api-technician-portal-enquiry.service';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SortPipe } from '@shared/pipes/sort.pipe';

describe('UniqueMarketReferenceComponent', () => {
  let component: UniqueMarketReferenceComponent;
  let fixture: ComponentFixture<UniqueMarketReferenceComponent>;
  let el: DebugElement;

  const domainEnquiryServiceSpy = jasmine.createSpyObj('DomainAPITechnicianPortalEnquiryService', [
    'apiV1GetUMRSectionsGet',
  ]);
  domainEnquiryServiceSpy.apiV1GetUMRSectionsGet.and.returnValue(of([]));

  const referenceDataStoreSpy = jasmine.createSpyObj('ReferenceDataStoreService', ['getRefData', 'selectAll']);
  referenceDataStoreSpy.selectAll.and.returnValue(of([]));

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UniqueMarketReferenceComponent, SortPipe],
      imports: [ReactiveFormsModule, TranslateModule.forRoot(), HttpClientTestingModule],
      providers: [
        MockStore,
        provideMockStore(),
        { provide: DomainAPITechnicianPortalEnquiryService, useValue: domainEnquiryServiceSpy },
        { provide: ReferenceDataStoreService, useValue: referenceDataStoreSpy },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UniqueMarketReferenceComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;

    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should call initForms in ngOnInit', () => {
    const initFormsSpy = spyOn(component, 'initForms').and.callThrough();

    component.ngOnInit();

    expect(initFormsSpy).toHaveBeenCalled();
    expect(component.umrForm).toBeDefined();
    expect(component.advancedSearchForm).toBeDefined();
  });

  describe('Form validations', () => {
    it('umrForm should be invalid if UMR is less than 8 characters', () => {
      const umrControl = component.umrForm.get('umr');
      umrControl?.setValue('1234567');
      expect(umrControl?.invalid).toBeTrue();
    });

    it('umrForm should be invalid if UMR is more than 17 characters', () => {
      const umrControl = component.umrForm.get('umr');
      umrControl?.setValue('A123456789012345678');
      expect(umrControl?.invalid).toBeTrue();
    });

    it('umrForm should be valid with a length between 8 and 17', () => {
      const umrControl = component.umrForm.get('umr');
      umrControl?.setValue('ABCD1234');
      expect(umrControl?.valid).toBeTrue();
    });
  });

  describe('UI interactions', () => {
    it('should toggle advanced search visibility when toggleAdvancedSearch() is called', () => {
      spyOn(component.advancedSearchToggled, 'emit');

      expect(component.isAdvancedSearchVisible).toBeFalse();

      component.toggleAdvancedSearch();
      expect(component.isAdvancedSearchVisible).toBeTrue();
      expect(component.advancedSearchToggled.emit).toHaveBeenCalledWith(true);

      component.toggleAdvancedSearch();
      expect(component.isAdvancedSearchVisible).toBeFalse();
      expect(component.advancedSearchToggled.emit).toHaveBeenCalledWith(false);
    });
  });
});
