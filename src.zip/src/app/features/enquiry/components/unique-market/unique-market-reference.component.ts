import { Component, EventEmitter, HostListener, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors } from '@angular/forms';
import { DxcTextInputComponent, DxcTextareaComponent, Option } from '@dxc-technology/halstack-angular';
import { SectionListRec, SectionListRecs } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { CreateEnquiryUMRPayload } from '@features/enquiry/const/payloads.const';
import { AdvanceSearchComponent } from '@shared/components/advance-search/advance-search.component';
import { DateRangeComponent } from '@shared/components/date-range/date-range.component';
import { FieldConfig } from '@shared/consts/shared.consts';
import { INPUT_TYPES } from '@shared/consts/shared.enums';
import { FormControls } from '@shared/models';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { BehaviorSubject, Subject, of } from 'rxjs';
import { catchError, debounceTime, switchMap, take, takeUntil, tap } from 'rxjs/operators';
import { DomainAPITechnicianPortalEnquiryService } from 'src/app/api/domain-api-technician-portal-enquiry/domain-api-technician-portal-enquiry.service';
import { ValidationInputStatus, formatOption, isString } from 'src/app/utils';

const validationMessages = {
  required: 'UMR is required',
  pattern: 'Invalid UMR format',
};

@Component({
  selector: 'app-unique-market-reference',
  templateUrl: './unique-market-reference.component.html',
  styleUrls: ['./unique-market-reference.component.scss'],
})
export class UniqueMarketReferenceComponent implements OnInit, OnDestroy {
  private destroyed$ = new Subject();
  readonly inputTypes = INPUT_TYPES;

  isBrokerNumberSelected: boolean;
  submitted: boolean;
  umrValue: string;

  @Input() set umr(umrValue: string) {
    if (umrValue) {
      this.umrInput$.next(umrValue);
    }
  }

  @Input() set isSearchEnquiry(isSearchEnquiry: Subject<boolean>) {
    isSearchEnquiry?.pipe(takeUntil(this.destroyed$)).subscribe((value) => {
      this.isSearchBtnClicked = !value;
    });
  }

  @Output() advancedSearchToggled = new EventEmitter<boolean>();
  @Output() handleSearchClick = new EventEmitter<any>();
  @Output() isSmallUMRScreen = new EventEmitter<boolean>();
  @Output() inProgressChange = new EventEmitter<boolean>();

  isSmallScreen = false;
  umrForm: FormGroup;
  advancedSearchForm: FormGroup;
  isSearchBtnClicked = false;
  isInProgress = false;
  isAdvancedSearchVisible = false;
  isSectionDropdownEnabled = false;

  sectionOptions: Option[] = [];

  bureauOptions: Option[] = [
    { label: 'LLOYDS', value: 'LLOYDS' },
    { label: 'ILU', value: 'ILU' },
    { label: 'LIRMA', value: 'LIRMA' },
  ];

  originalCurrencyOptions: Option[] = [];

  isoSettlementCurrencyOptions: Option[] = [];
  fieldConfig: FieldConfig[] = [];
  fieldConfigSubject: BehaviorSubject<any[]>;
  umrInput$ = new BehaviorSubject<string>('');
  isStartDateFormRequired$: Subject<boolean> = new Subject();
  isEndDateFormRequired$: Subject<boolean> = new Subject();
  signingDateRange: DateRangeComponent;
  userPressSearch = false;
  @ViewChild('advanceSearch') AdvanceSearch: AdvanceSearchComponent;

  constructor(
    private formBuilder: FormBuilder,
    private referenceDataStoreService: ReferenceDataStoreService,
    private technicianPortalEnquiryService: DomainAPITechnicianPortalEnquiryService
  ) {}

  @HostListener('window:resize')
  onResize(): void {
    this.checkScreenSize();
  }

  ngOnInit(): void {
    this.initForms();

    this.referenceDataStoreService.getRefData();
    this.referenceDataStoreService
      .selectAll()
      .pipe(take(1))
      .subscribe((data) => {
        const originalCurrencies = formatOption('isoCurrency', 'code', 'code', data) || [];
        // add space in value to fix issue of showing empty option for 'Select' option
        this.originalCurrencyOptions = [{ label: 'Select', value: ' ' }, ...originalCurrencies];

        const settlementCurrencies = formatOption('isoSettlementCurrency', 'code', 'code', data) || [];
        // add space in value to fix issue of showing empty option for 'Select' option
        this.isoSettlementCurrencyOptions = [{ label: 'Select', value: ' ' }, ...settlementCurrencies];
      });

    this.umrInput$
      .pipe(
        debounceTime(300),
        switchMap((umr) =>
          umr
            ? this.technicianPortalEnquiryService.apiV1GetUMRSectionsGet(umr).pipe(
                catchError((error) => {
                  console.error('Error fetching UMR sections:', error);
                  return of([]);
                })
              )
            : of([])
        ),
        takeUntil(this.destroyed$),
        tap((data: SectionListRecs) => {
          this.sectionOptions = [];
          this.umrForm.get('section')?.setValue([]);
          this.isSectionDropdownEnabled = false;

          if (data && data.length > 0) {
            const uniqueSectionsMap = new Map<number, SectionListRec>();

            data.forEach((section: SectionListRec) => {
              if (!uniqueSectionsMap.has(section.sectionNumber)) {
                uniqueSectionsMap.set(section.sectionNumber, section);
              }
            });

            this.sectionOptions = Array.from(uniqueSectionsMap.values())
              .sort((a, b) => a.sectionNumber - b.sectionNumber)
              .map((uniqueSection) => ({
                label: `Section - ${uniqueSection.sectionNumber}`,
                value: uniqueSection.sectionNumber.toString(),
              }));

            this.isSectionDropdownEnabled = this.sectionOptions.length > 0;
          }
        })
      )
      .subscribe();

    this.fieldConfig = [
      {
        type: 'select',
        name: 'settlementCurrency',
        label: 'ENQUIRY.SIGNING.SETTLEMENT_CURRENCY',
        value: '',
        options: this.isoSettlementCurrencyOptions,
        placeholder: 'INPUTS.SELECT',
      },
      {
        type: 'custom',
        name: 'dateRange',
        show: true,
        customProps: {
          component: 'date-range',
          disabled: this.isInProgress,
          startDateLabelKey: 'Signing start date',
          endDateLabelKey: 'Signing end date',
          endDateRequired: true,
          startDateRequired: true,
          isStartDateFormRequired$: this.isStartDateFormRequired$,
          isEndDateFormRequired$: this.isEndDateFormRequired$,
        },
      },
    ];

    this.fieldConfigSubject = new BehaviorSubject(this.fieldConfig);
  }

  initForms(): void {
    this.umrForm = this.formBuilder.group({
      umr: [null, isString(8, 17, true)],
      section: [[]],
      bureau: [[]],
      originalCurrency: [''],
      inProgress: [false],
    });

    this.advancedSearchForm = this.formBuilder.group({
      settlementCurrency: [''],
      signingDateRange: [],
    });
  }

  get umrControls(): FormControls {
    return this.umrForm?.controls;
  }

  onUmrChange(value: any): void {
    if (value?.value) {
      this.umrForm.get('umr')?.setValue(value?.value);
      this.umrInput$.next(value?.value);
    } else {
      this.isSectionDropdownEnabled = false;
      this.sectionOptions = [];
      this.umrForm.get('umr')?.setValue(null);
    }
  }

  onSectionChange(event: any): void {
    if (Array.isArray(event?.value)) {
      this.umrForm.get('section')?.setValue(event.value);
    } else {
      console.warn('Invalid section data:', event?.value);
      this.umrForm.get('section')?.setValue([]);
    }
  }

  onBureauChange(event: any): void {
    const selectedBureaus = event?.value ?? [];
    this.umrForm.get('bureau')?.setValue(selectedBureaus);
  }

  onOriginalCurrencyChange(event: any): void {
    this.umrForm.get('originalCurrency')?.setValue(event.value);
  }

  onSettlementCurrencyChange(event: any): void {
    this.advancedSearchForm.get('settlementCurrency')?.setValue(event.value);
  }

  onDateRangeChange(value: any): void {
    this.advancedSearchForm.get('signingDateRange')?.setValue(value);
  }

  inProgressChanged(event: boolean): void {
    this.isInProgress = event;
    this.inProgressChange.emit(this.isInProgress);

    this.umrForm.get('inProgress')?.setValue(event);

    if (this.isInProgress) {
      this.isStartDateFormRequired$.next(false);
      this.isEndDateFormRequired$.next(false);
    }

    this.AdvanceSearch?.reset();

    this.resetDates();

    this.fieldConfig[1].customProps.disabled = event;
    this.fieldConfigSubject.next(this.fieldConfig);
  }

  resetDates(): void {
    this.signingDateRange?.startDate.resetDateForm();
    this.signingDateRange?.endDate.resetDateForm();
  }

  toggleAdvancedSearch(): void {
    this.isAdvancedSearchVisible = !this.isAdvancedSearchVisible;
    this.advancedSearchToggled.emit(this.isAdvancedSearchVisible);
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.userPressSearch, formControl, input);
  }

  onSearch(): void {
    this.userPressSearch = true;

    if (this.AdvanceSearch) {
      const signingDateRange = this.AdvanceSearch.signingDateRange;
      const settlementCurrencyValue = this.AdvanceSearch?.formGroup?.controls?.settlementCurrency.value;

      const settlementCurrencyControl = this.advancedSearchForm.get('settlementCurrency');
      if (settlementCurrencyControl) {
        settlementCurrencyControl.setValue(settlementCurrencyValue);
      }

      const signingDateRangeControl = this.advancedSearchForm.get('signingDateRange');
      if (signingDateRange) {
        signingDateRangeControl.setValue(signingDateRange);
      }
    }

    if (this.umrForm.invalid || this.advancedSearchForm.invalid) {
      if (this.advancedSearchForm.invalid) {
        this.AdvanceSearch.hideAdvancedSearch = false;
      }
      return;
    }

    const dates = this.advancedSearchForm.get('signingDateRange')?.value || null;
    const settlementCurrency = this.advancedSearchForm.get('settlementCurrency')?.value || null;
    const { startDateValue = null, endDateValue = null } = dates;

    const payload = CreateEnquiryUMRPayload(
      {
        ...this.umrForm.value,
        section: this.umrForm?.value?.section || undefined,
        bureau: this.umrForm?.value?.bureau || undefined,
        originalCurrency: this.umrForm?.value?.originalCurrency || undefined,
      },
      this.isInProgress,
      startDateValue,
      endDateValue,
      settlementCurrency
    );

    this.AdvanceSearch.hideAdvancedSearch = true;
    this.handleSearchClick.emit(payload);
  }

  getErrorMessage(errors: ValidationErrors): string {
    const errorKey = Object.keys(errors)[0];
    return validationMessages[errorKey] || 'Invalid input';
  }

  private checkScreenSize(): void {
    const isSmall = window.innerWidth <= 1200;
    this.isSmallScreen = isSmall;
    this.isSmallUMRScreen.emit(isSmall);
  }

  ngOnDestroy(): void {
    this.isSmallUMRScreen.emit(false);
  }
}
