import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { FormControls } from '@shared/models/interfaces';
import { ValidationInputStatus, isPositiveEnquiryInteger } from 'src/app/utils/helper/helper';

@Component({
  selector: 'app-facility-search',
  templateUrl: './facility-search.component.html',
  styleUrls: ['./facility-search.component.scss'],
})
export class FacilitySearchComponent implements OnInit {
  private destroyed$ = new Subject();
  isSearchBtnClicked = false;
  facilityForm: FormGroup;
  @Input() set isSearchEnquiry(isSearchEnquiry: Subject<boolean>) {
    isSearchEnquiry?.pipe(takeUntil(this.destroyed$)).subscribe((value) => {
      this.isSearchBtnClicked = !value;
    });
  }
  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.initFacilityForm();
  }
  initFacilityForm(): void {
    this.facilityForm = this.formBuilder.group({
      YOANumberDate: ['', isPositiveEnquiryInteger(13, 13, true)],
    });
  }
  // get form controls of Facility form
  get facilityFormControls(): FormControls {
    return this.facilityForm?.controls;
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }
}
