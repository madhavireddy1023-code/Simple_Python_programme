import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilitySearchComponent } from './facility-search.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { DebugElement } from '@angular/core';

describe('FacilitySearchComponent', () => {
  let component: FacilitySearchComponent;
  let fixture: ComponentFixture<FacilitySearchComponent>;
  let el: DebugElement;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FacilitySearchComponent],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilitySearchComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call Facility  Form on init', () => {
    spyOn(component, 'initFacilityForm');
    component.ngOnInit();
    expect(component.initFacilityForm).toHaveBeenCalled();
  });
  it('should initialize the form with YOANumberDate control', () => {
    // Call the method
    component.initFacilityForm();

    // Verify the form structure
    expect(component.facilityForm).toBeDefined();
    expect(component.facilityForm.contains('YOANumberDate')).toBeTrue();

    // Verify the control's initial value
    const control = component.facilityForm.get('YOANumberDate');
    expect(control?.value).toBe('');
    expect(control?.valid).toBeFalse(); // Initially invalid if the validator requires specific input
  });

  it('should validate YOANumberDate with custom validator', () => {
    component.initFacilityForm();
    const control = component.facilityForm.get('YOANumberDate');

    // Invalid input
    control?.setValue('invalid123');
    expect(control?.valid).toBeFalse();

    // Valid input
    control?.setValue('1234567890123'); // Assuming valid input for the validator
    expect(control?.valid).toBeTrue();
  });
});
