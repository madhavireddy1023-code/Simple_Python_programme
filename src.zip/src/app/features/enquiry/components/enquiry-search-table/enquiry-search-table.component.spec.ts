import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';

import { EnquirySearchTableComponent } from './enquiry-search-table.component';
import { CorrectionStoreService } from '@features/corrections/services/corrections.store.service';
import { Params, Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { TransactionStatusValues } from '@features/enquiry/const/enquiry.const';
import { APP_BASE_HREF } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import {
  HEADER_NAIC_REPORTING_URL,
  HEADER_SURPLUS_LINES_URL,
  SUMMARY_URL,
  typeOfPremium,
} from '@shared/consts/shared.consts';
import { NAIC_SURPLUS_REPORTING_TYPE } from '@features/section-details/consts/premium-details.consts';
import {
  NaicSlReportingStatus,
  PremiumEnquiryRecord,
  TypeOfPremium,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Role } from '@shared/consts/shared.enums';
import { mockPremiumEnquiryRecord } from '@features/enquiry/const/mock-premium-enquiry-data.conts';
import { DefInstalmentService } from '@features/enquiry/services/def-instalment.service';
import { of } from 'rxjs';

describe('EnquirySearchTableComponent', () => {
  let component: EnquirySearchTableComponent;
  let fixture: ComponentFixture<EnquirySearchTableComponent>;
  let router: Router;
  let el: DebugElement;
  const defInstalmentServiceSpy = jasmine.createSpyObj('DefInstalmentService', ['getPremiumDetails']);

  beforeEach(async () => {
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      declarations: [EnquirySearchTableComponent],
      imports: [TranslateModule.forRoot(), RouterModule.forRoot([]), RouterTestingModule.withRoutes([])],
      providers: [
        MockStore,
        provideMockStore(),
        CorrectionStoreService,
        InfoHeaderStoreService,
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: DefInstalmentService, useValue: defInstalmentServiceSpy },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>; // Inject the Router spy here
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnquirySearchTableComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset checked rows', () => {
    component.isChecked = true;
    component.checkedRows = [1, 2];

    component.initTable();
    expect(component.isChecked).toBeFalsy();
    expect(component.checkedRows.length).toBe(0);
  });

  it('should render section details in the Enquiry data ', waitForAsync(() => {
    const accordionClickedSpy = spyOn(component, 'expandToggler').and.callThrough();
    const dataTableSpay = [
      {
        id: 1,
        umr: 'B1234ABC001',
        wpr: 'XYZWRS',
        Section: 'SECTN 01',
        csnd: '56789*2020/10/01',
        bsnd: '21345*2020/10/01',
        Transaction_Type: 'PM',
        Delinked_Release: 'Yes',
        Risk_code: 'P6',
        Policy_period_from_date: '01/01/2020',
        Payment_means: 'Delinked',
        Transaction_status: 'New',
        isExpanded: true,
        dataExpandedRow: {
          Broker_code: 'B1234',
          Original_currency: 'GBP',
          yoa: '2020',
          Policyholder: 'Description',
          Sett: 'USD',
          Narrative: 'Lorem',
          Period_from: '20 May 2022',
          Period_to: '20 May 2022',
        },
        checkboxChecked: true,
      },
      {
        id: 2,
        umr: 'B1234ABC001',
        wpr: 'XYZWRS',
        Section: 'SECTN 01',
        csnd: '56789*2020/10/01',
        bsnd: '21345*2020/10/01',
        Transaction_Type: 'PM',
        Delinked_Release: 'Yes',
        Risk_code: 'P6',
        Policy_period_from_date: '01/01/2020',
        Payment_means: 'Delinked',
        Transaction_status: 'New',
        isExpanded: false,
        dataExpandedRow: {
          Broker_code: 'B1234',
          Original_currency: 'GBP',
          yoa: '2020',
          Policyholder: 'Description',
          Sett: 'USD',
          Narrative: 'Lorem',
          Period_from: '20 May 2022',
          Period_to: '20 May 2022',
        },
        checkboxChecked: true,
      },
    ];
    component.paginatedTableData = dataTableSpay;
    fixture.detectChanges();
    component.expandToggler(dataTableSpay[0]);
    expect(component.paginatedTableData).toEqual(dataTableSpay);
    expect(accordionClickedSpy).toHaveBeenCalled();
  }));

  it('should return "green-color" for status "NEW"', () => {
    const status = TransactionStatusValues.NEW;
    const expected = 'green-color';
    const actual = component.getStatusClass(status);
    expect(actual).toEqual(expected);
  });

  it('should return "orange-color" for status "REP"', () => {
    const status = TransactionStatusValues.REP;
    const expected = 'orange-color';
    const actual = component.getStatusClass(status);
    expect(actual).toEqual(expected);
  });

  it('should return "red-color" for status "CAN"', () => {
    const status = TransactionStatusValues.CAN;
    const expected = 'red-color';
    const actual = component.getStatusClass(status);
    expect(actual).toEqual(expected);
  });

  it('should return "" for any other status', () => {
    const status = 'UNKNOWN';
    const expected = '';
    const actual = component.getStatusClass(status);
    expect(actual).toEqual(expected);
  });
  it('should return the correct key', () => {
    const result = component.getTypeOfPremiumKey(typeOfPremium, 'Premium');
    expect(result).toEqual(typeOfPremium[0].key);

    // Add similar expectations for other cases
  });

  describe('Copy Premium', () => {
    const premium = {
      path: 'premium-path',
      params: { premiumParam1: 'test param' },
    };

    it('should set isfromPremuim when premium nav details are provided', () => {
      component.premiumNavigation = premium;
      expect(component.isfromPremuim).toBe(true);
      expect(component.premiumPath).toBe('premium-path');
      expect(component.premiumParams).toEqual({ premiumParam1: 'test param' });
    });

    it('should navigate back to premium with premium copy id', () => {
      spyOn(router, 'navigate');

      component.premiumNavigation = premium;
      component.isfromPremuim = true;
      component.checkedRows = [
        {
          premiumId: 'copyId',
          transactionType: {
            typeOfTransactionType: 'Premium',
          },
        },
      ];
      component.backToPremuim();

      expect(router.navigate).toHaveBeenCalledWith([`/section-details/premium-path`], {
        queryParams: {
          premiumParam1: 'test param',
          copyPremiumId: 'copyId',
          copyTransactionType: 'Original_Premium',
        },
      });
    });

    it('should store and remove premium navigation data', () => {
      spyOn(sessionStorage, 'setItem').and.callFake((key, value) => {});
      spyOn(sessionStorage, 'removeItem');

      component.premiumNavigation = { testNavigation: 'testValue' };
      component.isfromPremuim = true;
      expect(sessionStorage.setItem).toHaveBeenCalledWith('premiumNavigation', '{"testNavigation":"testValue"}');

      component.checkedRows = [
        {
          premiumId: 'copyId',
          transactionType: {
            typeOfTransactionType: 'Premium',
          },
        },
      ];
      spyOn(router, 'navigate').and.callFake((path) => null);
      component.backToPremuim();
      expect(sessionStorage.removeItem).toHaveBeenCalledWith('premiumNavigation');
    });

    it('should returns correct warning message', () => {
      component.checkedRows = [
        {
          premiumId: 'copyId1',
          transactionType: {
            typeOfTransactionType: 'Premium',
          },
        },
        {
          premiumId: 'copyId2',
          transactionType: {
            typeOfTransactionType: 'Premium',
          },
        },
      ];

      expect(component.getCopyWarningMessage()).toBe('CORRECTIONS.COPY_PREMIUM.ONE_RECORD_WARNING');

      component.checkedRows.shift();
      component.premiumPath = 'Additional_Premium';
      expect(component.getCopyWarningMessage()).toBe('CORRECTIONS.COPY_PREMIUM.TYPE_MISMATCH_WARNING');

      component.premiumPath = 'Original_Premium';
      expect(component.getCopyWarningMessage()).toBeFalsy();
    });

    it('should show warning for more than one selected', () => {
      component.isfromPremuim = true;
      component.premiumPath = 'Original_Premium';
      component.checkedRows = [
        {
          premiumId: 'copyId1',
          transactionType: {
            typeOfTransactionType: 'Premium',
          },
        },
      ];
      fixture.detectChanges();

      expect(el.query(By.css('.alert-container'))).toBeFalsy();

      component.checkedRows.push({
        premiumId: 'copyId2',
        transactionType: {
          typeOfTransactionType: 'Premium',
        },
      });
      fixture.detectChanges();
      expect(el.query(By.css('.alert-container'))).toBeTruthy();
    });

    it('should enable copy button', () => {
      expect(el.query(By.css('#copyPremium')).nativeElement.disabled).toBeTruthy();

      component.isfromPremuim = true;
      component.premiumPath = 'Original_Premium';
      component.isChecked = true;
      component.checkedRows = [
        {
          premiumId: 'copyId',
          transactionType: {
            typeOfTransactionType: 'Premium',
          },
        },
      ];
      fixture.detectChanges();

      expect(el.query(By.css('#copyPremium')).nativeElement.disabled).toBeFalsy();
    });
  });

  it('should not set callback when queryParams are not set', () => {
    const queryParams: Params = null;

    component.queryParams = queryParams;

    expect(component.callback).toBeUndefined();
  });

  describe('isNAICLinkAvailable function', () => {
    it('should show naic btn if naicInfoStatus not COMPLETE and bureau is LLOYDS and matching value true', () => {
      const record = { ...mockPremiumEnquiryRecord, naicInfoStatus: NaicSlReportingStatus.INCOMPLETE };
      component.isNAICLinkAvailable(record);
      expect(component.isNAICLinkAvailable(record)).toEqual(true);
    });

    it('should not show naic btn if naicInfoStatus is COMPLETE and bureau is LLOYDS and matching value false', () => {
      const record = {
        ...mockPremiumEnquiryRecord,
        filCode1: { ...mockPremiumEnquiryRecord.filCode1, typeOfFilCode: 'USL1' },
        filCode2: { ...mockPremiumEnquiryRecord.filCode2, typeOfFilCode: 'USL1' },
      };
      component.isNAICLinkAvailable(record);
      expect(component.isNAICLinkAvailable(record)).toEqual(false);
    });

    it('should show surplus btn if usSurplusInfoStatus is not COMPLETE and bureau is LLOYDS and matching value true', () => {
      const record = { ...mockPremiumEnquiryRecord, usSurplusInfoStatus: NaicSlReportingStatus.INCOMPLETE };
      component.isSurplusLinkAvailable(record);
      expect(component.isSurplusLinkAvailable(record)).toEqual(true);
    });

    it('should not show surplus btn if usSurplusInfoStatus is COMPLETE and bureau is LLOYDS and matching value false', () => {
      const record = {
        ...mockPremiumEnquiryRecord,
        filCode1: { ...mockPremiumEnquiryRecord.filCode1, typeOfFilCode: 'USE2' },
      };
      component.isSurplusLinkAvailable(record);
      expect(component.isSurplusLinkAvailable(record)).toEqual(false);
    });

    it('should navigate to HEADER_NAIC_REPORTING_URL with queryParams', () => {
      spyOn(router, 'navigate');
      const mockRow = {
        premiumId: 'aecd-1234-shg45-348hssfz',
        transactionType: { typeOfTransactionType: 'Premium FDO' },
        submissionStatus: 'Signed',
        submissionId: '1',
      };

      component.onNaicOrSurplusClick(mockRow, NAIC_SURPLUS_REPORTING_TYPE.NAIC);
      const expectedQueryParams = {
        premiumId: 'aecd-1234-shg45-348hssfz',
        transactionType: 'Original_Premium',
        transactionStatus: true,
        submissionId: '1',
      };
      expect(router.navigate).toHaveBeenCalledWith([HEADER_NAIC_REPORTING_URL], { queryParams: expectedQueryParams });
    });

    it('should navigate to HEADER_SURPLUS_LINES_URL with queryParams', () => {
      spyOn(router, 'navigate');
      const mockRow = {
        premiumId: 'aecd-1234-shg45-348hssfz',
        transactionType: { typeOfTransactionType: 'Premium FDO' },
        submissionStatus: 'Signed',
        submissionId: '1',
      };

      component.onNaicOrSurplusClick(mockRow, NAIC_SURPLUS_REPORTING_TYPE.SURPLUS);
      const expectedQueryParams = {
        premiumId: 'aecd-1234-shg45-348hssfz',
        transactionType: 'Original_Premium',
        transactionStatus: true,
        submissionId: '1',
      };
      expect(router.navigate).toHaveBeenCalledWith([HEADER_SURPLUS_LINES_URL], { queryParams: expectedQueryParams });
    });
  });
  it('should hide warning icon when heritage view role is not included', () => {
    const columns = [
      {
        id: 10,
        key: 'warning',
        label: '',
        value: () => true,
        chip: false,
        icon: 'warning',
      },
      {
        id: 20,
        key: 'info',
        label: '',
        value: () => true,
        chip: false,
        icon: 'info',
      },
    ];

    component.tableColumns = columns;
    component.roles = ['abc'];
    fixture.detectChanges();

    expect(component.tableColumnsValue).toEqual([columns[1]]);
  });
  it('should show warning icon when heritage view role is  included', () => {
    const columns = [
      {
        id: 10,
        key: 'warning',
        label: '',
        value: () => true,
        chip: false,
        icon: 'warning',
      },
    ];

    component.roles = [Role.PROCESS_HERITAGE_VIEW];
    component.tableColumns = columns;
    fixture.detectChanges();
    expect(component.tableColumnsValue).toEqual(columns);
  });

  it('should show warning icon when the submission is heritage and has errors', () => {
    component.roles = [Role.PROCESS_HERITAGE_VIEW];
    component.tableColumns = [
      {
        id: 3,
        key: 'warning',
        label: '',
        value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
          premiumEnquiryRecord.hasErrors === true && premiumEnquiryRecord.isHeritageRecord === true,
        chip: false,
        icon: 'warning',
      },
    ];
    component.dataTable = {
      signings: [{ hasErrors: true, isHeritageRecord: true }],
      recordCount: 1,
      totalCount: 1,
    };
    component.getPaginatedItems({
      paginatedItems: [{ isExpanded: false, hasErrors: true, isHeritageRecord: true }],
    });
    fixture.detectChanges();
    expect(el.query(By.css('#warning'))).toBeTruthy();
  });
  it('should hide warning icon when the submission is not heritage and has errors', () => {
    component.roles = [Role.PROCESS_HERITAGE_VIEW];
    component.tableColumns = [
      {
        id: 3,
        key: 'warning',
        label: '',
        value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
          premiumEnquiryRecord.hasErrors === true && premiumEnquiryRecord.isHeritageRecord === true,
        chip: false,
        icon: 'warning',
      },
    ];
    component.dataTable = {
      signings: [{ hasErrors: true, isHeritageRecord: false }],
      recordCount: 1,
      totalCount: 1,
    };
    component.getPaginatedItems({
      paginatedItems: [{ isExpanded: true, hasErrors: true, isHeritageRecord: false }],
    });
    fixture.detectChanges();
    expect(el.query(By.css('#warning'))).toBeFalsy();
  });
  it('should hide warning icon when the submission is heritage and has no errors', () => {
    component.roles = [Role.PROCESS_HERITAGE_VIEW];
    component.tableColumns = [
      {
        id: 3,
        key: 'warning',
        label: '',
        value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
          premiumEnquiryRecord.hasErrors === true && premiumEnquiryRecord.isHeritageRecord === true,
        chip: false,
        icon: 'warning',
      },
    ];
    component.dataTable = {
      signings: [{ hasErrors: false, isHeritageRecord: true }],
      recordCount: 1,
      totalCount: 1,
    };
    component.getPaginatedItems({
      paginatedItems: [{ isExpanded: true, hasErrors: false, isHeritageRecord: true }],
    });
    fixture.detectChanges();
    expect(el.query(By.css('#warning'))).toBeFalsy();
  });
  it('should hide warning icon when the submission is not heritage and has no errors', () => {
    component.roles = [Role.PROCESS_HERITAGE_VIEW];
    component.tableColumns = [
      {
        id: 3,
        key: 'warning',
        label: '',
        value: (premiumEnquiryRecord: PremiumEnquiryRecord) =>
          premiumEnquiryRecord.hasErrors === true && premiumEnquiryRecord.isHeritageRecord === true,
        chip: false,
        icon: 'warning',
      },
    ];
    component.dataTable = {
      signings: [{ hasErrors: false, isHeritageRecord: false }],
      recordCount: 1,
      totalCount: 1,
    };
    component.getPaginatedItems({
      paginatedItems: [{ isExpanded: true, hasErrors: false, isHeritageRecord: false }],
    });
    fixture.detectChanges();
    expect(el.query(By.css('#warning'))).toBeFalsy();
  });
  it('should return true when PROCESS_HERITAGE_VIEW role is present, hasErrors is true, and isHeritageRecord is true', () => {
    component.roles = [Role.PROCESS_HERITAGE_VIEW];

    const result = component.canResolveErrors(true, true);

    expect(result).toBeTrue();
  });

  it('should return false when PROCESS_HERITAGE_VIEW role is not present, even if hasErrors and isHeritageRecord are true', () => {
    component.roles = [];

    const result = component.canResolveErrors(true, true);

    expect(result).toBeFalse();
  });

  it('should return false when hasErrors is false, even if PROCESS_HERITAGE_VIEW role and isHeritageRecord are true', () => {
    component.roles = [Role.PROCESS_HERITAGE_VIEW];

    const result = component.canResolveErrors(false, true);

    expect(result).toBeFalse();
  });

  it('should return false when isHeritageRecord is false, even if PROCESS_HERITAGE_VIEW role and hasErrors are true', () => {
    component.roles = [Role.PROCESS_HERITAGE_VIEW];

    const result = component.canResolveErrors(true, false);

    expect(result).toBeFalse();
  });

  it('should return false when all parameters are false', () => {
    component.roles = [];

    const result = component.canResolveErrors(false, false);

    expect(result).toBeFalse();
  });
  it('should call window.open with the correct URL when editMode is true', () => {
    const submissionId = '123';
    const submissionCsnd = 'CSND123';
    component.isInProgress = true;
    component.roles = [Role.PROCESS_HERITAGE_EDIT]; // Role that enables editMode

    const expectedQueryParams = {
      enquirySubmissionId: submissionId,
      csnd: submissionCsnd,
      isInProgress: true,
      editMode: true,
    };

    spyOn(window, 'open'); // Spy on window.open
    spyOn(router, 'createUrlTree').and.callFake((path) => null);
    component.editTransaction(submissionId, submissionCsnd);

    expect(router.createUrlTree).toHaveBeenCalledWith([SUMMARY_URL], { queryParams: expectedQueryParams });
    expect(window.open).toHaveBeenCalledWith(undefined, '_blank');
  });
  it('should call window.open with editMode null when the role does not include PROCESS_HERITAGE_EDIT', () => {
    const submissionId = '123';
    const submissionCsnd = 'CSND123';
    component.isInProgress = false;
    component.roles = []; // No roles for editMode

    const expectedQueryParams = {
      enquirySubmissionId: submissionId,
      csnd: submissionCsnd,
      isInProgress: false,
      editMode: null,
    };

    spyOn(window, 'open'); // Spy on window.open
    spyOn(router, 'createUrlTree').and.callFake((path) => null);
    component.editTransaction(submissionId, submissionCsnd);

    expect(router.createUrlTree).toHaveBeenCalledWith([SUMMARY_URL], { queryParams: expectedQueryParams });
    expect(window.open).toHaveBeenCalledWith(undefined, '_blank');
  });

  it('should call getPremiumDetails with correct parameters', () => {
    // Arrange
    component.workPackageRef = 'testRef';
    component.checkedRows = [
      {
        workPackageRef: 'testRef',
        premiumId: 'premium123',
        umr: 'umr123',
        csnd: 'csnd123',
        transactionType: { typeOfTransactionType: 'Premium' },
        submissionId: 'sub123',
      },
    ];

    defInstalmentServiceSpy.getPremiumDetails.and.returnValue();

    // Act
    component.goToDeferred();

    // Assert
    expect(defInstalmentServiceSpy.getPremiumDetails).toHaveBeenCalledWith(
      'testRef',
      'premium123',
      TypeOfPremium.OriginalPremium,
      'umr123',
      'csnd123'
    );
  });
});
