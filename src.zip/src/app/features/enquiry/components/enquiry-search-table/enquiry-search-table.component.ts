import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { Params, Router } from '@angular/router';
import { NewCorrectionSelection, NewCorrectionSelections } from '@dxc.lm.sdk.angular/ipos-premium-corrections-api';
import {
  NaicSlReportingStatus,
  PremiumEnquiryRecord,
  PremiumEnquiryRecords,
  PremiumSource,
  SubmissionStatuses,
  TechnicianPortalBureauEnum,
  TechnicianSVDetails,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { ChannelSubmission } from '@dxc.lm.sdk.angular/premiums-base-workflow-experience-api';
import { CorrectionStoreService } from '@features/corrections/services/corrections.store.service';
import {
  PremiumEnquiryRow,
  TransactionStatusClasses,
  TransactionStatusValues,
} from '@features/enquiry/const/enquiry.const';
import {
  NAIC_REQUIRED_VALUES,
  NAIC_SURPLUS_REPORTING_TYPE,
  SURPLUS_REQUIRED_VALUES,
} from '@features/section-details/consts/premium-details.consts';
import { SummaryStoreService } from '@features/summary/services/summary.store.service';
import { Store } from '@ngrx/store';
import {
  HEADER_NAIC_REPORTING_URL,
  HEADER_SURPLUS_LINES_URL,
  NodeType,
  PREMIUM_URL,
  SUMMARY_URL,
  typeOfPremium,
} from '@shared/consts/shared.consts';
import { Role } from '@shared/consts/shared.enums';
import { PaginationModel, TableColumn } from '@shared/models/interfaces';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { Builder } from 'builder-pattern';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { AppState } from 'src/app/store/app.reducer';
import {
  GetSortIcon,
  MapItem,
  ScrollUp,
  TransactionTypesValues,
  initiateWorkflowInfoHeaderData,
  transctionType,
} from 'src/app/utils/helper/helper';

import { PremiumGetRec } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { DefInstalmentService } from '@features/enquiry/services/def-instalment.service';
import { InstalmentDetailsStoreService } from '@features/instalment-details/services/instalment-details.store.service';
import { SortDirection } from '@features/signing-details/models/signing-details.model';
import { orderBy } from 'lodash';

@Component({
  selector: 'app-enquiry-search-table',
  templateUrl: './enquiry-search-table.component.html',
  styleUrls: ['./enquiry-search-table.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class EnquirySearchTableComponent implements OnInit {
  // change this type after get model
  allTableData: PremiumEnquiryRecord[] = [];
  paginatedTableData: PremiumEnquiryRow[] = [];
  tableColumnsValue: TableColumn[];
  tableExpandRowValue: TableColumn[];
  totalCount: number;
  isChecked = false;
  checkedRows: any[] = [];
  mappedCheckedRow: NewCorrectionSelections = [];
  workPackageRef: string;
  callback: string;
  isfromDeferred: boolean;
  isInProgress: boolean;
  workflowSubmissionId: string;
  isfromPremuim: boolean;
  premiumPath;
  premiumParams;
  isfromCorrection: boolean;
  NAIC_SURPLUS_REPORTING_TYPE = NAIC_SURPLUS_REPORTING_TYPE;
  isSchemeCanada: boolean;
  isAutoRI: boolean;
  selectAll: boolean;
  sortColumn: string;
  sortDirection: SortDirection = SortDirection.ASC;
  umr: string;
  rowCorrectionType: string;
  rolesRef: string[];
  @Output() totalCountAlertShown = new EventEmitter<number>();
  @Output() correctionTypeError = new EventEmitter<boolean>();

  @Input() signingNumber: string;
  @Input() userName: string;
  @Input() isUMRSearchSmallScreen: boolean;
  @Input() tableView: 'standard' | 'modified' = 'standard';
  @Output() updateTableColumns: EventEmitter<'standard' | 'modified'> = new EventEmitter();
  @Input() set roles(roles: string[]) {
    if (roles) {
      this.rolesRef = roles;
      if (!this.rolesRef?.includes(Role.PROCESS_HERITAGE_VIEW)) {
        this.tableColumnsValue = this.tableColumnsValue?.filter((col) => col.key !== 'warning');
      }
    }
  }

  @Input() set isInProgressChanged(isInProgress: boolean) {
    this.isInProgress = isInProgress;
    this.resetSearchResult();
  }

  @Input() set queryParams(queryParams: Params) {
    if (queryParams) {
      this.callback = queryParams?.callback;
      this.isfromDeferred = queryParams?.isfromDeferred;
      this.isfromCorrection = queryParams?.isfromCorrection;
      this.workflowSubmissionId = queryParams?.workflowSubmissionId;
      if (this.workflowSubmissionId && this.isfromCorrection) {
        this.infoHeaderStoreService.setInfoHeaderDetails(null);
        this.summaryStoreService.clearData();
        this.summaryStoreService.getSummaryWorkflowSubmission(this.workflowSubmissionId);
      }
    }

    if (this.userName && this.isfromCorrection && !this.workflowSubmissionId) {
      this.infoHeaderStoreService.getInfoHeaderDetails(this.userName);
    }
  }

  @Input() set premiumNavigation(premium) {
    if (!premium) {
      return;
    }

    sessionStorage.setItem('premiumNavigation', JSON.stringify(premium));

    this.isfromPremuim = true;
    this.premiumPath = premium?.path;
    this.premiumParams = premium.params;
  }

  @Input() set workflowSubmission(workflowSubmissionData: ChannelSubmission) {
    if (workflowSubmissionData) {
      this.infoHeaderStoreService.setInfoHeaderDetails(initiateWorkflowInfoHeaderData(workflowSubmissionData));
    }
  }
  reinstatementTotal: number | null = null;
  nonReinstatementTotal: number | null = null;
  @Input() set dataTable(value: PremiumEnquiryRecords) {
    if (value) {
      this.totalCount = value.totalCount;
      if (this.totalCount) {
        this.totalCountAlertShown.emit(this.totalCount);
      }
      this.reinstatementTotal = value?.reinstatementTotals;
      this.nonReinstatementTotal = value.nonReinstatementTotals;
      // sort by CSND in ascending order after searching
      this.sortColumn = 'csnd';
      this.allTableData = orderBy(value.signings.slice(0, 2000), [this.sortColumn], [this.sortDirection]);
      this.initTable();
    }
  }

  @Input() set tableColumns(tableColumns: TableColumn[]) {
    if (tableColumns) {
      this.tableColumnsValue = tableColumns;
    }
  }

  @Input() set premiumDetail(premiumDetail: PremiumGetRec) {
    if (premiumDetail) {
      const selectedRow = this.checkedRows[0];
      if (selectedRow) {
        const queryParams = {
          queryParams: {
            premiumId: selectedRow?.premiumId,
            typeOfPremium: this.getTypeOfPremiumKey(typeOfPremium, selectedRow?.transactionType?.typeOfTransactionType),
            submissionId: selectedRow?.submissionId,
            csnd: selectedRow?.csnd,
            umr: selectedRow?.umr,
            workPackageRef: selectedRow?.workPackageRef,
          },
        };

        this.router.navigate(['/instalment-details'], queryParams);
      }
    }
  }

  @Input() set tableExpandRow(tableExpandRow: TableColumn[]) {
    if (tableExpandRow) {
      this.tableExpandRowValue = tableExpandRow;
    }
  }

  @Input() set infoHeaderDetails(infoHeaderDetails: TechnicianSVDetails) {
    if (infoHeaderDetails) {
      this.workPackageRef = infoHeaderDetails.workPackageRef;
      this.umr = infoHeaderDetails.umr;
    }
  }

  constructor(
    private router: Router,
    private correctionStoreService: CorrectionStoreService,
    private infoHeaderStoreService: InfoHeaderStoreService,
    private summaryStoreService: SummaryStoreService,
    private defInstalmentService: DefInstalmentService,
    private store: Store<AppState>,
    private instalmentDetailsStoreService: InstalmentDetailsStoreService
  ) {}

  ngOnInit(): void {
    if (!this.premiumParams) {
      this.premiumNavigation = JSON.parse(sessionStorage.getItem('premiumNavigation'));
    }
  }

  getIntalmentDetails(): void {
    const selectedRow = this.checkedRows[0];
    const { workPackageRef, transactionType, umr, csnd, premiumId } = selectedRow;
    const typeOfPremiumVal = this.getTypeOfPremiumKey(
      typeOfPremium,
      selectedRow?.transactionType?.typeOfTransactionType
    );
  }

  initTable(): void {
    // map Enquiry array item data adding expanded property
    this.allTableData = MapItem(false, this.allTableData);
    this.expandMatchedSigningNumberRow();
    this.checkedRows = [];
    this.isChecked = false;
    this.sortColumn = '';
  }

  expandMatchedSigningNumberRow(): void {
    if (this.signingNumber) {
      this.allTableData.forEach((item: any) => {
        if (item?.csnd === this.signingNumber) {
          item.isExpanded = true;
        }
      });
    }
  }

  expandToggler(row: PremiumEnquiryRow): void {
    row.isExpanded = !row.isExpanded;
  }

  getPaginatedItems(event: PaginationModel): void {
    this.paginatedTableData = event.paginatedItems;
    const table = document.getElementById('divTable');
    if (table) {
      table.scrollTop = 0;
    }
  }

  getStatusClass(status: string): TransactionStatusClasses | '' {
    switch (status) {
      case TransactionStatusValues.NEW:
        return 'green-color';
      case TransactionStatusValues.REP:
        return 'orange-color';
      case TransactionStatusValues.CAN:
        return 'red-color';
      default:
        return '';
    }
  }

  enableCorrectioBtn(row, checked): void {
    row.checkboxChecked = checked;
    if (checked) {
      this.checkedRows.push(row);
    } else {
      const index = this.checkedRows.indexOf(row);
      this.checkedRows.splice(index, 1);
    }
    if (this.checkedRows?.length !== 0) {
      this.isChecked = true;
    } else {
      this.isChecked = false;
    }
    if (this.checkedRows?.length === this.allTableData?.length) {
      this.selectAll = this.checkedRows.every((item) => item.checkboxChecked === true);
    } else {
      this.selectAll = false;
    }
    this.mappedCheckedRow = this.checkedRows.map((item) => {
      return this.createNewCorrectionSelection(item);
    });
    this.isSchemeCanada = this.checkedRows.some((item) => item.premiumSource === PremiumSource.SchemeCanada);
    this.isAutoRI = this.checkedRows.some((item) => item.premiumSource === PremiumSource.AutoRI);
    this.createNewCorrection();
  }

  checkAllBtns(checked): void {
    this.selectAll = !this.selectAll;

    this.checkedRows = this.allTableData.map((item) => {
      return { ...item, checkboxChecked: checked };
    });
    if (checked) {
      this.allTableData = this.checkedRows.filter((item) => item.checkboxChecked === true);
      this.isChecked = true;
      this.createNewCorrection();
    } else {
      this.isChecked = false;
      this.allTableData = this.checkedRows;
      this.checkedRows = [];
    }
  }

  createNewCorrection(): void {
    this.mappedCheckedRow = this.checkedRows.map((item) => {
      return this.createNewCorrectionSelection(item);
    });

    this.isSchemeCanada = this.checkedRows.some((item) => item.premiumSource === PremiumSource.SchemeCanada);
    this.isAutoRI = this.checkedRows.some((item) => item.premiumSource === PremiumSource.AutoRI);
  }

  runIsSchemeCanadaErrorAlert(): void {
    ScrollUp(0, 0);
    this.store.dispatch(
      loadGlobalAlert({
        response: {
          responseMessage: 'CORRECTIONS.TABLE.SCHEME_CANADA_SIGNINGS',
          status: 400,
          isGlobalAlert: true,
        },
      })
    );
  }
  runIsAutoRIErrorAlert(): void {
    ScrollUp(0, 0);
    this.store.dispatch(
      loadGlobalAlert({
        response: {
          responseMessage: 'CORRECTIONS.TABLE.LIC_REINSURANCE_CANNOT_BE_SELECTED',
          status: 400,
          isGlobalAlert: true,
        },
      })
    );
  }

  goToCorrections(): void {
    if (this.isSchemeCanada || this.isAutoRI) {
      if (this.isSchemeCanada) {
        this.runIsSchemeCanadaErrorAlert();
      }
      if (this.isAutoRI) {
        this.runIsAutoRIErrorAlert();
      }
      return;
    }
    this.correctionStoreService.newCorrectionSelectionPost(
      this.mappedCheckedRow,
      this.callback,
      this.workflowSubmissionId
    );
  }

  getCopyWarningMessage(): string {
    if (this.checkedRows?.length > 1) {
      return 'CORRECTIONS.COPY_PREMIUM.ONE_RECORD_WARNING';
    }

    if (this.checkedRows?.length !== 1) {
      return '';
    }

    const { transactionType } = this.checkedRows[0];
    const copyTransactionType = this.getTypeOfPremiumKey(typeOfPremium, transactionType.typeOfTransactionType);
    if (!this.premiumPath.endsWith(copyTransactionType)) {
      return 'CORRECTIONS.COPY_PREMIUM.TYPE_MISMATCH_WARNING';
    }

    return '';
  }

  backToPremuim(): void {
    if (this.checkedRows?.length !== 1 || !this.isfromPremuim) {
      return;
    }

    sessionStorage.removeItem('premiumNavigation');

    const { premiumId, transactionType } = this.checkedRows[0];
    const copyTransactionType = this.getTypeOfPremiumKey(typeOfPremium, transactionType.typeOfTransactionType);

    const queryParams = {
      ...this.premiumParams,
      copyPremiumId: premiumId,
      copyTransactionType,
    };

    this.router.navigate([`/section-details/${this.premiumPath}`], { queryParams });
  }

  getTypeOfPremiumKey(typeOfPremiumArray, targetValue): string {
    const matchingItem = typeOfPremiumArray.find((item) => item.value === targetValue);
    return matchingItem ? matchingItem.key : null;
  }

  goToDeferred(): void {
    const selectedRow = this.checkedRows[0];
    if (!selectedRow) {
      return; // Ensure a row is selected
    }
    if (selectedRow?.correctionType === 'C') {
      ScrollUp(0, 0);
      this.correctionTypeError.emit(true);
      return;
    }
    this.correctionTypeError.emit(false);

    const { workPackageRef, transactionType, umr, csnd, premiumId } = selectedRow;

    const premiumType = transctionType(transactionType?.typeOfTransactionType);

    this.defInstalmentService.getPremiumDetails(workPackageRef, premiumId, premiumType, umr, csnd);
  }

  private createNewCorrectionSelection(rowRecord: any): NewCorrectionSelection {
    const newCorrectionSelectionBuilder = Builder<NewCorrectionSelection>();
    return newCorrectionSelectionBuilder
      .premiumid(rowRecord?.premiumId)
      .transactiontype(rowRecord?.transactionType)
      .umr(rowRecord?.umr)
      .workPackageRef(this.workPackageRef)
      .settlementCurrency(rowRecord?.settlementCurrency)
      .premiumNet(rowRecord?.netPremium)
      .bureau(rowRecord?.bureau)
      .bsnd(rowRecord?.bsnd)
      .csnd(rowRecord?.csnd)
      .releaseFlag(rowRecord?.releaseFlag)
      .releasedForSettlement(rowRecord?.releasedForSettlement)
      .build();
  }

  isNAICLinkAvailable(row: PremiumEnquiryRecord): boolean {
    const naicValidValues = NAIC_REQUIRED_VALUES;
    if (
      row?.bureau === TechnicianPortalBureauEnum.LLOYDS &&
      row?.naicInfoStatus !== NaicSlReportingStatus.COMPLETE &&
      (naicValidValues.includes(row?.filCode1?.typeOfFilCode) || naicValidValues.includes(row?.filCode2?.typeOfFilCode))
    ) {
      return true;
    } else {
      return false;
    }
  }

  isSurplusLinkAvailable(row: PremiumEnquiryRecord): boolean {
    const surplusValidValues = SURPLUS_REQUIRED_VALUES;
    if (
      row?.bureau === TechnicianPortalBureauEnum.LLOYDS &&
      row?.usSurplusInfoStatus !== NaicSlReportingStatus.COMPLETE &&
      (surplusValidValues.includes(row?.filCode1?.typeOfFilCode) ||
        surplusValidValues.includes(row?.filCode2?.typeOfFilCode))
    ) {
      return true;
    } else {
      return false;
    }
  }

  onNaicOrSurplusClick(row, reportingType: NAIC_SURPLUS_REPORTING_TYPE): void {
    const transactionType = TransactionTypesValues.find((t) => t.key === row?.transactionType?.typeOfTransactionType);
    const transactionStatusValue = row?.submissionStatus === SubmissionStatuses.Signed;
    const queryParams = {
      premiumId: row?.premiumId,
      transactionType: transactionType.value,
      transactionStatus: transactionStatusValue,
      submissionId: row.submissionId,
    };
    if (reportingType === NAIC_SURPLUS_REPORTING_TYPE.NAIC) {
      this.router.navigate([HEADER_NAIC_REPORTING_URL], { queryParams });
    } else {
      this.router.navigate([HEADER_SURPLUS_LINES_URL], { queryParams });
    }
  }

  viewTransaction(premium: PremiumEnquiryRow): void {
    const queryParamsProgress = {
      status: 'opened',
      section_no: premium?.sectionNumber,
      premiumId: premium?.premiumId,
      submissionId: premium?.submissionId,
      bureau: premium?.bureau,
      enquirySubmissionId: premium.submissionId,
      csnd: premium.csnd,
      workflowSubmissionId: this.workflowSubmissionId,
      isInProgress: this.isInProgress,
      nodeType: this.isInProgress ? null : NodeType.PremiumDetails,
    };
    const transactionType = transctionType(premium?.transactionType?.typeOfTransactionType);
    const url = this.router
      .createUrlTree([`${PREMIUM_URL}${premium?.bureau}/${transactionType}`], { queryParams: queryParamsProgress })
      .toString();
    window.open(url, '_blank');
  }

  resetSearchResult(): void {
    this.allTableData = [];
    this.initTable();
  }

  showCorrectionsButton(): boolean | number {
    return !this.allTableData?.length || (!this.isInProgress && this.allTableData?.length);
  }
  canResolveErrors(hasErrors: boolean, isHeritageRecord: boolean): boolean {
    const roleView = this.rolesRef?.includes(Role.PROCESS_HERITAGE_VIEW);
    if (roleView && hasErrors && isHeritageRecord) {
      return true;
    } else {
      return false;
    }
  }
  editTransaction(submissionId: string, submissionCsnd: string): void {
    const queryParams = {
      enquirySubmissionId: submissionId,
      csnd: submissionCsnd,
      isInProgress: this.isInProgress,
      editMode: this.rolesRef?.includes(Role.PROCESS_HERITAGE_EDIT) ? true : null,
    };
    // Is edit mode logic correct? Should we also check for isHeritage before we set as edit mode?
    const url = this.router.createUrlTree([SUMMARY_URL], { queryParams })?.toString();
    window.open(url, '_blank');
  }

  moveToDefInstHist(submissionId: string, csnd: string, premiumId: string): void {
    this.router.navigate(['/enquiry-details/def-inst-hist'], {
      queryParams: {
        isfromCorrection: this.isfromCorrection,
        workflowSubmissionId: this.workflowSubmissionId,
        premiumId,
        csnd,
        submissionID: submissionId,
      },
    });
  }

  sortTable(column: string): void {
    if (this.sortColumn === column) {
      if (this.sortDirection === SortDirection.ASC) {
        // Sorting the table in descending order by column
        this.sortDirection = SortDirection.DESC;
      } else if (this.sortDirection === SortDirection.DESC) {
        this.sortColumn = '';
        this.sortDirection = SortDirection.ASC;
      }
    } else {
      // Sorting the table in ascending order by column
      this.sortColumn = column;
      this.sortDirection = SortDirection.ASC;
    }

    if (this.sortColumn) {
      // Sorting the table in ascending or descending order by column
      this.allTableData = orderBy(this.allTableData, [column], [this.sortDirection]);
    } else {
      // Resetting to default ascending order by csnd
      this.allTableData = orderBy(this.allTableData, ['csnd'], [SortDirection.ASC]);
    }
  }

  getSortIcon(column: string): string {
    return GetSortIcon(column, this.sortColumn, this.sortDirection);
  }

  setTableView(tableType: 'standard' | 'modified'): void {
    this.tableView = tableType;
    this.updateTableColumns.emit(tableType);
  }
}
