import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { TranslateModule } from '@ngx-translate/core';
import { Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { mockSearchResult, mockTableColumns } from '@features/company-ref-update/const/mockSearchResult.consts';
import { CompanyDefInstHistoryTableComponent } from './instalment-history-table.component';
import { instalmentHistoryMockData } from '@features/enquiry/const/def-inst-hist.const';
import { TeambasketsTechniciansService } from '@shared/services/teambaskets-technicians.service';
import { IPOSService } from 'src/app/api/iPOS';
import { AppConfigService } from 'src/app/core/services/app-config/app-config.service';
import { PartiesService } from 'src/app/api/parties';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Configuration as workflowConfig } from '@dxc.lm.sdk.angular/premiums-base-workflow-experience-api';
import { Configuration as partiesConfig } from '@dxc.lm.sdk.angular/premiums-base-workflow-parties-api';
describe('CompanyRefTableComponent', () => {
  let component: CompanyDefInstHistoryTableComponent;
  let fixture: ComponentFixture<CompanyDefInstHistoryTableComponent>;
  const router = {
    navigate: jasmine.createSpy('navigate'),
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
        HttpClientTestingModule,
      ],
      declarations: [CompanyDefInstHistoryTableComponent],
      providers: [
        TeambasketsTechniciansService,
        IPOSService,
        AppConfigService,
        partiesConfig,
        workflowConfig,
        PartiesService,
        { provide: Router, useValue: router },
        MockStore,
        provideMockStore(),
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyDefInstHistoryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.tableDataCopy = instalmentHistoryMockData;
    component.allTableData = [...component.tableDataCopy];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset data if search keyword is empty', () => {
    const event = { target: { value: '' } } as unknown as Event;

    component.onSearch(event);

    expect(component.allTableData).toEqual(component.tableDataCopy);
  });

  it('should render deferred instalment data', waitForAsync(() => {
    const dataTableSpay = mockSearchResult;
    component.paginatedTableData = dataTableSpay;
    fixture.detectChanges();
    expect(component.paginatedTableData).toEqual(dataTableSpay);
  }));
  it('should get WorkpackageId to check in html', () => {
    const instalmentHistoryData = [
      { instalmentId: '1', instalmentType: 'Type1', instalmentNo: 1 },
      { instalmentId: '2', instalmentType: 'Type2', instalmentNo: 2 },
    ];
    component.paginatedTableData = instalmentHistoryData;
    const workpackageIdValue = component.getRowId(1);
    expect(workpackageIdValue).toBe('21');
  });
  it('should clear isExpanded', () => {
    component.isExpanded = ['123', '456'];
    fixture.detectChanges();
    expect(component.isExpanded.length).toBe(2);
    component.clearIsExpanded();
    expect(component.isExpanded.length).toBe(0);
  });
  it('should only expand or collapse the targeted row ID', () => {
    const rowId1 = 'row-1';
    const rowId2 = 'row-2';

    component.expandToggler(rowId1); // Expand row 1
    expect(component.isExpanded).toContain(rowId1);
    expect(component.isExpanded).not.toContain(rowId2); // Ensure row 2 is not affected

    component.expandToggler(rowId2); // Expand row 2
    expect(component.isExpanded).toContain(rowId1); // Row 1 remains expanded
    expect(component.isExpanded).toContain(rowId2); // Row 2 is also expanded

    component.expandToggler(rowId1); // Collapse row 1
    expect(component.isExpanded).not.toContain(rowId1); // Row 1 is now collapsed
    expect(component.isExpanded).toContain(rowId2); // Row 2 remains expanded
  });
});
