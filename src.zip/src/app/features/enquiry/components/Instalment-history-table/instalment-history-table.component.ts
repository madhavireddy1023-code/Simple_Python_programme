import { ChangeDetectorRef, Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { TableColumn, PaginationModel } from '@shared/models/interfaces';
import * as _ from 'lodash';

import { Router } from '@angular/router';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { InstalmentHistory, UwRefCompanyHistory } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { formatTechnicianSelect, sortTable } from 'src/app/utils/helper/helper';
import { SORT_TYPES } from '@shared/consts/shared.enums';
import { InstalmentHistoryTableData } from '@features/enquiry/const/def-inst-hist.const';
import { ngDateFormatSmall } from 'src/app/utils/consts/timestamp-format.const';
import { TeambasketsTechniciansService } from '@shared/services/teambaskets-technicians.service';
import { map, take, takeUntil } from 'rxjs/operators';
import { Observable, Subject, forkJoin, of } from 'rxjs';

@Component({
  selector: 'app-instalment-history-table',
  templateUrl: './instalment-history-table.component.html',
  styleUrls: ['./instalment-history-table.component.scss'],
})
export class CompanyDefInstHistoryTableComponent implements OnInit, OnDestroy {
  readonly dateFormat = ngDateFormatSmall;
  paginatedTableData = [];
  totalCount: number;
  tableColumnsValue: TableColumn[];
  tableExPandColumnsValue: TableColumn[];
  tableDataCopy: InstalmentHistoryTableData[] = [];
  instalmentHistoryRef: InstalmentHistory;
  private destroy$ = new Subject<void>();
  allTableData: InstalmentHistoryTableData[] = [];

  readonly sortTypes = SORT_TYPES;

  isColumnIconShown: string[] = [];
  currentSortedColumn: string;
  currentAscDesc: string;
  isExpanded: string[] = [];
  technicians: any;
  constructor(
    private changeDetectorRef: ChangeDetectorRef,
    private techniciansService: TeambasketsTechniciansService
  ) {}

  @Input() set dataTable(instalmentHistory: InstalmentHistory) {
    if (instalmentHistory) {
      this.instalmentHistoryRef = instalmentHistory;
      this.updateTechnicianNames(this.instalmentHistoryRef);
    }
  }

  @Input() set tableColumns(tableColumns: TableColumn[]) {
    if (tableColumns) {
      this.tableColumnsValue = tableColumns;
      this.isColumnIconShown = this.tableColumnsValue.map((column) => 'default');
    }
  }
  @Input() set tableExPandColumns(tableExPandColumns: TableColumn[]) {
    if (tableExPandColumns) {
      this.tableExPandColumnsValue = tableExPandColumns;
    }
  }

  ngOnInit(): void {
    this.clearIsExpanded();
  }

  getPaginatedItems(event: PaginationModel): void {
    this.paginatedTableData = event.paginatedItems;
    const table = document.getElementById('divTable');
    if (table) {
      table.scrollTop = 0;
    }
  }

  sortByColumn(column: [string, string]): void {
    this.currentSortedColumn = column[0];
    this.currentAscDesc = column[1];

    const sortParams = this.currentAscDesc === SORT_TYPES.DEFAULT ? ['dateCreated', 'asc'] : column;
    this.allTableData = sortTable(sortParams, this.tableDataCopy);
  }

  selectedSortColumn(colName: string, sortType: string, colIndex: number): void {
    const icons = { asc: 'asc', desc: 'desc', default: 'default' };
    this.isColumnIconShown = this.tableColumnsValue?.map(() => icons.default);
    this.isColumnIconShown[colIndex] = icons[sortType];
    this.sortByColumn([colName, sortType]);
  }

  onSearch(event: Event): void {
    // Extract keyword from the event object
    const keyword = (event.target as HTMLInputElement).value.trim().toLowerCase();

    // Reset to original data if the search keyword is empty
    if (!keyword) {
      this.allTableData = [...this.tableDataCopy];
      return;
    }

    // Filter table data by matching the keyword in any column
    this.allTableData = this.tableDataCopy.filter((row) =>
      Object.values(row).some((value) => value?.toString().toLowerCase().includes(keyword))
    );
  }

  expandToggler(id: string): void {
    if (this.isExpanded.includes(id)) {
      this.isExpanded = this.isExpanded.filter((item) => item !== id);
    } else {
      this.isExpanded.push(id);
    }
  }
  clearIsExpanded(): void {
    this.isExpanded = [];
    this.changeDetectorRef.detectChanges();
  }
  getRowId(index: number): string {
    const x = this.paginatedTableData[index];
    return x.instalmentId + index;
  }

  private convertInstalmentHistoryToTableData(instalmentHistoryarray): void {
    instalmentHistoryarray?.forEach((instalmentHistoryData) => {
      instalmentHistoryData?.instalmentHistoryNew?.instalments?.forEach((instalmentHisNew) => {
        const instalmentHisOldSecById = instalmentHistoryData?.instalmentHistoryOld?.instalments?.find(
          (instalmentHisOld) => instalmentHisOld?.instalmentId === instalmentHisNew?.instalmentId
        );
        this.allTableData.push({
          instalmentId: instalmentHisNew?.instalmentId,
          instalmentType: instalmentHisNew?.qualCatCode?.typeOfQualCatCode,
          instalmentNo: instalmentHisNew?.number,
          dueDateOriginal: instalmentHisOldSecById?.dueDate,
          dueDateCurrent: instalmentHisNew?.dueDate,
          instalmentDueAmount: instalmentHisNew?.netPremium,
          dateOfChange: instalmentHisNew?.actualPaymentDate,
          changeBy: instalmentHisNew?.lastUpdate,
          errorMadeBy: instalmentHistoryData?.instalmentHistoryNew?.mist?.errorMadeBy,
          category: instalmentHistoryData?.instalmentHistoryNew?.mist?.category,
          errorDescription: instalmentHistoryData?.instalmentHistoryNew?.mist?.errorDescription,
          technicianName: instalmentHistoryData?.instalmentHistoryNew?.mist?.teamNameOverriden
            ? instalmentHistoryData?.instalmentHistoryNew?.mist?.teamNameOverriden
            : instalmentHistoryData?.instalmentHistoryNew?.mist?.technicianName,
          mistNarrative: instalmentHistoryData?.instalmentHistoryNew?.mist?.mistNarrative,
        });
      });
    });

    this.tableDataCopy = _.cloneDeep(this.allTableData);
  }
  onTeamBasketChange(idTeamBasket: any, technicianId: any): Observable<string | undefined> {
    return this.techniciansService.getTechniciansForBasket(idTeamBasket).pipe(
      take(1),
      map((technicians) => {
        if (technicians.length > 0) {
          this.technicians = formatTechnicianSelect(technicians);
        }
        const technician = this.technicians.find((data: any) => technicianId === data.value);
        return technician?.label; // Return the technician name
      })
    );
  }
  updateTechnicianNames(instalmentHistoryArray: any[]): void {
    const updateObservables: Observable<any>[] = [];

    instalmentHistoryArray.forEach((item) => {
      const idTeamBasket = item.instalmentHistoryNew?.mist?.teamBasket?.id;
      const technicianId = item.instalmentHistoryNew?.mist?.teamNameOverriden;

      if (idTeamBasket && technicianId) {
        const updateObservable = this.onTeamBasketChange(idTeamBasket, technicianId).pipe(
          map((technicianName) => {
            // Return a new item with the updated technicianName
            return {
              ...item,
              instalmentHistoryNew: {
                ...item.instalmentHistoryNew,
                mist: {
                  ...item.instalmentHistoryNew.mist,
                  teamNameOverriden: technicianName || '',
                },
              },
            };
          })
        );
        updateObservables.push(updateObservable);
      } else {
        // Add a default update observable
        updateObservables.push(
          of({
            ...item,
            instalmentHistoryNew: {
              ...item.instalmentHistoryNew,
              mist: {
                ...item.instalmentHistoryNew.mist,
                teamNameOverriden: '',
              },
            },
          })
        );
      }
    });

    forkJoin(updateObservables).subscribe((updatedItems) => {
      const updatedArray = [...updatedItems];
      this.convertInstalmentHistoryToTableData(updatedArray);
    });
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
