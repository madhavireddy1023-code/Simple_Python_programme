import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainEnquiryComponent } from './main/main-enquiry/main-enquiry.component';
import { MainDefInstHistoryComponent } from './main/main-enquiry-def-inst-history/main-def-inst-history.component';

const routes: Routes = [
  { path: '', component: MainEnquiryComponent },
  { path: 'def-inst-hist', component: MainDefInstHistoryComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EnquiryRoutingModule {}
