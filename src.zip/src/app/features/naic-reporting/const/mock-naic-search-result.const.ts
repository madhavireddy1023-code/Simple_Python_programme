import { NaicData } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';

export const mockNaicSearchResult: NaicData = [
  {
    address: {
      addressLine1: 'Mercury House',
      city: 'London',
      state: {
        refISOCountryDivisionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        subDivisionCode: 'string',
        subDivisionName: 'string',
      },
      zipCode: 'E1 8RU',
    },
    companyName: 'DXC Technology',
    companyStatus: { companyStatusDescription: 'string' },
    contactMethods: [
      {
        contactMethodType: 'CONTACT_NUMBER',
        contactMethodValue: 'string',
      },
    ],
    deprecatedDate: 'string',
    effectiveDate: 'string',
    feinCode: 'string',
    groupCode: 'string',
    naicCode: '78388',
    stateOfDomicile: {
      refISOCountryDivisionId: '585d0c8c-141f-42ba-94b8-a20736709145',
      subDivisionCode: 'US-KS',
      subDivisionName: 'Kansas',
    },
    uuid: '585d0c8c-141f-42ba-94b8-a20736709145',
  },
];
