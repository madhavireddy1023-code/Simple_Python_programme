import { SORT_TYPES } from '@shared/consts/shared.enums';

export const NaicCodeTableColumns = [
  {
    id: 1,
    key: 'companyCode',
    label: 'NAIC_REPORTING.NAIC_TABLE.NAIC_CODE',
    value: '',
  },
  {
    id: 2,
    key: 'companyName',
    label: 'NAIC_REPORTING.NAIC_TABLE.COMPANY_NAME',
    value: '',
    sortIcon: SORT_TYPES.ASC,
  },
  {
    id: 3,
    key: 'poolCodeDescription',
    label: 'NAIC_REPORTING.NAIC_TABLE.STATE_OF_DOMICILE',
    value: '',
    sortIcon: SORT_TYPES.DEFAULT,
  },
  {
    id: 4,
    key: 'address',
    label: 'NAIC_REPORTING.NAIC_TABLE.ADDRESS',
    value: '',
  },
  {
    id: 5,
    key: 'city',
    label: 'NAIC_REPORTING.NAIC_TABLE.CITY',
    value: '',
    sortIcon: SORT_TYPES.DEFAULT,
  },
  {
    id: 6,
    key: 'state',
    label: 'NAIC_REPORTING.NAIC_TABLE.STATE',
    value: '',
    sortIcon: SORT_TYPES.DEFAULT,
  },
  {
    id: 7,
    key: 'zipCode',
    label: 'NAIC_REPORTING.NAIC_TABLE.ZIP_CODE',
    value: '',
  },
];

export const FeinCodeTableColumns = [
  {
    id: 1,
    key: 'feinCode',
    label: 'NAIC_REPORTING.NAIC_TABLE.FEIN_CODE',
    value: '',
  },
  {
    id: 2,
    key: 'companyName',
    label: 'NAIC_REPORTING.NAIC_TABLE.COMPANY_NAME',
    value: '',
    sortIcon: SORT_TYPES.ASC,
  },
  {
    id: 3,
    key: 'stateOfDomicile',
    label: 'NAIC_REPORTING.NAIC_TABLE.STATE_OF_DOMICILE',
    value: '',
    sortIcon: SORT_TYPES.DEFAULT,
  },
  {
    id: 4,
    key: 'address',
    label: 'NAIC_REPORTING.NAIC_TABLE.ADDRESS',
    value: '',
  },
  {
    id: 5,
    key: 'city',
    label: 'NAIC_REPORTING.NAIC_TABLE.CITY',
    value: '',
    sortIcon: SORT_TYPES.DEFAULT,
  },
  {
    id: 6,
    key: 'state',
    label: 'NAIC_REPORTING.NAIC_TABLE.STATE',
    value: '',
    sortIcon: SORT_TYPES.DEFAULT,
  },
  {
    id: 7,
    key: 'zipCode',
    label: 'NAIC_REPORTING.NAIC_TABLE.ZIP_CODE',
    value: '',
  },
];

export const PoolCodeTableColumns = [
  {
    id: 1,
    key: 'poolCode',
    label: 'NAIC_REPORTING.NAIC_TABLE.NAIC_POOL_CODE',
    value: '',
  },
  {
    id: 2,
    key: 'poolName',
    label: 'NAIC_REPORTING.NAIC_TABLE.POOL_NAME',
    value: '',
    sortIcon: SORT_TYPES.ASC,
  },
  {
    id: 3,
    key: 'poolDescription',
    label: 'NAIC_REPORTING.NAIC_TABLE.POOL_DESCRIPTION',
    value: '',
  },
];

export const GroupCodeTableColumns = [
  {
    id: 1,
    key: 'groupCode',
    label: 'NAIC_REPORTING.NAIC_TABLE.NAIC_GROUP_CODE',
    value: '',
  },
  {
    id: 2,
    key: 'groupDescription',
    label: 'NAIC_REPORTING.NAIC_TABLE.GROUP_NAME',
    value: '',
    sortIcon: SORT_TYPES.ASC,
  },
];

export const NaicPremiumAllocationTableColumns = [
  {
    id: 1,
    key: 'splitNo',
    label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.SPLIT_NO',
    value: '',
  },

  {
    id: 2,
    label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.CODE_TYPE',
    key: 'codeType',
    value: '',
  },

  {
    id: 3,
    label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.CODE',
    key: 'code',
    value: '',
  },

  {
    id: 4,
    label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.REINSURED_NAME',
    key: 'reinsuredName',
    value: '',
  },

  {
    id: 5,
    label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.GROSS_PREMIUM',
    key: 'grossPremium',
    value: '',
  },
  {
    id: 6,
    label: '',
    key: 'remove',
    value: '',
  },
];
