export enum NAIC_REPORTING_CODE_OPTIONS {
  NAIC = 'NAICCODE',
  FEIN = 'FEINCODE',
  NAIC_POOL = 'POOLCODE',
  NAIC_GROUP = 'GROUPCODE',
}

export interface SearchNaicObj {
  typeOfCode?: NAIC_REPORTING_CODE_OPTIONS;
  value?: string;
}
