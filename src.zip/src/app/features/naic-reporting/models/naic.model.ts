import { Address, ContactMethod, NaicData } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';
import { NAIC_REPORTING_CODE_OPTIONS } from '../const/naic-reporting.const';

export interface NaicReinsuredState {
  searchNaicReinsuredResult: NaicData;
  etag: string;
}

export interface NaicPremiumAllocation {
  id: string;
  codeType: string;
  code: string;
  reinsuredName: string;
  grossPremium: string;
  address: Address;
  contactMethods: ContactMethod[];
  companyStatus: string;
}
