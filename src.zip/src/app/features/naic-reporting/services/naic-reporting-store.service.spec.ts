import { TestBed } from '@angular/core/testing';

import { NaicReportingStoreService } from './naic-reporting-store.service';
import { mockNaicSearchResult } from '../const/mock-naic-search-result.const';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { of } from 'rxjs';
import { selectSearchNaicResult } from '../store/selectors/naic-reporting.selectors';

describe('NaicReportingStoreService', () => {
  let service: NaicReportingStoreService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideMockStore(), MockStore],
    });
    store = TestBed.inject(MockStore);
    service = TestBed.inject(NaicReportingStoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should select search NAIC result', () => {
    spyOn(store, 'select').withArgs(selectSearchNaicResult).and.returnValue(of(mockNaicSearchResult[0]));
    service.selectSearchNaicResult();
    expect(store.select).toHaveBeenCalled();
  });
});
