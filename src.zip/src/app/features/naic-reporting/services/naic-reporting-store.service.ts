import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';
import { NaicData } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';
import { Observable } from 'rxjs';
import { selectSearchNaicResult } from '../store/selectors/naic-reporting.selectors';

@Injectable({
  providedIn: 'root',
})
export class NaicReportingStoreService {
  constructor(private store: Store<AppState>) {}

  selectSearchNaicResult(): Observable<NaicData> {
    return this.store.select(selectSearchNaicResult);
  }
}
