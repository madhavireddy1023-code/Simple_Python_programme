import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { NaicReportingRoutingModule } from './naic-reporting-routing.module';
import { NaicReportingComponent } from './main/naic-reporting.component';
import { NaicSearchComponent } from './components/naic-search-container/naic-search.component';
import { NaicTableContainerComponent } from './components/naic-table-container/naic-table-container.component';
import { NaicSearchFormComponent } from './components/naic-search-form/naic-search-form.component';
import { NaicSearchInputComponent } from './components/naic-search-input/naic-search-input.component';
import { NaicPremiumAllocationComponent } from './components/naic-premium-allocation/naic-premium-allocation.component';
import { StoreModule } from '@ngrx/store';
import { NaicReinsuredReducer } from './store/reducers/naic-reporting.reducers';

@NgModule({
  declarations: [
    NaicReportingComponent,
    NaicSearchComponent,
    NaicTableContainerComponent,
    NaicSearchFormComponent,
    NaicSearchInputComponent,
    NaicPremiumAllocationComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    NaicReportingRoutingModule,
    StoreModule.forFeature('premium', NaicReinsuredReducer),
  ],
  providers: [],
})
export class NAICReportingModule {}
