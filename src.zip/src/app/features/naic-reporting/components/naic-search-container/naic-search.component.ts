import { ChangeDetectionStrategy, Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { NAIC_REPORTING_CODE_OPTIONS, SearchNaicObj } from '@features/naic-reporting/const/naic-reporting.const';
import { Store } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';
import * as actions from '../../store/actions/naic-reporting.action';

@Component({
  selector: 'app-search-naic-container',
  templateUrl: './naic-search.component.html',
  styleUrls: ['./naic-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NaicSearchComponent implements OnInit {
  selectedCode: NAIC_REPORTING_CODE_OPTIONS = NAIC_REPORTING_CODE_OPTIONS.NAIC;
  codeValue!: string;
  searchNaicObj: SearchNaicObj = {};
  @Output() search = new EventEmitter<any>();

  constructor(private store: Store<AppState>) {}

  ngOnInit(): void {}

  getCodeType(code): void {
    this.selectedCode = code;
  }

  getCodeValue(formValue): void {
    this.codeValue = formValue.code;
    this.createSearchNaicObj();
    this.store.dispatch(actions.searchNaicReinsured({ searchObject: this.searchNaicObj }));
    this.search.emit(this.searchNaicObj.typeOfCode);
  }

  createSearchNaicObj(): void {
    this.searchNaicObj = {
      typeOfCode: this.selectedCode,
      value: this.codeValue,
    };
  }
}
