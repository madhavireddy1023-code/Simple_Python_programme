import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NaicSearchComponent } from './naic-search.component';
import { TranslateModule } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { DxcButtonModule, DxcTableModule, DxcTextInputModule } from '@dxc-technology/halstack-angular';
import { NAIC_REPORTING_CODE_OPTIONS } from '@features/naic-reporting/const/naic-reporting.const';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

describe('NaicSearchComponent', () => {
  let component: NaicSearchComponent;
  let fixture: ComponentFixture<NaicSearchComponent>;
  let el: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NaicSearchComponent],
      imports: [TranslateModule.forRoot({}), ReactiveFormsModule, DxcButtonModule, DxcTextInputModule, DxcTableModule],
      providers: [MockStore, provideMockStore()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NaicSearchComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should update selectedCode property correctly', () => {
    component.getCodeType('NAIC');
    expect(component.selectedCode).toBe('NAIC');

    component.getCodeType('FEIN');
    expect(component.selectedCode).toBe('FEIN');
  });

  it('should update codeValue and emit search event', () => {
    const mockFormValue = { code: '123' };
    spyOn(component.search, 'emit');
    component.getCodeValue(mockFormValue);
    expect(component.codeValue).toEqual('123');
    expect(component.search.emit).toHaveBeenCalled();
  });

  it('should create SearchNaicObj with selected code and code value', () => {
    component.selectedCode = NAIC_REPORTING_CODE_OPTIONS.NAIC;
    component.codeValue = '123';
    component.createSearchNaicObj();
    expect(component.searchNaicObj).toEqual({
      typeOfCode: NAIC_REPORTING_CODE_OPTIONS.NAIC,
      value: '123',
    });
  });
});
