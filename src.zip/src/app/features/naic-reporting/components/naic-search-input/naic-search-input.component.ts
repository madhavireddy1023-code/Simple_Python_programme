import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewEncapsulation,
} from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { NAIC_REPORTING_CODE_OPTIONS } from '@features/naic-reporting/const/naic-reporting.const';
import { FormControls } from '@shared/models';
import { DxcTextInputComponent } from '@dxc-technology/halstack-angular';
import { ValidationInputStatus } from 'src/app/utils/helper/helper';

@Component({
  selector: 'app-naic-search-input',
  templateUrl: './naic-search-input.component.html',
  styleUrls: ['./naic-search-input.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NaicSearchInputComponent implements OnInit, OnChanges {
  @Input() isSelectedCode: string;
  @Output() formValue = new EventEmitter<string>();

  searchCodeForm: FormGroup;
  isSearchBtnClicked = false;
  codeName: string;
  codeControl = new FormControl(
    null,
    Validators.compose([Validators.required, this.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC)])
  );

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.setUpForm();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.isSelectedCode && this.searchCodeForm) {
      this.setCodeValidator(this.isSelectedCode);
      this.onResetForm();
      if (this.isSelectedCode === NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL) {
        this.autoCorrectValue('');
      }
    }
  }

  setUpForm(): void {
    this.searchCodeForm = this.formBuilder.group({
      code: this.codeControl,
    });
  }

  setCodeValidator(selectedCode: string): void {
    this.codeControl.setValidators([Validators.compose([Validators.required, this.validateCodeType(selectedCode)])]);
    this.codeControl.updateValueAndValidity();
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }

  // get form controls of contract information form
  get searchCodeFormControls(): FormControls {
    return this.searchCodeForm?.controls;
  }

  submit(): void {
    this.isSearchBtnClicked = true;
    if (this.isSelectedCode === NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL) {
      const control = this.searchCodeForm.get('code');
      control.markAsDirty();
      control.markAsTouched();
      control.updateValueAndValidity();
    }

    if (this.searchCodeForm.invalid) {
      return;
    }

    this.formValue.emit(this.searchCodeForm.value);
  }

  validateCodeType(selectedCode: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const value = control.value;

      this.codeName = '';
      const notNumber = !/^\d+$/.test(value);
      const naicCodePattern = /^\d{5}$/.test(value);
      const groupCodePattern = /^\d{4}$/.test(value);
      const firstTwoChars = value?.substring(0, 2) || '';
      const isFirstTwoCharsNumeric = /^\d{2}$/.test(firstTwoChars);
      const afterThirdCharNotNumber = /^.{2}-\d{7}$/.test(value);
      const thirdCharNotHyphen = /^..[^-]/.test(value);
      const isFirstTwoCharsAA = firstTwoChars === 'AA';
      const naicPoolPattern = /^AA-\d{7}$/.test(value);
      const feinPattern = /^\d{2}-\d{7}$/.test(value);

      if ((!control.pristine && value) || control.dirty) {
        switch (selectedCode) {
          case NAIC_REPORTING_CODE_OPTIONS.NAIC:
            if (notNumber) {
              this.codeName = 'NAIC_REPORTING.CODE_VALIDATION.NAIC_CODE';
              return { numberOnly: { value: control.value } };
            } else if (!naicCodePattern) {
              this.codeName = 'NAIC_REPORTING.CODE_VALIDATION.NAIC_CODE';
              return { mustBe5Digits: { value: control.value } };
            }
            break;
          case NAIC_REPORTING_CODE_OPTIONS.NAIC_GROUP:
            if (notNumber) {
              this.codeName = 'NAIC_REPORTING.CODE_VALIDATION.NAIC_GROUP_CODE';
              return { numberOnly: { value: control.value } };
            } else if (!groupCodePattern) {
              this.codeName = 'NAIC_REPORTING.CODE_VALIDATION.NAIC_GROUP_CODE';
              return { mustBe4Digits: { value: control.value } };
            }
            break;
          case NAIC_REPORTING_CODE_OPTIONS.FEIN:
            if (
              !feinPattern ||
              !isFirstTwoCharsNumeric ||
              thirdCharNotHyphen ||
              value.length > 10 ||
              (!afterThirdCharNotNumber && value.length > 3)
            ) {
              this.codeName = 'NAIC_REPORTING.CODE_VALIDATION.FEIN_CODE';
              return { formatCodeFein: { value: control.value } };
            }
            break;
          case NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL:
            if (
              !naicPoolPattern ||
              !isFirstTwoCharsAA ||
              thirdCharNotHyphen ||
              value.length > 10 ||
              (!afterThirdCharNotNumber && value.length > 3)
            ) {
              this.codeName = 'NAIC_REPORTING.CODE_VALIDATION.NAIC_POOL_CODE';
              return { formatCode: { value: control.value } };
            }
            break;

          default:
            return null;
        }
      }
      return null;
    };
  }

  autoCorrectValue(value: string): void {
    if (!value?.startsWith('AA-')) {
      this.searchCodeForm.get('code')?.setValue('AA-', { emitEvent: false });
    }
  }

  onKeyDown(event: KeyboardEvent): void {
    const inputElement = event.target as HTMLInputElement;
    const currentValue = inputElement.value;
    const selectionStart = inputElement.selectionStart ?? 0;
    const selectionEnd = inputElement.selectionEnd ?? 0;

    if (currentValue.startsWith('AA-')) {
      // Prevent using Backspace to remove the prefix or any part of it
      if (
        (event.key === 'Backspace' && selectionStart <= 3 && selectionEnd <= 3) ||
        (event.key === 'Delete' && selectionStart < 3 && selectionEnd <= 3)
      ) {
        event.preventDefault();
      }

      // Prevent deleting the prefix if selecting any part of it
      if (selectionStart < 3 && selectionEnd > 3) {
        event.preventDefault();
      }
    }
  }

  onResetForm(): void {
    this.searchCodeForm.reset();
    this.isSearchBtnClicked = false;
  }
}
