import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NaicSearchInputComponent } from './naic-search-input.component';
import { TranslateModule } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ControlContainer, FormBuilder, FormControl, FormGroupDirective, ReactiveFormsModule } from '@angular/forms';
import { NAIC_REPORTING_CODE_OPTIONS } from '@features/naic-reporting/const/naic-reporting.const';
import { DxcTextInputComponent, DxcTextInputModule } from '@dxc-technology/halstack-angular';

describe('NaicSearchInputComponent', () => {
  let component: NaicSearchInputComponent;
  let fixture: ComponentFixture<NaicSearchInputComponent>;
  let el: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NaicSearchInputComponent, DxcTextInputComponent],
      imports: [TranslateModule.forRoot({}), ReactiveFormsModule, DxcTextInputModule],
      providers: [
        { provide: FormBuilder, useValue: new FormBuilder() },
        { provide: ControlContainer, useExisting: FormGroupDirective },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NaicSearchInputComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set up the search code form with a code control', () => {
    component.setUpForm();
    expect(component.searchCodeForm).toBeDefined();
    expect(component.searchCodeForm.get('code')).toBeDefined();
  });

  it('should emit form value when submit is called for a valid naic group code', () => {
    component.isSelectedCode = NAIC_REPORTING_CODE_OPTIONS.NAIC_GROUP;
    component.searchCodeForm.setValue({ code: '1234' });
    spyOn(component.formValue, 'emit');
    component.searchCodeForm.get('code')?.markAsDirty();
    component.searchCodeForm.get('code')?.markAsTouched();
    component.searchCodeForm.updateValueAndValidity();
    component.submit();
    expect(component.formValue.emit).toHaveBeenCalled();
  });

  it('should code has required error if entered empty value', () => {
    const formControls = component.searchCodeForm.controls;
    formControls.code.setValue('');
    expect(formControls.code.hasError('required')).toBeTruthy();
  });

  it('should return null for a valid NAIC code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC);
    const control = new FormControl('12345');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toBeNull();
  });

  it('should return { numberOnly: { value: "abc" } } for an invalid NAIC code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC);
    const control = new FormControl('abc');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ numberOnly: { value: 'abc' } });
  });

  it('should return { mustBe5Digits: { value: "123" } } for an invalid NAIC code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC);
    const control = new FormControl('123');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ mustBe5Digits: { value: '123' } });
  });

  it('should return null for a valid Naic group code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC_GROUP);
    const control = new FormControl('1234');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toBeNull();
  });
  it('should return error for an invalid Naic group code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC_GROUP);
    const control = new FormControl('abc');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ numberOnly: { value: 'abc' } });
  });

  it('should return { mustBe4Digits: { value: "12" } } for an invalid Naic group code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC_GROUP);
    const control = new FormControl('12');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ mustBe4Digits: { value: '12' } });
  });

  it('should return null for a valid Fein code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.FEIN);
    const control = new FormControl('12-1234567');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toBeNull();
  });

  it('should return error for an invalid Fein code (third character not a hyphen)', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.FEIN);
    const control = new FormControl('CC1234567');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ formatCodeFein: { value: 'CC1234567' } });
  });

  it('should return error for an invalid Fein code (first two characters are not numbers)', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.FEIN);
    const control = new FormControl('CC-1234567');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ formatCodeFein: { value: 'CC-1234567' } });
  });

  it('should return error for an invalid Fein code (length greater than 10)', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.FEIN);
    const control = new FormControl('CC-123456789');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ formatCodeFein: { value: 'CC-123456789' } });
  });

  it('should return error for an invalid Fein code (letter after third character)', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.FEIN);
    const control = new FormControl('CC-A234567');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ formatCodeFein: { value: 'CC-A234567' } });
  });

  it('should prepend "AA" and validate correctly for NAIC_POOL', () => {
    const fb = new FormBuilder();
    component.searchCodeForm = fb.group({
      code: [''],
    });

    component.isSelectedCode = 'NAIC_POOL';

    const codeControl = component.searchCodeForm.get('code');
    codeControl?.valueChanges.subscribe((value) => {
      component.autoCorrectValue(value);
    });

    codeControl?.setValue('');
    fixture.detectChanges();

    expect(codeControl?.value).toBe('AA-');

    const validator = component.validateCodeType('NAIC_POOL');
    const validationErrors = validator(codeControl as FormControl);
    expect(validationErrors).toBeNull();
  });

  it('should return null for a valid Naic pool code', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL);
    const control = new FormControl('AA-1234567');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toBeNull();
  });

  it('should return error for an invalid Naic pool code (third character not a hyphen)', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL);
    const control = new FormControl('CC1234567');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ formatCode: { value: 'CC1234567' } });
  });

  it('should return error for an invalid Naic pool code (length greater than 10)', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL);
    const control = new FormControl('CC-123456789');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ formatCode: { value: 'CC-123456789' } });
  });

  it('should return error for an invalid Naic pool code (letter after third character)', () => {
    const validator = component.validateCodeType(NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL);
    const control = new FormControl('CC-A234567');
    control.markAsDirty();
    const result = validator(control);
    expect(result).toEqual({ formatCode: { value: 'CC-A234567' } });
  });
});
