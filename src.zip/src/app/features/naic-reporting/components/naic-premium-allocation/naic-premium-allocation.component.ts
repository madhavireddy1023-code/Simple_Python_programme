import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TypeOfField } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { PremiumAllocationComponent } from '@features/base-premium-allocation/components/premium-allocation/premium-allocation.component';
import { PremiumAllocationStoreService } from '@features/base-premium-allocation/services/premium-allocation-store.service';
import { NaicPremiumAllocationTableColumns } from '@features/naic-reporting/const/naic-table-columns';
import { NaicPremiumAllocation } from '@features/naic-reporting/models/naic.model';
import { NaicReportingStoreService } from '@features/naic-reporting/services/naic-reporting-store.service';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { SharedPremiumDataService } from '@features/section-details/services/shared-premium-data.service';
import { TranslateService } from '@ngx-translate/core';
import { Location } from '@angular/common';
import { NaicCarrier, PremiumNaicUsslInfo } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Actions } from '@ngrx/effects';
import { REPORTING_STATUS_OPTIONS } from '@features/base-premium-allocation/const/naic-reporting-status.const';

@Component({
  selector: 'app-naic-premium-allocation',
  templateUrl: '../../../base-premium-allocation/components/premium-allocation/premium-allocation.component.html',
  styleUrls: ['../../../base-premium-allocation/components/premium-allocation/premium-allocation.component.scss'],
})
export class NaicPremiumAllocationComponent extends PremiumAllocationComponent {
  premiumAllocationType = TypeOfField.NAIC;
  premiumAllocationTableColumns = NaicPremiumAllocationTableColumns;
  tableData: NaicPremiumAllocation[] = [];

  constructor(
    protected fb: FormBuilder,
    storeService: NaicReportingStoreService,
    protected sectionDetailsService: SectionDetailsStoreService,
    protected translate: TranslateService,
    protected premiumAllocationService: PremiumAllocationStoreService,
    protected route: ActivatedRoute,
    protected router: Router,
    protected sharedPremiumDataService: SharedPremiumDataService,
    protected location: Location,
    protected cdr: ChangeDetectorRef,
    protected actions: Actions
  ) {
    super(
      fb,
      storeService,
      sectionDetailsService,
      translate,
      premiumAllocationService,
      route,
      router,
      sharedPremiumDataService,
      location,
      cdr,
      actions
    );
  }
  getNaicCarriersArray(): NaicCarrier[] {
    const naicCarriersArray: NaicCarrier[] = [];
    let matchingCarrier = {} as NaicCarrier;
    const premiumNaicSlData = this.premiumNaicSlData?.naicDetails?.naicCarriers;
    this.tableData?.forEach((row, i) => {
      if (premiumNaicSlData) {
        matchingCarrier = premiumNaicSlData.find(
          (carrier) =>
            carrier?.feinCode === row?.code ||
            carrier?.naicCode === row?.code ||
            carrier?.poolCode === row?.code ||
            carrier?.groupCode === row?.code
        );
      }
      const naicCarrierObj = {} as NaicCarrier;
      (naicCarrierObj.uuid = matchingCarrier ? matchingCarrier?.uuid : ''),
        (naicCarrierObj.splitNumber = i),
        (naicCarrierObj.reinsuredName = row?.reinsuredName),
        (naicCarrierObj.companyStatus = row?.companyStatus),
        (naicCarrierObj.address = { state: row?.address?.state?.subDivisionName }),
        (naicCarrierObj.grossPremium = parseFloat(this.controlsById[row?.code].value));
      switch (row?.codeType) {
        case this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC'):
          naicCarrierObj.naicCode = row.code;
          break;
        case this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.FEIN'):
          naicCarrierObj.feinCode = row.code;
          break;
        case this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC_GROUP'):
          naicCarrierObj.groupCode = row.code;
          break;
        case this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC_POOL'):
          naicCarrierObj.poolCode = row.code;
          break;
      }
      naicCarriersArray.push(naicCarrierObj);
    });
    return naicCarriersArray;
  }

  protected getSavePayload(): PremiumNaicUsslInfo {
    const premiumId = this.premiumData?.premiumId;
    return {
      premiumId,
      transactionType: this.premiumData?.transactionType,
      naicDetails: {
        naicRequired: true,
        naicInfoStatus: this.premiumForm?.controls?.reportingStatus?.value,
        naicCarriers: this.getNaicCarriersArray(),
      },
    };
  }

  fillPremiumNAICSL(naicCarriers: NaicCarrier[]): void {
    naicCarriers?.forEach((row: NaicCarrier) => {
      const newRow = {
        id: row?.uuid,
        reinsuredName: row.reinsuredName,
        codeType: '',
        code: '',
        grossPremium: row.grossPremium,
        address: row.address,
        contactMethods: [],
        companyStatus: '',
      };
      if (row.naicCode) {
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC');
        newRow.code = row.naicCode;
      } else if (row.feinCode) {
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.FEIN');
        newRow.code = row.feinCode;
      } else if (row.poolCode) {
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC_POOL');
        newRow.code = row.poolCode;
      } else if (row.groupCode) {
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC_GROUP');
        newRow.code = row.groupCode;
      }

      const isDuplicate = this.tableData?.some((existingRow: NaicPremiumAllocation) => existingRow?.id === row?.uuid);

      if (!isDuplicate) {
        this.premiumAllocationStoreService.addPremiumRow(newRow);
      }
    });
  }

  protected openNJSplitPage(id: string, val: any): void {}
}
