import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NaicTableContainerComponent } from './naic-table-container.component';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { NAIC_REPORTING_CODE_OPTIONS } from '../../const/naic-reporting.const';
import { DxcTableModule } from '@dxc-technology/halstack-angular';
import {
  FeinCodeTableColumns,
  GroupCodeTableColumns,
  NaicCodeTableColumns,
  PoolCodeTableColumns,
} from '@features/naic-reporting/const/naic-table-columns';
import { SORT_TYPES } from '@shared/consts/shared.enums';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { PaginationModel } from '@shared/models';
import { mockNaicSearchResult } from '@features/naic-reporting/const/mock-naic-search-result.const';
import { PremiumAllocationStoreService } from '@features/base-premium-allocation/services/premium-allocation-store.service';
import { addPremiumRow } from '@features/base-premium-allocation/store/actions/premium-allocation-base.action';
import { UppercaseDisplayPipe } from '@shared/pipes/uppercase.pipe';
import { NaicCodeData1, NaicData } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';
import { ApprovalStatus } from '@dxc.lm.sdk.angular/ipos-party-api';

describe('NaicTableContainerComponent', () => {
  let component: NaicTableContainerComponent;
  let fixture: ComponentFixture<NaicTableContainerComponent>;
  let premiumAllocationStoreService: PremiumAllocationStoreService;
  let translateService: TranslateService;
  let store: Store;
  let el: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NaicTableContainerComponent, UppercaseDisplayPipe],
      imports: [TranslateModule.forRoot({}), DxcTableModule],
      providers: [TranslateService, Store, MockStore, provideMockStore()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NaicTableContainerComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    translateService = TestBed.inject(TranslateService);
    component.premiumTableData = [];
    premiumAllocationStoreService = TestBed.inject(PremiumAllocationStoreService);
    store = TestBed.inject(Store);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set tableColumns based on selectedCodewhen ', () => {
    component.naicTableData = mockNaicSearchResult;
    component.premiumTableData = [];
    component.selectedCode = NAIC_REPORTING_CODE_OPTIONS.NAIC;
    component.bindTemplatesToColumns();
    expect(component.tableColumns).toEqual(NaicCodeTableColumns);

    component.selectedCode = NAIC_REPORTING_CODE_OPTIONS.FEIN;
    component.bindTemplatesToColumns();
    expect(component.tableColumns).toEqual(FeinCodeTableColumns);

    component.selectedCode = NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL;
    component.bindTemplatesToColumns();
    expect(component.tableColumns).toEqual(PoolCodeTableColumns);

    component.selectedCode = NAIC_REPORTING_CODE_OPTIONS.NAIC_GROUP;
    component.bindTemplatesToColumns();
    expect(component.tableColumns).toEqual(GroupCodeTableColumns);
  });

  it('should update sortIcon based on sortType', () => {
    component.tableColumns = [
      { id: 1, key: 'companyName', label: 'company name', value: '', sortIcon: SORT_TYPES.DEFAULT },
      { id: 2, key: 'city', label: 'city', value: '', sortIcon: SORT_TYPES.DEFAULT },
      { id: 3, key: 'state', label: 'state', value: '', sortIcon: SORT_TYPES.DEFAULT },
    ];

    component.selectedSortColumn('Column1', 'asc', 0);
    expect(component.tableColumns[0].sortIcon).toBe('asc');

    component.selectedSortColumn('Column2', 'desc', 1);
    expect(component.tableColumns[1].sortIcon).toBe('desc');

    component.selectedSortColumn('Column3', 'default', 2);
    expect(component.tableColumns[2].sortIcon).toBe('default');
  });

  it('should add a new row if the row is not a duplicate', () => {
    component.premiumTableData = [];
    const row: NaicCodeData1 = {
      uuid: '1',
      naicCode: '1234',
      companyName: 'Company Name',
      address: {},
      contactMethods: [],
      companyStatus: { companyStatusDescription: 'string' },
      effectiveDate: '',
    };

    const newRow = {
      id: '',
      codeType: 'NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC',
      code: '1234',
      reinsuredName: 'Company Name',
      grossPremium: '',
      address: {},
      contactMethods: [],
      companyStatus: 'string',
    };

    spyOn(store, 'dispatch');

    component.onAdd(row);
    expect(store.dispatch).toHaveBeenCalledWith(addPremiumRow({ row: newRow }));
  });

  it('should update allTableData when sortByColumn is called with a non-default column', () => {
    const column = ['someColumn', SORT_TYPES.ASC];
    const initialTableData = mockNaicSearchResult;
    component.tableDataCopy = initialTableData;
    component.naicTableData = initialTableData;
    component.sortByColumn(column);

    expect(component.naicTableData).toEqual(initialTableData);
  });

  it('should set paginated table data and scroll to top', () => {
    const mockEvent: PaginationModel = { paginatedItems: [] };
    const mockTableElement = document.createElement('div');
    spyOn(document, 'getElementById').and.returnValue(mockTableElement);
    component.getPaginatedItems(mockEvent);
    expect(component.paginatedTableData).toBe(mockEvent.paginatedItems);
    expect(document.getElementById).toHaveBeenCalledWith('divTable');
    expect(mockTableElement.scrollTop).toBe(0);
  });

  it('should set naicTableData and tableDataCopy when dataTable is set with valid data', () => {
    const mockNaicData: NaicData = [
      {
        uuid: '1',
        naicCode: '1234',
        companyName: 'Company Name',
        address: {},
        contactMethods: [],
        companyStatus: { companyStatusDescription: 'string' },
        approvalStatus: ApprovalStatus.APPROVED,
        effectiveDate: '',
      },
    ];

    component.dataTable = mockNaicData;

    expect(component.naicTableData).toEqual(mockNaicData);
    expect(component.tableDataCopy).toEqual(mockNaicData);
  });

  it('should filter out non-approved rows when dataTable is set', () => {
    const mockNaicData: NaicData = [
      {
        uuid: '1',
        naicCode: '1234',
        companyName: 'Company Name',
        address: {},
        contactMethods: [],
        companyStatus: { companyStatusDescription: 'string' },
        approvalStatus: ApprovalStatus.APPROVED,
        effectiveDate: '',
      },
      {
        uuid: '2',
        naicCode: '5678',
        companyName: 'Another Company',
        address: {},
        contactMethods: [],
        companyStatus: { companyStatusDescription: 'string' },
        approvalStatus: ApprovalStatus.AWAITINGAPPROVAL,
        effectiveDate: '',
      },
    ];

    component.dataTable = mockNaicData;

    expect(component.naicTableData.length).toBe(1);
    expect(component.naicTableData[0].uuid).toBe('1');
  });
});
