import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  ViewEncapsulation,
} from '@angular/core';
import { PaginationModel, TableColumn } from '@shared/models';
import { SORT_TYPES } from '@shared/consts/shared.enums';
import { NAIC_REPORTING_CODE_OPTIONS } from '@features/naic-reporting/const/naic-reporting.const';
import {
  FeinCodeTableColumns,
  GroupCodeTableColumns,
  NaicCodeTableColumns,
  PoolCodeTableColumns,
} from '@features/naic-reporting/const/naic-table-columns';
import { Store } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {
  Address,
  GroupCodeData1,
  NaicCodeData1,
  NaicData,
  PoolCodeData1,
} from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';
import * as _ from 'lodash';
import { sortTable } from 'src/app/utils/helper/helper';
import { NaicPremiumAllocation } from '@features/naic-reporting/models/naic.model';
import { TranslateService } from '@ngx-translate/core';
import { PremiumAllocationStoreService } from '@features/base-premium-allocation/services/premium-allocation-store.service';
import { addPremiumRow } from '@features/base-premium-allocation/store/actions/premium-allocation-base.action';
import { ApprovalStatus } from '@dxc.lm.sdk.angular/ipos-party-api';

@Component({
  selector: 'app-naic-table-container',
  templateUrl: './naic-table-container.component.html',
  styleUrls: ['./naic-table-container.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NaicTableContainerComponent implements OnInit, OnChanges, OnDestroy {
  private readonly destroy$ = new Subject<void>();
  readonly sortTypes = SORT_TYPES;
  readonly naicOptions = NAIC_REPORTING_CODE_OPTIONS;
  tableColumns: TableColumn[] = null;
  naicTableData: any = [];
  tableDataCopy = [];
  paginatedTableData = [];
  premiumTableData: NaicPremiumAllocation[] = [];

  @Input() selectedCode: NAIC_REPORTING_CODE_OPTIONS = NAIC_REPORTING_CODE_OPTIONS.NAIC;
  @Input() submitSearch = false;
  @Input() set dataTable(naicSearchResult: NaicData) {
    if (naicSearchResult) {
      this.naicTableData = [...naicSearchResult].filter((row) => row?.approvalStatus === ApprovalStatus.APPROVED);
      this.tableDataCopy = _.cloneDeep(this.naicTableData);
      this.sortByColumn(['companyName', 'asc']);
    } else {
      this.naicTableData = [];
      this.tableDataCopy = [];
    }
  }

  constructor(
    private store: Store<AppState>,
    private cd: ChangeDetectorRef,
    private translate: TranslateService,
    private premiumAllocationStoreService: PremiumAllocationStoreService
  ) {}

  ngOnInit(): void {
    this.getPremiumTableData();
  }

  getPremiumTableData(): void {
    this.premiumAllocationStoreService
      .getPremiumAllocatedRows()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: NaicPremiumAllocation[]) => {
        this.premiumTableData = data;
        this.cd.detectChanges();
      });
  }

  ngOnChanges(): void {
    this.bindTemplatesToColumns();
  }

  bindTemplatesToColumns(): void {
    switch (this.selectedCode) {
      case NAIC_REPORTING_CODE_OPTIONS.NAIC:
        this.tableColumns = [...NaicCodeTableColumns];
        break;
      case NAIC_REPORTING_CODE_OPTIONS.FEIN:
        this.tableColumns = [...FeinCodeTableColumns];
        break;
      case NAIC_REPORTING_CODE_OPTIONS.NAIC_POOL:
        this.tableColumns = [...PoolCodeTableColumns];
        break;
      case NAIC_REPORTING_CODE_OPTIONS.NAIC_GROUP:
        this.tableColumns = [...GroupCodeTableColumns];
        break;
    }
  }

  isAlreadyAdded(rowData: any): boolean {
    const codesToCheck = [rowData?.feinCode, rowData?.naicCode, rowData?.groupCode, rowData?.companyCode];

    const isPremiumRow = this.premiumTableData?.some((row: NaicPremiumAllocation) => codesToCheck.includes(row.code));
    const reinsuredAddedValue = isPremiumRow ? true : false;
    return reinsuredAddedValue;
  }

  sortByColumn(column: string[]): void {
    column[1] === SORT_TYPES.DEFAULT
      ? (this.naicTableData = sortTable(['companyName', 'asc'], this.tableDataCopy))
      : (this.naicTableData = sortTable(column, this.tableDataCopy));
  }

  selectedSortColumn(colName: string, sortType: string, colIndex: number): void {
    this.tableColumns.map((column) => {
      if (column.sortIcon) {
        column.sortIcon = this.sortTypes.DEFAULT;
      }
    });
    if (sortType === 'asc') {
      this.tableColumns[colIndex].sortIcon = this.sortTypes.ASC;
    }
    if (sortType === 'desc') {
      this.tableColumns[colIndex].sortIcon = this.sortTypes.DESC;
    }
    if (sortType === 'default') {
      this.tableColumns[colIndex].sortIcon = this.sortTypes.DEFAULT;
    }

    this.sortByColumn([colName, sortType]);
  }

  getPaginatedItems(event: PaginationModel): void {
    this.paginatedTableData = event.paginatedItems;
    const table = document.getElementById('divTable');
    if (table) {
      table.scrollTop = 0;
    }
  }

  onAdd(row: GroupCodeData1 | PoolCodeData1 | NaicCodeData1): void {
    const newRow: NaicPremiumAllocation = {
      id: '',
      codeType: '',
      code: '',
      reinsuredName: '',
      grossPremium: '',
      address: {},
      contactMethods: [],
      companyStatus: '',
    };
    switch (this.selectedCode) {
      case 'NAICCODE':
        const rowNaicData = row as NaicCodeData1;
        newRow.code = rowNaicData?.naicCode;
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC');
        newRow.reinsuredName = rowNaicData?.companyName;
        newRow.address = rowNaicData?.address;
        newRow.contactMethods.push(...(rowNaicData?.contactMethods as any));
        newRow.companyStatus = rowNaicData?.companyStatus?.companyStatusDescription;
        break;
      case 'FEINCODE':
        const rowFeinData = row as any;
        newRow.code = rowFeinData?.feinCode;
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.FEIN');
        newRow.reinsuredName = rowFeinData?.companyName;
        newRow.address = rowFeinData?.address;
        newRow.contactMethods.push(...(rowFeinData?.contactMethods as any));
        newRow.companyStatus = rowFeinData?.companyStatus?.companyStatusDescription;
        break;
      case 'GROUPCODE':
        const rowGroupData = row as GroupCodeData1;
        newRow.code = rowGroupData?.groupCode;
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC_GROUP');
        newRow.reinsuredName = rowGroupData?.groupName;
        break;
      case 'POOLCODE':
        const rowPoolData = row as PoolCodeData1;
        newRow.code = rowPoolData?.companyCode;
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC_POOL');
        newRow.reinsuredName = rowPoolData?.companyName;
        break;
      default:
        const defaultRow = row as NaicCodeData1;
        newRow.code = defaultRow?.naicCode;
        newRow.codeType = this.translate.instant('NAIC_REPORTING.NAIC_SEARCH_FORM.NAIC');
        newRow.reinsuredName = defaultRow?.companyName;
        newRow.address = defaultRow?.address;
        newRow.contactMethods.push(...(defaultRow?.contactMethods as any));
        newRow.companyStatus = defaultRow?.companyStatus?.companyStatusDescription;
        break;
    }

    const isDuplicate = this.premiumTableData?.some(
      (existingRow: NaicPremiumAllocation) =>
        existingRow?.code === newRow.code && existingRow.codeType === newRow.codeType
    );

    if (!isDuplicate) {
      this.store.dispatch(addPremiumRow({ row: newRow }));
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
