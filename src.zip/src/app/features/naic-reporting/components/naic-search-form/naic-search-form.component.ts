import { ChangeDetectionStrategy, Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { SORT_TYPES } from '@shared/consts/shared.enums';
import { NAIC_REPORTING_CODE_OPTIONS } from '@features/naic-reporting/const/naic-reporting.const';

@Component({
  selector: 'app-naic-search-form',
  templateUrl: './naic-search-form.component.html',
  styleUrls: ['./naic-search-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NaicSearchFormComponent implements OnInit {
  readonly naicReportingCodeOptions = NAIC_REPORTING_CODE_OPTIONS;
  readonly sortTypes = SORT_TYPES;

  isSelected: string = NAIC_REPORTING_CODE_OPTIONS.NAIC;

  @Output() codeType = new EventEmitter<string>();

  constructor() {}

  ngOnInit(): void {
    this.codeType.emit(this.isSelected);
  }

  selectCode(value: string): void {
    this.isSelected = value;
    this.codeType.emit(this.isSelected);
  }
}
