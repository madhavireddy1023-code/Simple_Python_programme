import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NaicSearchFormComponent } from './naic-search-form.component';
import { TranslateModule } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { NAIC_REPORTING_CODE_OPTIONS } from '../../const/naic-reporting.const';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

describe('NaicSearchFormComponent', () => {
  let component: NaicSearchFormComponent;
  let fixture: ComponentFixture<NaicSearchFormComponent>;
  let store: MockStore<any>;
  let el: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NaicSearchFormComponent],
      imports: [TranslateModule.forRoot({})],
      providers: [provideMockStore()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NaicSearchFormComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    store = TestBed.inject(MockStore);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set selected code on radio button click to isSelected', () => {
    component.selectCode(NAIC_REPORTING_CODE_OPTIONS.FEIN);
    expect(component.isSelected).toBe(NAIC_REPORTING_CODE_OPTIONS.FEIN);
  });
});
