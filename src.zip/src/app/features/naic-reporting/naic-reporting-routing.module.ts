import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NaicReportingComponent } from './main/naic-reporting.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: NaicReportingComponent,
    resolve: {},
    canActivate: [],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NaicReportingRoutingModule {}
