import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { NAIC_REPORTING_CODE_OPTIONS } from '../const/naic-reporting.const';
import { NaicData } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';
import { Observable, Subject } from 'rxjs';
import { NaicReportingStoreService } from '../services/naic-reporting-store.service';
import { ActivatedRoute, Params } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { TypeOfLlyodsPremiumsProcessor } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { ORIGINAL_PREMIUM } from '@shared/consts/shared.consts';
import { PremiumAllocationStoreService } from '@features/base-premium-allocation/services/premium-allocation-store.service';

@Component({
  selector: 'app-naic-reporting',
  templateUrl: './naic-reporting.component.html',
  styleUrls: ['./naic-reporting.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NaicReportingComponent implements OnInit, OnDestroy {
  private destroyed$ = new Subject<void>();
  codeType: NAIC_REPORTING_CODE_OPTIONS = NAIC_REPORTING_CODE_OPTIONS.NAIC;
  dataTable$: Observable<NaicData>;
  submitSearch = false;
  responseData$: Observable<any>;
  typeOfPremium: TypeOfLlyodsPremiumsProcessor = ORIGINAL_PREMIUM;
  premiumId: string;
  originalPremiumClicked = false;
  isOriginalPremiumIncompleteShown = false;
  TypeOfLlyodsPremiumsProcessor = TypeOfLlyodsPremiumsProcessor;

  constructor(
    private route: ActivatedRoute,
    private sectionDetailsStoreService: SectionDetailsStoreService,
    private naicReportingStoreService: NaicReportingStoreService,
    private globalAlertStoreService: GlobalAlertStoreService,
    protected cdr: ChangeDetectorRef,
    private premiumAllocationStoreService: PremiumAllocationStoreService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.pipe(takeUntil(this.destroyed$)).subscribe((params: Params) => {
      this.sectionDetailsStoreService.getPremiumData(params?.premiumId, params?.transactionType);
      this.typeOfPremium = params?.transactionType;
    });
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.globalAlertStoreService.clearGlobalResponse();
  }

  onSearch(codeType): void {
    this.codeType = codeType;
    this.dataTable$ = this.naicReportingStoreService.selectSearchNaicResult();
    this.submitSearch = true;
  }

  getOriginalPremium(): void {
    this.originalPremiumClicked = !this.originalPremiumClicked;
  }

  isOriginalPremiumIncomplete(event: boolean): void {
    this.isOriginalPremiumIncompleteShown = event;
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {
    this.premiumAllocationStoreService.clearData();
    this.destroyed$.next();
    this.destroyed$.complete();
    this.originalPremiumClicked = false;
  }
}
