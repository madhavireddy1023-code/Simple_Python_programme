import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NaicReportingComponent } from './naic-reporting.component';
import { TranslateModule } from '@ngx-translate/core';
import { DebugElement } from '@angular/core';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { NaicReportingStoreService } from '../services/naic-reporting-store.service';
import { By } from '@angular/platform-browser';

describe('NAICReportingComponent', () => {
  let component: NaicReportingComponent;
  let fixture: ComponentFixture<NaicReportingComponent>;
  let sectionDetailsStoreService: SectionDetailsStoreService;
  let globalAlertStoreService: GlobalAlertStoreService;
  let naicReportingStoreService: NaicReportingStoreService;
  let el: DebugElement;

  beforeEach(async () => {
    const naicReportingStoreServiceSpy = jasmine.createSpyObj('NaicReportingStoreService', ['selectSearchNaicResult']);
    await TestBed.configureTestingModule({
      declarations: [NaicReportingComponent],
      imports: [TranslateModule.forRoot({}), RouterTestingModule],
      providers: [
        MockStore,
        provideMockStore(),
        SectionDetailsStoreService,
        GlobalAlertStoreService,
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: of({ premiumId: 'a9cffd94-22dc-4221-a4c7-fc81f5a27e46', transactionType: 'Original_Premium' }),
          },
        },
        { provide: NaicReportingStoreService, useValue: naicReportingStoreServiceSpy },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NaicReportingComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    globalAlertStoreService = TestBed.inject(GlobalAlertStoreService);
    sectionDetailsStoreService = TestBed.inject(SectionDetailsStoreService);
    naicReportingStoreService = TestBed.inject(NaicReportingStoreService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should update codeType property when onSearch is called', () => {
    const mockCodeType = 'Naic';
    component.onSearch(mockCodeType);
    expect(component.codeType).toEqual(mockCodeType);
  });

  it('should call getPremiumData with params from queryParams', () => {
    spyOn(sectionDetailsStoreService, 'getPremiumData');
    component.ngOnInit();
    expect(sectionDetailsStoreService.getPremiumData).toHaveBeenCalledWith(
      'a9cffd94-22dc-4221-a4c7-fc81f5a27e46',
      'Original_Premium'
    );
  });

  it('should show alert when isOriginalPremiumIncomplete is called with true', () => {
    component.isOriginalPremiumIncomplete(true);
    fixture.detectChanges();
    const originalPremiumIncompleteWarning = el.query(By.css('#incompleteOriginalPremiumWarning')).nativeElement;
    expect(originalPremiumIncompleteWarning).toBeTruthy();
  });

  it('should hide alert when isOriginalPremiumIncomplete is called with false', () => {
    component.isOriginalPremiumIncomplete(false);
    fixture.detectChanges();
    const originalPremiumIncompleteWarning = el.query(By.css('#incompleteOriginalPremiumWarning'));
    expect(originalPremiumIncompleteWarning).toBeFalsy();
  });
});
