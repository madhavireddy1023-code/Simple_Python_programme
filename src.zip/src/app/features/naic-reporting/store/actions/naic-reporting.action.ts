import { NaicData } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';
import { createAction, props } from '@ngrx/store';

const NAIC_PREFIX = '[NAICReinsured]';

// Search naic reinsured request
const SEARCH_NAIC_REINSURED = `${NAIC_PREFIX} SEARCH_NAIC_REINSURED`;
export const searchNaicReinsured = createAction(SEARCH_NAIC_REINSURED, props<{ searchObject: any }>());

// Set naic reinsured result
const SET_SEARCH_NAIC_REINSURED_RESULT = `${NAIC_PREFIX} SET_SEARCH_NAIC_REINSURED_RESULT`;
export const setSearchNaicReinsuredResult = createAction(
  SET_SEARCH_NAIC_REINSURED_RESULT,
  props<{ searchNaicReinsuredResult: NaicData }>()
);
