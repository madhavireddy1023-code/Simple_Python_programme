import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Action } from '@ngrx/store';
import { Observable } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';
import { searchNaicReinsured, setSearchNaicReinsuredResult } from './naic-reporting.action';

describe('naic reporting Actions', () => {
  const actions$ = new Observable<Action>();
  let scheduler: TestScheduler;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideMockActions(() => actions$)],
    });

    scheduler = new TestScheduler((actual, expected) => {
      expect(actual).toEqual(expected);
    });
  });

  it('should return correct types', () => {
    // Search naic request
    expect(searchNaicReinsured.type).toEqual('[NAICReinsured] SEARCH_NAIC_REINSURED');

    // Set search naic result
    expect(setSearchNaicReinsuredResult.type).toEqual('[NAICReinsured] SET_SEARCH_NAIC_REINSURED_RESULT');
  });
});
