import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable, of, throwError } from 'rxjs';
import { NaicReinsuredEffects } from './naic-reporting.effects';
import * as actions from '../actions/naic-reporting.action';
import { NaicApiService } from 'src/app/api/naic-surplus-lines-api';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Action } from '@ngrx/store';
import { NaicData } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';

describe('NaicReinsuredEffects', () => {
  let actions$: Observable<Action>;
  let effects: NaicReinsuredEffects;
  let naicApiService: jasmine.SpyObj<NaicApiService>;

  beforeEach(() => {
    const spy = jasmine.createSpyObj('NaicApiService', ['apiV2NaicDataGet']);

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [NaicReinsuredEffects, provideMockActions(() => actions$), { provide: NaicApiService, useValue: spy }],
    });

    effects = TestBed.inject(NaicReinsuredEffects);
    naicApiService = TestBed.inject(NaicApiService) as jasmine.SpyObj<NaicApiService>;
  });

  it('should return setSearchNaicReinsuredResult action on success', (done) => {
    const searchObject = { typeOfCode: 'someType', value: 'someValue' };
    const searchResult: NaicData = [
      {
        uuid: '1',
        groupCode: '12',
        groupName: 'mock description',
        effectiveDate: '01-01-2024',
        deprecatedDate: '01-01-2024',
      },
    ];

    const action = actions.searchNaicReinsured({ searchObject });
    const completion = actions.setSearchNaicReinsuredResult({ searchNaicReinsuredResult: searchResult });

    actions$ = of(action);
    naicApiService.apiV2NaicDataGet.and.returnValue(of(searchResult as any));

    effects.searchNaicReinsured$.subscribe((resultAction) => {
      expect(resultAction).toEqual(completion);
      done();
    });
  });

  it('should expect multiple actions on error', (done) => {
    const searchObject = { typeOfCode: 'someType', value: 'someValue' };
    const action = actions.searchNaicReinsured({ searchObject });
    const error = { message: 'error message' };

    actions$ = of(action);
    naicApiService.apiV2NaicDataGet.and.returnValue(throwError(error));

    const expectedActions = [
      actions.setSearchNaicReinsuredResult({ searchNaicReinsuredResult: [] }),

      loadGlobalAlert({
        response: { ...error, isGlobalAlert: true },
      }),
    ];

    const actionsEmitted = [];
    effects.searchNaicReinsured$.subscribe({
      next: (actionEmitted) => {
        actionsEmitted.push(actionEmitted);
      },
      error: done,
      complete: () => {
        expect(actionsEmitted.length).toBeGreaterThanOrEqual(expectedActions.length - 1);
        done();
      },
    });
  });
});
