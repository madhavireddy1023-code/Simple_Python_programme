import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { from, of } from 'rxjs';
import * as actions from '../actions/naic-reporting.action';
import { catchError, map, switchMap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { setEtagForSaveNaicSlPremiumAllocation } from '@features/base-premium-allocation/store/actions/premium-allocation-base.action';
import { NaicApiService } from 'src/app/api/naic-surplus-lines-api';
import { ScrollUp } from 'src/app/utils/helper';

@Injectable()
export class NaicReinsuredEffects {
  constructor(private actions$: Actions, public httpClient: HttpClient, private naicApiService: NaicApiService) {}

  // Search naic reinsured
  searchNaicReinsured$ = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.searchNaicReinsured),
      switchMap((action) => {
        return this.naicApiService.apiV2NaicDataGet(action.searchObject.typeOfCode, action.searchObject.value).pipe(
          switchMap((response: any) => {
            return of(actions.setSearchNaicReinsuredResult({ searchNaicReinsuredResult: response }));
          }),
          catchError((error) => {
            ScrollUp(0, 0);
            let actionsArray = [];

            if (error.status === 404) {
              actionsArray = [
                actions.setSearchNaicReinsuredResult({ searchNaicReinsuredResult: [] }),
                loadGlobalAlert({
                  response: {
                    responseMessage: 'No reinsureds match the search criteria',
                    status: 404,
                    isGlobalAlert: true,
                  },
                }),
              ];

              return from(actionsArray);
            }

            actionsArray = [
              actions.setSearchNaicReinsuredResult({ searchNaicReinsuredResult: [] }),
              loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }),
            ];

            return from(actionsArray);
          })
        );
      })
    )
  );
}
