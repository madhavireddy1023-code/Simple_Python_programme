import { Action } from '@ngrx/store';
import { NaicReinsuredReducer, initialState } from './naic-reporting.reducers';
import * as actions from '../actions/naic-reporting.action';
import { mockNaicSearchResult } from '@features/naic-reporting/const/mock-naic-search-result.const';

describe('NaicReportingReducer', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = NaicReinsuredReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should update the state of [mockSearchNaicResults]', () => {
    const expectedState = mockNaicSearchResult;
    const action = actions.setSearchNaicReinsuredResult({ searchNaicReinsuredResult: expectedState });
    const newState = NaicReinsuredReducer(initialState, action);
    expect(newState.searchNaicReinsuredResult).toEqual(expectedState);
  });
});
