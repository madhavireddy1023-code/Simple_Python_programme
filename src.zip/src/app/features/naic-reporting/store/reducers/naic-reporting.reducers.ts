import { NaicReinsuredState } from '@features/naic-reporting/models/naic.model';
import { Action, ActionReducer, createReducer, on } from '@ngrx/store';

import * as actions from '../actions/naic-reporting.action';
import * as _ from 'lodash';

export const initialState: NaicReinsuredState = {
  searchNaicReinsuredResult: null,
  etag: '',
};

export const NaicReinsuredReducer: ActionReducer<NaicReinsuredState, Action> = createReducer(
  initialState,

  // update state search naic result
  on(actions.setSearchNaicReinsuredResult, (state: NaicReinsuredState, action) =>
    _.setWith(_.clone(state), 'searchNaicReinsuredResult', action.searchNaicReinsuredResult, _.clone)
  )
);
