import { mockNaicSearchResult } from '@features/naic-reporting/const/mock-naic-search-result.const';
import * as selectors from './naic-reporting.selectors';

describe('NaicReportingSelector', () => {
  const state = {
    searchNaicReinsuredResult: mockNaicSearchResult,
    etag: '',
  };

  it('should select selectSearchQueriesResult', () => {
    const expectedData = mockNaicSearchResult;
    const searchNaicReportingSelector = selectors.selectSearchNaicResult.projector(state);
    expect(searchNaicReportingSelector).toEqual(expectedData);
  });
});
