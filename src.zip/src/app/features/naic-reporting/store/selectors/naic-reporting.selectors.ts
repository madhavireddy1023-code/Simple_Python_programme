import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.naic;

// Select search naic result
export const selectSearchNaicResult = createSelector(selectState, (state) => state?.searchNaicReinsuredResult);
