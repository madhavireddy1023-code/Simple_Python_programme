import { Component, EventEmitter, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-close-query-warning',
  templateUrl: './close-query-warning.component.html',
  styleUrls: ['./close-query-warning.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CloseQueryWarningComponent {
  @Output() canceled: EventEmitter<boolean> = new EventEmitter();

  @Output() confirmed: EventEmitter<boolean> = new EventEmitter();

  constructor() {}

  cancel(): void {
    this.canceled.emit(true);
  }

  confirm(): void {
    this.confirmed.emit(true);
  }
}
