import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { CloseQueryWarningComponent } from './close-query-warning.component';
import { TranslateModule } from '@ngx-translate/core';

describe('CloseQueryWarningComponent', () => {
  let component: CloseQueryWarningComponent;
  let fixture: ComponentFixture<CloseQueryWarningComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CloseQueryWarningComponent],
      imports: [TranslateModule.forRoot()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CloseQueryWarningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should allow to cancel', () => {
    spyOn(component.canceled, 'emit');

    const $component = fixture.nativeElement;
    const $btn = $component.querySelector('#closeQueryCancel');
    $btn.click();
    expect(component.canceled.emit).toHaveBeenCalled();
  });

  it('should allow to confirm', () => {
    spyOn(component.confirmed, 'emit');

    const $component = fixture.nativeElement;
    const $btn = $component.querySelector('#closeQueryConfirm');
    $btn.click();
    expect(component.confirmed.emit).toHaveBeenCalled();
  });
});
