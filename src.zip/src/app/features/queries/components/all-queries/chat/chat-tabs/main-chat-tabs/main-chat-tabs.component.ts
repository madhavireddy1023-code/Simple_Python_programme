import { Component, Input, ViewEncapsulation } from '@angular/core';
import { TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { QueriesStoreService } from '@features/queries/services/queries.store.service';
import { Role } from '@shared/consts/shared.enums';
import { QueryData } from '@dxc.lm.sdk.angular/portal-queries-api';

@Component({
  selector: 'app-main-chat-tabs',
  templateUrl: './main-chat-tabs.component.html',
  styleUrls: ['./main-chat-tabs.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MainChatTabsComponent {
  readonly rolesList = Role;

  activeTabIndex = 0;
  rolesData: string[];
  technicianData: TechnicianSVDetails;

  @Input() activeQueries: Array<QueryData>;
  @Input() allQueries: Array<QueryData>;
  @Input() closedQueries: Array<QueryData>;
  @Input() set roles(roles: string[]) {
    if (roles?.length) {
      this.rolesData = roles;
    }
  }
  @Input() selectedQueryId: string;
  @Input() set technicianDetails(technicianDetails: TechnicianSVDetails) {
    if (technicianDetails) {
      this.technicianData = technicianDetails;
    }
  }

  constructor(private queriesStoreService: QueriesStoreService) {}

  getQueryById(id: string): void {
    this.selectedQueryId = id;
    this.queriesStoreService.getQueryById(id);
  }

  tabClicked(tabIndex: number): void {
    this.activeTabIndex = tabIndex;
  }
}
