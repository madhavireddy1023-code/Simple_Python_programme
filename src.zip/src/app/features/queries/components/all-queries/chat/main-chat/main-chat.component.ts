import { Component, Input, ViewChild, ViewEncapsulation } from '@angular/core';
import { QueriesStoreService } from '@features/queries/services/queries.store.service';
import { QueryDetail, TechnicianSVDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Role } from '@shared/consts/shared.enums';
import { Query, QueryData } from '@dxc.lm.sdk.angular/portal-queries-api';
import * as _ from 'lodash';
import { UpdateQuery } from '@dxc.lm.sdk.angular/portal-queries-api';
import { ContactMethods, Party } from '@dxc.lm.sdk.angular/ipos-party-api';
import { ActivatedRoute } from '@angular/router';
import { MainChatTabsComponent } from '../chat-tabs/main-chat-tabs/main-chat-tabs.component';

@Component({
  selector: 'app-main-chat',
  templateUrl: './main-chat.component.html',
  styleUrls: ['./main-chat.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MainChatComponent {
  readonly rolesList = Role;
  allQueriesData: Array<QueryData>;
  createdUpdatedQueryData: Query;
  hideReassignAlertMsg: boolean;
  queryDetails: Query;
  selectedId: string;
  showRefreshBanner: boolean;
  @Input() activeQueries: Array<QueryData>;
  @Input() set allQueries(allQueries: Array<QueryData>) {
    this.allQueriesData = allQueries;
    if (allQueries?.length && this.queryDetails) {
      this.shiftSelectQuery();
    }
    // If BE return queries list not correct having created or updated query then show Refresh page banner
    if (this.createdUpdatedQueryData) {
      if (this.createdUpdatedQueryData?.status === QueryData.StatusEnum.ACTIVE) {
        this.showRefreshBanner = !allQueries?.some((query) => query?.queryId === this.createdUpdatedQueryData?.queryId);
      } else if (this.createdUpdatedQueryData?.status === QueryData?.StatusEnum?.CLOSED) {
        this.showRefreshBanner = allQueries.some(
          (query) =>
            query?.queryId === this.createdUpdatedQueryData?.queryId && query?.status === QueryData?.StatusEnum?.ACTIVE
        );
      }
    } else {
      this.showRefreshBanner = false;
    }
  }

  @Input() set createdUpdatedQuery(createdUpdatedQuery: Query) {
    this.createdUpdatedQueryData = createdUpdatedQuery;
  }

  @Input() closedQueries: Array<QueryData>;
  @Input() contactMethods: ContactMethods;
  @Input() party: Party;
  @Input() partyOrganisationId: string;
  @Input() partyOrganisationRole: string;
  @Input() roles: string[];
  @Input() set selectedQueryId(selectedQueryId: string) {
    this.selectedId = selectedQueryId;
  }

  @Input() set selectedQueryDetails(queryDetails: Query) {
    this.queryDetails = queryDetails;
    if (this.allQueriesData?.length && queryDetails) {
      this.shiftSelectQuery();
    }

    // Reset hideReassignAlertMsg with every query selected
    this.hideReassignAlertMsg = false;
  }
  @Input() technicianDetails: TechnicianSVDetails;
  @Input() userRoles: string[];

  @ViewChild(MainChatTabsComponent) mainChatTabsView: MainChatTabsComponent;

  constructor(private queriesStoreService: QueriesStoreService, private route: ActivatedRoute) {}

  updateQuery(query: any): void {
    const queryId = query?.queryId;
    const workPackageReference = query?.externalIdentifiers?.premiumIdentifiers?.workPackageReference;
    const updateQueryObj: UpdateQuery = {
      status: query?.queryStatus,
      validResolvedReasonInd: query?.validResolvedReasonInd,
    };
    this.queriesStoreService.updateQueryStatus(queryId, updateQueryObj, workPackageReference);
  }

  closeReassignAlert(): void {
    this.hideReassignAlertMsg = true;
  }

  shiftSelectQuery(): void {
    // Early return if necessary data is missing
    if (!this.allQueriesData || !this.queryDetails) {
      return;
    }
    const allQueriesWithoutSelectedQuery = this.allQueriesData?.filter(
      (obj) => obj.queryId !== this.queryDetails?.queryId
    );
    const sortedQueries = _.sortBy(allQueriesWithoutSelectedQuery, ['createdAt'])?.reverse();

    this.allQueriesData = [this.queryDetails, ...sortedQueries];
  }

  clickRefreshLink(): void {
    const selectedWPR = this.route?.snapshot?.queryParamMap?.get('wpr');
    this.queriesStoreService.getQueries(selectedWPR);
    this.queriesStoreService.clearCreatedUpdatedQuery();
    this.mainChatTabsView.activeTabIndex = 0;
  }
}
