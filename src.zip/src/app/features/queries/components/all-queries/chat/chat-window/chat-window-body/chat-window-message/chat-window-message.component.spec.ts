import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { ChatWindowMessageComponent } from './chat-window-message.component';
import { SharedModule } from '@shared/shared.module';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { mockQuery } from '@features/queries/consts/chat.consts';
import { TranslateModule } from '@ngx-translate/core';

describe('ChatWindowMessageComponent', () => {
  let component: ChatWindowMessageComponent;
  let fixture: ComponentFixture<ChatWindowMessageComponent>;
  let el: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChatWindowMessageComponent],
      imports: [SharedModule, TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatWindowMessageComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('subQueries visibility', () => {
    it('should show sub query container for initial message', () => {
      component.chatMessage = mockQuery?.messages[0];
      component.isInitialMessage = true;
      fixture.detectChanges();

      const subQuery = el.query(By.css('.subQuery'));
      expect(subQuery).toBeTruthy();

      const queryMessage = el.query(By.css('#queryMessage'));
      expect(queryMessage).toBeFalsy();
    });

    it('should show all sub queries', () => {
      component.chatMessage = mockQuery?.messages[0];
      component.isInitialMessage = true;
      fixture.detectChanges();

      expect(el.query(By.css('#subQuery-1'))).toBeTruthy();
      expect(el.query(By.css('#subQuery-2'))).toBeTruthy();
    });

    it('should not show sub queries for not initial messages', () => {
      component.chatMessage = mockQuery?.messages[0];
      component.isInitialMessage = false;
      fixture.detectChanges();

      const queryMessage = el.query(By.css('#queryMessage'));
      expect(queryMessage).toBeTruthy();
      const subQuery = el.query(By.css('.subQuery'));
      expect(subQuery).toBeFalsy();
    });

    it('should show queryMessage container for normal messages', () => {
      component.chatMessage = mockQuery?.messages[1];
      fixture.detectChanges();

      const queryMessage = el.query(By.css('#queryMessage'));
      expect(queryMessage).toBeTruthy();
      const subQuery = el.query(By.css('.subQuery'));
      expect(subQuery).toBeFalsy();
    });
  });

  describe('Contact cards visability', () => {
    it('should contact card appear on mouse in and disappear on mouse out', fakeAsync(() => {
      const chatLabel = fixture.nativeElement.querySelector('.chat-label');
      component.chatMessage = mockQuery?.messages[1];
      fixture.detectChanges();

      chatLabel.dispatchEvent(new Event('mouseover'));

      const contactCard = fixture.nativeElement.querySelector('.contact-card');
      expect(contactCard).toBeTruthy();

      chatLabel.dispatchEvent(new Event('mouseout'));
      fixture.detectChanges();
      tick();

      const contactCardAfterHover = fixture.nativeElement.querySelector('.contact-card');
      const computedStyleAfterHover = window.getComputedStyle(contactCardAfterHover);
      expect(computedStyleAfterHover.display).toBe('none');
    }));

    it('should show all contacts', () => {
      component.chatMessage = mockQuery?.messages[0];
      fixture.detectChanges();

      expect(el.queryAll(By.css('.contact-card-info')).length).toBe(4);
    });

    it('should show correct contact label', () => {
      component.chatMessage = mockQuery?.messages[1];
      fixture.detectChanges();

      const $contactLabels = el.queryAll(By.css('.contact-card-label'));
      expect($contactLabels[0].nativeElement.innerHTML).toBe('ALL_QUERIES.TEL: ');
      expect($contactLabels[1].nativeElement.innerHTML).toBe('ALL_QUERIES.EMAIL: ');
    });

    it('should show contact value', () => {
      component.chatMessage = mockQuery?.messages[1];
      fixture.detectChanges();

      const $contactValues = el.queryAll(By.css('.contact-card-label + span'));
      expect($contactValues[0].nativeElement.innerHTML).toBe('019999999');
      expect($contactValues[1].nativeElement.innerHTML).toBe('john@acarrier.com');
    });
  });

  afterEach(() => {
    fixture.destroy();
  });
});
