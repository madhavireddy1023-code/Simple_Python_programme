import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Query } from '@dxc.lm.sdk.angular/portal-queries-api';
import { Role } from '@shared/consts/shared.enums';

@Component({
  selector: 'app-chat-tab-item',
  templateUrl: './chat-tab-item.component.html',
  styleUrls: ['./chat-tab-item.component.scss'],
})
export class ChatTabItemComponent {
  readonly roles = Role;

  @Input() queryItem: Query;
  @Input() isActive: boolean;
  @Output() selectQuery = new EventEmitter();

  constructor(private route: ActivatedRoute) {}
  nullValueChecker(data: any): any {
    return data ? data : '-';
  }

  selectQueryEvent(id: string): void {
    this.selectQuery.emit(id);
    const selectedWpr = this.queryItem?.externalIdentifiers?.premiumIdentifiers?.workPackageReference;
    const selectedWorkflowSubmissionId = this.queryItem?.externalIdentifiers?.premiumIdentifiers?.premiumId;
    // Replace queryId, wpr and workflow submission id in the url on select new query
    window.history.replaceState(
      {},
      '',
      `${window.location.pathname}?wpr=${selectedWpr}&workflowSubmissionId=${selectedWorkflowSubmissionId}&queryId=${id}`
    );
  }
}
