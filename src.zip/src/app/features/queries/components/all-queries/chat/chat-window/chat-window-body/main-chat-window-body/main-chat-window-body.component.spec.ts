import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { MainChatWindowBodyComponent } from './main-chat-window-body.component';
import { mockQuery } from '@features/queries/consts/chat.consts';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { QueryMessage } from '@dxc.lm.sdk.angular/portal-queries-api';

describe('MainChatWindowBodyComponent', () => {
  let component: MainChatWindowBodyComponent;
  let fixture: ComponentFixture<MainChatWindowBodyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainChatWindowBodyComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainChatWindowBodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test chatMessages setting and scrollToLastMessage function called', () => {
    spyOn(component, 'scrollToLastMessage');
    const messages = mockQuery?.messages;
    component.chatMessages = mockQuery?.messages;
    expect(component.allMessages).toEqual(messages);
    expect(component.scrollToLastMessage).toHaveBeenCalled();
  });
  it('should have access to virtualScrollViewport', () => {
    // Arrange: Ensure that virtualScrollViewport is defined
    fixture.detectChanges();

    expect(component.virtualScrollViewport).toBeTruthy();
    expect(component.virtualScrollViewport).toBeDefined();
    expect(component.virtualScrollViewport instanceof CdkVirtualScrollViewport).toBe(false);
  });

  it('should display the date correctly', () => {
    const mockDate = new Date('01-01-2022'); // Replace with your desired date

    component.dateOfChat = mockDate;
    fixture.detectChanges();

    const $dateContainer = fixture.nativeElement.querySelector('#headerDate');
    expect($dateContainer.textContent.trim()).toBe('01-01-2022');
  });

  it('should scroll to the last message', () => {
    const mockMessages: QueryMessage[] = [];
    spyOn(document, 'getElementsByClassName').and.returnValue(null);

    component.chatMessages = mockMessages;

    fixture.detectChanges();

    expect(document.getElementsByClassName).not.toHaveBeenCalledWith(
      'chat-messages cdk-virtual-scroll-orientation-vertical'
    );
    expect(document.getElementsByClassName).not.toHaveBeenCalledTimes(2); // Called in setTimeout
  });
  afterEach(() => {
    fixture.destroy();
  });
});
