import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { MainChatTabsComponent } from './main-chat-tabs.component';
import { PlusNumberPipe } from '@shared/pipe/plus-number.pipe';
import { InfoHeaderStoreService } from '@shared/services/info-header/info-header.store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { QueriesStoreService } from '@features/queries/services/queries.store.service';
describe('MainChatTabsComponent', () => {
  let component: MainChatTabsComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<MainChatTabsComponent>;
  let infoHeaderStoreService: InfoHeaderStoreService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainChatTabsComponent, PlusNumberPipe],
      imports: [TranslateModule.forRoot()],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [MockStore, provideMockStore(), QueriesStoreService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainChatTabsComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    infoHeaderStoreService = TestBed.inject(InfoHeaderStoreService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test technicianDetails setting', () => {
    const technicianDetails = {
      workPackageRef: 'ABCDEF123',
    };
    component.technicianDetails = technicianDetails;
    expect(component.technicianData).toEqual(technicianDetails);
  });

  it('should test roles setting', () => {
    const roles = [component.rolesList.PROCESS_TEAM_MANAGER];
    component.roles = roles;
    expect(component.rolesData).toEqual(roles);
  });

  it('should show/hide work package container for Technician', () => {
    component.technicianData = {
      workPackageRef: 'ABCDEF123',
    };
    component.rolesData = [component.rolesList.PROCESS_TEAM_MANAGER];
    fixture.detectChanges();
    const workPackageContainer = el.query(By.css('.work-package-container'));
    expect(workPackageContainer).toBeTruthy();
  });

  it('should show/hide work package container for broker/carrier', () => {
    component.technicianData = {
      workPackageRef: 'ABCDEF123',
    };
    fixture.detectChanges();
    const workPackageContainer = el.query(By.css('.work-package-container'));
    component.rolesData = [component.rolesList.PROCESS_QUERY_BROKER];
    expect(workPackageContainer).toBeTruthy();
  });
});
