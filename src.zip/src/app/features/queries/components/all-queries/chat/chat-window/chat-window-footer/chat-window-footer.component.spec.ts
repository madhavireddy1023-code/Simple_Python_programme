import { QueryFlowType } from '@features/queries/consts/chat.consts';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ChatWindowFooterComponent } from './chat-window-footer.component';
import { QUERY_STATUS } from '@features/queries/consts/queries.consts';
import { QueriesStoreService } from '@features/queries/services/queries.store.service';
import { Query } from '@dxc.lm.sdk.angular/portal-queries-api';
import { Role } from '@shared/consts/shared.enums';
import { activeQueriesData } from '@features/section-details/consts/mock-queries.consts';
import {
  mockContactMethods,
  mockParty,
  mockPartyInfoUser,
  mockPartyInfoUserBroker,
} from '@shared/consts/mock-party.const';
import { ContactMethod } from '@dxc.lm.sdk.angular/ipos-party-api';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { Subject } from 'rxjs';
import { DatePipe } from '@angular/common';

const authMock = {
  roles$: new Subject(),
};

describe('ChatWindowFooterComponent', () => {
  let component: ChatWindowFooterComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<ChatWindowFooterComponent>;
  let queriesStoreService: QueriesStoreService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChatWindowFooterComponent],
      imports: [TranslateModule.forRoot(), FormsModule, ReactiveFormsModule],
      providers: [
        MockStore,
        provideMockStore(),
        QueriesStoreService,
        { provide: AuthenticationService, useValue: authMock },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatWindowFooterComponent);
    component = fixture.componentInstance;
    component.queryDetails = activeQueriesData[1];
    el = fixture.debugElement;
    queriesStoreService = TestBed.inject(QueriesStoreService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test characters count if not exceed max length', () => {
    spyOn(component, 'getValue').and.callThrough();
    const messageInput = el.query(By.css('#typeMessageInput')).nativeElement;
    messageInput.value = 'test';
    messageInput.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(component.getValue).toHaveBeenCalled();
    expect(component.valueLength).toEqual(4);
    const charsCount = el.query(By.css('#charsCountDown')).nativeElement;
    expect(charsCount).not.toHaveClass('char-exceed-limit');
  });

  it('should test characters count if exceeds max length', () => {
    spyOn(component, 'getValue').and.callThrough();
    component.maxValueLength = 10;
    const messageInput = el.query(By.css('#typeMessageInput')).nativeElement;
    messageInput.value = 'test test test';
    messageInput.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(component.getValue).toHaveBeenCalled();
    expect(component.valueLength).toEqual(-4);
    const charsCount = el.query(By.css('#charsCountDown')).nativeElement;
    expect(charsCount).toHaveClass('char-exceed-limit');
  });

  it('should allow type a message for active query', () => {
    const $component = fixture.nativeElement;

    component.queryDetails = { status: QUERY_STATUS.CLOSED } as Query;
    fixture.detectChanges();

    expect($component.querySelector('#typeMessageInput')).toBeFalsy();
    expect($component.querySelector('#queryClosedMsg')).toBeInstanceOf(HTMLElement);

    component.queryDetails = { status: QUERY_STATUS.ACTIVE } as Query;
    fixture.detectChanges();

    expect($component.querySelector('#typeMessageInput')).toBeInstanceOf(HTMLElement);
    expect($component.querySelector('#queryClosedMsg')).toBeFalsy();
  });

  it('should not allow type message for closed query', () => {
    const $component = fixture.nativeElement;

    component.queryDetails = { status: QUERY_STATUS.ACTIVE } as Query;
    fixture.detectChanges();

    expect($component.querySelector('#typeMessageInput')).toBeInstanceOf(HTMLElement);
    expect($component.querySelector('#queryClosedMsg')).toBeFalsy();

    component.queryDetails = { status: QUERY_STATUS.CLOSED } as Query;
    fixture.detectChanges();

    expect($component.querySelector('#typeMessageInput')).toBeFalsy();
    expect($component.querySelector('#queryClosedMsg')).toBeInstanceOf(HTMLElement);
  });

  it('should allow send a message', () => {
    spyOn(queriesStoreService, 'sendMessage').and.callFake(() => {});
    const testMsgContent = 'test message';
    const testQuery = { testQuery: 'testQuery', status: QUERY_STATUS.ACTIVE } as any;

    component.queryDetails = testQuery;

    el.query(By.css('#typeMessageInput')).nativeElement.value = testMsgContent;
    el.query(By.css('#typeMessageInput')).nativeElement.dispatchEvent(new Event('input'));
    el.query(By.css('#sendMessageBtn')).nativeElement.click();
    fixture.detectChanges();

    expect(queriesStoreService.sendMessage).toHaveBeenCalledWith(
      testQuery,
      jasmine.objectContaining({ queryMessage: testMsgContent })
    );
  });

  it('should not allow send a message if it is empty or invalid', () => {
    spyOn(queriesStoreService, 'sendMessage').and.callFake(() => {});

    component.messageContent = '';
    component.getValidationInputStatus = () => null;

    component.sendMessage();
    expect(queriesStoreService.sendMessage).not.toHaveBeenCalled();

    component.messageContent = 'not empty';
    component.getValidationInputStatus = () => true;
    component.sendMessage();

    expect(queriesStoreService.sendMessage).not.toHaveBeenCalled();
  });

  it('should clear message box if query was updated', () => {
    el.query(By.css('#typeMessageInput')).nativeElement.value = 'test';
    el.query(By.css('#typeMessageInput')).nativeElement.dispatchEvent(new Event('input'));
    fixture.detectChanges();

    expect(component.messageContent).toBe('test');

    component.queryDetails = { query: 'updatedQuery' } as any;
    fixture.detectChanges();

    expect(component.messageContent).toBeFalsy();
  });

  describe('user role dependency', () => {
    const mappedContactMethod = [
      {
        type: ContactMethod?.TypeEnum?.MOBILE,
        contactMethod: '002012266534',
      },
      {
        type: ContactMethod?.TypeEnum?.PHONE,
        contactMethod: '4456282',
      },
      {
        type: ContactMethod?.TypeEnum?.EMAIL,
        contactMethod: 'LloydsDirectOP@dxc.com',
      },
    ];
    beforeEach(() => {
      component.messageContent = 'not empty';
      component.getValidationInputStatus = () => false;
      spyOn(queriesStoreService, 'sendMessage').and.callFake(() => {});
    });

    it('should send message with Initial flow type if user is technician', () => {
      component.roles = [Role.PROCESS_TEAM_MANAGER];

      component.sendMessage();
      expect(queriesStoreService.sendMessage).toHaveBeenCalledWith(
        jasmine.any(Object),
        jasmine.objectContaining({ queryFlowType: QueryFlowType.Initial })
      );
    });

    it('should send message with Sender originator if user is technician', () => {
      component.roles = [Role.PROCESS_TEAM_MANAGER];

      component.sendMessage();
      expect(queriesStoreService.sendMessage).toHaveBeenCalledWith(
        jasmine.any(Object),
        jasmine.objectContaining({ originator: 'sender' })
      );
    });

    it('should send message with Response flow type if user is broker or carrier', () => {
      component.roles = [Role.PROCESS_QUERY_BROKER, Role.PROCESS_QUERY_CARRIER];

      component.sendMessage();
      expect(queriesStoreService.sendMessage).toHaveBeenCalledWith(
        jasmine.any(Object),
        jasmine.objectContaining({ queryFlowType: QueryFlowType.Response })
      );
    });

    it('should send message with Receiver originator if user is broker or carrier', () => {
      component.roles = [Role.PROCESS_QUERY_BROKER, Role.PROCESS_QUERY_CARRIER];

      component.sendMessage();
      expect(queriesStoreService.sendMessage).toHaveBeenCalledWith(
        jasmine.any(Object),
        jasmine.objectContaining({ originator: 'receiver' })
      );
    });

    it('should create sender object from party and contactMethods for role technician', () => {
      component.roles = [Role.PROCESS_TEAM_MANAGER];
      component.party = mockParty;
      component.contactMethods = mockContactMethods;
      component.partyOrganisationId = mockPartyInfoUser.partyOrganisationId;

      component.sendMessage();

      expect(queriesStoreService.sendMessage).toHaveBeenCalledWith(
        jasmine.any(Object),
        jasmine.objectContaining({
          sender: {
            organisation: {
              partyId: component.partyOrganisationId,
              marketId: null,
            },
            person: {
              name: `${mockParty.partyPerson.forename} ${mockParty.partyPerson.surname}`,
              contactMethod: mappedContactMethod,
            },
          },
          originator: 'sender',
        })
      );
    });

    it('should create sender object from party and contactMethods for role broker/carrier', () => {
      component.roles = [Role.PROCESS_QUERY_BROKER, Role.PROCESS_QUERY_CARRIER];
      component.party = mockParty;
      component.contactMethods = mockContactMethods;
      component.partyOrganisationId = mockPartyInfoUserBroker.partyOrganisationId;

      component.sendMessage();

      expect(queriesStoreService.sendMessage).toHaveBeenCalledWith(
        jasmine.any(Object),
        jasmine.objectContaining({
          sender: {
            organisation: {
              partyId: component.partyOrganisationId,
              marketId: null,
            },
            person: {
              name: `${mockParty.partyPerson.forename} ${mockParty.partyPerson.surname}`,
              contactMethod: mappedContactMethod,
            },
          },
          originator: 'receiver',
        })
      );
    });
  });

  it('should display closed message with formatted date when query status is closed', () => {
    const testDate = new Date('2024-09-10T13:15:22.390Z');
    const mockQueryDetails: Query = {
      queryId: '1',
      sourceChannel: 'EBOT',
      sourceApplication: 'TREATY',
      status: 'CLOSED',
      audit: {
        user: 'user',
        at: testDate,
      },
    };
    component.queryDetails = mockQueryDetails;

    fixture.detectChanges();

    const closedMessageElement = fixture.debugElement.query(By.css('#queryClosedMsg'));
    expect(closedMessageElement).toBeTruthy();
    const messageText = closedMessageElement.nativeElement.textContent.trim();
    const datePipe = new DatePipe('en-US');
    const expectedDateString = datePipe.transform(testDate, 'dd MMMM yyyy HH:mm');
    expect(messageText).toContain(expectedDateString);
  });
});
