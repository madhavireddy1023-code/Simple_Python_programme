import { Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QueryDetail, SearchQueryRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Query, QueryPartyPersonContactMethod } from '@dxc.lm.sdk.angular/portal-queries-api';
import { mockTechnicianContactInfo } from '@features/queries/consts/mock-contact-info.consts';
import { QueryPerson } from '@features/queries/models/chat.model';
import { Role } from '@shared/consts/shared.enums';

@Component({
  selector: 'app-chat-window-header',
  templateUrl: './chat-window-header.component.html',
  styleUrls: ['./chat-window-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ChatWindowHeaderComponent {
  readonly Role = Role;
  readonly QUERY_STATUS = QueryDetail.QueryStatusEnum;
  readonly ORGANISATION_ROLE = SearchQueryRequest.RoleEnum;

  @Input()
  organisationName: string;

  queryPerson: QueryPerson = mockTechnicianContactInfo;
  contactPhone: string;
  contactEmail: string;

  @Input() partyOrganisationRole: string;
  @Input() set queryDetails(query: Query) {
    this.onDialogClosed();
    this.query = query;
    this.query?.originator?.person?.contactMethod?.forEach((contact) => {
      if (
        [QueryPartyPersonContactMethod.TypeEnum.MOBILE, QueryPartyPersonContactMethod.TypeEnum.PHONE].includes(
          contact.type
        )
      ) {
        this.contactPhone = contact.contactMethod;
      }

      if (contact.type === QueryPartyPersonContactMethod.TypeEnum.EMAIL) {
        this.contactEmail = contact.contactMethod;
      }
    });
  }

  get queryDetails(): Query {
    return this.query;
  }

  @Input()
  roles = [];

  @Output() queryUpdated: EventEmitter<Query> = new EventEmitter();

  query: Query;

  isCloseBtnClicked = false;

  isInvalidateBtnClicked = false;

  constructor(private route: ActivatedRoute) {}

  onDialogClosed(): void {
    this.isCloseBtnClicked = false;
    this.isInvalidateBtnClicked = false;
  }

  showCloseWarning(): void {
    this.isCloseBtnClicked = true;
    this.isInvalidateBtnClicked = false;
  }

  closeQuery(): void {
    this.onDialogClosed();

    const query = { ...this.query, queryStatus: QueryDetail.QueryStatusEnum.CLOSED, validResolvedReasonInd: true };
    this.queryUpdated.emit(query);
  }

  showInvalidateWarning(): void {
    this.isInvalidateBtnClicked = true;
    this.isCloseBtnClicked = false;
  }

  invalidateQuery(): void {
    this.onDialogClosed();

    const query = { ...this.query, queryStatus: QueryDetail.QueryStatusEnum.CLOSED, validResolvedReasonInd: false };
    // Get selected query WPR from  query params
    const selectedWPR = this.route?.snapshot?.queryParamMap?.get('wpr');
    // Get selected workflow submission id details from query params
    const selectedWorkflowSubmissionId = this.route?.snapshot?.queryParamMap?.get('workflowSubmissionId');
    // After invalidating query use the same query params except queryID
    window.history.replaceState(
      {},
      '',
      `${window.location.pathname}?wpr=${selectedWPR}&workflowSubmissionId=${selectedWorkflowSubmissionId}`
    );
    this.queryUpdated.emit(query);
  }
}
