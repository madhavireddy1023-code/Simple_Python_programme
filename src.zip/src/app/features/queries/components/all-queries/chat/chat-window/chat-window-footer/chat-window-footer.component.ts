import { Subscription } from 'rxjs';
import { QueriesStoreService } from '@features/queries/services/queries.store.service';
import { Component, OnInit, Input, ViewEncapsulation, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors } from '@angular/forms';
import { DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { FormControls } from '@shared/models/interfaces';
import { ValidationInputStatus, isString } from 'src/app/utils/helper';
import { QueryDetail } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { QUERY_MESSAGE_ORIGINATOR } from '@features/queries/consts/queries.consts';
import { Role } from '@shared/consts/shared.enums';
import { Query, QueryMessage } from '@dxc.lm.sdk.angular/portal-queries-api';
import { QueryFlowType } from '@features/queries/consts/chat.consts';
import { ContactMethods, Party } from '@dxc.lm.sdk.angular/ipos-party-api';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';

@Component({
  selector: 'app-chat-window-footer',
  templateUrl: './chat-window-footer.component.html',
  styleUrls: ['./chat-window-footer.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ChatWindowFooterComponent implements OnInit {
  readonly QUERY_STATUS = QueryDetail.QueryStatusEnum;

  @Input() contactMethods: ContactMethods;
  @Input() party: Party;
  @Input() partyOrganisationId: string;
  @Input() set queryDetails(query: Query) {
    this.resetMessageBox();
    this.query = query;
  }

  get queryDetails(): Query {
    return this.query;
  }

  @Input() roles = [];

  @ViewChild('typeMessageInput')
  messageInput: DxcTextInputComponent;

  inputValueLength = 0;
  messageContent = '';
  messageKey = '';
  maxValueLength = 350;
  valueLength = 0;

  isUploadDialogOpen: boolean;
  typeMessageInputInfoForm: FormGroup;

  get typeMessageInputInfoFormControls(): FormControls {
    return this.typeMessageInputInfoForm?.controls;
  }

  private query: Query;

  constructor(
    private queriesStoreService: QueriesStoreService,
    private formBuilder: FormBuilder,
    private auth: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.typeMessageInputInfoForm = this.formBuilder.group({
      typeMessageInput: ['', isString(2, 350)],
    });
  }

  getValue(event): void {
    this.inputValueLength = event.target.value.length;
    this.messageContent = event.target.value;
    if (this.inputValueLength > this.maxValueLength) {
      this.valueLength = this.maxValueLength - this.inputValueLength;
    } else {
      this.valueLength = this.inputValueLength;
    }
  }

  sendMessage(): void {
    if (!this.messageContent) {
      return;
    }

    if (this.getValidationInputStatus(this.typeMessageInputInfoFormControls?.typeMessageInput, this.messageInput)) {
      return;
    }

    const query = this.queryDetails;

    let originator;
    let queryFlowType;

    switch (true) {
      case this.roles.includes(Role.PROCESS_TEAM_MANAGER):
        originator = QUERY_MESSAGE_ORIGINATOR.SENDER;
        queryFlowType = QueryFlowType.Initial;
        break;

      case this.roles.includes(Role.PROCESS_QUERY_BROKER):
      case this.roles.includes(Role.PROCESS_QUERY_CARRIER):
        originator = QUERY_MESSAGE_ORIGINATOR.RECEIVER;
        queryFlowType = QueryFlowType.Response;
        break;
    }

    // Send contactMethod and type only to the payload from contactMethods array
    const contactMethods = this.contactMethods?.map(({ type, contactMethod }) => {
      return { contactMethod, type };
    });

    const sender = {
      organisation: {
        partyId: this.partyOrganisationId,
        marketId: null,
      },
      person: {
        name: `${this.party?.partyPerson?.forename} ${this.party?.partyPerson?.surname}`,
        contactMethod: contactMethods,
      },
    };

    const message = {
      queryMessage: this.messageContent,
      sentAt: new Date(),
      sender,
      originator,
      queryFlowType,
    } as QueryMessage;

    this.queriesStoreService.sendMessage(query, message);
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(true, formControl, input);
  }

  private resetMessageBox(): void {
    this.inputValueLength = 0;
    this.valueLength = 0;
    this.messageContent = '';
  }
}
