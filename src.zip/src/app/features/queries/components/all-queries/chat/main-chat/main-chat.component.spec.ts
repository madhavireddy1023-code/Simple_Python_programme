import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { By } from '@angular/platform-browser';

import { MainChatComponent } from './main-chat.component';
import { QueriesStoreService } from '@features/queries/services/queries.store.service';
import { allQueriesData } from '@features/section-details/consts/mock-queries.consts';
import * as _ from 'lodash';
import { Query, QueryData } from '@dxc.lm.sdk.angular/portal-queries-api';
import { DebugElement } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { MainChatTabsComponent } from '../chat-tabs/main-chat-tabs/main-chat-tabs.component';
import { PlusNumberPipe } from '@shared/pipe/plus-number.pipe';
import { mockActiveQueryData, mockClosedQueryData } from '@features/queries/consts/queries.consts';

describe('MainChatComponent', () => {
  let component: MainChatComponent;
  let el: DebugElement;
  let fixture: ComponentFixture<MainChatComponent>;
  const queriesStoreService = jasmine.createSpyObj('QueriesStoreService', [
    'updateQueryStatus',
    'getQueries',
    'clearCreatedUpdatedQuery',
  ]);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainChatComponent, MainChatTabsComponent, PlusNumberPipe],
      providers: [
        MockStore,
        provideMockStore(),
        { provide: QueriesStoreService, useValue: queriesStoreService },
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: of({}),
          },
        },
      ],
      imports: [TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainChatComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test query selection', () => {
    component.selectedQueryDetails = allQueriesData[2];
    expect(component.queryDetails).toEqual(allQueriesData[2]);
  });

  it('should test set createdUpdatedQuery', () => {
    component.createdUpdatedQuery = mockActiveQueryData;
    expect(component.createdUpdatedQueryData).toEqual(mockActiveQueryData);
  });

  describe('Reassign warning visibility', () => {
    it('should display the warning alert when selected query is confidential', () => {
      component.userRoles = [component.rolesList.PR_Premium_QueryPremium];
      component.queryDetails = allQueriesData[0];
      component.hideReassignAlertMsg = false;
      fixture.detectChanges();
      const divElement = fixture.debugElement.query(By.css('#reassignWarningBanner'));
      expect(divElement).toBeTruthy();
    });

    it('should hide the warning alert when selected query is not confidential', () => {
      component.userRoles = [component.rolesList.PR_Premium_QueryPremium];
      component.queryDetails = allQueriesData[1];
      component.hideReassignAlertMsg = false;
      fixture.detectChanges();
      const divElement = fixture.debugElement.query(By.css('#reassignWarningBanner'));
      expect(divElement).toBeFalsy();
    });
  });
  it('should call updateQueryStatus with the correct parameters', () => {
    const mockQuery = {
      queryId: 'mockQueryId',
      queryStatus: 'ACTIVE',
      reference: 'xyz',
      validResolvedReasonInd: true,
      externalIdentifiers: {
        premiumIdentifiers: { premiumId: 'mockWorkflowSubmissionId', workPackageReference: 'xyz' },
      },
    };

    component.updateQuery(mockQuery);

    expect(queriesStoreService.updateQueryStatus).toHaveBeenCalledWith(
      'mockQueryId',
      { status: 'ACTIVE', validResolvedReasonInd: true },
      'xyz'
    );
  });

  it('should close Reassign Alert', () => {
    component.closeReassignAlert();
    expect(component.hideReassignAlertMsg).toBeTruthy();
  });

  it('should reset hideReassignAlertMsg to false', () => {
    component.selectedQueryDetails = {
      queryId: 'id1',
      createdAt: new Date('2022-01-01'),
      sourceChannel: 'EBOT',
      sourceApplication: 'TREATY',
    };
    expect(component.hideReassignAlertMsg).toBe(false);
  });

  it('should update selectedId property', () => {
    const mockSelectedQueryId = 'mockId';
    component.selectedQueryId = mockSelectedQueryId;
    expect(component.selectedId).toEqual(mockSelectedQueryId);
  });

  it('should update activeQueries property', () => {
    const mockActiveQueries: Array<QueryData> = [
      { queryId: 'id1', createdAt: new Date('2022-01-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
      { queryId: 'id2', createdAt: new Date('2022-02-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
    ];
    component.activeQueries = mockActiveQueries;
    expect(component.activeQueries).toEqual(mockActiveQueries);
  });

  it('should update closedQueries property', () => {
    const mockClosedQueries: Array<QueryData> = [
      { queryId: 'id1', createdAt: new Date('2022-01-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
      { queryId: 'id2', createdAt: new Date('2022-02-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
    ];
    component.closedQueries = mockClosedQueries;
    expect(component.closedQueries).toEqual(mockClosedQueries);
  });

  it('should update roles property', () => {
    const mockRoles: string[] = ['Role1', 'Role2', 'Role3'];
    component.roles = mockRoles;
    expect(component.roles).toEqual(mockRoles);
  });

  it('should set selectedQueryDetails correctly', () => {
    // Arrange
    const mockQueryDetails: Query = {
      queryId: '1',
      sourceChannel: 'EBOT',
      sourceApplication: 'TREATY',
    };
    const mockAllQueries = [
      { queryId: 'id1', createdAt: new Date('2022-01-01'), sourceChannel: null, sourceApplication: 'TREATY' },
    ];

    // Act
    component.selectedQueryDetails = mockQueryDetails;

    // Assert
    expect(component.queryDetails).toEqual(mockQueryDetails);

    const expectedSortedQueries = [
      mockQueryDetails,
      ...mockAllQueries.filter((obj) => obj.queryId !== mockQueryDetails.queryId),
    ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    expect(component.hideReassignAlertMsg).toBeFalse();
  });

  it('should shiftSelectQuery correctly', () => {
    // Arrange
    const mockQueryDetails: Query = {
      queryId: '1',
      sourceChannel: 'EBOT',
      sourceApplication: 'TREATY',
    };
    const mockAllQueriesData: Array<QueryData> = [
      { queryId: 'id1', createdAt: new Date('2022-01-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
      { queryId: 'id2', createdAt: new Date('2022-02-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
    ];

    // Act
    component.allQueriesData = mockAllQueriesData;
    component.queryDetails = mockQueryDetails;
    component.shiftSelectQuery();

    // Assert
    const expectedSortedQueries = [
      mockQueryDetails,
      ...mockAllQueriesData.filter((obj) => obj.queryId !== mockQueryDetails.queryId),
    ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    expect(component.allQueriesData).toEqual(expectedSortedQueries);
  });

  it('should early return if necessary data is missing', () => {
    // Arrange
    const mockAllQueriesData: Array<QueryData> = [
      { queryId: 'id1', createdAt: new Date('2022-01-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
      { queryId: 'id2', createdAt: new Date('2022-02-01'), sourceChannel: 'EBOT', sourceApplication: 'TREATY' },
    ];

    // Act
    component.allQueriesData = mockAllQueriesData;
    component.queryDetails = null;
    component.shiftSelectQuery();

    // Assert
    expect(component.allQueriesData).toEqual(mockAllQueriesData);
  });

  it('should test refreshPageBanner is shown when create query and BE API for queries list gets old data before create query', () => {
    component.createdUpdatedQuery = mockActiveQueryData;
    component.allQueries = [];
    fixture.detectChanges();
    const refreshPageBanner = el.nativeElement.querySelector('#refreshPageBanner');
    expect(component.allQueriesData).toEqual([]);
    expect(refreshPageBanner).toBeTruthy();
  });

  it('should test refreshPageBanner is hidden when create query and BE API for queries list gets new data after create query', () => {
    component.createdUpdatedQuery = mockActiveQueryData;
    component.allQueries = [mockActiveQueryData];
    fixture.detectChanges();
    const refreshPageBanner = el.nativeElement.querySelector('#refreshPageBanner');
    expect(component.allQueriesData).toEqual([mockActiveQueryData]);
    expect(refreshPageBanner).toBeFalsy();
  });

  it('should test refreshPageBanner is shown when close/invalidate query and BE API for queries list gets old data before updating', () => {
    component.createdUpdatedQuery = mockClosedQueryData;
    component.allQueries = [mockActiveQueryData];
    fixture.detectChanges();
    const refreshPageBanner = el.nativeElement.querySelector('#refreshPageBanner');
    expect(component.allQueriesData).toEqual([mockActiveQueryData]);
    expect(refreshPageBanner).toBeTruthy();
  });

  it('should test refreshPageBanner is hidden when close/invalidate query and BE API for queries list gets new data after updating', () => {
    component.createdUpdatedQuery = mockClosedQueryData;
    component.allQueries = [mockClosedQueryData];
    fixture.detectChanges();
    const refreshPageBanner = el.nativeElement.querySelector('#refreshPageBanner');
    expect(component.allQueriesData).toEqual([mockClosedQueryData]);
    expect(refreshPageBanner).toBeFalsy();
  });

  it('should test clickRefreshLink function', () => {
    component.mainChatTabsView.activeTabIndex = 1;
    component.clickRefreshLink();
    expect(queriesStoreService.getQueries).toHaveBeenCalled();
    expect(queriesStoreService.clearCreatedUpdatedQuery).toHaveBeenCalled();
    expect(component.mainChatTabsView.activeTabIndex).toEqual(0);
  });

  afterEach(() => {
    fixture.destroy();
  });
});
