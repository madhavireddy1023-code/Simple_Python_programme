import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatTabItemComponent } from './chat-tab-item.component';
import { TranslateModule } from '@ngx-translate/core';
import { PlusNumberPipe } from '@shared/pipe/plus-number.pipe';
import { InitialLettersPipe } from '@shared/pipes/initial-letters.pipe';
import { RouterTestingModule } from '@angular/router/testing';

describe('ChatTabItemComponent', () => {
  let component: ChatTabItemComponent;
  let fixture: ComponentFixture<ChatTabItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChatTabItemComponent, PlusNumberPipe, InitialLettersPipe],
      imports: [TranslateModule.forRoot(), RouterTestingModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatTabItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit selectQuery event and update window history', () => {
    spyOn(component.selectQuery, 'emit');
    spyOn(window.history, 'replaceState');

    const mockQueryId = 'mockQueryId';
    component.queryItem = {
      reference: 'mockReference',
      sourceChannel: 'EBOT',
      sourceApplication: 'TREATY',
      externalIdentifiers: {
        premiumIdentifiers: { premiumId: 'mockWorkflowSubmissionId', workPackageReference: 'mockReference' },
      },
    };
    component.selectQueryEvent(mockQueryId);

    expect(component.selectQuery.emit).toHaveBeenCalledWith(mockQueryId);
    expect(window.history.replaceState).toHaveBeenCalledWith(
      {},
      '',
      `${window.location.pathname}?wpr=mockReference&workflowSubmissionId=mockWorkflowSubmissionId&queryId=${mockQueryId}`
    );
  });

  it('should return data if not null or undefined, otherwise return "-"', () => {
    const testData = 'testData';

    const result1 = component.nullValueChecker(testData);
    const result2 = component.nullValueChecker(null);
    const result3 = component.nullValueChecker(undefined);

    expect(result1).toEqual(testData);
    expect(result2).toEqual('-');
    expect(result3).toEqual('-');
  });
});
