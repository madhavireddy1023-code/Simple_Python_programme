import { Query, QueryData } from '@dxc.lm.sdk.angular/portal-queries-api';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { provideMockStore } from '@ngrx/store/testing';

import { MainChatWindowComponent } from './main-chat-window.component';
import { activeQueriesData, allQueriesData } from '@features/section-details/consts/mock-queries.consts';
import { By } from '@angular/platform-browser';
import { Role } from '@shared/consts/shared.enums';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { Subject, of } from 'rxjs';
import { QueriesStoreService } from '@features/queries/services/queries.store.service';
import { PartyService } from 'src/app/api/party/party.service';
import { SearchQueryRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

describe('MainChatWindowComponent', () => {
  let component: MainChatWindowComponent;
  let fixture: ComponentFixture<MainChatWindowComponent>;
  let queriesStoreService: QueriesStoreService;
  let el: DebugElement;

  const authMock = {
    roles$: new Subject(),
  };

  const partyServiceMock = {
    findPartyByPartyId: (partyId: string) => of({}),
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainChatWindowComponent],
      imports: [TranslateModule.forRoot(), AngularSvgIconModule.forRoot(), HttpClientTestingModule],
      providers: [
        { provide: AuthenticationService, useValue: authMock },
        provideMockStore(),
        { provide: PartyService, useValue: partyServiceMock },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainChatWindowComponent);
    component = fixture.componentInstance;
    queriesStoreService = TestBed.inject(QueriesStoreService);
    fixture.detectChanges();
    el = fixture.debugElement;
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test query setting', () => {
    component.query = allQueriesData[0];
    expect(component.queryDetails).toEqual(allQueriesData[0]);
  });

  it('should ask to select query', () => {
    const $component = fixture.nativeElement;

    expect($component.querySelector('#noQueryMessage')).toBeInstanceOf(HTMLElement);
    expect($component.querySelector('#chatWindowBody')).toBeNull();

    component.query = allQueriesData[1];
    fixture.detectChanges();

    expect($component.querySelector('#noQueryMessage')).toBeNull();
    expect($component.querySelector('#chatWindowBody')).toBeInstanceOf(HTMLElement);
  });

  describe('chat footer visibility', () => {
    beforeEach(() => {
      component.query = { ...activeQueriesData[1] };
    });

    it('should show chat footer if query is closed', () => {
      component.query = { ...component.query, status: QueryData.StatusEnum.CLOSED };
      fixture.detectChanges();

      expect(el.query(By.css('#chatWindowFooter'))).toBeTruthy();
    });

    it('should show chat footer if user role is technician', () => {
      component.partyOrganisationRole = SearchQueryRequest.RoleEnum.TECHNICIAN;
      component.query = { ...component.query };
      fixture.detectChanges();

      expect(el.query(By.css('#chatWindowFooter'))).toBeTruthy();
    });

    it('should not show chat footer if user role is broker or carrier and not match with assignee role', () => {
      component.partyOrganisationRole = SearchQueryRequest.RoleEnum.BROKER;
      component.query = {
        ...component.query,
        assignees: [
          {
            assignee: {
              role: 'CARRIER',
            },
          },
        ],
      };
      fixture.detectChanges();

      expect(el.query(By.css('#chatWindowFooter'))).toBeFalsy();
    });
  });

  describe('Organisation name', () => {
    it('should fetch organization name for selected query', () => {
      spyOn(partyServiceMock, 'findPartyByPartyId').and.callThrough();
      component.query = { ...allQueriesData[1] };
      fixture.detectChanges();

      expect(partyServiceMock.findPartyByPartyId).toHaveBeenCalledWith('600808f3-302e-4103-b748-dca548d40ae3');
    });

    it('should set organisation name', () => {
      spyOn(partyServiceMock, 'findPartyByPartyId').and.callFake((partyId: string) => {
        return of({ partyOrganisation: { organisationName: 'test organisation' } });
      });
      component.query = { ...allQueriesData[1] };
      fixture.detectChanges();
    });
  });
});
