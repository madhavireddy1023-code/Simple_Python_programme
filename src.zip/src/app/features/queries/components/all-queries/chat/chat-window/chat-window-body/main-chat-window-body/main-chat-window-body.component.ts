import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { Component, Input, ViewChild } from '@angular/core';
import { QueryMessage } from '@dxc.lm.sdk.angular/portal-queries-api';
import { ngDateFormatSmall } from 'src/app/utils/consts/timestamp-format.const';

@Component({
  selector: 'app-main-chat-window-body',
  templateUrl: './main-chat-window-body.component.html',
  styleUrls: ['./main-chat-window-body.component.scss'],
})
export class MainChatWindowBodyComponent {
  readonly dateFormat = ngDateFormatSmall;
  allMessages: Array<QueryMessage> = [];
  @Input() set chatMessages(messages: Array<QueryMessage>) {
    if (messages?.length) {
      this.allMessages = messages;
      this.scrollToLastMessage();
    }
  }
  @Input() dateOfChat: Date;

  @ViewChild('virtualScroll') virtualScrollViewport: CdkVirtualScrollViewport;

  scrollToLastMessage(): void {
    setTimeout(() => {
      this.virtualScrollViewport?.scrollToIndex(this.allMessages.length - 1);
      setTimeout(() => {
        const messages = document.getElementsByClassName('chat-messages cdk-virtual-scroll-orientation-vertical');
        if (messages?.length > 3) {
          messages[messages.length - 1]?.scrollIntoView();
        }
      }, 10);
    });
  }
}
