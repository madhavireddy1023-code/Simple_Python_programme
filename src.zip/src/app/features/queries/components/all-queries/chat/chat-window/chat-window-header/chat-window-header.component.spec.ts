import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

import { ChatWindowHeaderComponent } from './chat-window-header.component';
import { InitialLettersPipe } from '@shared/pipes/initial-letters.pipe';
import { activeQueriesData, closedQueriesData } from '@features/section-details/consts/mock-queries.consts';
import { QUERY_STATUS } from '@features/queries/consts/queries.consts';
import { Role } from '@shared/consts/shared.enums';
import { DxcButtonModule } from '@dxc-technology/halstack-angular';
import { ReactiveFormsModule } from '@angular/forms';
import { QueryDetail, SearchQueryRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { ActivatedRoute } from '@angular/router';

describe('ChatWindowHeaderComponent', () => {
  let component: ChatWindowHeaderComponent;
  let fixture: ComponentFixture<ChatWindowHeaderComponent>;
  let el: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChatWindowHeaderComponent, InitialLettersPipe],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule, DxcButtonModule],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              queryParamMap: {
                get: (key: string) => {
                  switch (key) {
                    case 'wpr':
                      return '123';
                    case 'workflowSubmissionId':
                      return 'workflowSubmissionIdTest';
                  }
                },
              },
            },
          },
        },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatWindowHeaderComponent);
    component = fixture.componentInstance;
    component.queryDetails = activeQueriesData[0];
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Close functionality', () => {
    it('shoud display close button for technician', () => {
      const $component = fixture.nativeElement;

      component.roles = [Role.PROCESS_TEAM_MANAGER];
      component.partyOrganisationRole = SearchQueryRequest.RoleEnum.TECHNICIAN;
      fixture.detectChanges();

      expect($component.querySelector('#closeQueryBtn')).toBeInstanceOf(HTMLElement);
    });

    it('should show warning', () => {
      const $component = fixture.nativeElement;
      component.roles = [Role.PROCESS_TEAM_MANAGER];
      component.partyOrganisationRole = SearchQueryRequest.RoleEnum.TECHNICIAN;
      fixture.detectChanges();

      $component.querySelector('#closeQueryBtn').click();
      fixture.detectChanges();
      expect($component.querySelector('#closeWarningMessage')).toBeInstanceOf(HTMLElement);
    });

    it('should rise event with updated query', () => {
      spyOn(component.queryUpdated, 'emit').and.callFake(() => {});
      component.queryDetails = { queryStatus: QUERY_STATUS.ACTIVE } as any;

      component.closeQuery();
      expect(component.queryUpdated.emit).toHaveBeenCalledWith({
        queryStatus: QUERY_STATUS.CLOSED,
        validResolvedReasonInd: true,
      } as any);
    });
  });

  describe('Technician contact card visability', () => {
    it('should technician contact card appear if queryDetails has data', () => {
      component.queryDetails = activeQueriesData[1];
      fixture.detectChanges();
      const $banner = fixture.nativeElement.querySelector('#bannerMsg');
      expect($banner).toBeTruthy();
    });

    it('should hide query actions if query is closed', () => {
      const $component = fixture.nativeElement;
      component.partyOrganisationRole = SearchQueryRequest.RoleEnum.TECHNICIAN;

      component.queryDetails = activeQueriesData[0];
      fixture.detectChanges();
      expect($component.querySelector('#queryActions')).toBeInstanceOf(HTMLElement);

      component.queryDetails = closedQueriesData[0];
      fixture.detectChanges();
      const $queryHeader = $component.querySelector('#queryHeader');
      expect($queryHeader.children.length).toBe(1);
      expect($queryHeader.children[0].id).toBe('queryInfo');
    });
  });

  describe('Invalidate functionality', () => {
    it('shoud display invalidate button for technician', () => {
      const $component = fixture.nativeElement;

      component.roles = [Role.PROCESS_TEAM_MANAGER];
      component.partyOrganisationRole = SearchQueryRequest.RoleEnum.TECHNICIAN;
      fixture.detectChanges();

      expect($component.querySelector('#invalidateQueryBtn')).toBeInstanceOf(HTMLElement);
    });

    it('should show invalidate warning', () => {
      const $component = fixture.nativeElement;
      component.roles = [Role.PROCESS_TEAM_MANAGER];
      component.partyOrganisationRole = SearchQueryRequest.RoleEnum.TECHNICIAN;
      fixture.detectChanges();

      $component.querySelector('#invalidateQueryBtn').click();
      fixture.detectChanges();
      expect($component.querySelector('#invalidateWarningMessage')).toBeInstanceOf(HTMLElement);
    });
    describe('invalidateQuery', () => {
      it('should call onDialogClosed and emit the updated query', () => {
        spyOn(component, 'onDialogClosed');
        spyOn(component.queryUpdated, 'emit');

        component.invalidateQuery();

        expect(component.onDialogClosed).toHaveBeenCalled();

        expect(component.queryUpdated.emit).toHaveBeenCalled();

        const query = {
          ...component.query,
          queryStatus: QueryDetail.QueryStatusEnum.CLOSED,
          validResolvedReasonInd: false,
        };
        expect(component.queryUpdated.emit).toHaveBeenCalledWith(query);
      });
    });
  });

  describe('Originator details', () => {
    beforeEach(() => {
      component.queryDetails = { ...activeQueriesData[1] };
      fixture.detectChanges();
    });

    it('should display contactPhone', () => {
      expect(el.query(By.css('#headerContactPhone span')).nativeElement.innerHTML).toBe('37897111');
    });

    it('should display contactEmail', () => {
      expect(el.query(By.css('#headerContactEmail span')).nativeElement.innerHTML).toBe('abc@gmail.com');
    });

    it('should display queryId', () => {
      expect(el.query(By.css('#headerQueryId span')).nativeElement.innerHTML).toBe('WPR8830123456');
    });

    it('should show organisation name', () => {
      component.organisationName = 'Test Organisation';
      fixture.detectChanges();

      expect(el.query(By.css('#orgName span')).nativeElement.innerHTML).toBe('Test Organisation');
    });
  });
});
