import { Component, Input } from '@angular/core';
import { QueryMessage } from '@dxc.lm.sdk.angular/portal-queries-api';
import { QueryFlowType } from '@features/queries/consts/chat.consts';

@Component({
  selector: 'app-chat-window-message',
  templateUrl: './chat-window-message.component.html',
  styleUrls: ['./chat-window-message.component.scss'],
})
export class ChatWindowMessageComponent {
  readonly QueryFlowType = QueryFlowType;
  currentDate: Date = new Date();

  @Input() chatMessage: QueryMessage;

  @Input() isInitialMessage = false;

  showSubQueries(): boolean {
    return (
      this.isInitialMessage &&
      this.chatMessage?.queryFlowType === QueryFlowType?.Initial &&
      !!this.chatMessage.subQueries?.length
    );
  }
}
