import { Subscription } from 'rxjs';
import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { Query, QueryData } from '@dxc.lm.sdk.angular/portal-queries-api';
import { ContactMethods, Party } from '@dxc.lm.sdk.angular/ipos-party-api';
import { Role } from '@shared/consts/shared.enums';
import { CREATE_QUERY_ASSIGNEE } from '@features/queries/consts/create-query.consts';
import { PartyService } from 'src/app/api/party/party.service';
import { SearchQueryRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

@Component({
  selector: 'app-main-chat-window',
  templateUrl: './main-chat-window.component.html',
  styleUrls: ['./main-chat-window.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MainChatWindowComponent implements OnInit {
  queryDetails: Query;
  showChatFooter: boolean;

  @Input() contactMethods: ContactMethods;
  @Input() party: Party;
  @Input() partyOrganisationId: string;
  @Input() partyOrganisationRole: string;
  @Input() set query(queryData: Query) {
    this.setQuery(queryData);
  }

  get query(): Query {
    return this.queryDetails;
  }

  @Output() queryUpdated: EventEmitter<Query> = new EventEmitter();

  organisationName: string;

  roles = [];

  private subscription = new Subscription();

  constructor(private auth: AuthenticationService, private partyService: PartyService) {}

  ngOnInit(): void {
    this.subscription.add(
      this.auth.roles$.subscribe((roles) => {
        this.roles = roles;
      })
    );
  }

  setQuery(query: Query): void {
    this.queryDetails = query;

    this.checkChatFooterAvailability();

    if (!this.queryDetails || !this.queryDetails.originator) {
      return;
    }

    const { organisation } = this.queryDetails.originator;

    this.partyService.findPartyByPartyId(organisation.partyId).subscribe(({ partyOrganisation }) => {
      this.organisationName = partyOrganisation?.organisationName;
    });
  }

  checkChatFooterAvailability(): void {
    this.showChatFooter = false;

    if (
      this.queryDetails?.status === QueryData.StatusEnum.CLOSED ||
      this.partyOrganisationRole === SearchQueryRequest.RoleEnum.TECHNICIAN
    ) {
      this.showChatFooter = true;
      return;
    }

    this.queryDetails?.assignees?.forEach((assignee) => {
      // The assignee?.currentAssigneeInd is commented as it is not supported in BE yet
      if (
        // assignee?.currentAssigneeInd &&
        assignee?.assignee?.organisation?.partyId === this.partyOrganisationId &&
        assignee?.assignee?.role === CREATE_QUERY_ASSIGNEE.BROKER.toUpperCase() &&
        this.partyOrganisationRole === SearchQueryRequest.RoleEnum.BROKER
      ) {
        this.showChatFooter = true;
        return;
      }
    });
  }

  updateQuery(query: Query): void {
    this.queryUpdated.emit(query);
  }
}
