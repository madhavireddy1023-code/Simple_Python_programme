import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidateQueryWarningComponent } from './invalidate-query-warning.component';
import { TranslateModule } from '@ngx-translate/core';

describe('InvalidateQueryWarningComponent', () => {
  let component: InvalidateQueryWarningComponent;
  let fixture: ComponentFixture<InvalidateQueryWarningComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InvalidateQueryWarningComponent],
      imports: [TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvalidateQueryWarningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should allow to cancel invalidate', () => {
    spyOn(component.canceled, 'emit');

    const $component = fixture.nativeElement;
    const $btn = $component.querySelector('#cancelInvalidate');
    $btn.click();
    expect(component.canceled.emit).toHaveBeenCalled();
  });

  it('should allow to confirm invalidate', () => {
    spyOn(component.confirmed, 'emit');

    const $component = fixture.nativeElement;
    const $btn = $component.querySelector('#confirmInvalidate');
    $btn.click();
    expect(component.confirmed.emit).toHaveBeenCalled();
  });
});
