import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExchangeRateEnquirySearchComponent } from './exchange-rate-enquiry-search.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { StateObservable, Store } from '@ngrx/store';
import { ExchangeRateEnquiryStoreService } from '@features/exchange-rate-enquiry/services/exchange-rate-enquiry-store.service';
import { provideMockStore } from '@ngrx/store/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { SortPipe } from '@shared/pipes/sort.pipe';

describe('ExchangeRateEnquirySearchComponent', () => {
  let component: ExchangeRateEnquirySearchComponent;
  let fixture: ComponentFixture<ExchangeRateEnquirySearchComponent>;
  const initialState = {
    currenciesList: [],
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ExchangeRateEnquirySearchComponent, SortPipe],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule],
      providers: [
        ExchangeRateEnquiryStoreService,
        StateObservable,
        Store,
        provideMockStore({ initialState }),
        HttpClient,
        HttpHandler,
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExchangeRateEnquirySearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should limit characters when typing in an input field', () => {
    const keyEvent = new KeyboardEvent('keypress', {
      key: '2024',
    });
    const value = 'existingValue';
    const limit = 13;

    component.limitCharacters(keyEvent, value, limit);
    expect(value.length).toBeLessThanOrEqual(limit);
  });

  it('should swap from and to currencies and countries correctly', () => {
    component.form.setValue({
      fromSearchCurrency: '100',
      fromIsoCurrency: 'USD',
      toSearchCurrency: '85',
      toIsoCurrency: 'EUR',
      monthFrom: '',
      yearFrom: '',
      monthTo: '',
      yearTo: '',
    });

    component.swapCurrencies();

    const formValue = component.form.value;
    expect(formValue.fromSearchCurrency).toBe('85');
    expect(formValue.fromIsoCurrency).toBe('EUR');
    expect(formValue.toSearchCurrency).toBe('100');
    expect(formValue.toIsoCurrency).toBe('USD');
  });

  it('should set the provided value to the given control', () => {
    const control = new FormControl('');
    const testValue = 'Test Value';

    component.setSelectValue(control, testValue);

    expect(control.value).toBe(testValue);
  });
});
