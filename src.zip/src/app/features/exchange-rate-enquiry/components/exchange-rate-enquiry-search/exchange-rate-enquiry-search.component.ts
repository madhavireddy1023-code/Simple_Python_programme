import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { months, optionalMonths } from '@shared/consts/month.const';
import { Option } from '@dxc-technology/halstack-angular';
import { LimitCharacters, setSelectValue } from 'src/app/utils/helper/helper';
import { ExchangeRateEnquiryStoreService } from '@features/exchange-rate-enquiry/services/exchange-rate-enquiry-store.service';
import { filter, map } from 'rxjs/operators';
import {
  dateRangeValidator,
  maxMonthLimitWithCurrentYearValidator,
} from '@features/exchange-rate-enquiry/utils/validations.helper';

@Component({
  selector: 'app-exchange-rate-enquiry-search',
  templateUrl: './exchange-rate-enquiry-search.component.html',
  styleUrls: ['./exchange-rate-enquiry-search.component.scss'],
})
export class ExchangeRateEnquirySearchComponent implements OnInit {
  form: FormGroup;
  monthOptions: Option[] = months;
  isSubmitButtonClicked: boolean;
  currenciesList$ = this.storeService.selectCurrenciesList().pipe(
    filter((currenciesList) => Array.isArray(currenciesList)),
    map((currenciesList) => {
      return currenciesList.map((currencyItem) => ({
        label: currencyItem.code,
        value: `${currencyItem.code} ${currencyItem.description}`,
      }));
    })
  );

  constructor(private fb: FormBuilder, private storeService: ExchangeRateEnquiryStoreService) {}

  @Input() set isOptionalMonths(isOptional: boolean | undefined) {
    this.monthOptions = (isOptional && optionalMonths) || months;
  }

  get monthFromControl(): AbstractControl {
    return this.form.get('monthFrom');
  }
  get monthToControl(): AbstractControl {
    return this.form.get('monthTo');
  }

  get yearFromControl(): AbstractControl {
    return this.form.get('yearFrom');
  }
  get yearToControl(): AbstractControl {
    return this.form.get('yearTo');
  }

  ngOnInit(): void {
    this.form = this.fb.group(
      {
        fromSearchCurrency: [''],
        fromIsoCurrency: ['', Validators.required],
        toSearchCurrency: [''],
        toIsoCurrency: ['', Validators.required],
        monthFrom: [''],
        yearFrom: [''],
        monthTo: ['', maxMonthLimitWithCurrentYearValidator()],
        yearTo: [''],
      },
      { validators: dateRangeValidator('monthFrom', 'yearFrom', 'monthTo', 'yearTo') }
    );

    this.storeService.getCurrenciesList();
    this.setDate11MonthsAgo();
    this.setCurrentDate();
  }

  swapCurrencies(): void {
    const fromSearchCurrency = this.form.get('fromSearchCurrency').value;
    const fromIsoCurrency = this.form.get('fromIsoCurrency').value;
    const toSearchCurrency = this.form.get('toSearchCurrency').value;
    const toIsoCurrency = this.form.get('toIsoCurrency').value;

    this.form.get('fromSearchCurrency').setValue(toSearchCurrency);
    this.form.get('toSearchCurrency').setValue(fromSearchCurrency);
    this.form.get('fromIsoCurrency').setValue(toIsoCurrency);
    this.form.get('toIsoCurrency').setValue(fromIsoCurrency);
  }

  limitCharacters(event: KeyboardEvent, value: string, limit: number): void {
    LimitCharacters(event, value, limit);
  }

  setSelectValue(control: AbstractControl, value: string): void {
    setSelectValue(control, value);
  }

  setDate11MonthsAgo(): void {
    const date = new Date();
    date.setMonth(date.getMonth() - 11);
    const month11Ago = this.formatMonth(date.getMonth() + 1);
    const year11Ago = date.getFullYear();

    this.monthFromControl.setValue(month11Ago);
    this.yearFromControl.setValue(year11Ago);
  }

  setCurrentDate(): void {
    const currentDate = new Date();
    const currentMonth = this.formatMonth(currentDate.getMonth() + 1);
    const currentYear = currentDate.getFullYear();

    this.monthToControl.setValue(currentMonth);
    this.yearToControl.setValue(currentYear);
  }

  formatMonth(month: number): string {
    return month < 10 ? `0${month}` : `${month}`;
  }

  onSubmit(): void {
    this.isSubmitButtonClicked = true;

    if (this.form.valid) {
      const submitValue = {
        fromCurrency: this.form.get('fromIsoCurrency').value,
        toCurrency: this.form.get('toIsoCurrency').value,
        fromDate:
          this.yearFromControl.value && this.monthFromControl.value
            ? new Date(this.yearFromControl.value, this.monthFromControl.value - 1, 1)
            : null,
        toDate:
          this.yearToControl.value && this.monthToControl.value
            ? new Date(this.yearToControl.value, this.monthToControl.value - 1, 1)
            : null,
      };

      this.storeService.getExchangeRateLimitsList(submitValue);
    }
  }
}
