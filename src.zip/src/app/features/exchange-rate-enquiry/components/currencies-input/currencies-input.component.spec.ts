import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';

import { CurrenciesInputComponent } from './currencies-input.component';
import { FormControl } from '@angular/forms';
import { SortPipe } from '@shared/pipes/sort.pipe';

describe('CurrenciesInputComponent', () => {
  let component: CurrenciesInputComponent;
  let fixture: ComponentFixture<CurrenciesInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CurrenciesInputComponent, SortPipe],
    }).compileComponents();

    fixture = TestBed.createComponent(CurrenciesInputComponent);
    component = fixture.componentInstance;
    component.currencySearchControl = new FormControl('');
    component.isoCurrencyControl = new FormControl('');
    component.currencyList = [
      { value: 'USD', label: 'US Dollar' },
      { value: 'EUR', label: 'Euro' },
      { value: 'JPY', label: 'Japanese Yen' },
    ];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the provided value to the given control', () => {
    const control = new FormControl('');
    const testValue = 'Test Value';

    component.setSelectValue(control, testValue);

    expect(control.value).toBe(testValue);
  });

  it('should filter currencies based on search input', fakeAsync(() => {
    spyOn(component, 'filterCurrencies');

    component.setupFilter();
    fixture.detectChanges();
  }));

  it('should filter to matching currencies', () => {
    component.filterCurrencies('us');
    expect(component.filteredCurrencyList).toEqual([{ value: 'USD', label: 'US Dollar' }]);
  });

  it('should reset list if no currency matches', () => {
    spyOn(component.isoCurrencyControl, 'setValue');
    spyOn(component, 'setSelectValue').and.callThrough();
    component.filterCurrencies('xyz');
    expect(component.filteredCurrencyList.length).toBe(0);
    expect(component.isoCurrencyControl.setValue).toHaveBeenCalledWith('');
    expect(component.setSelectValue).toHaveBeenCalledWith(component.isoCurrencyControl, '');
  });

  it('should reset to full list if empty string provided', () => {
    component.filterCurrencies('');
    expect(component.filteredCurrencyList.length).toBe(3);
  });
});
