import { ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { Option } from '@dxc-technology/halstack-angular/lib/dxc-select/interfaces/option.interface';
import { AbstractControl, FormControl } from '@angular/forms';
import { setSelectValue } from 'src/app/utils/helper/helper';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-currencies-input',
  templateUrl: './currencies-input.component.html',
  styleUrls: ['./currencies-input.component.scss'],
})
export class CurrenciesInputComponent implements OnInit, OnChanges, OnDestroy {
  private destroy$ = new Subject();

  @Input() label: string;
  @Input() requiredErrorMessage: string;
  @Input() currencyList: Option[];
  @Input() currencySearchControl: FormControl;
  @Input() isoCurrencyControl: FormControl;
  @Input() isSubmitButtonClicked: boolean;

  filteredCurrencyList: Option[] = [];

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.currencyList && this.currencyList) {
      this.filteredCurrencyList = [...this.currencyList];
      this.setupFilter();
    }
  }

  constructor(private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.filteredCurrencyList = [...this.currencyList];
  }

  setSelectValue(control: AbstractControl, value: string): void {
    if (value) {
      this.currencySearchControl.setValue(value);
      setSelectValue(control, value);
    }
  }

  setupFilter(): void {
    this.currencySearchControl?.valueChanges.pipe(takeUntil(this.destroy$)).subscribe((val) => {
      this.filterCurrencies(val);
    });
  }

  filterCurrencies(val: string): void {
    if (!val) {
      this.filteredCurrencyList = [...this.currencyList];
    } else {
      const filtered = this.currencyList.filter((option) => option.value.toLowerCase().includes(val.toLowerCase()));

      if (!filtered.length) {
        this.isoCurrencyControl.setValue('');
        this.setSelectValue(this.isoCurrencyControl, '');
        this.cdr.detectChanges();
      }
      this.filteredCurrencyList = filtered;
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
