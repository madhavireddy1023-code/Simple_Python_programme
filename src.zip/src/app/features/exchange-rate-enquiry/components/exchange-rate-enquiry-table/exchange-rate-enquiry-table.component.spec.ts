import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExchangeRateEnquiryTableComponent } from './exchange-rate-enquiry-table.component';
import { ExchangeRateEnquiryStoreService } from '@features/exchange-rate-enquiry/services/exchange-rate-enquiry-store.service';
import { StateObservable, Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Pagination } from '@shared/models';

describe('ExchangeRateEnquiryTableComponent', () => {
  let component: ExchangeRateEnquiryTableComponent;
  let fixture: ComponentFixture<ExchangeRateEnquiryTableComponent>;

  const initialState = {
    currenciesList: [],
    pagination: {
      page: 1,
      itemsPerPage: 10,
    },
  };
  const storeServiceSpy = jasmine.createSpyObj('StoreService', [
    'selectAllExchangeRateEnquiryTable',
    'paginationChanged',
  ]);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ExchangeRateEnquiryTableComponent],
      providers: [
        ExchangeRateEnquiryStoreService,
        StateObservable,
        Store,
        provideMockStore({ initialState }),
        HttpClient,
        HttpHandler,
        { provide: ExchangeRateEnquiryStoreService, useValue: storeServiceSpy },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExchangeRateEnquiryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should paginationChanged to be called', () => {
    const pagination: Pagination = {
      page: 0,
      itemsPerPage: 0,
    };
    component.onPaginationChanged(pagination);
    expect(storeServiceSpy.paginationChanged).toHaveBeenCalledWith(pagination);
  });
});
