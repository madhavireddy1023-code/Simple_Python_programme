import { Component, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Pagination, TableView } from '@shared/models';
import { RateOfExchangeColumns } from '@features/exchange-rate-enquiry/consts/rate-of-exchange-table';
import { ExchangeRateEnquiryStoreService } from '@features/exchange-rate-enquiry/services/exchange-rate-enquiry-store.service';
import { ExchangeRateLimitValues } from '@dxc.lm.sdk.angular/ipos-master-data-api/lib/swaggerhub-extract/model/exchangeRateLimitValues';
import { TableSort } from '@shared/components/table/table-sort';

@Component({
  selector: 'app-exchange-rate-enquiry-table',
  templateUrl: './exchange-rate-enquiry-table.component.html',
  styleUrls: ['./exchange-rate-enquiry-table.component.scss'],
})
export class ExchangeRateEnquiryTableComponent implements OnInit {
  tableView$: Observable<TableView<ExchangeRateLimitValues>>;
  tableColumns = RateOfExchangeColumns;

  constructor(private storeService: ExchangeRateEnquiryStoreService) {}

  ngOnInit(): void {
    this.tableView$ = this.storeService.selectAllExchangeRateEnquiryTable();
  }

  onSortChanged(props: TableSort): void {
    this.storeService.sortChanged(props);
  }

  onPaginationChanged(pagination: Pagination): void {
    this.storeService.paginationChanged(pagination);
  }
}
