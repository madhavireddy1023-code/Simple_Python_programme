export interface IsoCurrency {
  id: string;
  numericCode: string;
  description: string;
  minorUnit: number;
  code: string;
  effectiveDate: string;
  datasource: string;
}

export interface CurrenciesRateLimits {
  fromCurrency: string;
  toCurrency: string;
  fromDate?: string;
  toDate?: string;
}
