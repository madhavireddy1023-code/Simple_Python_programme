import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ExchangeRateEnquiryComponent } from '@features/exchange-rate-enquiry/main/exchange-rate-enquiry/exchange-rate-enquiry.component';

const routes: Routes = [{ path: '', component: ExchangeRateEnquiryComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ExchangeRateEnquiryRoutingModule {}
