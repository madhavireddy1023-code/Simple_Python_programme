import { CurrenciesRateLimits } from '@features/exchange-rate-enquiry/interfaces/exchange-rate';

export const currenciesRateLimitsParams = (params: Partial<CurrenciesRateLimits>): CurrenciesRateLimits => {
  return {
    fromCurrency: params?.fromCurrency?.slice(0, 3),
    toCurrency: params?.toCurrency?.slice(0, 3),
    fromDate: formatDateToMonthYearDay(new Date(params?.fromDate), true),
    toDate: formatDateToMonthYearDay(new Date(params?.toDate), false),
  };
};

export function formatDateToMonthYearDay(date: Date, isStartDate: boolean): string {
  const year: string = date.getFullYear().toString();
  const month: string = (date.getMonth() + 1).toString().padStart(2, '0');
  const day: string = isStartDate ? '01' : date.getDate().toString().padStart(2, '0');

  return `${year}-${month}-${day}`;
}
