import { TableCol, TableColumnType } from '@shared/models';

export const RateOfExchangeColumns: TableCol[] = [
  {
    fieldName: 'EXCHANGE_RATE_ENQUIRY.YEAR',
    field: 'year',
    type: TableColumnType.text,
  },
  {
    fieldName: 'EXCHANGE_RATE_ENQUIRY.MONTH',
    field: 'month',
    type: TableColumnType.text,
  },
  {
    fieldName: 'EXCHANGE_RATE_ENQUIRY.LOWER_LIMIT',
    field: 'lowerLimit',
    type: TableColumnType.text,
  },
  {
    fieldName: 'EXCHANGE_RATE_ENQUIRY.UPPER_LIMIT',
    field: 'upperLimit',
    type: TableColumnType.text,
  },
];

export const RateOfExchangeTableNoDataText = 'EXCHANGE_RATE_ENQUIRY.NO_DATA';
