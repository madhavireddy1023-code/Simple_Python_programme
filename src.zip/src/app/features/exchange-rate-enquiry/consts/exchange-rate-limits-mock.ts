export const ExchangeRateLimitsMock = [
  {
    year: '2024',
    month: '12',
    lowerLimit: '0.75',
    upperLimit: '0.75',
  },
  {
    year: '2024',
    month: '1',
    lowerLimit: '0.65',
    upperLimit: '0.85',
  },
];
