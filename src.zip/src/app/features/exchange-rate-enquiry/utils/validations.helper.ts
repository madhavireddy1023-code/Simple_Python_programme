import { AbstractControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';

export function dateRangeValidator(
  monthFromKey: string,
  yearFromKey: string,
  monthToKey: string,
  yearToKey: string
): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!(control instanceof FormGroup)) {
      return null;
    }

    const monthFrom = control.get(monthFromKey)?.value;
    const yearFrom = control.get(yearFromKey)?.value;
    const monthTo = control.get(monthToKey)?.value;
    const yearTo = control.get(yearToKey)?.value;

    if (monthFrom && yearFrom && monthTo && yearTo) {
      const fromDate = new Date(yearFrom, monthFrom - 1);
      const toDate = new Date(yearTo, monthTo - 1);

      if (fromDate > toDate) {
        return { invalidDateRange: true };
      }
    }
    return null;
  };
}

export function maxMonthLimitWithCurrentYearValidator(): ValidatorFn {
  return (control: AbstractControl) => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();

    const inputMonth = parseInt(control.value, 10);

    if (inputMonth > currentMonth + 1) {
      return { monthExceedsMaxLimitWithCurrentYear: true };
    }

    return null;
  };
}
