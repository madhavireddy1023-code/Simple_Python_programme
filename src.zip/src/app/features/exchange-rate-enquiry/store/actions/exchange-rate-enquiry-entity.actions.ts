import { createAction, props } from '@ngrx/store';
import { Pagination } from '@shared/models';
import { CurrenciesRateLimits, IsoCurrency } from '@features/exchange-rate-enquiry/interfaces/exchange-rate';
import { ExchangeRateLimitValues } from '@dxc.lm.sdk.angular/ipos-master-data-api';
import { HttpErrorResponse } from '@angular/common/http';
import { TableSort } from '@shared/components/table/table-sort';

export const getCurrenciesList = createAction('[ExchangeRate/API] Get Currency List');

export const getCurrenciesListSuccess = createAction(
  '[ExchangeRate/API] Get Currency List Success',
  props<{ currenciesList: IsoCurrency[] }>()
);

export const getCurrenciesListError = createAction(
  '[ExchangeRate/API] Get Currency List Error',
  props<{ error: HttpErrorResponse }>()
);

export const getExchangeRateLimits = createAction(
  '[ExchangeRate/API] Get Exchange Rate Limits',
  props<{ params: CurrenciesRateLimits }>()
);

export const getExchangeRateLimitsSuccess = createAction(
  '[ExchangeRate/API] Get Exchange Rate Limits Success',
  props<{ exchangeRateLimitsList: ExchangeRateLimitValues[] }>()
);

export const getExchangeRateLimitsError = createAction(
  '[ExchangeRate/API] Get Exchange Rate Limits Error',
  props<{ error: HttpErrorResponse }>()
);

export const paginationChanged = createAction(
  '[ExchangeRate/API] pagination changed',
  props<{ pagination: Pagination }>()
);

export const sortChanged = createAction('[ExchangeRate/API] sort changed', props<{ tableSort: TableSort }>());
