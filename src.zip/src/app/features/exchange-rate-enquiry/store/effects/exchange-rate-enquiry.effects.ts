import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { ExchangeRateEnquiryEntityActions } from '../actions';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { IposMasterDataApiService } from '../../../../api/ipos-master-data-api';
import { currenciesRateLimitsParams } from '@features/exchange-rate-enquiry/consts/payload.const';

@Injectable()
export class ExchangeRateEnquiryEffects {
  loadCurrenciesList$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ExchangeRateEnquiryEntityActions.getCurrenciesList),
      switchMap(() =>
        this.referenceDataStoreService.selectPremiumDetails().pipe(
          map((referenceData) => {
            return ExchangeRateEnquiryEntityActions.getCurrenciesListSuccess({
              currenciesList: referenceData.isoCurrency,
            });
          }),
          catchError((error) => {
            return of(ExchangeRateEnquiryEntityActions.getCurrenciesListError({ error }));
          })
        )
      )
    )
  );

  loadExchangeRateLimits$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ExchangeRateEnquiryEntityActions.getExchangeRateLimits),
      switchMap(({ params }) => {
        const { fromCurrency, toCurrency, fromDate, toDate } = currenciesRateLimitsParams(params);

        return this.iposMasterDataApiService
          .apiV1ExchangeRateLimitsGet(fromCurrency, toCurrency, fromDate, toDate, 'response')
          .pipe(
            map((response) => {
              return ExchangeRateEnquiryEntityActions.getExchangeRateLimitsSuccess({
                exchangeRateLimitsList: response?.body,
              });
            }),
            catchError((error) => {
              return of(ExchangeRateEnquiryEntityActions.getExchangeRateLimitsError({ error }));
            })
          );
      })
    )
  );
  constructor(
    private actions$: Actions,
    private referenceDataStoreService: ReferenceDataStoreService,
    private iposMasterDataApiService: IposMasterDataApiService
  ) {}
}
