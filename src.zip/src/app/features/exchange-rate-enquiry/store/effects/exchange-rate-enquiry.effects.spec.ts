import { TestBed } from '@angular/core/testing';
import { Observable, of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ExchangeRateEnquiryEffects } from '@features/exchange-rate-enquiry/store/effects/exchange-rate-enquiry.effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { ActionsSubject, ReducerManager, ReducerManagerDispatcher, StateObservable, Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { IposMasterDataApiService } from '../../../../api/ipos-master-data-api';
import { ExchangeRateEnquiryEntityActions } from '@features/exchange-rate-enquiry/store';

describe('ExchangeRateEnquiryEffects', () => {
  let actions$: Observable<any>;
  let effects: ExchangeRateEnquiryEffects;
  let referenceDataStoreService: jasmine.SpyObj<ReferenceDataStoreService>;
  let iposMasterDataApiService: jasmine.SpyObj<IposMasterDataApiService>;

  const initialState = {
    currenciesList: [],
  };

  beforeEach(() => {
    const spy1 = jasmine.createSpyObj('ReferenceDataStoreService', ['selectPremiumDetails']);
    const spy2 = jasmine.createSpyObj('IposMasterDataApiService', ['apiV1ExchangeRateLimitsGet']);

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        ExchangeRateEnquiryEffects,
        Store,
        StateObservable,
        ActionsSubject,
        ReducerManager,
        ReducerManagerDispatcher,
        IposMasterDataApiService,
        { provide: ReferenceDataStoreService, useValue: spy1 },
        { provide: IposMasterDataApiService, useValue: spy2 },

        provideMockActions(() => actions$),
        provideMockStore({ initialState }),
      ],
    });

    effects = TestBed.inject(ExchangeRateEnquiryEffects);
    referenceDataStoreService = TestBed.inject(ReferenceDataStoreService) as jasmine.SpyObj<ReferenceDataStoreService>;
    iposMasterDataApiService = TestBed.inject(IposMasterDataApiService) as jasmine.SpyObj<IposMasterDataApiService>;
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });

  it('should dispatch getCurrenciesListSuccess with currencies list on success', (done) => {
    const mockReferenceData = {
      isoCurrency: [
        {
          id: '28b43e82-0180-418b-9ca8-a3ce54b8ff12',
          numericCode: '965',
          description: 'ADB Unit of Account',
          minorUnit: 0,
          code: 'XUA',
          effectiveDate: '1900-01-01',
          datasource: 'DEFAULT',
        },
      ],
    };
    referenceDataStoreService.selectPremiumDetails.and.returnValue(of(mockReferenceData));
    actions$ = of(ExchangeRateEnquiryEntityActions.getCurrenciesList());

    effects.loadCurrenciesList$.subscribe((action) => {
      expect(action).toEqual(
        ExchangeRateEnquiryEntityActions.getCurrenciesListSuccess({
          currenciesList: mockReferenceData.isoCurrency,
        })
      );
      done();
    });
  });

  it('should dispatch getExchangeRateLimitsSuccess with exchange rate limits list on success', (done) => {
    const mockParams = {
      fromCurrency: 'USD',
      toCurrency: 'EUR',
      fromDate: '2023-01-01',
      toDate: '2023-01-31',
    };
    const mockResponse = {
      body: [
        {
          id: 'test-id',
          fromCurrency: 'USD',
          toCurrency: 'EUR',
          limit: 1000,
          fromDate: '2023-01-01',
          toDate: '2023-01-31',
        },
      ],
    };

    // @ts-ignore
    iposMasterDataApiService.apiV1ExchangeRateLimitsGet.and.returnValue(of(mockResponse));

    actions$ = of(ExchangeRateEnquiryEntityActions.getExchangeRateLimits({ params: mockParams }));

    effects.loadExchangeRateLimits$.subscribe((action) => {
      expect(action).toEqual(
        ExchangeRateEnquiryEntityActions.getExchangeRateLimitsSuccess({
          // @ts-ignore
          exchangeRateLimitsList: mockResponse.body,
        })
      );
      done();
    });
  });
});
