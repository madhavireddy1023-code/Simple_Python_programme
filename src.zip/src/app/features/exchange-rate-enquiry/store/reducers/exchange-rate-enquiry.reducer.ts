import { createReducer, on } from '@ngrx/store';
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import {
  getCurrenciesListSuccess,
  getExchangeRateLimitsError,
  getExchangeRateLimitsSuccess,
  paginationChanged,
  sortChanged,
} from '@features/exchange-rate-enquiry/store/actions/exchange-rate-enquiry-entity.actions';
import { DefaultPagination, Pagination } from '@shared/models';
import { IsoCurrency } from '@features/exchange-rate-enquiry/interfaces/exchange-rate';
import { ExchangeRateLimitValues } from '@dxc.lm.sdk.angular/ipos-master-data-api/lib/swaggerhub-extract/model/exchangeRateLimitValues';
import { TableSort } from '@shared/components/table/table-sort';

export const exchangeRateEnquiryFeatureKey = 'exchangeRateEnquiry';

export interface ExchangeRateEnquiryState extends EntityState<ExchangeRateLimitValues> {
  currenciesList: IsoCurrency[];
  pagination: Pagination;
  tableSort: TableSort;
}

export const adapter: EntityAdapter<ExchangeRateLimitValues> = createEntityAdapter<ExchangeRateLimitValues>();

export const initialState: ExchangeRateEnquiryState = adapter.getInitialState({
  currenciesList: [],
  pagination: DefaultPagination,
  tableSort: null,
});

export const reducer = createReducer(
  initialState,
  on(getCurrenciesListSuccess, (state, { currenciesList }) => ({
    ...state,
    currenciesList,
  })),
  on(getExchangeRateLimitsSuccess, (state, { exchangeRateLimitsList }) => {
    if (!Array.isArray(exchangeRateLimitsList)) {
      if (exchangeRateLimitsList && typeof exchangeRateLimitsList === 'object') {
        exchangeRateLimitsList = [exchangeRateLimitsList];
      } else {
        return state;
      }
    }

    const exchangeRateLimitsWithIds = exchangeRateLimitsList.map((item, index) => ({
      ...item,
      id: `${index}`,
    }));

    return adapter.setAll(exchangeRateLimitsWithIds, state);
  }),
  on(getExchangeRateLimitsError, (state) => {
    return adapter.removeAll({
      ...state,
      pagination: DefaultPagination,
    });
  }),
  on(paginationChanged, (state, { pagination }) => ({
    ...state,
    pagination: { ...pagination },
  })),
  on(sortChanged, (state, { tableSort }) => ({
    ...state,
    tableSort: { ...tableSort },
  }))
);

export const { selectIds, selectEntities, selectAll, selectTotal } = adapter.getSelectors();
