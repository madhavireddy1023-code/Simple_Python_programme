import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromExchangeRateEnquiry from '../reducers/exchange-rate-enquiry.reducer';
import { ExchangeRateEnquiryState } from '../reducers/exchange-rate-enquiry.reducer';
import { DefaultPagination } from '@shared/models';
import { RateOfExchangeTableNoDataText } from '@features/exchange-rate-enquiry/consts/rate-of-exchange-table';
import { SORT_TYPES } from '@shared/consts/shared.enums';
import * as _ from 'lodash';
import { ExchangeRateLimitValues } from '@dxc.lm.sdk.angular/ipos-master-data-api';

export const selectExchangeRateEnquiryState = createFeatureSelector<ExchangeRateEnquiryState>(
  fromExchangeRateEnquiry.exchangeRateEnquiryFeatureKey
);

export const selectAllExchangeRateEnquiry = createSelector(
  selectExchangeRateEnquiryState,
  fromExchangeRateEnquiry.selectAll
);

export const selectTableSort = createSelector(selectExchangeRateEnquiryState, (state) => state?.tableSort);

export const selectSortedExchangeRateEnquiry = createSelector(
  selectAllExchangeRateEnquiry,
  selectTableSort,
  (exchangeRateEnquiry, tableSort) => {
    if (!tableSort || tableSort.sortType === SORT_TYPES.DEFAULT) {
      return exchangeRateEnquiry;
    }
    const fieldName = tableSort.fieldName;
    const sortedStops = _.sortBy(exchangeRateEnquiry, (data: ExchangeRateLimitValues) => {
      // Undefined properties need to be moved to the end
      if (data[fieldName] === undefined) {
        return null;
      }
      return data[fieldName];
    });
    return tableSort.sortType === SORT_TYPES.ASC ? sortedStops : sortedStops?.reverse();
  }
);

export const selectCurrenciesList = createSelector(selectExchangeRateEnquiryState, (state) => state?.currenciesList);
export const selectPagination = createSelector(selectExchangeRateEnquiryState, (state) => state?.pagination);

export const selectAllExchangeRateEnquiryTable = createSelector(
  selectSortedExchangeRateEnquiry,
  selectPagination,
  selectTableSort,
  (sortedExchangeRateEnquiry, pagination, tableSort) => ({
    allItems: sortedExchangeRateEnquiry,
    getRowClass: () => 's',
    checkIsSelected: () => false,
    checkIsExpanded: () => false,
    getChipClass: () => 'red-color',
    getColumnSort: (fieldName: string) =>
      tableSort && tableSort.fieldName === fieldName ? tableSort.sortType : SORT_TYPES.DEFAULT,
    paginatedItems: sortedExchangeRateEnquiry.slice(
      (pagination.page - 1) * pagination.itemsPerPage,
      (pagination.page - 1) * pagination.itemsPerPage + pagination.itemsPerPage
    ),
    pagination: DefaultPagination,
    noDataText: RateOfExchangeTableNoDataText,
  })
);
