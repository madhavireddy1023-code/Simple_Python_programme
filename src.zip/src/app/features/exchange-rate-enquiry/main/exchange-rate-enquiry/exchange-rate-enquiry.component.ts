import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exchange-rate-enquiry',
  templateUrl: './exchange-rate-enquiry.component.html',
  styleUrls: ['./exchange-rate-enquiry.component.scss'],
})
export class ExchangeRateEnquiryComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
