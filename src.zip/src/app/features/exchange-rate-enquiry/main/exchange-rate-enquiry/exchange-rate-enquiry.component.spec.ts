import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExchangeRateEnquiryComponent } from './exchange-rate-enquiry.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormBuilder } from '@angular/forms';

describe('ExchangeRateEnquiryComponent', () => {
  let component: ExchangeRateEnquiryComponent;
  let fixture: ComponentFixture<ExchangeRateEnquiryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ExchangeRateEnquiryComponent],
      imports: [TranslateModule.forRoot()],
      providers: [FormBuilder],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExchangeRateEnquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
