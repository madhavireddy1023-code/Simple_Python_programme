import { TestBed } from '@angular/core/testing';

import { ExchangeRateEnquiryStoreService } from './exchange-rate-enquiry-store.service';
import { StateObservable, Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ExchangeRateLimitsMock } from '@features/exchange-rate-enquiry/consts/exchange-rate-limits-mock';
import { ExchangeRateEnquiryEntityActions } from '@features/exchange-rate-enquiry/store';
import { of } from 'rxjs';

describe('ExchangeRateEnquiryStoreService', () => {
  let service: ExchangeRateEnquiryStoreService;
  const initialState = {
    currenciesList: [],
  };
  let store: MockStore;
  let dispatchSpy: jasmine.Spy;
  const mockExchangeRateEnquiries = [
    { id: 1, rate: '0.75', currency: 'USD' },
    { id: 2, rate: '0.85', currency: 'EUR' },
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ExchangeRateEnquiryStoreService,
        StateObservable,
        Store,
        provideMockStore({ initialState }),
        HttpClient,
        HttpHandler,
      ],
    });
    service = TestBed.inject(ExchangeRateEnquiryStoreService);
    store = TestBed.inject(MockStore);
    dispatchSpy = spyOn(store, 'dispatch');
    spyOn(store, 'select').and.returnValue(of(mockExchangeRateEnquiries));
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return an observable that emits the exchange rate limits', (done: DoneFn) => {
    service.getExchangeRateLimits().subscribe((data) => {
      expect(data.length).toBe(ExchangeRateLimitsMock.length);

      data.forEach((limit, index) => {
        const expectedLimit = ExchangeRateLimitsMock[index];
        expect(limit.year).toEqual(expectedLimit.year);
        expect(limit.month).toEqual(expectedLimit.month);
        expect(limit.lowerLimit).toEqual(expectedLimit.lowerLimit);
        expect(limit.upperLimit).toEqual(expectedLimit.upperLimit);
      });

      done();
    }, done.fail);
  });

  it('should dispatch getExchangeRateLimits action with given params', () => {
    const mockParams = {
      fromCurrency: 'USD',
      toCurrency: 'EUR',
      fromDate: '2023-01-01',
      toDate: '2023-12-31',
    };
    service.getExchangeRateLimitsList(mockParams);

    expect(dispatchSpy).toHaveBeenCalledWith(
      ExchangeRateEnquiryEntityActions.getExchangeRateLimits({ params: mockParams })
    );
  });
});
