import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { ExchangeRateEnquiryEntityActions, fromExchangeRateEnquiry } from '@features/exchange-rate-enquiry/store';
import { Observable, of } from 'rxjs';
import { ExchangeRateEnquirySelectors } from '../store/selectors';
import { ExchangeRateLimitsMock } from '@features/exchange-rate-enquiry/consts/exchange-rate-limits-mock';
import { HttpClient } from '@angular/common/http';
import { Pagination } from '@shared/models';
import { TableSort } from '@shared/components/table/table-sort';

@Injectable({
  providedIn: 'root',
})
export class ExchangeRateEnquiryStoreService {
  constructor(private store: Store<fromExchangeRateEnquiry.ExchangeRateEnquiryState>, private http: HttpClient) {}

  sortChanged(tableSort: TableSort): void {
    this.store.dispatch(ExchangeRateEnquiryEntityActions.sortChanged({ tableSort }));
  }

  getExchangeRateLimits(): Observable<any[]> {
    return of(ExchangeRateLimitsMock);
  }

  selectExchangeRateEnquiryState(): Observable<any> {
    return this.store.select(ExchangeRateEnquirySelectors.selectExchangeRateEnquiryState);
  }

  getExchangeRateLimitsList(params: any): void {
    this.store.dispatch(ExchangeRateEnquiryEntityActions.getExchangeRateLimits({ params }));
  }
  getCurrenciesList(): void {
    this.store.dispatch(ExchangeRateEnquiryEntityActions.getCurrenciesList());
  }

  paginationChanged(pagination: Pagination): void {
    this.store.dispatch(ExchangeRateEnquiryEntityActions.paginationChanged({ pagination }));
  }

  selectCurrenciesList(): Observable<any[]> {
    return this.store.select(ExchangeRateEnquirySelectors.selectCurrenciesList);
  }

  selectAllExchangeRateEnquiryTable(): Observable<any> {
    return this.store.select(ExchangeRateEnquirySelectors.selectAllExchangeRateEnquiryTable);
  }
}
