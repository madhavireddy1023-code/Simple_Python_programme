import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';
import { ExchangeRateEnquiryComponent } from '@features/exchange-rate-enquiry/main/exchange-rate-enquiry/exchange-rate-enquiry.component';
import { ExchangeRateEnquiryRoutingModule } from '@features/exchange-rate-enquiry/exchange-rate-enquiry-routing.module';
import { CurrenciesInputComponent } from './components/currencies-input/currencies-input.component';
import { DxcSelectModule } from '@dxc-technology/halstack-angular';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import * as fromExchangeRateEnquiry from '@features/exchange-rate-enquiry/store/reducers/exchange-rate-enquiry.reducer';
import { ExchangeRateEnquiryEffects } from '@features/exchange-rate-enquiry/store/effects/exchange-rate-enquiry.effects';
import { ExchangeRateEnquirySearchComponent } from './components/exchange-rate-enquiry-search/exchange-rate-enquiry-search.component';
import { ExchangeRateEnquiryTableComponent } from './components/exchange-rate-enquiry-table/exchange-rate-enquiry-table.component';

@NgModule({
  declarations: [
    ExchangeRateEnquiryComponent,
    CurrenciesInputComponent,
    ExchangeRateEnquirySearchComponent,
    ExchangeRateEnquiryTableComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    ExchangeRateEnquiryRoutingModule,
    DxcSelectModule,
    EffectsModule.forFeature([ExchangeRateEnquiryEffects]),
    StoreModule.forFeature(fromExchangeRateEnquiry.exchangeRateEnquiryFeatureKey, fromExchangeRateEnquiry.reducer),
  ],
})
export class ExchangeRateEnquiryModule {}
