import { AccountingTypeEnum } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

/**
 * Accounting type option labels mapping
 */
export const ACCOUNTING_TYPE_OPTIONS = {
  [AccountingTypeEnum.NONCASHPAIDBYCHEQUE]: 'Non cash / Paid by cheque',
  [AccountingTypeEnum.NORMALTRANSACTION]: 'Normal transaction',
};
