import { PremiumGetRec, SigningGetRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

export const mockPremiumDetails: PremiumGetRec = {
  premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  transactionType: {
    refTypeOfTransactionTypeId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
    typeOfTransactionType: 'Premium',
  },
  chargesIndicator: true,
  instalmentDetails: [
    {
      instalmentId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      dtInstalmentId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      number: 0,
      dueDate: '2024-02-26',
      netPremium: 0,
      settlementStatus: 'None',
      settled: 'N',
      settlementId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    },
  ],
  correctionNarrative: 'CAN',
};

// TODO: Change back to variable type after contract upgrade over vesion 1.2.0
export const mockInstalmentCorrectionRecord: any = {
  premiumId: 'bb11c218-ed73-4cd8-934d-209c2dbcd715',
  userId: '',
  transactionType: {
    refTypeOfTransactionTypeId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
    typeOfTransactionType: 'Premium',
  },
  chargeableIndicator: true,
  correctionSigningNarrative: 'string',
  instalments: [
    {
      instalmentId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      dtInstalmentId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      number: 0,
      dueDate: '2024-02-26',
      netPremium: 0,
      settlementStatus: 'None',
      settled: 'N',
      settlementId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    },
  ],
};

export const mockSigningDetails: SigningGetRecord = {
  signingId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  submissionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  presentationDate: '2024-02-29',
  chargeableIndicator: true,
  correctionNarrative: 'string',
  signingPremiums: [
    {
      signingPremiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      signingId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      sectionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      sectionNumber: 0,
      riskCode: 'string',
      premiumNarrative: 'string',
      originalCurrency: {
        refTypeCurrencyId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
        typeOfCurrency: 'GBP',
      },
      premiumNet: 0,
      transaction: {
        refTypeOfTransactionTypeId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
        typeOfTransactionType: 'Premium',
      },
      bsnd: 'string',
      csnd: 'string',
      csn: 'string',
      csnVersion: 0,
      bsn: 'string',
      bsnVersion: 0,
      signingMessage: 'string',
      signedByUser: 'string',
      signedByUserFullName: 'string',
      signedByUserEmail: 'string',
      directPremiumBsnd: 'string',
      directPremiumCsnd: 'string',
      recordStatusCode: 'Active',
      naicInfoStatus: 'COMPLETE',
      usSurplusLineInfoStatus: 'COMPLETE',
    },
  ],
};
