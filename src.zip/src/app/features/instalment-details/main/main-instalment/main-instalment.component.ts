import { Component, OnInit } from '@angular/core';
import { PremiumGetRec, SigningGetRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Observable } from 'rxjs';
import { InstalmentDetailsStoreService } from '@features/instalment-details/services/instalment-details.store.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';

@Component({
  selector: 'app-main-instalment',
  templateUrl: './main-instalment.component.html',
  styleUrls: ['./main-instalment.component.scss'],
})
export class MainInstalmentComponent implements OnInit {
  premiumDetailsData$: Observable<any>;
  queryParams$: Observable<Params>;
  signingDetailsData$: Observable<SigningGetRecord>;
  authDetails$: Observable<any>;
  url: string;

  constructor(
    private instalmentDetailsStoreService: InstalmentDetailsStoreService,
    private route: ActivatedRoute,
    private auth: AuthenticationService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.signingDetailsData$ = this.instalmentDetailsStoreService.selectSigningDetails();
    this.premiumDetailsData$ = this.instalmentDetailsStoreService.selectPremiumDetailsFromDef();
    this.queryParams$ = this.route.queryParams;
    this.authDetails$ = this.auth.username$;
    this.url = this.router.url;
  }
}
