import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MainInstalmentComponent } from './main-instalment.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { InstalmentDetailsStoreService } from '@features/instalment-details/services/instalment-details.store.service';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';

describe('MainInstalmentComponent', () => {
  let component: MainInstalmentComponent;
  let fixture: ComponentFixture<MainInstalmentComponent>;
  let instalmentDetailsStoreService: InstalmentDetailsStoreService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainInstalmentComponent],
      imports: [TranslateModule.forRoot(), RouterModule.forRoot([]), RouterTestingModule.withRoutes([])],
      providers: [MockStore, provideMockStore(), InstalmentDetailsStoreService, AuthenticationService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainInstalmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    instalmentDetailsStoreService = TestBed.inject(InstalmentDetailsStoreService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call selectPremiumDetails on onInit', () => {
    spyOn(instalmentDetailsStoreService, 'selectPremiumDetailsFromDef');
    component.ngOnInit();
    fixture.detectChanges();
    expect(instalmentDetailsStoreService.selectPremiumDetailsFromDef).toHaveBeenCalled();
  });

  it('should call selectSigningDetails on onInit', () => {
    spyOn(instalmentDetailsStoreService, 'selectSigningDetails');
    component.ngOnInit();
    fixture.detectChanges();
    expect(instalmentDetailsStoreService.selectSigningDetails).toHaveBeenCalled();
  });
});
