import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainInstalmentComponent } from '@features/instalment-details/main/main-instalment/main-instalment.component';

const routes: Routes = [{ path: '', component: MainInstalmentComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InstalmentDetailsRoutingModule {}
