import { PremiumGetRec, SigningGetRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

export interface InstalmentDetailsState {
  premiumDetails: PremiumGetRec;
  etag: string;
  signingDetails: SigningGetRecord;
  instalmentDetails: PremiumGetRec;
}
