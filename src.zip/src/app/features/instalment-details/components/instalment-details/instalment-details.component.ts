import { Component, Input, OnInit, QueryList, ViewChildren, ViewEncapsulation, ViewChild } from '@angular/core';
import {
  PremiumGetRec,
  SigningGetRecord,
  IposReferenceData,
  SigningPremiumGets,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Observable, Subject } from 'rxjs';
import { InstalmentDetailsStoreService } from '@features/instalment-details/services/instalment-details.store.service';
import { Params, Router } from '@angular/router';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DateInputComponent } from '@shared/components/date-input/date-input.component';
import { DatePipe } from '@angular/common';
import { InstalmentDetail, InstalmentDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { parseValue } from '@shared/consts/shared.consts';
import { ENQUIRY_URL } from '@shared/consts/shared.consts';
import { ReferenceDataService } from '@shared/services/reference-data/reference-data.service';
import { TeamBasketStoreService } from '@shared/services/team-basket/team-basket.store.service';
import { TeamBasket } from '@shared/interfaces/team-basket';
import { formatOption } from 'src/app/utils';
import { ScrollUp } from 'src/app/utils';
import { TranslateService } from '@ngx-translate/core';
import { dueDatesSequenceValidator } from '@features/section-details/helper/business-rule-instalment-validators';
import { DefInstalmentService } from '@features/enquiry/services/def-instalment.service';
import * as _ from 'lodash';
import { InstalmentCorrectionRecord } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';
import { FormControls } from '@shared/models';

@Component({
  selector: 'app-instalment-details',
  templateUrl: './instalment-details.component.html',
  styleUrls: ['./instalment-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class InstalmentDetailsComponent implements OnInit {
  isInstalmentDetails: boolean;
  premiumDetailsRef: PremiumGetRec;
  premiumId: string;
  typeOfPremium: string;
  responseData$: Observable<any>;
  etag: string;
  chargeableIndicatorCheckbox: boolean;
  instalmentCorrectionRecord: InstalmentCorrectionRecord;
  instalmentDetailsForm: FormGroup;
  datePipe = new DatePipe('en-UK');
  submissionId: string;
  signingDetailsRef: SigningGetRecord;
  signingPremObj: any;
  refErrorDescriptionsRefData$: Observable<IposReferenceData>;
  saveBtnClicked: Subject<boolean> = new Subject<boolean>();
  chargeableIndicator: boolean;
  requiredErrorBanner = false;
  requiredLabel: string;
  instalmentsErrors: string[] = [];
  requiredErrors: string[] = [];
  userNameRef: string;
  wrongDueDatesOrder: boolean;
  disableDueDate: boolean[] = [];
  umr: string;
  workPackageRef: string;
  csnd: string;
  initialValue = [];

  mistFormValues = {};
  isFormVaild = false;
  readonly ERROR_DESCRIPTION = 'errorDescription';
  readonly TEAM_BASKET = 'teamBasket';
  signedByUserFullName: string;

  @Input() set premiumDetails(premiumDetails: PremiumGetRec) {
    this.premiumDetailsRef = premiumDetails;
    if (premiumDetails?.instalmentDetails?.length > 0) {
      this.premiumDetailsRef?.instalmentDetails?.forEach((instalment: InstalmentDetail, index: number) => {
        const dueDate = new Date(instalment?.dueDate);
        const currentDate = new Date();
        const dueDateMonth = dueDate.getMonth();
        const currentMonth = currentDate.getMonth();
        const threeDaysBefore = dueDate.getDate() - 3;
        const dateBeforeDueDate = new Date(dueDate.getFullYear(), dueDateMonth, threeDaysBefore);
        const disableDate = this.checkWeekend(dateBeforeDueDate) ? dueDate.getDate() - 5 : dueDate.getDate() - 3;

        if (currentDate.getDate() >= disableDate && dueDateMonth === currentMonth) {
          this.disableDueDate[index] = true;
        }
        index === 0 ? this.initInstalmentDetailsForm(instalment) : this.onAddInstalmentDetails(instalment);
      });
    } else {
      this.initInstalmentDetailsForm();
    }
  }

  @Input() set signingDetails(signingDetails: SigningGetRecord) {
    this.signingDetailsRef = signingDetails;
    this.signingPremObj = signingDetails?.signingPremiums?.find(
      (submission) => submission.premiumId === this.premiumId
    );
    this.chargeableIndicatorCheckbox = this.signingPremObj?.chargeableIndicator;
    this.signedByUserFullName = this.signingPremObj?.signedByUserFullName;
  }

  @Input() set queryParams(params: Params) {
    if (params) {
      this.premiumId = params?.premiumId;
      this.typeOfPremium = params?.typeOfPremium;
      this.submissionId = params?.submissionId;
      this.umr = params?.umr;
      this.workPackageRef = params?.workPackageRef;
      this.csnd = params?.csnd;
      if (!this.premiumDetailsRef) {
        this.defInstalmentService.getPremiumDetails(
          this.workPackageRef,
          this.premiumId,
          this.typeOfPremium,
          this.umr,
          this.csnd
        );
      }
    }
  }

  @Input() url;

  @Input() userName;

  mistFormConfig = {
    errorMadeBy: {
      value: '',
      disabled: false,
      options: [
        { label: 'Broker', value: 'Broker' },
        { label: 'Underwriter', value: 'Underwriter' },
        { label: 'Non-Attributable', value: 'Non-Attributable' },
        { label: 'Velonetic', value: 'Velonetic' },
        { label: 'Old Tech Error', value: 'Old Tech Error' },
        { label: 'Technician/Broker', value: 'Technician/Broker' },
      ],
    },
    category: {
      value: '',
      disabled: false,
      options: [
        { label: 'Code Changes', value: 'Code Changes' },
        { label: 'Excess of Loss', value: 'Excess of Loss' },
        { label: 'Premium Change', value: 'Premium Change' },
        { label: 'Regulatory Changes', value: 'Regulatory Changes' },
        { label: 'Settlement Changes', value: 'Settlement Changes' },
        { label: 'Tax Legislatio', value: 'Tax Legislatio' },
      ],
    },
    errorDescription: {
      value: '',
      disabled: false,
      options: [],
    },
    mistNarrative: {
      value: '',
      disabled: false,
    },
    noOneLeaver: {
      value: '',
      disabled: false,
      options: [
        { label: 'No one', value: 'No one' },
        { label: 'Leaver', value: 'Leaver' },
      ],
    },
    override: {
      value: false,
      disabled: false,
    },
    teamBasket: {
      value: '',
      disabled: false,
      options: [],
    },
    teamNameOverriden: {
      value: '',
      disabled: false,
      options: [],
    },
  };

  @ViewChildren('dueDate') dueDate: QueryList<DateInputComponent>;
  @ViewChild('actualPaymentDate') actualPaymentDate: DateInputComponent;

  showChargeableError = false;
  childFieldValues = {
    errorMadeBy: '',
    noOneLeaver: '',
  };
  chargeableErrorMsg = '';
  constructor(
    private instalmentDetailsStoreService: InstalmentDetailsStoreService,
    private globalAlertStoreService: GlobalAlertStoreService,
    private router: Router,
    private formBuilder: FormBuilder,
    private referenceDataService: ReferenceDataService,
    private teamBasketStoreService: TeamBasketStoreService,
    private translateService: TranslateService,
    private defInstalmentService: DefInstalmentService
  ) {}

  get instalmentDetailsControls(): any {
    return this.instalmentDetailsForm?.controls;
  }

  get instalmentDetailsFormArray(): FormArray {
    return this.instalmentDetailsForm?.get('instalments') as FormArray;
  }

  ngOnInit(): void {
    this.isInstalmentDetails = true;
    this.refErrorDescriptionsRefData$ = this.referenceDataService.getIposRefData(`refErrorDescriptions`);
    this.instalmentDetailsStoreService.getPremiumDetails(this.premiumId, this.typeOfPremium);
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.globalAlertStoreService.clearGlobalResponse();
    this.instalmentDetailsStoreService.getSigningDetails(this.submissionId);
    this.setErrorDescriptionValues();
    this.setTeamBaskets();
    this.initialValue = this.instalmentDetailsForm?.get('instalments')?.value;
  }
  setErrorDescriptionValues(): void {
    this.refErrorDescriptionsRefData$?.subscribe((data: any) => {
      if (data) {
        this.mistFormConfig.errorDescription.options = formatOption('refData', 'errorDescription', 'id', data);
        this.setTeamBaskets();
      }
    });
  }
  setTeamBaskets(): void {
    this.teamBasketStoreService.getTeamBaskets();
    this.teamBasketStoreService?.selectAll().subscribe((teamBasket: TeamBasket[]) => {
      if (teamBasket) {
        this.mistFormConfig.teamBasket.options = formatOption('teamBaskets', 'description', 'id', teamBasket);
      }
    });
  }
  checkWeekend(dateBeforeDueDate: Date): boolean {
    if (dateBeforeDueDate.getDay() === 0 || dateBeforeDueDate.getDay() === 6) {
      return true;
    }

    return false;
  }

  onMistFormChange($event: any): void {
    this.isFormVaild = $event?.valid;
    if (this.isFormVaild) {
      const result = Object.entries($event?.value).reduce((acc, [key, value]) => {
        if (value) {
          if (key === this.ERROR_DESCRIPTION) {
            const errorObj = this.mistFormConfig.errorDescription.options.find((error) => error.value === value);
            return {
              ...acc,
              [key]: {
                refErrorDescriptionId: value,
                typeOfErrorDescription: errorObj?.label,
              },
            };
          } else if (key === this.TEAM_BASKET) {
            const teamObj = this.mistFormConfig.teamBasket.options.find((team) => team.value === value);
            return {
              ...acc,
              [key]: {
                id: value,
                longCode: teamObj?.label,
              },
            };
          } else {
            return { ...acc, [key]: value };
          }
        }
        return acc;
      }, {});

      this.mistFormValues = result;
    }
  }

  onAddInstalmentDetails(instalment?: InstalmentDetail): void {
    this.instalmentDetailsFormArray?.push(this.initInstalmentsFormArray(instalment));
  }

  get instalmentDetailsFormControls(): FormControls {
    return this.instalmentDetailsForm?.controls;
  }

  initInstalmentDetailsForm(instalment?: InstalmentDetail): void {
    this.instalmentDetailsForm = this.formBuilder.group({
      chargeableIndicator:
        this.chargeableIndicatorCheckbox || this.instalmentDetailsForm?.controls?.chargeableIndicator?.value,
      correctionNarrative: this.instalmentDetailsForm?.controls?.correctionNarrative?.value,
      instalments: this.formBuilder.array([this.initInstalmentsFormArray(instalment)]),
    });
  }

  initInstalmentsFormArray(instalment?): FormGroup {
    return this.formBuilder.group({
      dueDate: [instalment?.dueDate],
    });
  }

  setChargeableCheckbox(chargeable: boolean): void {
    this.chargeableIndicatorCheckbox = chargeable;
    this.instalmentDetailsControls?.chargeableIndicator?.setValue(this.chargeableIndicatorCheckbox);
    this.validateChargeable();
  }

  createInstalments(): InstalmentDetails {
    const instalmentDetailsFormValue = this.instalmentDetailsForm?.value;
    const instalmentDetailsArray: InstalmentDetails = [];
    const dueDateList = this.dueDate.toArray();
    instalmentDetailsFormValue?.instalments?.forEach((item, index) =>
      instalmentDetailsArray?.push({
        instalmentId: this.premiumDetailsRef?.instalmentDetails[index]?.instalmentId,
        number: this.premiumDetailsRef?.instalmentDetails[index]?.number,
        dueDate: parseValue(dueDateList[index]?.formatDate()),
        netPremium: parseValue(this.premiumDetailsRef?.instalmentDetails[index]?.netPremium),
        actualPaymentDate: parseValue(this.premiumDetailsRef?.instalmentDetails[index]?.actualPaymentDate),
        dtInstalmentId: this.premiumDetailsRef?.instalmentDetails[index]?.dtInstalmentId,
        settlementStatus: this.premiumDetailsRef?.instalmentDetails[index]?.settlementStatus,
        settled: this.premiumDetailsRef?.instalmentDetails[index]?.settled,
        settlementId: this.premiumDetailsRef?.instalmentDetails[index]?.settlementId,
        lastUpdate: this.getDueDateByForm(this.initialValue, index) === item?.dueDate ? undefined : new Date(),
      })
    );
    return instalmentDetailsArray;
  }

  formatDate(date: Date): string {
    return date ? this.datePipe.transform(date, 'yyyy-MM-dd') : '';
  }

  getDueDateByForm(initialValue: any, index: number): void {
    const dueDatevalue = !initialValue ? null : initialValue[index] || null;
    return dueDatevalue?.dueDate;
  }

  dueDateChange(date: string, index: number): void {
    this.instalmentDetailsFormArray.at(index)?.get('dueDate').setValue(date);
  }

  setDueDateValidation(): void {
    this.instalmentDetailsFormArray?.controls.map((item: any, i) => {
      const currentSettlementDueDate = this.instalmentDetailsFormArray?.controls[i]?.value?.dueDate;
      const previousInstalmentDate = this.instalmentDetailsFormArray?.controls[i - 1]?.value?.dueDate;
      const dueDate = item.get('dueDate');
      const url = this.url?.split('?');
      dueDate.setValidators([dueDatesSequenceValidator(previousInstalmentDate, url)]);
      dueDate.updateValueAndValidity();
    });
  }

  checkMandatoryFields(): string[] {
    const requiredErrors: string[] = [];
    if (this.instalmentDetailsForm?.controls?.chargeableIndicator?.errors?.required) {
      requiredErrors.push('INSTALMENT_DETAILS.CHARGEABLE_MANDATORY');
    }
    if (this.instalmentDetailsForm?.controls?.correctionNarrative?.errors?.required) {
      requiredErrors.push('INSTALMENT_DETAILS.CORRECTION_NARRATIVE_MANDATORY');
    }
    return requiredErrors;
  }

  getInvalidDueDateErrors(): string[] {
    const invalidDueDateErrors: string[] = [];
    this.instalmentDetailsFormArray?.controls?.forEach((item: AbstractControl) => {
      const invalidDueDateError = item?.get('dueDate')?.errors?.invalidDueDate;
      if (invalidDueDateError) {
        invalidDueDateErrors.push(invalidDueDateError);
      }
    });

    return invalidDueDateErrors;
  }

  onSaveInstalmentEvent(): void {
    this.saveBtnClicked.next(true);
    this.setRequired();
    this.setDueDateValidation();
    this.getInstalmentsErrors();

    this.etag = this.instalmentDetailsStoreService.getEtag();
    this.instalmentCorrectionRecord = this.createInstalmentCorrectionRecord();
    if (!this.isFormVaild || this.showChargeableError) {
      return;
    }
    if (this.instalmentsErrors.length === 0) {
      this.instalmentDetailsStoreService.saveInstalmentDetails(
        this.etag,
        this.premiumId,
        this.instalmentCorrectionRecord,
        this.typeOfPremium,
        this.submissionId
      );
    }
  }

  // TODO: Change back to variable type after contract upgrade over vesion 1.2.0
  createInstalmentCorrectionRecord(): any {
    let instalmentCorrectionPayload = {
      premiumId: this.premiumDetailsRef?.premiumId,
      userId: this.userName,
      transactionType: {
        refTypeOfTransactionTypeId: this.premiumDetailsRef?.transactionType?.refTypeOfTransactionTypeId,
        typeOfTransactionType: this.premiumDetailsRef?.transactionType?.typeOfTransactionType,
      },
      chargeableIndicator: this.instalmentDetailsForm?.controls?.chargeableIndicator?.value,
      correctionSigningNarrative: this.instalmentDetailsForm?.controls?.correctionNarrative?.value,
      instalments: this.createInstalments(),
    };

    if (this.mistFormValues && this.isFormVaild) {
      instalmentCorrectionPayload = { ...instalmentCorrectionPayload, ...{ mist: this.mistFormValues } };
    }

    return instalmentCorrectionPayload;
  }

  goToEnquiryEvent(): void {
    const queryParams = {
      queryParams: {
        isfromDeferred: true,
      },
    };
    this.router.navigate([ENQUIRY_URL], queryParams);
  }
  onMistFormFieldsChanges(fields: { errorMadeBy: string; noOneLeaver: string }): void {
    this.childFieldValues = fields;
    this.validateChargeable(); // Check validation whenever child fields change
  }
  validateChargeable(): void {
    const { errorMadeBy, noOneLeaver } = this.childFieldValues;
    const invalidErrorMadeByOptions = ['Technician/Broker', 'Velonetic', 'Old Tech Error'];
    const invalidNoOneLeaverOption = 'Leaver';

    if (invalidErrorMadeByOptions.includes(errorMadeBy) && noOneLeaver === invalidNoOneLeaverOption) {
      this.chargeableErrorMsg = 'Error made by and No on/Leaver';
    }
    if (invalidErrorMadeByOptions.includes(errorMadeBy) && noOneLeaver !== invalidNoOneLeaverOption) {
      this.chargeableErrorMsg = 'Error made by';
    }
    if (!invalidErrorMadeByOptions.includes(errorMadeBy) && noOneLeaver === invalidNoOneLeaverOption) {
      this.chargeableErrorMsg = 'No on/Leaver';
    }

    this.showChargeableError =
      this.chargeableIndicatorCheckbox &&
      (invalidErrorMadeByOptions.includes(errorMadeBy) || noOneLeaver === invalidNoOneLeaverOption);
  }
  private setRequired(): void {
    this.instalmentDetailsForm?.controls?.chargeableIndicator.setValidators(Validators.required);
    this.instalmentDetailsForm?.controls?.chargeableIndicator.updateValueAndValidity();

    this.instalmentDetailsForm?.controls?.correctionNarrative.setValidators(Validators.required);
    this.instalmentDetailsForm?.controls?.correctionNarrative.updateValueAndValidity();
  }

  private getInstalmentsErrors(): void {
    this.instalmentsErrors = [];
    if (this.getInvalidDueDateErrors()?.length || this.checkMandatoryFields()?.length) {
      ScrollUp(0, 0);
      const dueDateErrors = this.getInvalidDueDateErrors();
      const requiredErrors = this.checkMandatoryFields();
      const combinedErrors = _.union(dueDateErrors, requiredErrors);
      const translatedErrors = combinedErrors?.map((error: string) => this.translateService.instant(error)); // Use the translate pipe
      this.instalmentsErrors = translatedErrors;
    }
  }
}
