import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { InstalmentDetailsComponent } from './instalment-details.component';
import { InstalmentDetailsStoreService } from '@features/instalment-details/services/instalment-details.store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { dueDatesSequenceValidator } from '@features/section-details/helper/business-rule-instalment-validators';
import { ReferenceDataService } from '@shared/services/reference-data/reference-data.service';
import { TechnicianPortalReferenceDataService } from 'src/app/api/reference-data/technician-portal-reference-data.service';
import { Configuration } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('InstalmentDetailsComponent', () => {
  let component: InstalmentDetailsComponent;
  let fixture: ComponentFixture<InstalmentDetailsComponent>;
  let el: DebugElement;
  let instalmentDetailsStoreService: InstalmentDetailsStoreService;
  let router: Router;
  let formControlsArrayField;
  let formBuilder: FormBuilder;
  let formControls;
  let referenceDataService: ReferenceDataService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InstalmentDetailsComponent],
      imports: [
        TranslateModule.forRoot(),
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
        HttpClientTestingModule,
      ],
      providers: [
        MockStore,
        provideMockStore(),
        InstalmentDetailsStoreService,
        FormBuilder,
        Configuration,
        ReferenceDataService,
        TechnicianPortalReferenceDataService,
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InstalmentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    instalmentDetailsStoreService = TestBed.inject(InstalmentDetailsStoreService);
    el = fixture.debugElement;
    router = TestBed.inject(Router);
    formBuilder = TestBed.inject(FormBuilder);
    const instalmentArray = formBuilder.group({
      dueDate: [null],
    });
    formControlsArrayField = instalmentArray?.controls;
    component.initInstalmentDetailsForm();
    formControls = component.instalmentDetailsControls;
    referenceDataService = TestBed.inject(ReferenceDataService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getPremiumDetails on onInit', () => {
    spyOn(instalmentDetailsStoreService, 'getPremiumDetails');
    component.ngOnInit();
    fixture.detectChanges();
    expect(instalmentDetailsStoreService.getPremiumDetails).toHaveBeenCalled();
  });

  it('should call getSigningDetails on onInit', () => {
    spyOn(instalmentDetailsStoreService, 'getSigningDetails');
    component.ngOnInit();
    fixture.detectChanges();
    expect(instalmentDetailsStoreService.getSigningDetails).toHaveBeenCalled();
  });

  it('should call saveInstalmentDetails in onSaveInstalmentEvent', () => {
    component.isFormVaild = true;
    spyOn(instalmentDetailsStoreService, 'saveInstalmentDetails');
    formControls.chargeableIndicator.setValue(true);
    formControls.correctionNarrative.setValue('123');
    component.onSaveInstalmentEvent();
    fixture.detectChanges();
    expect(instalmentDetailsStoreService.saveInstalmentDetails).toHaveBeenCalled();
  });
  it('should not call saveInstalmentDetails in onSaveInstalmentEvent', () => {
    component.isFormVaild = false;
    spyOn(instalmentDetailsStoreService, 'saveInstalmentDetails');
    component.onSaveInstalmentEvent();
    expect(instalmentDetailsStoreService.saveInstalmentDetails).not.toHaveBeenCalled();
  });

  it('should be navigate called when goToEnquiryEvent invoked', () => {
    const spy = spyOn(router, 'navigate');
    const ENQUIRY_DETAILS_URL = '/enquiry-details';
    const queryParams = {
      queryParams: {
        isfromDeferred: true,
      },
    };
    component.goToEnquiryEvent();
    expect(spy).toHaveBeenCalledWith([ENQUIRY_DETAILS_URL], queryParams);
  });

  it('due date should be invalid if it is less than the previous due date', () => {
    formControlsArrayField?.dueDate?.setValue('2024-01-01');
    formControlsArrayField?.dueDate?.setValidators(dueDatesSequenceValidator('2024-02-02', 'instalment-details'));
    formControlsArrayField?.dueDate?.setErrors({
      invalidDueDate: 'ALERTS.INSTALMENT_DUE_DATE_SEQUENCE',
    });
    fixture.detectChanges();
    expect(formControlsArrayField?.dueDate?.errors?.invalidDueDate).toBe('ALERTS.INSTALMENT_DUE_DATE_SEQUENCE');
  });

  it('should chargeableIndicator has required error if entered empty value on click save', () => {
    component.onSaveInstalmentEvent();
    fixture.detectChanges();
    formControls.chargeableIndicator.setValue('true');
    expect(formControls.chargeableIndicator.hasError('required')).toBeFalsy();
  });

  it('should correctionNarrative has required error if entered empty value on click save', () => {
    component.onSaveInstalmentEvent();
    fixture.detectChanges();
    formControls.correctionNarrative.setValue('');
    expect(formControls.correctionNarrative.hasError('required')).toBeTruthy();
  });

  it('should check if the entered date is weekend', () => {
    const date = new Date('2024-03-03');
    component.checkWeekend(date);
    fixture.detectChanges();
    expect(component.checkWeekend(date)).toBeTruthy();
  });

  it('should check if the entered date is weekend', () => {
    component.setChargeableCheckbox(true);
    fixture.detectChanges();
    expect(component.setChargeableCheckbox).toBeTruthy();
  });
});
