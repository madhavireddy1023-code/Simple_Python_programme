import * as selectors from './instalment-details.selectors';
import { mockPremiumDetails, mockSigningDetails } from '../../const/mock-premium-details.const';

describe('InstalmentDetailsSelector', () => {
  const state = {
    premiumDetails: mockPremiumDetails,
    etag: '12345',
    signingDetails: mockSigningDetails,
  };

  it('should select selectPremiumDetails', () => {
    const expectedData = mockPremiumDetails;
    const selectPremiumDetails = selectors.selectPremiumDetails.projector(state);
    expect(selectPremiumDetails).toEqual(expectedData);
  });

  it('should select selectSigningDetails', () => {
    const expectedData = mockSigningDetails;
    const selectSigningDetails = selectors.selectSigningDetails.projector(state);
    expect(selectSigningDetails).toEqual(expectedData);
  });

  it('should select selectEtag', () => {
    const expectedData = '12345';
    const etagSelector = selectors.selectEtag.projector(state);
    expect(etagSelector).toEqual(expectedData);
  });
});
