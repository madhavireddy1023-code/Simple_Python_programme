import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.instalmentDetails;

// Select premium details
export const selectPremiumDetails = createSelector(selectState, (state) => state?.premiumDetails);

// get etag
export const selectEtag = createSelector(selectState, (state) => state?.etag);

// select signing details
export const selectSigningDetails = createSelector(selectState, (state) => state?.signingDetails);
