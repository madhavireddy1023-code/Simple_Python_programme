import { InstalmentDetailsEffects } from './effects/instalment-details.effects';
import * as InstalmentDetailsActions from './actions/instalment-details.action';
import * as InstalmentDetailsSelectors from './selectors/instalment-details.selectors';
import { InstalmentDetailsReducer } from './reducers/instalment-details.reducers';
import { InstalmentDetailsState } from '../models/instalment-details.model';

export {
  InstalmentDetailsActions,
  InstalmentDetailsEffects,
  InstalmentDetailsState,
  InstalmentDetailsReducer,
  InstalmentDetailsSelectors,
};
