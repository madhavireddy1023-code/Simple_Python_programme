import { createAction, props } from '@ngrx/store';
import { PremiumGetRec, SigningGetRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { InstalmentCorrectionRecord } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';

const INSTALMENT_DETAILS_PREFIX = '[INSTALMENT_DETAILS]';

// get premium details
const GET_PREMIUM_DETAILS = `${INSTALMENT_DETAILS_PREFIX} GET_PREMIUM_DETAILS`;
export const getPremiumDetails = createAction(
  GET_PREMIUM_DETAILS,
  props<{ premiumId: string; typeOfPremium: string }>()
);

// set premium details in store
const SET_PREMIUM_DETAILS = `${INSTALMENT_DETAILS_PREFIX} SET_PREMIUM_DETAILS`;
export const setPremiumDetails = createAction(SET_PREMIUM_DETAILS, props<{ premiumDetails: PremiumGetRec }>());

// save instalment details
const SAVE_INSTALMENT_DETAILS = `${INSTALMENT_DETAILS_PREFIX} SAVE_INSTALMENT_DETAILS`;
export const saveInstalmentDetails = createAction(
  SAVE_INSTALMENT_DETAILS,
  props<{
    etag: string;
    premiumId: string;
    body: InstalmentCorrectionRecord;
    typeOfPremium: string;
    submissionId: string;
  }>()
);

// set etag
const SET_ETAG = `${INSTALMENT_DETAILS_PREFIX} SET_ETAG`;
export const setEtag = createAction(SET_ETAG, props<{ etag: string }>());

// get signing details
const GET_SIGNING_DETAILS = `${INSTALMENT_DETAILS_PREFIX} GET_SIGNING_DETAILS`;
export const getSigningDetails = createAction(GET_SIGNING_DETAILS, props<{ submissionId: string }>());

// set signing details in store
const SET_SIGNING_DETAILS = `${INSTALMENT_DETAILS_PREFIX} SET_SIGNING_DETAILS`;
export const setSigningDetails = createAction(SET_SIGNING_DETAILS, props<{ signingDetails: SigningGetRecord }>());
