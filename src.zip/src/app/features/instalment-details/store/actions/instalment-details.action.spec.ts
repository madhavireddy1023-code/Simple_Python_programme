import {
  getPremiumDetails,
  setPremiumDetails,
  saveInstalmentDetails,
  setEtag,
  getSigningDetails,
  setSigningDetails,
} from './instalment-details.action';

describe('InstalmentDetails Actions', () => {
  it('should return correct types', () => {
    expect(getPremiumDetails.type).toEqual('[INSTALMENT_DETAILS] GET_PREMIUM_DETAILS');

    expect(setPremiumDetails.type).toEqual('[INSTALMENT_DETAILS] SET_PREMIUM_DETAILS');

    expect(saveInstalmentDetails.type).toEqual('[INSTALMENT_DETAILS] SAVE_INSTALMENT_DETAILS');

    expect(setEtag.type).toEqual('[INSTALMENT_DETAILS] SET_ETAG');

    expect(getSigningDetails.type).toEqual('[INSTALMENT_DETAILS] GET_SIGNING_DETAILS');

    expect(setSigningDetails.type).toEqual('[INSTALMENT_DETAILS] SET_SIGNING_DETAILS');
  });
});
