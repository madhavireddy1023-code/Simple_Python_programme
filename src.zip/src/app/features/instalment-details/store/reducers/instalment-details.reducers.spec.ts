import { Action } from '@ngrx/store';
import { InstalmentDetailsReducer, initialState } from './instalment-details.reducers';
import * as actions from '../actions/instalment-details.action';
import { mockPremiumDetails, mockSigningDetails } from '../../const/mock-premium-details.const';
import { PremiumGetRec, SigningGetRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

describe('InstalmentDetailsReducers', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = InstalmentDetailsReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should update the state of [premiumDetails]', () => {
    const expectedState: PremiumGetRec = mockPremiumDetails;
    const action = actions.setPremiumDetails({ premiumDetails: expectedState });
    const newState = InstalmentDetailsReducer(initialState, action);
    expect(newState.premiumDetails).toEqual(expectedState);
  });

  it('should update the state of [signingDetails]', () => {
    const expectedState: SigningGetRecord = mockSigningDetails;
    const action = actions.setSigningDetails({ signingDetails: expectedState });
    const newState = InstalmentDetailsReducer(initialState, action);
    expect(newState.signingDetails).toEqual(expectedState);
  });

  it('should update the state of [etag]', () => {
    const expectedState = 'etag123';
    const action = actions.setEtag({ etag: expectedState });
    const newState = InstalmentDetailsReducer(initialState, action);
    expect(newState.etag).toEqual(expectedState);
  });
});
