import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/instalment-details.action';
import * as _ from 'lodash';
import { InstalmentDetailsState } from '@features/instalment-details/models/instalment-details.model';

export const initialState: InstalmentDetailsState = {
  premiumDetails: null,
  etag: '',
  signingDetails: null,
  instalmentDetails: null,
};

export const InstalmentDetailsReducer: ActionReducer<InstalmentDetailsState, Action> = createReducer(
  initialState,

  on(actions.setPremiumDetails, (state: InstalmentDetailsState, action) =>
    _.setWith(_.clone(state), 'premiumDetails', action.premiumDetails, _.clone)
  ),

  // update state etag
  on(actions.setEtag, (state: InstalmentDetailsState, action) =>
    _.setWith(_.clone(state), 'etag', action.etag, _.clone)
  ),

  on(actions.setSigningDetails, (state: InstalmentDetailsState, action) =>
    _.setWith(_.clone(state), 'signingDetails', action.signingDetails, _.clone)
  )
);
