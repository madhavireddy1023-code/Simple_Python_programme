import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InstalmentDetailsEffects } from './instalment-details.effects';
import { provideMockStore } from '@ngrx/store/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { initialState } from '../reducers/instalment-details.reducers';
import { Observable, of, throwError } from 'rxjs';
import * as action from '../actions/instalment-details.action';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { take } from 'rxjs/operators';
import { MainInstalmentComponent } from '@features/instalment-details/main/main-instalment/main-instalment.component';
import { TechnicianPortalService } from 'src/app/api/technician-portal';
import { mockInstalmentCorrectionRecord } from '../../const/mock-premium-details.const';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { TechnicianPortalCorrectionsExperienceService } from 'src/app/api/premium-technician-experience-corrections/premium-technician-experience-corrections.service';

describe('InstalmentDetailsEffects', () => {
  let actions$: Observable<any>;
  let effects: InstalmentDetailsEffects;
  let technicianPortalService: jasmine.SpyObj<TechnicianPortalService>;
  let domainTechnicianPortalCorrectionService: jasmine.SpyObj<TechnicianPortalCorrectionsExperienceService>;

  beforeEach(() => {
    const technicianPortalServiceSpy = jasmine.createSpyObj('TechnicianPortalService', [
      'apiV2PremiumDetailsGet',
      'apiV1SigningDetailsGet',
    ]);

    const domainAPITechnicianPortalCorrectionServiceSpy = jasmine.createSpyObj(
      'TechnicianPortalCorrectionsExperienceService',
      ['apiV1InstalmentCorrectionPatch']
    );

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([{ path: 'instalment-details', component: MainInstalmentComponent }]),
      ],
      providers: [
        InstalmentDetailsEffects,
        { provide: TechnicianPortalService, useValue: technicianPortalServiceSpy },
        {
          provide: TechnicianPortalCorrectionsExperienceService,
          useValue: domainAPITechnicianPortalCorrectionServiceSpy,
        },
        provideMockStore({ initialState }),
        provideMockActions(() => actions$),
      ],
    });
    effects = TestBed.inject(InstalmentDetailsEffects);
    technicianPortalService = TestBed.inject(TechnicianPortalService) as jasmine.SpyObj<TechnicianPortalService>;
    domainTechnicianPortalCorrectionService = TestBed.inject(
      TechnicianPortalCorrectionsExperienceService
    ) as jasmine.SpyObj<TechnicianPortalCorrectionsExperienceService>;
  });

  it('should test getPremiumDetails$ effect', () => {
    actions$ = of(
      action.getPremiumDetails({ premiumId: 'b3a70c00-c1d0-4937-b1b6-a1e5b97328f0', typeOfPremium: 'Original_Premium' })
    );
    technicianPortalService.apiV2PremiumDetailsGet.and.returnValue(of(new HttpResponse({ status: 200 })));
    effects.getPremiumDetails$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setEtag.type);
    });
  });

  it('should test saveInstalmentDetails$ effect', () => {
    const body = mockInstalmentCorrectionRecord;
    actions$ = of(
      action.saveInstalmentDetails({
        etag: '123',
        premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        body,
        typeOfPremium: 'Original_Premium',
        submissionId: '00f0e3b1-7640-4d54-8045-2a58024b5238',
      })
    );
    domainTechnicianPortalCorrectionService.apiV1InstalmentCorrectionPatch.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.saveInstalmentDetails$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type);
    });
  });

  it('should handle 500 error when saving instalment details', () => {
    const body = mockInstalmentCorrectionRecord;
    actions$ = of(
      action.saveInstalmentDetails({
        etag: '123',
        premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        body,
        typeOfPremium: 'Original_Premium',
        submissionId: '00f0e3b1-7640-4d54-8045-2a58024b5238',
      })
    );

    // actions$ = of(action);

    const error = new HttpErrorResponse({ status: 500, statusText: 'Internal Server Error' });
    domainTechnicianPortalCorrectionService.apiV1InstalmentCorrectionPatch.and.returnValue(throwError(error));

    effects.saveInstalmentDetails$.pipe(take(1)).subscribe((resultAction) => {
      expect(resultAction).toEqual(
        loadGlobalAlert({
          response: {
            ...error,
            responseMessage: 'ALERTS.500_MSG',
            isGlobalAlert: true,
          },
        })
      );
    });
  });

  it('should test getSigningDetails$ effect', () => {
    actions$ = of(action.getSigningDetails({ submissionId: '00f0e3b1-7640-4d54-8045-2a58024b5238' }));
    technicianPortalService.apiV1SigningDetailsGet.and.returnValue(of(new HttpResponse({ status: 200 })));
    effects.getSigningDetails$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setSigningDetails.type);
    });
  });
});
