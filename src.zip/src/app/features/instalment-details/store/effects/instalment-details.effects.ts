import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { TechnicianPortalCorrectionsExperienceService } from 'src/app/api/premium-technician-experience-corrections/premium-technician-experience-corrections.service';
import { TechnicianPortalService } from 'src/app/api/technician-portal';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { GetEtag, ScrollUp } from 'src/app/utils/helper';
import * as actions from '../actions/instalment-details.action';
@Injectable()
export class InstalmentDetailsEffects {
  constructor(
    private actions$: Actions,
    private router: Router,
    private route: ActivatedRoute,
    private technicalPortalService: TechnicianPortalService,
    private technicianPortalCorrectionsExperienceService: TechnicianPortalCorrectionsExperienceService
  ) {}

  // get premium details
  getPremiumDetails$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getPremiumDetails),
      switchMap((action) => {
        return this.technicalPortalService
          .apiV2PremiumDetailsGet(action.premiumId, action.typeOfPremium, 'response')
          .pipe(
            switchMap((response) => {
              return of(
                actions.setEtag({ etag: GetEtag(response) }),
                actions.setPremiumDetails({ premiumDetails: response?.body })
              );
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                      isAuthAlert: true,
                      isVisible: false,
                    },
                  })
                );
              }
              return of(
                loadGlobalAlert({
                  response: { ...error, isGlobalAlert: true },
                })
              );
            })
          );
      })
    )
  );

  // get signing details
  getSigningDetails$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getSigningDetails),
      switchMap((action) => {
        return this.technicalPortalService.apiV1SigningDetailsGet(action.submissionId, 'response').pipe(
          switchMap((response) => {
            return of(actions.setSigningDetails({ signingDetails: response?.body }));
          }),
          catchError((error) => {
            ScrollUp(0, 0);
            if (error?.status === 403) {
              return of(
                loadGlobalAlert({
                  response: {
                    ...error,
                    responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                    isAuthAlert: true,
                    isVisible: false,
                  },
                })
              );
            }
            return of(
              loadGlobalAlert({
                response: { ...error, isGlobalAlert: true },
              })
            );
          })
        );
      })
    )
  );

  saveInstalmentDetails$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.saveInstalmentDetails),
      switchMap((action) => {
        return this.technicianPortalCorrectionsExperienceService
          .apiV1InstalmentCorrectionPatch(action.etag, action.premiumId, action?.body, 'response')
          .pipe(
            switchMap((response) => {
              ScrollUp(0, 0);
              return of(
                actions.getPremiumDetails({ premiumId: action.premiumId, typeOfPremium: action.typeOfPremium }),
                actions.getSigningDetails({ submissionId: action.submissionId }),
                loadGlobalAlert({
                  response: { responseMessage: 'ALERTS.UPDATE_SUCCESSFUL', status: 200, isGlobalAlert: true },
                })
              );
            }),
            catchError((error: HttpErrorResponse) => {
              ScrollUp(0, 0);
              if (error?.error?.status === 400) {
                return of(
                  loadGlobalAlert({
                    response: {
                      error,
                      responseMessage: error?.error[0]?.detail,
                      status: 400,
                      isGlobalAlert: true,
                      isMultiple: true,
                    },
                  })
                );
              }
              const errorMessages = {
                404: 'ALERTS.DEFAULT_ERROR_MSG',
                500: 'ALERTS.500_MSG',
                default: 'ALERTS.UPDATE_FAILED',
              };
              const errMsg = errorMessages[error.status] || errorMessages.default;
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(
                loadGlobalAlert({
                  response: { ...error, responseMessage: errMsg, isGlobalAlert: true },
                })
              );
            })
          );
      })
    )
  );
}
