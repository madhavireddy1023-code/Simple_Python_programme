import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';

import { InstalmentDetailsRoutingModule } from './instalment-details-routing.module';
import { MainInstalmentComponent } from './main/main-instalment/main-instalment.component';
import { InstalmentDetailsComponent } from './components/instalment-details/instalment-details.component';

@NgModule({
  declarations: [MainInstalmentComponent, InstalmentDetailsComponent],
  imports: [CommonModule, SharedModule, InstalmentDetailsRoutingModule],
})
export class InstalmentDetailsModule {}
