import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from '../../../store/app.reducer';
import * as actions from '../store/actions/instalment-details.action';
import { Observable } from 'rxjs';
import * as selectors from '../store/selectors/instalment-details.selectors';

import * as selectorsDef from '../../enquiry/store/selectors/def-instalment.selector';
import { PremiumDetail, PremiumGetRec, SigningGetRecord } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { SetEtag } from 'src/app/utils/helper/helper';
import { InstalmentCorrectionRecord } from '@dxc.lm.sdk.angular/ipos-premium-technician-experience-api';

@Injectable({
  providedIn: 'root',
})
export class InstalmentDetailsStoreService {
  constructor(private store: Store<AppState>) {}

  getPremiumDetails(premiumId: string, typeOfPremium: string): void {
    this.store.dispatch(actions.getPremiumDetails({ premiumId, typeOfPremium }));
  }

  setPremiumDetails(premiumDetails: PremiumGetRec): void {
    this.store.dispatch(actions.setPremiumDetails({ premiumDetails }));
  }

  selectPremiumDetails(): Observable<PremiumGetRec> {
    return this.store.select(selectors.selectPremiumDetails);
  }

  selectPremiumDetailsFromDef(): Observable<PremiumDetail> {
    return this.store.select(selectorsDef.selectPremiumDetails);
  }

  saveInstalmentDetails(
    etag: string,
    premiumId: string,
    body?: InstalmentCorrectionRecord,
    typeOfPremium?: string,
    submissionId?: string
  ): void {
    this.store.dispatch(actions.saveInstalmentDetails({ etag, premiumId, body, typeOfPremium, submissionId }));
  }

  getEtag(): string {
    const selector = this.store.select(selectors.selectEtag);
    return SetEtag(selector);
  }

  getSigningDetails(submissionId: string): void {
    this.store.dispatch(actions.getSigningDetails({ submissionId }));
  }

  setSigningDetails(signingDetails: SigningGetRecord): void {
    this.store.dispatch(actions.setSigningDetails({ signingDetails }));
  }

  selectSigningDetails(): Observable<SigningGetRecord> {
    return this.store.select(selectors.selectSigningDetails);
  }
}
