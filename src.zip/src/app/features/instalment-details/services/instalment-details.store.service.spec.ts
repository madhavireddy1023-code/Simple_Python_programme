import { TestBed } from '@angular/core/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import * as selectors from '../store/selectors/instalment-details.selectors';
import { InstalmentDetailsStoreService } from './instalment-details.store.service';
import {
  mockPremiumDetails,
  mockInstalmentCorrectionRecord,
  mockSigningDetails,
} from '../const/mock-premium-details.const';

describe('InstalmentDetailsStoreService', () => {
  let service: InstalmentDetailsStoreService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockStore, provideMockStore()],
    });
    service = TestBed.inject(InstalmentDetailsStoreService);
    store = TestBed.inject(MockStore);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should getPremiumDetails to be called', () => {
    const premiumId = 'b3a70c00-c1d0-4937-b1b6-a1e5b97328f0';
    const typeOfPremium = 'Original_Premium';
    spyOn(store, 'dispatch');
    service.getPremiumDetails(premiumId, typeOfPremium);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should setPremiumDetails to be called', () => {
    spyOn(store, 'dispatch');
    service.setPremiumDetails(mockPremiumDetails);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should selectPremiumDetails to be called', () => {
    spyOn(service, 'selectPremiumDetails');
    service.selectPremiumDetails();
    expect(service.selectPremiumDetails).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectPremiumDetails);
    expect(store.select).toHaveBeenCalled();
  });

  it('should saveInstalmentDetails to be called', () => {
    const premiumId = '3fa85f64-5717-4562-b3fc-2c963f66afa6';
    const etag = '123';
    const body = mockInstalmentCorrectionRecord;
    spyOn(store, 'dispatch');
    service.saveInstalmentDetails(etag, premiumId, body);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should getSigningDetails to be called', () => {
    const submissionId = '00f0e3b1-7640-4d54-8045-2a58024b5238';
    spyOn(store, 'dispatch');
    service.getSigningDetails(submissionId);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should setSigningDetails to be called', () => {
    spyOn(store, 'dispatch');
    service.setSigningDetails(mockSigningDetails);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should selectSigningDetails to be called', () => {
    spyOn(service, 'selectSigningDetails');
    service.selectSigningDetails();
    expect(service.selectSigningDetails).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectSigningDetails);
    expect(store.select).toHaveBeenCalled();
  });
});
