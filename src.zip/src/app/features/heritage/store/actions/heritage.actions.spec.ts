import { postReachBackHeritage, postReachBackHeritageFailed, postReachBackHeritageSuccess } from './heritage.actions';

describe('Heritage Actions', () => {
  it('should return correct types', () => {
    expect(postReachBackHeritage.type).toEqual('[ReachBackHetitage/API] Post ReachBack Heritage');

    expect(postReachBackHeritageFailed.type).toEqual('[ReachBackHeritage/API] Post ReachBack Heritage Failure');

    expect(postReachBackHeritageSuccess.type).toEqual('[ReachBackHeritage/API] Post ReachBack Heritage Success');
  });
});
