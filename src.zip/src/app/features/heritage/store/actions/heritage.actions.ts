import { ReachbackRequest } from '@dxc.lm.sdk.angular/premiums-reachback-api';
import { createAction, props } from '@ngrx/store';

export const postReachBackHeritage = createAction(
  '[ReachBackHetitage/API] Post ReachBack Heritage',
  props<{ payload: ReachbackRequest }>()
);

export const postReachBackHeritageFailed = createAction(
  '[ReachBackHeritage/API] Post ReachBack Heritage Failure',
  props<{ messageCode: string; status: number }>()
);

export const postReachBackHeritageSuccess = createAction(
  '[ReachBackHeritage/API] Post ReachBack Heritage Success',
  props<{ messageCode: string; status: number }>()
);
