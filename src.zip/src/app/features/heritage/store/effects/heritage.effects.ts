import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { catchError, switchMap } from 'rxjs/operators';
import {
  postReachBackHeritage,
  postReachBackHeritageFailed,
  postReachBackHeritageSuccess,
} from '../actions/heritage.actions';
import { getHeritageMessageConst } from '@features/heritage/heritage-message.helper';
import { ReachBackService } from 'src/app/api/domain-api-reachback';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class HeritageEffects {
  constructor(private actions$: Actions, private reachBackService: ReachBackService) {}

  postReachBackHeritage$: Observable<{ messageCode: string; status: number }> = createEffect(() =>
    this.actions$.pipe(
      ofType(postReachBackHeritage),
      switchMap((action) => {
        return this.reachBackService.apiV1PremiumReachbackRequestPost(action.payload).pipe(
          switchMap(() => {
            return of(postReachBackHeritageSuccess({ messageCode: 'SUCCESS_200', status: 200 }));
          }),
          catchError((err: HttpErrorResponse) => {
            const errorCode = err?.error?.[0]?.errorCode || err?.status;
            const errorBannerCode = `ERROR_${errorCode}${action.payload?.snd ? '_SND' : ''}`;
            return of(postReachBackHeritageFailed({ messageCode: errorBannerCode, status: err?.status }));
          })
        );
      })
    )
  );

  loadAlertOnReachBackHeritageResponse$: Observable<any> = createEffect(() => {
    return this.actions$.pipe(
      ofType(postReachBackHeritageSuccess, postReachBackHeritageFailed),
      switchMap((action) => {
        return of(
          loadGlobalAlert({
            response: {
              responseMessage: getHeritageMessageConst(action.messageCode),
              status: action?.status,
              isGlobalAlert: false,
              type: 'heritage-alert',
            },
          })
        );
      })
    );
  });
}
