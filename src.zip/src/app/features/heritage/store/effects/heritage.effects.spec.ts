import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable, of, throwError } from 'rxjs';
import { HeritageEffects } from './heritage.effects';
import {
  postReachBackHeritage,
  postReachBackHeritageSuccess,
  postReachBackHeritageFailed,
} from '../actions/heritage.actions';
import { ReachBackService } from 'src/app/api/domain-api-reachback';
import { getHeritageMessageConst } from '@features/heritage/heritage-message.helper';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { ReachbackRequest } from '@dxc.lm.sdk.angular/premiums-reachback-api';

describe('HeritageEffects', () => {
  let actions$: Observable<any>;
  let effects: HeritageEffects;
  let reachBackService: jasmine.SpyObj<ReachBackService>;

  beforeEach(() => {
    const reachBackServiceSpy = jasmine.createSpyObj('ReachBackService', ['apiV1PremiumReachbackRequestPost']);
    TestBed.configureTestingModule({
      providers: [
        HeritageEffects,
        provideMockActions(() => actions$),
        { provide: ReachBackService, useValue: reachBackServiceSpy },
      ],
    });

    effects = TestBed.inject(HeritageEffects);
    reachBackService = TestBed.inject(ReachBackService) as jasmine.SpyObj<ReachBackService>;
  });

  describe('postReachBackHeritage$', () => {
    it('should dispatch postReachBackHeritageSuccess on successful API call', () => {
      const payload: ReachbackRequest = {
        snd: '1237hjhhiui',
      };
      const action = postReachBackHeritage({ payload });
      const successResponse: any = {};
      const expectedResult = postReachBackHeritageSuccess({ messageCode: 'SUCCESS_200', status: 200 });

      actions$ = of(action);
      reachBackService.apiV1PremiumReachbackRequestPost.and.returnValue(of(successResponse));

      effects.postReachBackHeritage$.subscribe((result) => {
        expect(result).toEqual(expectedResult);
      });
    });

    it('should dispatch postReachBackHeritageFailed on failed API call', () => {
      const payload: ReachbackRequest = {
        umr: '23234234234',
      };
      const action = postReachBackHeritage({ payload });
      const expectedResult = postReachBackHeritageFailed({ messageCode: 'ERROR_404', status: 404 });

      actions$ = of(action);

      reachBackService.apiV1PremiumReachbackRequestPost.and.returnValue(
        throwError({ error: [{ errorCode: 404 }], status: 404 })
      );

      effects.postReachBackHeritage$.subscribe((result) => {
        expect(result).toEqual(expectedResult);
      });
    });

    it('should dispatch postReachBackHeritageFailed on failed API call', () => {
      const payload: ReachbackRequest = {
        snd: '23234234234',
      };
      const action = postReachBackHeritage({ payload });
      const expectedResult = postReachBackHeritageFailed({ messageCode: 'ERROR_1110_SND', status: 400 });

      actions$ = of(action);

      reachBackService.apiV1PremiumReachbackRequestPost.and.returnValue(
        throwError({ error: [{ errorCode: 1110 }], status: 400 })
      );

      effects.postReachBackHeritage$.subscribe((result) => {
        expect(result).toEqual(expectedResult);
      });
    });
  });

  describe('loadAlertOnReachBackHeritageResponse$', () => {
    it('should dispatch loadGlobalAlert on postReachBackHeritageSuccess', () => {
      const messageCode = 'SUCCESS_201';
      const status = 201;
      const action = postReachBackHeritageSuccess({ messageCode, status });
      const expectedResult = loadGlobalAlert({
        response: {
          responseMessage: getHeritageMessageConst(messageCode),
          status,
          isGlobalAlert: false,
          type: 'heritage-alert',
        },
      });

      actions$ = of(action);

      effects.loadAlertOnReachBackHeritageResponse$.subscribe((result) => {
        expect(result).toEqual(expectedResult);
      });
    });

    it('should dispatch loadGlobalAlert on postReachBackHeritageFailed', () => {
      const messageCode = 'ERROR_404';
      const status = 404;
      const action = postReachBackHeritageFailed({ messageCode, status });
      const expectedResult = loadGlobalAlert({
        response: {
          responseMessage: getHeritageMessageConst(messageCode),
          status,
          isGlobalAlert: false,
          type: 'heritage-alert',
        },
      });

      actions$ = of(action);

      effects.loadAlertOnReachBackHeritageResponse$.subscribe((result) => {
        expect(result).toEqual(expectedResult);
      });
    });

    it('should dispatch loadGlobalAlert on postReachBackHeritageFailed with 1110 error and invalid snd', () => {
      const messageCode = 'ERROR_1110_SND';
      const status = 400;
      const action = postReachBackHeritageFailed({ messageCode, status });
      const expectedResult = loadGlobalAlert({
        response: {
          responseMessage: getHeritageMessageConst(messageCode),
          status,
          isGlobalAlert: false,
          type: 'heritage-alert',
        },
      });

      actions$ = of(action);

      effects.loadAlertOnReachBackHeritageResponse$.subscribe((result) => {
        expect(result).toEqual(expectedResult);
      });
    });
  });
});
