import * as HeritageActions from './actions/heritage.actions';
import { HeritageEffects } from './effects/heritage.effects';

export { HeritageActions, HeritageEffects };
