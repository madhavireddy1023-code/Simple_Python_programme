import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeritageDialogComponent } from './component/heritage-dialog/heritage-dialog.component';
const routes: Routes = [{ path: '', component: HeritageDialogComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HeritageRoutingModule {}
