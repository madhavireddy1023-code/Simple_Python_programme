import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeritageRoutingModule } from './heritage-routing.module';
import { SharedModule } from '@shared/shared.module';
import { HeritageDialogComponent } from './component/heritage-dialog/heritage-dialog.component';

@NgModule({
  declarations: [HeritageDialogComponent],
  imports: [CommonModule, HeritageRoutingModule, SharedModule],
})
export class HeritageModule {}
