import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { DxcTextInputComponent } from '@dxc-technology/halstack-angular';
import { postReachBackHeritage } from '@features/heritage/store/actions/heritage.actions';
import { Store } from '@ngrx/store';
import { FormControls } from '@shared/models';
import { Observable, Subject } from 'rxjs';
import { AppState } from 'src/app/store/app.reducer';
import { selectGlobalAlertResponse } from 'src/app/store/selectors/global-alert.selector';
import {
  ValidationInputStatus,
  marketReferenceValidator,
  oneInputValidator,
  signingRefalphaNumValidator,
} from 'src/app/utils';
import { ReachbackRequest } from '@dxc.lm.sdk.angular/premiums-reachback-api';

@Component({
  selector: 'app-heritage-dialog',
  templateUrl: './heritage-dialog.component.html',
  styleUrls: ['./heritage-dialog.component.scss'],
})
export class HeritageDialogComponent implements OnInit, OnDestroy {
  selectHeritageResponse!: Observable<string>;
  form!: FormGroup;
  searchClicked = false;
  validationUpdated = false;
  lastEnteredControl: FormControl = new FormControl();
  private destroy$ = new Subject();
  constructor(private formBuilder: FormBuilder, private store: Store<AppState>) {}

  ngOnInit(): void {
    this.selectHeritageResponse = this.store.select(selectGlobalAlertResponse);
    this.form = this.formBuilder.group(
      {
        umr: ['', [Validators.required, Validators.minLength(8), marketReferenceValidator(), Validators.maxLength(17)]],
        signingRef: [
          '',
          [Validators.required, Validators.minLength(8), signingRefalphaNumValidator(), Validators.maxLength(17)],
        ],
      },
      { validator: oneInputValidator('umr', 'signingRef', this.lastEnteredControl) }
    );

    this.form.valueChanges.subscribe(() => {
      if (!this.validationUpdated) {
        this.updateValidation();
      }
    });
  }

  get getFormControls(): FormControls {
    return this.form?.controls;
  }

  updateValidation(): void {
    this.validationUpdated = true;
    const umrControl = this.getFormControls.umr;
    const signingRefControl = this.getFormControls.signingRef;
    if (umrControl.value && signingRefControl.value) {
      this.form.setValidators([oneInputValidator('umr', 'signingRef', this.lastEnteredControl)]);
    } else if (!umrControl.value && !signingRefControl.value) {
      umrControl.setValidators([Validators.required]);
      signingRefControl.setValidators([Validators.required]);
    } else {
      umrControl.clearValidators();
      signingRefControl.clearValidators();
      umrControl.setValidators([Validators.minLength(8), marketReferenceValidator(), Validators.maxLength(17)]);
      signingRefControl.setValidators([
        Validators.minLength(8),
        signingRefalphaNumValidator(),
        Validators.maxLength(17),
      ]);
    }
    umrControl.updateValueAndValidity();
    signingRefControl.updateValueAndValidity();
    this.validationUpdated = false;
  }

  getLastEnteredControl(event: any, control: any): void {
    this.lastEnteredControl = control;
  }

  preventSpace(event): void {
    if (event.keyCode === 32) {
      event.preventDefault();
    }
  }

  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.searchClicked, formControl, input);
  }

  submit(): void {
    this.searchClicked = true;
    this.updateValidation();
    this.form.updateValueAndValidity();
    if (this.form.valid) {
      const heritagePayload: ReachbackRequest = {};

      if (this.getFormControls.umr.value) {
        heritagePayload.umr = this.getFormControls.umr.value;
      }

      if (this.getFormControls.signingRef.value) {
        heritagePayload.snd = this.getFormControls.signingRef.value;
      }

      this.store.dispatch(postReachBackHeritage({ payload: heritagePayload }));
    }
  }

  cancel(): void {
    this.form.reset();
    this.searchClicked = false;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
