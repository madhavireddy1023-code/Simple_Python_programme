import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HeritageDialogComponent } from './heritage-dialog.component';
import { TranslateModule } from '@ngx-translate/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { DxcTextInputComponent } from '@dxc-technology/halstack-angular';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { v4 as uuid } from 'uuid';
import { postReachBackHeritage } from '@features/heritage/store/actions/heritage.actions';

describe('HeritageDialogComponent', () => {
  let component: HeritageDialogComponent;
  let fixture: ComponentFixture<HeritageDialogComponent>;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HeritageDialogComponent],
      imports: [TranslateModule.forRoot({}), SharedModule, ReactiveFormsModule],
      providers: [provideMockStore({})],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    store = TestBed.inject(MockStore);
    fixture = TestBed.createComponent(HeritageDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the form group', () => {
    component.ngOnInit();
    expect(component.form).toBeDefined();
    expect(component.form.get('umr')).toBeDefined();
    expect(component.form.get('signingRef')).toBeDefined();
  });

  it('should reset the dialog', () => {
    component.ngOnInit();
    component.form.get('umr').setValue('umr');
    component.form.get('signingRef').setValue('signingRef');
    expect(component.form.get('umr').value).toBe('umr');
    expect(component.form.get('signingRef').value).toBe('signingRef');
    component.cancel();
    expect(component.form.get('umr').value).toBe(null);
    expect(component.form.get('signingRef').value).toBe(null);
  });

  it('should update validation when both umr and signingRef are filled', () => {
    const umrControl = new FormControl('UMR');
    const signingRefControl = new FormControl('SigningRef');
    component.updateValidation();

    expect(umrControl.validator).toBeNull();
    expect(signingRefControl.validator).toBeNull();
  });

  it('should add required error when two inputs empty', () => {
    component.form.controls.umr.setValue('');
    component.form.controls.signingRef.setValue('');
    component.updateValidation();
    fixture.detectChanges();
    expect(component.form.controls.umr.errors).toEqual({ required: true });
    expect(component.form.controls.signingRef.errors).toEqual({ required: true });
  });

  it('should add one empty error when two inputs have value', () => {
    component.form.controls.umr.setValue('b1234aaaaa');
    component.form.controls.signingRef.setValue('123456789');
    component.lastEnteredControl = component.form.controls.umr as FormControl;
    component.updateValidation();
    fixture.detectChanges();
    expect(component.form.controls.umr.errors).toEqual({ oneEmpty: true });
    expect(component.form.controls.signingRef.errors).toEqual(null);
  });

  it('should submit an valid umr input', () => {
    component.form.controls.umr.setValue('b1234aaaaa');
    expect(component.form.controls.umr.errors).toEqual(null);
  });

  it('should submit an invalid alpha numeric only error for umr input', () => {
    component.form.controls.umr.setValue('c1234aaaa#');
    expect(component.form.controls.umr.errors).toEqual({ alphaNumericOnly: true });
  });

  it('should submit an invalid format error for umr input', () => {
    component.form.controls.umr.setValue('11234234');
    expect(component.form.controls.umr.errors).toEqual({
      format: true,
    });
  });

  it('should submit an invalid max length error for umr input', () => {
    component.form.controls.umr.setValue('b1234attfhrrthrthhrt');
    fixture.detectChanges();
    expect(component.form.controls.umr.errors).toEqual({
      maxlength: { requiredLength: 17, actualLength: 20 },
    });
  });

  it('should submit an invalid min length error for umr input', () => {
    component.form.controls.umr.setValue('b123');
    fixture.detectChanges();
    expect(component.form.controls.umr.errors).toEqual({
      minlength: { requiredLength: 8, actualLength: 4 },
    });
  });

  it('should return null for valid input', () => {
    const formControl = new FormControl('valid input');
    const inputComponent = {} as DxcTextInputComponent;

    const result = component.getValidationInputStatus(formControl, inputComponent);

    expect(result).not.toBeDefined();
  });

  it('should return ValidationErrors for invalid input', () => {
    const formControl = new FormControl('invalid input');
    const inputComponent = {} as DxcTextInputComponent;

    const result = component.getValidationInputStatus(formControl, inputComponent);

    expect(result).not.toBeDefined();
  });

  it('should dispatch postReachBackHeritage action with correct payload when form is valid', () => {
    spyOn(store, 'dispatch');
    component.getFormControls.umr.setValue('B123456jkkff');
    component.submit();

    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should not dispatch postReachBackHeritage action when form is invalid', () => {
    spyOn(store, 'dispatch');
    component.submit();
    expect(store.dispatch).not.toHaveBeenCalled();
  });
});
