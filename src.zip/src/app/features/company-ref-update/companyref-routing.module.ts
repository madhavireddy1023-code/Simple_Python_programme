import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainCompanyRefUpdateComponent } from '@features/company-ref-update/main/main-company-ref-update/main-company-ref-update.component';
import { MainCompanyRefBureauComponent } from './main/main-company-ref-bureau/main-company-ref-bureau.component';
import { UwfRecordCorrectionResolver } from './services/company-ref-update-resolver';
import { MainCompanyRefHistoryComponent } from './main/main-company-ref-history/main-company-ref-history.component';
import { UwfHistoryResolver } from './services/company-ref-history-resolver';

const routes: Routes = [
  { path: '', component: MainCompanyRefUpdateComponent },
  { path: 'company-bureau', component: MainCompanyRefBureauComponent, resolve: { data: UwfRecordCorrectionResolver } },
  { path: 'company-ref-history', component: MainCompanyRefHistoryComponent, resolve: { data: UwfHistoryResolver } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CompanyrefRoutingModule {}
