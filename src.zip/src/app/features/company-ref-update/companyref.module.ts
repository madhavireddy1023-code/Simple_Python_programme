import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';

import { CompanyrefRoutingModule } from './companyref-routing.module';
import { MainCompanyRefUpdateComponent } from './main/main-company-ref-update/main-company-ref-update.component';
import { CompanyRefUpdateComponent } from './components/company-ref-update/company-ref-update.component';
import { CompanyRefTableComponent } from './components/company-ref-table/company-ref-table.component';
import { MainCompanyRefBureauComponent } from './main/main-company-ref-bureau/main-company-ref-bureau.component';
import { CompanyRefBureauIluComponent } from './components/company-ref-bureau-ilu/company-ref-bureau-ilu.component';
import { CompanyRefBureauLirmaComponent } from './components/company-ref-bureau-lirma/company-ref-bureau-lirma.component';
import { UwfRecordCorrectionResolver } from './services/company-ref-update-resolver';
import { CompanyRefHistoryTableComponent } from './components/company-ref-history-table/company-ref-history-table.component';
import { MainCompanyRefHistoryComponent } from './main/main-company-ref-history/main-company-ref-history.component';

@NgModule({
  declarations: [
    MainCompanyRefUpdateComponent,
    CompanyRefUpdateComponent,
    CompanyRefTableComponent,
    MainCompanyRefBureauComponent,
    CompanyRefBureauIluComponent,
    CompanyRefBureauLirmaComponent,
    CompanyRefHistoryTableComponent,
    MainCompanyRefHistoryComponent,
  ],
  imports: [CommonModule, CompanyrefRoutingModule, SharedModule],
  providers: [UwfRecordCorrectionResolver],
})
export class CompanyrefModule {}
