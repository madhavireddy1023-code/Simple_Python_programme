import { Component, OnInit } from '@angular/core';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Observable } from 'rxjs';
import { UwRefCompanyHistory, UwRefCompanyHistoryRecords } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { FormBuilder, FormGroup } from '@angular/forms';
import { debounceTime, distinctUntilChanged, last, takeLast } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-main-company-ref-history',
  templateUrl: './main-company-ref-history.component.html',
  styleUrls: ['./main-company-ref-history.component.scss'],
})
export class MainCompanyRefHistoryComponent implements OnInit {
  companyRefHistoryTable$: Observable<UwRefCompanyHistory>;
  allTableData$: [];
  companyRefHistoryForm: FormGroup;
  currentUserVal = true;
  companyCodeQuery: string;
  signigNumberAndDateQuery: string;
  companyCode: string;
  signigNumberAndDate: string;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private location: Location,
    private companyRefUpdateStoreService: CompanyRefUpdateStoreService
  ) {}

  ngOnInit(): void {
    this.companyRefHistoryTable$ = this.companyRefUpdateStoreService.selectCompanyHistory();

    this.companyRefHistoryForm = this.fb.group({
      companyCode: [''],
      signigNumberAndDate: [''],
      currentUser: [this.currentUserVal],
    });
    this.getQueryParams();
  }

  getQueryParams(): void {
    this.route?.queryParams.subscribe((params) => {
      this.companyCodeQuery = params?.companyCode;
      this.signigNumberAndDateQuery = params?.bureauSigningReference;
    });
  }
  onSubmit(): void {
    if (
      this.companyRefHistoryForm?.controls?.companyCode?.touched ||
      this.companyRefHistoryForm?.controls?.signigNumberAndDate?.touched
    ) {
      this.companyCode = this.companyRefHistoryForm?.controls?.companyCode.value || null;
      this.signigNumberAndDate = this.companyRefHistoryForm?.controls?.signigNumberAndDate.value || null;
    } else {
      this.companyCode = this.companyCodeQuery || null;
      this.signigNumberAndDate = this.signigNumberAndDateQuery || null;
    }

    this.companyRefUpdateStoreService.getCompanyHistory(
      this.currentUserVal,
      this.signigNumberAndDate,
      this.companyCode
    );
  }

  onSelectCurrentUser(event): void {
    this.currentUserVal = event;
    this.companyRefHistoryForm.get('currentUser')?.setValue(event);
  }

  callGetHistoryRef(value): void {}

  navigateToSearch(): void {
    this.location.back();
  }
}
