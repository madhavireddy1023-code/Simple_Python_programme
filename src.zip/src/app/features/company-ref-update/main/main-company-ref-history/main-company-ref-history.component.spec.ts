import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MainCompanyRefHistoryComponent } from './main-company-ref-history.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { constants } from 'buffer';

describe('MainCompanyHistoryUpdateComponent', () => {
  let component: MainCompanyRefHistoryComponent;
  let fixture: ComponentFixture<MainCompanyRefHistoryComponent>;
  const routerSpy = jasmine.createSpyObj('Router', ['company-ref-history']);
  const activatedRouteSpy = {
    queryParams: of({ companyCode: '123', bureauSigningReference: 'ABC' }),
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainCompanyRefHistoryComponent],
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
      ],
      providers: [
        MockStore,
        provideMockStore(),
        CompanyRefUpdateStoreService,
        FormBuilder,
        { provide: Router, useValue: routerSpy },
        { provide: ActivatedRoute, useValue: activatedRouteSpy },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainCompanyRefHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    spyOn(component, 'getQueryParams');
    component.ngOnInit();
    expect(component.getQueryParams).toHaveBeenCalled();
    expect(component).toBeTruthy();
  });
});
