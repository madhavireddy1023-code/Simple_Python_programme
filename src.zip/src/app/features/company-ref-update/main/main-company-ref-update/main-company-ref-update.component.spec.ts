import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MainCompanyRefUpdateComponent } from './main-company-ref-update.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';

describe('MainCompanyRefUpdateComponent', () => {
  let component: MainCompanyRefUpdateComponent;
  let fixture: ComponentFixture<MainCompanyRefUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainCompanyRefUpdateComponent],
      imports: [TranslateModule.forRoot()],
      providers: [MockStore, provideMockStore(), CompanyRefUpdateStoreService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainCompanyRefUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
