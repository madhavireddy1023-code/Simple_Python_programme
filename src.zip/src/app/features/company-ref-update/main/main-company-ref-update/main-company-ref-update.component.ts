import { Component, OnInit } from '@angular/core';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-main-company-ref-update',
  templateUrl: './main-company-ref-update.component.html',
  styleUrls: ['./main-company-ref-update.component.scss'],
})
export class MainCompanyRefUpdateComponent implements OnInit {
  allTableData$: Observable<UwRefSearchRecords>;

  constructor(private companyRefUpdateStoreService: CompanyRefUpdateStoreService) {}

  ngOnInit(): void {
    this.allTableData$ = this.companyRefUpdateStoreService.selectSearchResult();
  }
}
