import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';

import { MainCompanyRefBureauComponent } from './main-company-ref-bureau.component';
import { CompanyRefBureauStoreService } from '@features/company-ref-update/services/company-ref-bureau.store';
import { AuthorizedStatusService } from '@shared/services/authorized-status/authorized-status.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { StoreModule } from '@ngrx/store';
import { initialState } from '@features/company-ref-update/store/reducers/company-ref-update.reducers';

describe('CompanyRefBureauComponent', () => {
  let component: MainCompanyRefBureauComponent;
  let fixture: ComponentFixture<MainCompanyRefBureauComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MainCompanyRefBureauComponent],
      imports: [
        StoreModule.forRoot({}, {}),
        TranslateModule.forRoot(),
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
      ],
      providers: [MockStore, provideMockStore({ initialState }), CompanyRefBureauStoreService, AuthorizedStatusService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainCompanyRefBureauComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
