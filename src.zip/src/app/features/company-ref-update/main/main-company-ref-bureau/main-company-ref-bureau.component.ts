import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { UwRefUpdateRecord } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { CompanyRefBureauStoreService } from '@features/company-ref-update/services/company-ref-bureau.store';
import { AuthorizedStatusService } from '@shared/services/authorized-status/authorized-status.service';
import { Observable, Subject, Subscription } from 'rxjs';
@Component({
  selector: 'app-main-company-ref-bureau',
  templateUrl: './main-company-ref-bureau.component.html',
  styleUrls: ['./main-company-ref-bureau.component.scss'],
})
export class MainCompanyRefBureauComponent implements OnInit, OnDestroy {
  bureau: TechnicianPortalBureauEnum;
  etag$: Observable<string>;
  formResponse$: Observable<UwRefUpdateRecord>;
  queryParams$: Observable<Params>;

  roles$: Observable<string[]>;

  constructor(
    private readonly companyRefStoreService: CompanyRefBureauStoreService,
    private authorizedStatusService: AuthorizedStatusService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.formResponse$ = this.companyRefStoreService.getCompanyRefSelector();
    this.etag$ = this.companyRefStoreService.getCompanyRefHeaderEtagSelector();
    this.queryParams$ = this.route.queryParams;

    this.getBureauType();
    this.roles$ = this.authorizedStatusService.roles$;
  }

  ngOnDestroy(): void {}

  getBureauType(): void {
    this.formResponse$.subscribe({
      next: (value) => {
        if (value) {
          this.bureau = value?.bureau;
        }
      },
      error: (error) => {
        // Handle any error that occurs during subscription
        //  console.error('Error occurred:', error);
      },
    });
  }
}
