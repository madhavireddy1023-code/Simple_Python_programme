import { TestBed } from '@angular/core/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import * as actions from '../store/actions/company-ref-update.action';
import * as selectors from '../store/selectors/company-ref-update.selectors';
import { CompanyRefUpdateStoreService } from './company-ref-update.store.service';

describe('CorrectionsStoreService', () => {
  let service: CompanyRefUpdateStoreService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockStore, provideMockStore()],
    });
    service = TestBed.inject(CompanyRefUpdateStoreService);
    store = TestBed.inject(MockStore);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should getSearchResult to be called', () => {
    const companyCode = '';
    spyOn(store, 'dispatch');
    service.getSearchResult(companyCode);
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should selectSearchResult to be called', () => {
    spyOn(service, 'selectSearchResult');
    service.selectSearchResult();
    expect(service.selectSearchResult).toHaveBeenCalled();
    spyOn(store, 'select');
    store.select(selectors.selectSearchResult);
    expect(store.select).toHaveBeenCalled();
  });
});
