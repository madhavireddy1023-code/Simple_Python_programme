import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { CompanyRefBureauStoreService } from './company-ref-bureau.store';

@Injectable({
  providedIn: 'root',
})
export class UwfRecordCorrectionResolver implements Resolve<boolean> {
  constructor(private readonly companyRefStoreService: CompanyRefBureauStoreService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const marketId = route.queryParams[`marketId`];
    const marketSyndicateId = route.queryParams[`marketSyndicateId`];
    const premiumId = route.queryParams[`premiumId`];
    this.companyRefStoreService.newcompanyRefSelectionGet(marketId, marketSyndicateId, premiumId);
    return of(true);
  }
}
