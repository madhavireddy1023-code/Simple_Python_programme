import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from '../../../store/app.reducer';
import * as actions from '../store/actions/company-ref-update.action';
import { Observable } from 'rxjs';

import * as selectors from '../store/selectors/company-ref-update.selectors';
import { TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { UwRefUpdateRecord } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

@Injectable({
  providedIn: 'root',
})
export class CompanyRefBureauStoreService {
  constructor(private store: Store<AppState>) {}

  newcompanyRefSelectionGet(marketId: string, marketSyndicateId: string, premiumId: string): void {
    this.store.dispatch(actions.newCompanRefSelectionGet({ marketId, marketSyndicateId, premiumId }));
  }

  patchUwfCorrectionRecords(
    etag: string,
    marketId: string,
    marketSyndicateId: string,
    premiumId: string,
    bureau: TechnicianPortalBureauEnum,
    body: UwRefUpdateRecord
  ): void {
    this.store.dispatch(actions.uwRefCorrectionPatch({ etag, marketId, marketSyndicateId, premiumId, bureau, body }));
  }

  getCompanyRefSelector(): Observable<UwRefUpdateRecord> {
    return this.store.select(selectors.selectuwfCorrectionRecord);
  }

  getCompanyRefHeaderEtagSelector(): Observable<string> {
    return this.store.select(selectors.selectuwfCorrectionRecordEtag);
  }
}
