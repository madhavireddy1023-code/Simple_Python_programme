import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { CompanyRefBureauStoreService } from './company-ref-bureau.store';
import { CompanyRefUpdateStoreService } from './company-ref-update.store.service';

@Injectable({
  providedIn: 'root',
})
export class UwfHistoryResolver implements Resolve<boolean> {
  constructor(private readonly companyRefUpdateStoreService: CompanyRefUpdateStoreService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const companyCode = route.queryParams[`companyCode`] || null;
    const bureauSigningReference = route.queryParams[`bureauSigningReference`] || null;
    this.companyRefUpdateStoreService?.getCompanyHistory(true, bureauSigningReference, companyCode);
    return of(true);
  }

  callApiGetHistory(userId, companyCode?, bureauSigningReference?): void {}
}
