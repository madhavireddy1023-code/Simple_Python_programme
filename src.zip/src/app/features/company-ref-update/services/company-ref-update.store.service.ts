import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from '../../../store/app.reducer';
import * as actions from '../store/actions/company-ref-update.action';
import { Observable } from 'rxjs';
import * as selectors from '../store/selectors/company-ref-update.selectors';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { UwRefCompanyHistory, UwRefCompanyHistoryRecords } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

@Injectable({
  providedIn: 'root',
})
export class CompanyRefUpdateStoreService {
  constructor(private store: Store<AppState>) {}

  getSearchResult(companyCode: string, companyReference?: string, signingReference?: string): void {
    this.store.dispatch(actions.getSearchResult({ companyCode, companyReference, signingReference }));
  }

  selectSearchResult(): Observable<UwRefSearchRecords> {
    return this.store.select(selectors.selectSearchResult);
  }

  setSearchResult(searchResult: UwRefSearchRecords): void {
    this.store.dispatch(actions.setSearchResult({ searchResult }));
  }

  getCompanyHistory(userId?: boolean, signingNumberAndDate?: string, companyCode?: string): void {
    this.store.dispatch(actions.getCompanyHistory({ userId, signingNumberAndDate, companyCode }));
  }

  setCompanyHistory(companyHistoryResult: UwRefCompanyHistory): void {
    this.store.dispatch(actions.setCompanyHistory({ companyHistoryResult }));
  }

  selectCompanyHistory(): Observable<UwRefCompanyHistory> {
    return this.store.select(selectors.selectCompanyHistory);
  }
}
