export interface HistoryRecords {
  dateAmended: string;
  bureauSingingRef: string;
  lineNo: number;
  origRef1: string;
  newReference1: string;
  origRef2: string;
  newReference2: string;
  companyCode: string;
}
