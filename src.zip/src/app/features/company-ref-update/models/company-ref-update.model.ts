import {
  UwRefCompanyHistory,
  UwRefCompanyHistoryRecords,
  UwRefUpdateRecord,
} from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { HistoryRecords } from './company-ref-history.model';

export interface CompanyRefUpdateState {
  searchResult: UwRefSearchRecords;
  uwfCorrectionRecord: UwRefUpdateRecord;
  headers: string;
  companyHistoryResult: UwRefCompanyHistory;
  history: HistoryRecords[];
}
