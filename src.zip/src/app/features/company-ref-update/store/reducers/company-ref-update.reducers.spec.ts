import { Action } from '@ngrx/store';
import { CompanyRefUpdateReducer, initialState } from './company-ref-update.reducers';
import * as actions from '../actions/company-ref-update.action';
import { mockSearchResult } from '../../const/mockSearchResult.consts';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { UwRefCompanyHistory } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { mockCompanyHistory } from '../../const/mockCompanyHistory.consts';

describe('CompanyRefUpdateReducer', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = CompanyRefUpdateReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should update the state of [companyREfUpdateSearchResult]', () => {
    const expectedState: UwRefSearchRecords = mockSearchResult;
    const action = actions.setSearchResult({ searchResult: expectedState });
    const newState = CompanyRefUpdateReducer(initialState, action);
    expect(newState.searchResult).toEqual(expectedState);
  });

  it('should return the default state', () => {
    const action = {} as any;
    const state = CompanyRefUpdateReducer(undefined, action);

    expect(state).toBe(initialState);
  });

  it('should set UWF correction record', () => {
    const uwRefupdateRecord = {
      /* mock UWF correction record data */
    } as any; // Use correct type
    const action = actions.setuwfCorrectionRecord({ uwRefupdateRecord });
    const updatedState = CompanyRefUpdateReducer(initialState, action);

    expect(updatedState.uwfCorrectionRecord).toEqual(uwRefupdateRecord);
  });

  it('should set UWF correction record headers', () => {
    const headers = 'etag';
    const action = actions.setuwfCorrectionRecordHeader({ headers });
    const updatedState = CompanyRefUpdateReducer(initialState, action);

    expect(updatedState.headers).toEqual(headers);
  });

  it('should update the state of companyHistoryResult', () => {
    const expectedState: UwRefCompanyHistory = mockCompanyHistory;
    const action = actions.setCompanyHistory({ companyHistoryResult: expectedState });
    const newState = CompanyRefUpdateReducer(initialState, action);
    expect(newState.companyHistoryResult).toEqual(expectedState);
  });
});
