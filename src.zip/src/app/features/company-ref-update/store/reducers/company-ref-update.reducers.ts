import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/company-ref-update.action';
import * as _ from 'lodash';
import { CompanyRefUpdateState } from '@features/company-ref-update/models/company-ref-update.model';

export const initialState: CompanyRefUpdateState = {
  searchResult: null,
  uwfCorrectionRecord: null,
  headers: null,
  companyHistoryResult: null,
  history: null,
};

export const CompanyRefUpdateReducer: ActionReducer<CompanyRefUpdateState, Action> = createReducer(
  initialState,

  on(actions.setSearchResult, (state: CompanyRefUpdateState, action) =>
    _.setWith(_.clone(state), 'searchResult', action.searchResult, _.clone)
  ),
  on(actions.setuwfCorrectionRecord, (state: CompanyRefUpdateState, action) =>
    _.setWith(_.clone(state), 'uwfCorrectionRecord', action.uwRefupdateRecord, _.clone)
  ),
  on(actions.setuwfCorrectionRecordHeader, (state: CompanyRefUpdateState, action) =>
    _.setWith(_.clone(state), 'headers', action.headers, _.clone)
  ),
  on(actions.setCompanyHistory, (state: CompanyRefUpdateState, action) =>
    _.setWith(_.clone(state), 'companyHistoryResult', action.companyHistoryResult, _.clone)
  )
);
