import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.companyRefUpdate;

// Select search result
export const selectSearchResult = createSelector(selectState, (state) => state?.searchResult);

export const selectuwfCorrectionRecord = createSelector(selectState, (state) => state?.uwfCorrectionRecord);

export const selectuwfCorrectionRecordEtag = createSelector(selectState, (state) => state?.headers);

export const selectCompanyHistory = createSelector(selectState, (state) => state?.companyHistoryResult);
