import * as selectors from './company-ref-update.selectors';
import { mockSearchResult } from '../../const/mockSearchResult.consts';
import { mockCompanyHistory } from '../../const/mockCompanyHistory.consts';

describe('CompanyRefUpdateSelectors', () => {
  const state = {
    searchResult: mockSearchResult,
    companyHistoryResult: mockCompanyHistory,
  };

  it('should select selectSearchResult', () => {
    const expectedData = mockSearchResult;
    const selectCorrectionSelectionResult = selectors.selectSearchResult.projector(state);
    expect(selectCorrectionSelectionResult).toEqual(expectedData);
  });

  it('should select selectCompanyHistory', () => {
    const expectedData = mockCompanyHistory;
    const selectCompanyHistoryResult = selectors.selectCompanyHistory.projector(state);
    expect(selectCompanyHistoryResult).toEqual(expectedData);
  });
});
