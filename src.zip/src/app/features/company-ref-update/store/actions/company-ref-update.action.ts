import {
  UwRefCompanyHistory,
  UwRefCompanyHistoryRecords,
  UwRefUpdateRecord,
} from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-technician-experience-api/lib/swaggerhub-extract/model/technicianPortalBureauEnum';
import { createAction, props } from '@ngrx/store';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { HttpHeaders } from '@angular/common/http';

const COMPANY_REF_PREFIX = '[COMPANY-REF]';

// Get correction selection
const GET_COMPANY_REF = `${COMPANY_REF_PREFIX} GET_COMPANY_REF_SELECTION`;
export const newCompanRefSelectionGet = createAction(
  GET_COMPANY_REF,
  props<{ marketId: string; marketSyndicateId: string; premiumId: string }>()
);

// set correction data in store
const SET_UWFCORRECTIONRECOR_RESULT = `${COMPANY_REF_PREFIX} SET_UWFCORRECTIONRECOR_RESULT`;
export const setuwfCorrectionRecord = createAction(
  SET_UWFCORRECTIONRECOR_RESULT,
  props<{ uwRefupdateRecord: UwRefUpdateRecord }>()
);

const SET_UWFCORRECTIONRECOR_HEADER = `${COMPANY_REF_PREFIX} SET_UWFCORRECTIONRECOR_HEADER`;
export const setuwfCorrectionRecordHeader = createAction(SET_UWFCORRECTIONRECOR_HEADER, props<{ headers: string }>());

//  Patch Correction Workpackage Status
const UWREF_CORRECTION_RECORD_PATCH = `${COMPANY_REF_PREFIX} UWREF_CORRECTION_RECORD_PATCH`;
export const uwRefCorrectionPatch = createAction(
  UWREF_CORRECTION_RECORD_PATCH,
  props<{
    etag: string;
    marketId: string;
    marketSyndicateId: string;
    premiumId: string;
    bureau: TechnicianPortalBureauEnum;
    body: UwRefUpdateRecord;
  }>()
);

const COMPANY_REF_UPDATE_PREFIX = '[COMPANY_REF_UPDATE]';

// Get search result
const GET_SEARCH_RESULT = `${COMPANY_REF_UPDATE_PREFIX} GET_SEARCH_RESULT`;
export const getSearchResult = createAction(
  GET_SEARCH_RESULT,
  props<{ companyCode: string; companyReference?: string; signingReference?: string }>()
);

// set correction data in store
const SET_SEARCH_RESULT = `${COMPANY_REF_UPDATE_PREFIX} SET_SEARCH_RESULT`;
export const setSearchResult = createAction(SET_SEARCH_RESULT, props<{ searchResult: UwRefSearchRecords }>());

// Get company history
const GET_COMPANY_HISTORY = `${COMPANY_REF_UPDATE_PREFIX} GET_COMPANY_HISTORY`;
export const getCompanyHistory = createAction(
  GET_COMPANY_HISTORY,
  props<{ userId?: boolean; signingNumberAndDate?: string; companyCode?: string }>()
);

// set company history
const SET_COMPANY_HISTORY = `${COMPANY_REF_UPDATE_PREFIX} SET_COMPANY_HISTORY`;
export const setCompanyHistory = createAction(
  SET_COMPANY_HISTORY,
  props<{ companyHistoryResult: UwRefCompanyHistory }>()
);
