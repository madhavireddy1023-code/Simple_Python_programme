import { getSearchResult, setSearchResult, getCompanyHistory, setCompanyHistory } from './company-ref-update.action';

describe('CompanyRefUpdate Actions', () => {
  it('should return correct types', () => {
    // get search result
    expect(getSearchResult.type).toEqual('[COMPANY_REF_UPDATE] GET_SEARCH_RESULT');

    // set search result
    expect(setSearchResult.type).toEqual('[COMPANY_REF_UPDATE] SET_SEARCH_RESULT');

    expect(getCompanyHistory.type).toEqual('[COMPANY_REF_UPDATE] GET_COMPANY_HISTORY');

    expect(setCompanyHistory.type).toEqual('[COMPANY_REF_UPDATE] SET_COMPANY_HISTORY');
  });
});
