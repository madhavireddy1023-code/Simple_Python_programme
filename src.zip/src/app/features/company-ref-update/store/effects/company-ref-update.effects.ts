import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, from, of } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import * as actions from '../actions/company-ref-update.action';

import { DomainAPITechnicianPortalCorrectionService } from 'src/app/api/domain-api-technician-portal-correction';
import { TechnicianPortalEnquiryService } from 'src/app/api/premium-technician-portal-enquiry';
import { ScrollUp } from 'src/app/utils';

@Injectable()
export class CompanyRefUpdateEffects {
  constructor(
    private actions$: Actions,
    private domainAPITechnicianPortalCorrectionService: DomainAPITechnicianPortalCorrectionService,
    private technicianPortalEnquiryService: TechnicianPortalEnquiryService
  ) {}

  newCompanyRefSelectionGet$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.newCompanRefSelectionGet),
      switchMap((action) => {
        return this.domainAPITechnicianPortalCorrectionService
          .apiV1UwRefCorrectionRecordGet(action.marketId, action.marketSyndicateId, action.premiumId, 'response')
          .pipe(
            switchMap((response) => {
              // Access headers

              const customHeader = response.headers.get(`Etag`);
              const actionsArray = [
                actions.setuwfCorrectionRecordHeader({ headers: customHeader }),
                actions.setuwfCorrectionRecord({ uwRefupdateRecord: response.body }),
              ];
              return from(actionsArray); //
            })
          );
      }),
      catchError((error) => {
        ScrollUp(0, 0);
        if (error?.status === 403) {
          return of(
            loadGlobalAlert({
              response: {
                ...error,
                responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                isAuthAlert: true,
                isVisible: false,
              },
            })
          );
        }
        return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
      })
    )
  );

  uwRefCorrectionRecordPatch$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.uwRefCorrectionPatch),
      switchMap((action) => {
        return this.domainAPITechnicianPortalCorrectionService
          .apiV1UwRefCorrectionRecordPatch(
            action.etag,
            action.marketId,
            action.marketSyndicateId,
            action.premiumId,
            action.bureau,
            action.body
          )
          .pipe(
            switchMap((response) => {
              const actionsArray = [
                actions.newCompanRefSelectionGet({
                  marketId: action.marketId,
                  marketSyndicateId: action.marketSyndicateId,
                  premiumId: action.premiumId,
                }),
                loadGlobalAlert({
                  response: { response, status: 200, isGlobalAlert: true },
                }),
              ];
              return from(actionsArray); //
            }), // This can be simplified as it's currently a pass-through
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              loadGlobalAlert({
                response: { error, status: 400, isGlobalAlert: true },
              });
            }) // Handle errors by returning them as an observable
          );
      })
    )
  );

  // get search results
  getSearchResult$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getSearchResult),
      switchMap((action) => {
        return this.technicianPortalEnquiryService
          .apiV1CompanyBureauSearchPost(
            action.companyCode,
            null,
            action?.companyReference ? action?.companyReference : null,
            action?.signingReference ? action?.signingReference : null,
            'response'
          )
          .pipe(
            switchMap((response) => {
              return of(actions.setSearchResult({ searchResult: response.body }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 400) {
                const errorActions = error?.error?.map((item) => {
                  return loadGlobalAlert({
                    response: {
                      error,
                      responseMessage: item?.detail,
                      status: 400,
                      isGlobalAlert: true,
                      isMultiple: true,
                    },
                  });
                });

                return from([...errorActions]);
              } else if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                      isAuthAlert: true,
                      isVisible: false,
                    },
                  })
                );
              } else {
                return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
              }
            })
          );
      })
    )
  );

  // get company history
  getCompanyHistory$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.getCompanyHistory),
      switchMap((action) => {
        return this.domainAPITechnicianPortalCorrectionService
          .apiV1UwRefCompanyHistoryGet(action?.userId, action?.signingNumberAndDate, action?.companyCode, 'response')
          .pipe(
            switchMap((response) => {
              return of(actions.setCompanyHistory({ companyHistoryResult: response?.body }));
            }),
            catchError(() => of(actions.setCompanyHistory({ companyHistoryResult: [] })))
          );
      })
    )
  );
}
