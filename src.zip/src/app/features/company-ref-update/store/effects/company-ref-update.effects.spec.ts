import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CompanyRefUpdateEffects } from './company-ref-update.effects';
import { provideMockStore } from '@ngrx/store/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { initialState } from '../reducers/company-ref-update.reducers';
import { Observable, of } from 'rxjs';
import * as action from '../actions/company-ref-update.action';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { take } from 'rxjs/operators';
import { MainCompanyRefUpdateComponent } from '@features/company-ref-update/main/main-company-ref-update/main-company-ref-update.component';
import { DomainAPITechnicianPortalCorrectionService } from 'src/app/api/domain-api-technician-portal-correction';

import { mockGetUfResult } from '@features/company-ref-update/const/mockLirmaFormResponse.consts';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { Success, TechnicianPortalBureauEnum } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { TechnicianPortalEnquiryService } from 'src/app/api/premium-technician-portal-enquiry';

describe('CompanyRefUpdateEffects', () => {
  let actions$: Observable<any>;
  let effects: CompanyRefUpdateEffects;
  let technicianPortalExpCorrectionsService: jasmine.SpyObj<TechnicianPortalEnquiryService>;
  let domaineApitechnicianPortalExpCorrectionsService: jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;

  beforeEach(() => {
    const technicianPortalExpCorrectionsServiceSpy = jasmine.createSpyObj('TechnicianPortalExpCorrectionService', [
      'apiV1UwRefCorrectionRecordsGet',
    ]);
    const domaineApitechnicianPortalExpCorrectionsServiceSpy = jasmine.createSpyObj(
      'DomainAPITechnicianPortalCorrectionService',
      ['apiV1UwRefCorrectionRecordPatch', 'apiV1UwRefCorrectionRecordGet', 'apiV1UwRefCompanyHistoryGet']
    );

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([{ path: 'company-ref-update', component: MainCompanyRefUpdateComponent }]),
      ],
      providers: [
        CompanyRefUpdateEffects,
        {
          provide: DomainAPITechnicianPortalCorrectionService,
          useValue: domaineApitechnicianPortalExpCorrectionsServiceSpy,
        },
        { provide: TechnicianPortalEnquiryService, useValue: technicianPortalExpCorrectionsServiceSpy },
        provideMockStore({ initialState }),
        provideMockActions(() => actions$),
      ],
    });
    effects = TestBed.inject(CompanyRefUpdateEffects);
    technicianPortalExpCorrectionsService = TestBed.inject(
      TechnicianPortalEnquiryService
    ) as jasmine.SpyObj<TechnicianPortalEnquiryService>;

    domaineApitechnicianPortalExpCorrectionsService = TestBed.inject(
      DomainAPITechnicianPortalCorrectionService
    ) as jasmine.SpyObj<DomainAPITechnicianPortalCorrectionService>;
  });

  xit('should test apiV1CompanyBureauSearchPost$ effect', () => {
    actions$ = of(action.getSearchResult({ companyCode: 'string' }));
    technicianPortalExpCorrectionsService.apiV1CompanyBureauSearchPost.and.returnValue(
      of(new HttpResponse({ status: 400 }))
    );
    effects.getSearchResult$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setSearchResult.type);
    });
  });

  it('should test getCompanyHistory$ effect', () => {
    actions$ = of(action.getCompanyHistory({ userId: true, signingNumberAndDate: 'string', companyCode: 'string' }));
    domaineApitechnicianPortalExpCorrectionsService.apiV1UwRefCompanyHistoryGet.and.returnValue(
      of(new HttpResponse({ status: 200 }))
    );
    effects.getCompanyHistory$.pipe(take(1)).subscribe((res: any) => {
      expect(res.type).toEqual(action.setCompanyHistory.type);
    });
  });

  it('should dispatch setuwfCorrectionRecordHeader and setuwfCorrectionRecord actions on success', () => {
    const mockAction = action.newCompanRefSelectionGet({
      marketId: '1',
      marketSyndicateId: '2',
      premiumId: '3',
    });

    const mockResponse = new HttpResponse({
      body: mockGetUfResult[0],
      headers: new HttpHeaders({ Etag: 'mock-etag-value' }),
    });

    actions$ = of(mockAction);
    domaineApitechnicianPortalExpCorrectionsService.apiV1UwRefCorrectionRecordGet.and.returnValue(of(mockResponse));

    const expectedActions = [
      action.setuwfCorrectionRecordHeader({ headers: 'mock-etag-value' }),
      action.setuwfCorrectionRecord({ uwRefupdateRecord: mockGetUfResult[0] }),
    ];

    effects.newCompanyRefSelectionGet$.subscribe((actionRe) => {
      expect(expectedActions).toContain(actionRe);
    });
  });

  it('should dispatch loadGlobalAlert action with a successful response', () => {
    const mockAction = action.uwRefCorrectionPatch({
      etag: 'some-etag',
      marketId: '1',
      marketSyndicateId: '2',
      premiumId: '3',
      bureau: TechnicianPortalBureauEnum.LIRMA,
      body: {},
    });
    const mockResponse = new HttpResponse<Success>({
      body: {},
      status: 200,
      statusText: 'OK',
      headers: new HttpHeaders(),
    });

    actions$ = of(mockAction);
    domaineApitechnicianPortalExpCorrectionsService.apiV1UwRefCorrectionRecordPatch.and.returnValue(
      of(new HttpResponse(mockResponse))
    );

    const expectedActions = [
      action.newCompanRefSelectionGet({
        marketId: '1',
        marketSyndicateId: '2',
        premiumId: '3',
      }),
      loadGlobalAlert({
        response: { response: mockResponse, status: 200, isGlobalAlert: true },
      }),
    ];

    effects.uwRefCorrectionRecordPatch$.subscribe((resultAction) => {
      expect(expectedActions).toContain(resultAction);
    });
  });

  afterEach(() => {
    // httpTestingController.verify();
  });
});
