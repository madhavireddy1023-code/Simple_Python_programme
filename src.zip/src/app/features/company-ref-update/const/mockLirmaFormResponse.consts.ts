import { TechnicianPortalBureauEnum, UwRefUpdateRecord } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

export const mockGetUfResult: UwRefUpdateRecord[] = [
  {
    marketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    marketSyndicateId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    premiumId: '6bc29dc1-ecda-4354-9fd9-2f7757fd35be',
    lineNumber: 0,
    syndicateNumber: 'string',
    syndicatePercentage: 0,
    syndicateReference: 'string',
    syndicateSecondaryReference: 'string',
    csnd: 'string',
    bureau: TechnicianPortalBureauEnum.ILU,
    commuted: true,
  },
];
