import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { TableColumn } from '@shared/models/interfaces';

export const mockSearchResult: UwRefSearchRecords = [
  {
    marketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    marketSyndicateId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    csnd: '68513 06022024',
    syndicatePercentage: 0,
  },
  {
    marketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    marketSyndicateId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    csnd: '68513 06022024',
    syndicatePercentage: 0,
  },
  {
    marketId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    marketSyndicateId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    csnd: '68513 06022024',
    syndicatePercentage: 0,
  },
];

export const mockTableColumns: TableColumn[] = [
  {
    id: 1,
    key: '1',
    label: '123',
    value: '123',
  },
];
