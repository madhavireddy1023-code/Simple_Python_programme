import { UwRefUpdateRecord } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';

export function getValueForCompanyNewRef(value: any, key: string, formResponse: UwRefUpdateRecord): string {
  if (value !== false && value !== '' && value !== null) {
    return value;
  } else if (value === '' || value === null) {
    return key === 'companyNewRef1' || key === 'companyNewRef'
      ? formResponse.syndicateReference
      : formResponse.syndicateSecondaryReference;
  }
  return '';
}
