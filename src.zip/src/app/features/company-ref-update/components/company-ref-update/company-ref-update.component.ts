import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { Store } from '@ngrx/store';
import { COMPANY_REF_HISTORY } from '@shared/consts/shared.consts';
import { FormControls } from '@shared/models';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { Observable } from 'rxjs';
import { ValidationInputStatus } from 'src/app/utils';
@Component({
  selector: 'app-company-ref-update',
  templateUrl: './company-ref-update.component.html',
  styleUrls: ['./company-ref-update.component.scss'],
})
export class CompanyRefUpdateComponent implements OnInit {
  allTableDataRef: UwRefSearchRecords;
  companyRefUpdateForm: FormGroup;
  shareCompanyCode: string;
  shareCompanyReference: string;
  shareBureauSigningRef: string;
  errorBanner = false;
  errorMsg: string;
  errorResponseData$: Observable<any>;
  isInvalidSigning$: Observable<boolean>;

  isSearchBtnClicked: boolean;
  customErrorMsg: boolean;

  @Input() set allTableData(allTableData: UwRefSearchRecords) {
    this.allTableDataRef = allTableData;
  }
  constructor(
    private formBuilder: FormBuilder,
    private companyRefUpdateStoreService: CompanyRefUpdateStoreService,
    private router: Router,
    private globalAlertStoreService: GlobalAlertStoreService
  ) {}

  ngOnInit(): void {
    this.iniCompanyRefUpdateForm();
    this.errorResponseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.customErrorMsg = false;
    this.globalAlertStoreService.clearGlobalResponse();
  }

  iniCompanyRefUpdateForm(): void {
    this.companyRefUpdateForm = this.formBuilder.group({
      companyCode: [null, [Validators.required, Validators.maxLength(7)]],
      companyReference: [null],
      bureauSigningReference: [null],
    });
  }
  // get form controls of contract information form
  get companyRefUpdateFormControls(): FormControls {
    return this.companyRefUpdateForm?.controls;
  }
  getValidationInputStatus(
    formControl: AbstractControl,
    input: DxcTextInputComponent | DxcTextareaComponent
  ): boolean | ValidationErrors | null {
    return ValidationInputStatus(this.isSearchBtnClicked, formControl, input);
  }

  onSearch(): void {
    this.globalAlertStoreService.clearGlobalResponse();
    if (!this.shareCompanyCode) {
      this.isSearchBtnClicked = true;
    }
    if (this.allTableDataRef) {
      this.allTableDataRef = [];
    }
    this.shareCompanyCode = this.companyRefUpdateForm?.controls?.companyCode.value;
    this.shareCompanyReference = this.companyRefUpdateForm?.controls?.companyReference.value;
    this.shareBureauSigningRef = this.companyRefUpdateForm?.controls?.bureauSigningReference.value;

    if (this.shareCompanyCode && !(this.shareCompanyReference || this.shareBureauSigningRef)) {
      this.errorBanner = true;
      this.errorMsg = 'COMPANY_REF_UPDATE.COMPANY_REF_ERROR';
    } else if (!this.shareCompanyCode && (this.shareCompanyReference || this.shareBureauSigningRef)) {
      this.errorBanner = true;
      this.errorMsg = 'COMPANY_REF_UPDATE.COMPANY_CODE_ERROR';
    } else {
      this.errorBanner = false;
      if (this.companyRefUpdateForm?.valid) {
        this.companyRefUpdateStoreService.getSearchResult(
          this.shareCompanyCode,
          this.shareCompanyReference,
          this.shareBureauSigningRef
        );
      }
    }
  }

  navigateToHistory(): void {
    this.router.navigate([COMPANY_REF_HISTORY], {
      queryParams: {
        companyCode: this.shareCompanyCode,
        bureauSigningReference: this.shareBureauSigningRef,
      },
    });
  }
}
