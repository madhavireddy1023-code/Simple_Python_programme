import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyRefUpdateComponent } from './company-ref-update.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { mockSearchResult, mockTableColumns } from '@features/company-ref-update/const/mockSearchResult.consts';
import { RouterTestingModule } from '@angular/router/testing';
import { Router, RouterModule } from '@angular/router';

describe('CompanyRefUpdateComponent', () => {
  let component: CompanyRefUpdateComponent;
  let fixture: ComponentFixture<CompanyRefUpdateComponent>;
  let el: DebugElement;
  let formBuilder: FormBuilder;
  let companyRefUpdateStoreService: CompanyRefUpdateStoreService;
  const technicianPortalExpCorrectionsServiceSpy = jasmine.createSpyObj('TechnicianPortalExpCorrectionService', [
    'apiV1UwRefCorrectionRecordsGet',
  ]);

  const router = {};

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
      ],
      declarations: [CompanyRefUpdateComponent],
      providers: [
        MockStore,
        provideMockStore(),
        { provide: Router, useValue: router },
        CompanyRefUpdateStoreService,
        FormBuilder,
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRefUpdateComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    formBuilder = TestBed.inject(FormBuilder);
    fixture.detectChanges();
    companyRefUpdateStoreService = TestBed.inject(CompanyRefUpdateStoreService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the companyRefUpdateForm', () => {
    expect(component.companyRefUpdateForm).toBeDefined();
  });

  it('should call iniCompanyRefUpdateForm in oninit', () => {
    spyOn(component, 'iniCompanyRefUpdateForm');
    component.allTableData = mockSearchResult;
    component.ngOnInit();
    expect(component.iniCompanyRefUpdateForm).toHaveBeenCalled();
  });

  it('should call getSearchResult in onSearch', () => {
    spyOn(companyRefUpdateStoreService, 'getSearchResult');
    fixture.detectChanges();
    component.allTableData = mockSearchResult;
    component.onSearch();
    expect(component.companyRefUpdateForm.invalid);
  });

  it('should appear error banner if entered company code only', () => {
    component.companyRefUpdateForm?.controls?.companyCode.setValue('6000');
    component.onSearch();
    expect(component.errorBanner).toBeTruthy();
  });

  it('should appear error banner if entered signing ref without company code', () => {
    component.companyRefUpdateForm?.controls?.bureauSigningReference.setValue('2024060219873');
    component.onSearch();
    expect(component.errorBanner).toBeTruthy();
  });

  it('should appear error banner if entered company ref without company code', () => {
    component.companyRefUpdateForm?.controls?.bureauSigningReference.setValue('2024060219873');
    component.onSearch();
    expect(component.errorBanner).toBeTruthy();
  });
});
