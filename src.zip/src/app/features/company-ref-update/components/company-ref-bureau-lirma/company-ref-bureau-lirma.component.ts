import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Params, Router } from '@angular/router';
import { CompanyRefBureauStoreService } from '@features/company-ref-update/services/company-ref-bureau.store';
import { COMPANY_REF_UPDATE } from '@shared/consts/shared.consts';
import { Role } from '@shared/consts/shared.enums';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { Subject, Observable } from 'rxjs';
import { TechnicianPortalBureauEnum, UwRefUpdateRecord } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { takeUntil } from 'rxjs/operators';
import { FormControls } from '@shared/models/interfaces';
import { getValueForCompanyNewRef } from '@features/company-ref-update/const/company-ref.helper';
import { PartyDetails, SearchQueryRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { PARTY_TECHNICIAN, DXC_USER_TECHNICIAN } from '@shared/consts/party.const';
import { PartyStoreService } from '@shared/services/party/party.store.service';

@Component({
  selector: 'app-company-ref-bureau-lirma',
  templateUrl: './company-ref-bureau-lirma.component.html',
  styleUrls: ['./company-ref-bureau-lirma.component.scss'],
})
export class CompanyRefBureauLirmaComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  userPartyRole: SearchQueryRequest.RoleEnum;
  technician = DXC_USER_TECHNICIAN;
  formChanged = false;
  marketId: string;
  marketSyndicateId: string;
  premiumId: string;
  saveLirmaForm: FormGroup;
  ref1: string;
  ref2: string;
  responseData$: Observable<any>;
  lirmaFormResponseRef: UwRefUpdateRecord;
  checkCommutedCheckboxValue = false;
  canEditCommuted: boolean;
  // Flag for controlling suppressed editability
  canEditSuppressed = false;
  isSuppressedChecked = false;

  @Input() set role(roles: string[]) {
    this.roles = roles;
    this.updateSuppressionAccessibility();
    this.updateCommutedAccessibility();
  }
  get role(): string[] {
    return this.roles;
  }
  private roles: string[];
  @Input() etag: string;

  @Input() set queryParams(params: Params) {
    this.globalAlertStoreService.clearGlobalResponse();
    if (params) {
      this.marketId = params?.marketId;
      this.marketSyndicateId = params?.marketSyndicateId;
      this.premiumId = params?.premiumId;
    }
  }

  @Input() set lirmaFormResponse(lirmaFormResponse: UwRefUpdateRecord) {
    if (lirmaFormResponse) {
      this.lirmaFormResponseRef = lirmaFormResponse;
      this.initSaveLirmaFormGroup();
      this.updateReferences();
      this.formChanged = false;
    }
  }

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private companyRefUpdateStoreService: CompanyRefUpdateStoreService,
    private companyRefStoreService: CompanyRefBureauStoreService,
    private globalAlertStoreService: GlobalAlertStoreService,
    private partyStoreService: PartyStoreService
  ) {}

  get saveLirmaFormControls(): FormControls {
    return this.saveLirmaForm?.controls;
  }

  ngOnInit(): void {
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.initSaveLirmaFormGroup();
    this.initSaveLirmaFormValueChanges();
    this.getUserPartyRole();
  }

  initSaveLirmaFormGroup(): void {
    this.saveLirmaForm = this.formBuilder.group({
      companyNewRef1: [null, [Validators.maxLength(12)]],
      companyNewRef2: [null, [Validators.maxLength(12)]],
      commuted: new FormControl(false),
    });

    // Load old references from the response
    this.ref1 = this.lirmaFormResponseRef?.syndicateReference;
    this.ref2 = this.lirmaFormResponseRef?.syndicateSecondaryReference;
  }

  /**
   * Update the disabled state of the "suppressed" control based on user roles.
   * The control is enabled only if the user has the PROCESS_LINE_SUPPRESSION_EDIT role.
   */
  updateSuppressionAccessibility(): void {
    const hasSuppressionEditRole = this.role && this.role.includes(Role.PROCESS_LINE_SUPPRESSION_EDIT);
    this.canEditSuppressed = hasSuppressionEditRole;
  }
  /**
   * Update the disabled state of the "Commuted" control based on user roles.
   * The control is enabled only if the user has the PROCESS_LINE_SUPPRESSION_EDIT role.
   */
  updateCommutedAccessibility(): void {
    const hasCommutedEditRole = this.role && !this.role.includes(Role.All_Tech_Premiums);
    this.canEditCommuted = hasCommutedEditRole;
  }

  initSaveLirmaFormValueChanges(): void {
    this.saveLirmaForm.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.formChanged = true;
    });
  }

  onNewSearchClick(): void {
    this.companyRefUpdateStoreService.setSearchResult(null);
    this.router.navigate([COMPANY_REF_UPDATE]);
  }

  saveChanges(): void {
    if (!this.formChanged) {
      return;
    }
    if (this.saveLirmaForm.valid) {
      this.companyRefStoreService.patchUwfCorrectionRecords(
        this.etag,
        this.lirmaFormResponseRef?.marketId,
        this.lirmaFormResponseRef?.marketSyndicateId,
        this.lirmaFormResponseRef?.premiumId,
        TechnicianPortalBureauEnum.LIRMA,
        this.getFilledFormValues()
      );
    }
  }

  getFilledFormValues(): UwRefUpdateRecord {
    const filledValues: UwRefUpdateRecord = {};

    Object.keys(this.saveLirmaForm.controls).forEach((key) => {
      const control = this.saveLirmaForm.get(key);
      const value = control.value;
      switch (key) {
        case 'companyNewRef1':
          filledValues.syndicateReference = getValueForCompanyNewRef(value, key, this.lirmaFormResponseRef);
          break;
        case 'companyNewRef2':
          filledValues.syndicateSecondaryReference = getValueForCompanyNewRef(value, key, this.lirmaFormResponseRef);
          break;
        case 'commuted':
          filledValues.commuted = value;
          break;
        default:
          break;
      }
    });

    // Alternatively, using the component's checkbox state variables:
    filledValues.commuted = this.checkCommutedCheckboxValue;
    filledValues.suppressed = this.isSuppressedChecked;

    return filledValues;
  }

  updateReferences(): void {
    this.companyRefStoreService
      .getCompanyRefSelector()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data) => {
        this.ref1 = data?.syndicateReference;
        this.ref2 = data?.syndicateSecondaryReference;
        this.saveLirmaForm.get('companyNewRef1').setValue('');
        this.saveLirmaForm.get('companyNewRef2').setValue('');
        this.checkCommutedCheckboxValue = data?.commuted;
        // Update the suppressed control value.
        this.suppressedChanged(data?.suppressed);
      });
  }

  commutedChanged(commutedValue: boolean): void {
    this.checkCommutedCheckboxValue = commutedValue;
  }

  /**
   * Update the suppressed form control when the checkbox value changes.
   * Converts "on" or boolean values into a proper boolean.
   */
  suppressedChanged(event: any): void {
    this.formChanged = true;
    const boolValue = event === 'on' || event === true;
    this.isSuppressedChecked = boolValue;
  }

  getUserPartyRole(): void {
    this.partyStoreService.getPartyInfoOfUser();
    this.partyStoreService
      .selectPartyInfoOfUser()
      .pipe(takeUntil(this.destroy$))
      .subscribe((partyInfo: PartyDetails) => {
        if (partyInfo) {
          const partyUserRole = partyInfo.partyOrganisationRole;
          this.userPartyRole =
            partyUserRole.toUpperCase() === PARTY_TECHNICIAN
              ? SearchQueryRequest.RoleEnum.TECHNICIAN
              : SearchQueryRequest.RoleEnum[partyUserRole.toUpperCase()];
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
