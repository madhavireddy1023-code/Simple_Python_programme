import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyRefBureauLirmaComponent } from './company-ref-bureau-lirma.component';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Params, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { provideMockStore } from '@ngrx/store/testing';
import { mockGetUfResult } from '@features/company-ref-update/const/mockLirmaFormResponse.consts';
import { By } from '@angular/platform-browser';
import { DxcButtonModule, DxcCheckboxModule, DxcTextInputModule } from '@dxc-technology/halstack-angular';
import { CompanyRefBureauStoreService } from '@features/company-ref-update/services/company-ref-bureau.store';
import { Router } from '@angular/router';
import { COMPANY_REF_UPDATE } from '@shared/consts/shared.consts';
import { of } from 'rxjs';
import { SearchQueryRequest } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { mockPartyInfoUser, mockPartyInfoUserCarrier, mockPartyInfoUserBroker } from '@shared/consts/mock-party.const';
import { PartyStoreService } from '@shared/services/party/party.store.service';

describe('CompanyRefBureauLirmaComponent', () => {
  let component: CompanyRefBureauLirmaComponent;
  let fixture: ComponentFixture<CompanyRefBureauLirmaComponent>;

  let storeService: jasmine.SpyObj<CompanyRefBureauStoreService>;
  const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
  const activatedRouteMock = {
    queryParams: of({
      marketId: 'mockMarketId',
      marketSyndicateId: 'mockSyndicateId',
      premiumId: 'mockPremiumId',
    }),
  };
  let partyStoreService: PartyStoreService;

  beforeEach(async () => {
    const spy = jasmine.createSpyObj('CompanyRefBureauStoreService', [
      'patchUwfCorrectionRecords',
      'newcompanyRefSelectionGet',
      'getCompanyRefSelector',
    ]);

    await TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        ReactiveFormsModule,
        RouterModule.forRoot([]),
        RouterTestingModule.withRoutes([]),
        DxcCheckboxModule,
        DxcButtonModule,
        DxcTextInputModule,
      ],
      providers: [
        CompanyRefUpdateStoreService,
        { provide: CompanyRefBureauStoreService, useValue: spy },
        { provide: Router, useValue: routerSpy },
        provideMockStore(),
        { provide: ActivatedRoute, useValue: activatedRouteMock },
        PartyStoreService,
      ],

      declarations: [CompanyRefBureauLirmaComponent],
    }).compileComponents();

    storeService = TestBed.inject(CompanyRefBureauStoreService) as jasmine.SpyObj<CompanyRefBureauStoreService>;
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRefBureauLirmaComponent);
    component = fixture.componentInstance;
    component.lirmaFormResponseRef = mockGetUfResult[0];
    partyStoreService = TestBed.inject(PartyStoreService);

    component.role = [];
    storeService.getCompanyRefSelector.and.returnValue(
      of({
        syndicateReference: 'MockRef1',
        syndicateSecondaryReference: 'MockRef2',
      })
    );
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should disbale commuted checkbox', () => {
    component.canEditCommuted = true;
    fixture.detectChanges();
    const checkboxComponent = fixture.debugElement.query(By.css('#commutedcheckbox')).componentInstance;
    expect(checkboxComponent.disabled).toBeTrue();
  });

  it('should call patch methode from Store service', () => {
    spyOn(component, 'saveChanges').and.callThrough();
    component.formChanged = true;
    const button = fixture.debugElement.query(By.css('#companyRefFormSaveBtn')).nativeElement;
    component.etag = 'etagValue';
    component.lirmaFormResponseRef = {
      marketId: 'marketId',
      marketSyndicateId: 'marketSyndicateId',
      premiumId: 'premiumId',
    };

    component.saveLirmaForm.setValue({
      companyNewRef1: 'newRef1',
      companyNewRef2: 'newRef2',
      commuted: true,
    });
    component.saveChanges();

    if (button) {
      button.click();
      expect(storeService?.patchUwfCorrectionRecords).toHaveBeenCalled();
    }
  });

  it('should update references correctly', (done: DoneFn) => {
    component.updateReferences();

    fixture.detectChanges();

    setTimeout(() => {
      expect(component.ref1).toEqual('MockRef1');
      expect(component.ref2).toEqual('MockRef2');
      done();
    });
  });

  it('initializes the form with default values', () => {
    const formValue = {
      companyNewRef1: null,
      companyNewRef2: null,
      commuted: false,
    };
    expect(component.saveLirmaForm.value).toEqual(formValue);
  });

  it('navigates to COMPANY_REF_UPDATE on new search', () => {
    component.onNewSearchClick();
    expect(routerSpy.navigate).toHaveBeenCalledWith([COMPANY_REF_UPDATE]);
  });
  it('should set userPartyRole to TECHNICIAN when partyOrganisationRole is DXC', () => {
    const mockPartyInfo = mockPartyInfoUser;
    const getPartyInfoOfUserSpy = spyOn(partyStoreService, 'getPartyInfoOfUser');
    const selectPartyInfoOfUserSpy = spyOn(partyStoreService, 'selectPartyInfoOfUser').and.returnValue(
      of(mockPartyInfo)
    );
    component.getUserPartyRole();

    expect(getPartyInfoOfUserSpy).toHaveBeenCalled();
    expect(selectPartyInfoOfUserSpy).toHaveBeenCalled();
    expect(component.userPartyRole).toBe(SearchQueryRequest.RoleEnum.TECHNICIAN);
  });

  it('should set userPartyRole to CARRIER when partyOrganisationRole is CARRIER', () => {
    const mockPartyInfo = mockPartyInfoUserCarrier;
    const getPartyInfoOfUserSpy = spyOn(partyStoreService, 'getPartyInfoOfUser');
    const selectPartyInfoOfUserSpy = spyOn(partyStoreService, 'selectPartyInfoOfUser').and.returnValue(
      of(mockPartyInfo)
    );
    component.getUserPartyRole();

    expect(getPartyInfoOfUserSpy).toHaveBeenCalled();
    expect(selectPartyInfoOfUserSpy).toHaveBeenCalled();
    expect(component.userPartyRole).toBe(SearchQueryRequest.RoleEnum.CARRIER);
  });

  it('should set userPartyRole to BROKER when partyOrganisationRole is BROKER', () => {
    const mockPartyInfo = mockPartyInfoUserBroker;
    const getPartyInfoOfUserSpy = spyOn(partyStoreService, 'getPartyInfoOfUser');
    const selectPartyInfoOfUserSpy = spyOn(partyStoreService, 'selectPartyInfoOfUser').and.returnValue(
      of(mockPartyInfo)
    );
    component.getUserPartyRole();

    expect(getPartyInfoOfUserSpy).toHaveBeenCalled();
    expect(selectPartyInfoOfUserSpy).toHaveBeenCalled();
    expect(component.userPartyRole).toBe(SearchQueryRequest.RoleEnum.BROKER);
  });
});
