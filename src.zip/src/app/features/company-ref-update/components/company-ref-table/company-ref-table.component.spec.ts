import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CompanyRefTableComponent } from './company-ref-table.component';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { mockSearchResult, mockTableColumns } from '@features/company-ref-update/const/mockSearchResult.consts';

describe('CompanyRefTableComponent', () => {
  let component: CompanyRefTableComponent;
  let fixture: ComponentFixture<CompanyRefTableComponent>;
  const router = {
    navigate: jasmine.createSpy('navigate'),
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterModule.forRoot([]), RouterTestingModule.withRoutes([])],
      declarations: [CompanyRefTableComponent],
      providers: [{ provide: Router, useValue: router }, MockStore, provideMockStore()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRefTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render CompanyRefUpdate data ', waitForAsync(() => {
    const dataTableSpay = mockSearchResult;
    component.paginatedTableData = dataTableSpay;
    fixture.detectChanges();
    expect(component.paginatedTableData).toEqual(dataTableSpay);
  }));

  it('should navigate be called on redirectToCompanyRefBureau', () => {
    component.allTableData = mockSearchResult;
    component.tableColumns = mockTableColumns;
    component.getPaginatedItems({});
    component.redirectToCompanyRefBureau(mockSearchResult[0]);

    expect(router.navigate).toHaveBeenCalled();
  });
});
