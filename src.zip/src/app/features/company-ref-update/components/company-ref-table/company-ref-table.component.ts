import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TableColumn, PaginationModel } from '@shared/models/interfaces';
import * as _ from 'lodash';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { COMPANY_REF_BUREAU } from '@shared/consts/shared.consts';
import { Router } from '@angular/router';

@Component({
  selector: 'app-company-ref-table',
  templateUrl: './company-ref-table.component.html',
  styleUrls: ['./company-ref-table.component.scss'],
})
export class CompanyRefTableComponent implements OnInit {
  allTableDataRef: UwRefSearchRecords;
  paginatedTableData = [];
  totalCount: number;
  tableColumnsValue: TableColumn[];

  @Input() companyCode: string;
  @Input() companyReference: string;
  @Input() bureauSigningReference: string;

  @Input() set allTableData(allTableData: UwRefSearchRecords) {
    if (allTableData) {
      this.allTableDataRef = allTableData.slice(0, 2000);
      this.totalCount = allTableData?.length;
    }
  }

  @Input() set tableColumns(tableColumns: TableColumn[]) {
    if (tableColumns) {
      this.tableColumnsValue = tableColumns;
    }
  }

  constructor(private router: Router) {}

  ngOnInit(): void {}

  getPaginatedItems(event: PaginationModel): void {
    this.paginatedTableData = event.paginatedItems;
    const table = document.getElementById('divTable');
    if (table) {
      table.scrollTop = 0;
    }
  }

  redirectToCompanyRefBureau(companyRefData): void {
    const queryParams = {
      marketId: companyRefData?.marketId,
      marketSyndicateId: companyRefData?.marketSyndicateId,
      premiumId: companyRefData?.premiumId,
    };
    this.router.navigate([COMPANY_REF_BUREAU], { queryParams });
  }
}
