import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Params, Router } from '@angular/router';
import { CompanyRefBureauStoreService } from '@features/company-ref-update/services/company-ref-bureau.store';
import { COMPANY_REF_UPDATE } from '@shared/consts/shared.consts';
import { GlobalAlertStoreService } from '@shared/services/global-alert/global-alert.store.service';
import { Observable, Subject } from 'rxjs';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { TechnicianPortalBureauEnum, UwRefUpdateRecord } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { takeUntil } from 'rxjs/operators';
import { FormControls } from '@shared/models/interfaces';
import { getValueForCompanyNewRef } from '@features/company-ref-update/const/company-ref.helper';
import { SearchQueryRequest, PartyDetails } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { DXC_USER_TECHNICIAN, PARTY_TECHNICIAN } from '@shared/consts/party.const';
import { PartyStoreService } from '@shared/services/party/party.store.service';
import { Role } from '@shared/consts/shared.enums';

@Component({
  selector: 'app-company-ref-bureau-ilu',
  templateUrl: './company-ref-bureau-ilu.component.html',
  styleUrls: ['./company-ref-bureau-ilu.component.scss'],
})
export class CompanyRefBureauIluComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  technician = DXC_USER_TECHNICIAN;
  userPartyRole: SearchQueryRequest.RoleEnum;

  saveIluForm: FormGroup;
  ref1: string;
  responseData$: Observable<any>;
  formChanged = false;
  marketId: string;
  marketSyndicateId: string;
  premiumId: string;
  iluFormResponseRef: UwRefUpdateRecord;
  canEditSuppressed = false;
  isSuppressedChecked = false;
  @Input() etag: string;

  @Input() set role(roles: string[]) {
    this.roles = roles;
    this.updateSuppressionAccessibility();
  }
  get role(): string[] {
    return this.roles;
  }
  private roles: string[];

  @Input() set queryParams(params: Params) {
    this.globalAlertStoreService.clearGlobalResponse();
    if (params) {
      this.marketId = params?.marketId;
      this.marketSyndicateId = params?.marketSyndicateId;
      this.premiumId = params?.premiumId;
    }
  }

  @Input() set iluFormResponse(response: UwRefUpdateRecord) {
    if (response) {
      this.initSaveIluFormGroup();
      this.iluFormResponseRef = response;
      this.updateReferences();
      this.formChanged = false;
    }
  }

  get saveIluFormControls(): FormControls {
    return this.saveIluForm.controls;
  }

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private companyRefStoreService: CompanyRefBureauStoreService,
    private companyRefUpdateStoreService: CompanyRefUpdateStoreService,
    private globalAlertStoreService: GlobalAlertStoreService,
    private partyStoreService: PartyStoreService
  ) {}

  ngOnInit(): void {
    this.responseData$ = this.globalAlertStoreService.selectGlobalAlertResponse();
    this.initSaveIluFormGroup();
    this.initSaveIluFormValueChanges();
    this.getUserPartyRole();
  }

  /**
   * Initialize the reactive form group.
   */
  initSaveIluFormGroup(): void {
    this.saveIluForm = this.formBuilder.group({
      companyNewRef: [null, [Validators.maxLength(15)]],
    });
  }

  /**
   * Listen for any changes on the form to flag unsaved changes.
   */
  initSaveIluFormValueChanges(): void {
    this.saveIluForm.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.formChanged = true;
    });
  }

  /**
   * Update the disabled state of the "suppressed" control based on the user roles
   * and the party role. The control is enabled only if the user has the required
   * suppression edit role and is not a technician.
   */
  updateSuppressionAccessibility(): void {
    const hasSuppressionEditRole = this.role && this.role.includes(Role.PROCESS_LINE_SUPPRESSION_EDIT);
    this.canEditSuppressed = hasSuppressionEditRole;
  }

  /**
   * Update the suppressed form control when the checkbox value changes.
   * @param event The new checkbox value (true or false).
   */
  suppressedChanged(event: any): void {
    this.formChanged = true;
    const boolValue = event === 'on' || event === true; // Handle both cases
    this.isSuppressedChecked = boolValue;
  }

  /**
   * Navigate back to the new search screen.
   */
  onNewSearchClick(): void {
    this.companyRefUpdateStoreService.setSearchResult(null);
    this.router.navigate([COMPANY_REF_UPDATE]);
  }

  /**
   * Save the changes if the form is valid and has been modified.
   */
  saveChanges(): void {
    if (!this.formChanged) {
      return;
    }
    if (this.saveIluForm.valid) {
      this.companyRefStoreService.patchUwfCorrectionRecords(
        this.etag,
        this.iluFormResponseRef?.marketId,
        this.iluFormResponseRef?.marketSyndicateId,
        this.iluFormResponseRef?.premiumId,
        TechnicianPortalBureauEnum.ILU,
        this.getFilledFormValues()
      );
    }
  }

  /**
   * Prepare the form values for submission.
   */
  getFilledFormValues(): UwRefUpdateRecord {
    const filledValues: UwRefUpdateRecord = {};
    const companyNewRefValue = this.saveIluForm.get('companyNewRef').value;
    filledValues.syndicateReference = getValueForCompanyNewRef(
      companyNewRefValue,
      'companyNewRef',
      this.iluFormResponseRef
    );
    if (companyNewRefValue === '' || companyNewRefValue === null) {
      filledValues.syndicateReference = this.iluFormResponseRef?.syndicateReference;
    }
    filledValues.suppressed = this.isSuppressedChecked;
    return filledValues;
  }

  /**
   * Subscribe to the store to update references and form values.
   */
  updateReferences(): void {
    this.companyRefStoreService
      .getCompanyRefSelector()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data) => {
        this.ref1 = data?.syndicateReference;
        // Reset the Company New Reference field.
        this.saveIluForm.get('companyNewRef').setValue('');
        // Update the suppressed control value.
        this.suppressedChanged(data?.suppressed);
      });
  }

  /**
   * Retrieve the current user's party role and update suppression access.
   */
  getUserPartyRole(): void {
    this.partyStoreService.getPartyInfoOfUser();
    this.partyStoreService
      .selectPartyInfoOfUser()
      .pipe(takeUntil(this.destroy$))
      .subscribe((partyInfo: PartyDetails) => {
        if (partyInfo) {
          const partyUserRole = partyInfo.partyOrganisationRole;
          this.userPartyRole =
            partyUserRole.toUpperCase() === PARTY_TECHNICIAN
              ? SearchQueryRequest.RoleEnum.TECHNICIAN
              : SearchQueryRequest.RoleEnum[partyUserRole.toUpperCase()];
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
