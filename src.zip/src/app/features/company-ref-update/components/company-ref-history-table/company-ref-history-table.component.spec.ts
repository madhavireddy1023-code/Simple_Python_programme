import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CompanyRefHistoryTableComponent } from './company-ref-history-table.component';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { mockSearchResult, mockTableColumns } from '@features/company-ref-update/const/mockSearchResult.consts';
import { mockCompanyHistory } from '@features/company-ref-update/const/mockCompanyHistory.consts';

describe('CompanyRefTableComponent', () => {
  let component: CompanyRefHistoryTableComponent;
  let fixture: ComponentFixture<CompanyRefHistoryTableComponent>;
  const router = {
    navigate: jasmine.createSpy('navigate'),
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterModule.forRoot([]), RouterTestingModule.withRoutes([])],
      declarations: [CompanyRefHistoryTableComponent],
      providers: [{ provide: Router, useValue: router }, MockStore, provideMockStore()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRefHistoryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render CompanyRefUpdate data ', waitForAsync(() => {
    const dataTableSpay = mockSearchResult;
    component.paginatedTableData = dataTableSpay;
    fixture.detectChanges();
    expect(component.paginatedTableData).toEqual(dataTableSpay);
  }));

  it('should navigate be called on redirectToCompanyRefBureau', () => {
    component.allTableDataRef = mockCompanyHistory;
    component.tableColumnsValue = mockTableColumns;
    component.getPaginatedItems({});
    component.redirectToCompanyRefBureau(mockSearchResult[0]);

    expect(router.navigate).toHaveBeenCalled();
  });
});
