import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TableColumn, PaginationModel } from '@shared/models/interfaces';
import * as _ from 'lodash';
import { UwRefSearchRecords } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { COMPANY_REF_BUREAU } from '@shared/consts/shared.consts';
import { Router } from '@angular/router';
import { CompanyRefUpdateStoreService } from '@features/company-ref-update/services/company-ref-update.store.service';
import { UwRefCompanyHistory, UwRefCompanyHistoryRecords } from '@dxc.lm.sdk.angular/ipos-premium-domain-api';
import { sortTable } from 'src/app/utils/helper/helper';
import { ngDateFormatSmall } from 'src/app/utils/consts/timestamp-format.const';

@Component({
  selector: 'app-company-ref-history-table',
  templateUrl: './company-ref-history-table.component.html',
  styleUrls: ['./company-ref-history-table.component.scss'],
})
export class CompanyRefHistoryTableComponent implements OnInit {
  readonly dateFormat = ngDateFormatSmall;
  allTableDataRef: UwRefCompanyHistory;
  paginatedTableData = [];
  totalCount: number;
  tableColumnsValue: TableColumn[];
  tableDataCopy: UwRefCompanyHistory;

  @Input() set companyHistoryData(companyHistoryData: UwRefCompanyHistory) {
    if (companyHistoryData) {
      this.allTableDataRef = companyHistoryData.slice(0, 2000);
      this.tableDataCopy = _.cloneDeep(this.allTableDataRef);
      const sortParams = ['uwRefHistoryRecordNew', 'desc', 'amendedDate'];
      this.allTableDataRef = sortTable(sortParams, this.tableDataCopy);
      this.totalCount = companyHistoryData?.length;
    }
  }

  constructor(private router: Router, private companyRefUpdateStoreService: CompanyRefUpdateStoreService) {}

  ngOnInit(): void {}

  getPaginatedItems(event: PaginationModel): void {
    this.paginatedTableData = event.paginatedItems;
    const table = document.getElementById('divTable');
    if (table) {
      table.scrollTop = 0;
    }
  }

  redirectToCompanyRefBureau(companyRefData): void {
    const queryParams = {
      marketId: companyRefData?.marketId,
      marketSyndicateId: companyRefData?.marketSyndicateId,
      premiumId: companyRefData?.premiumId,
    };
    this.router.navigate([COMPANY_REF_BUREAU], { queryParams });
  }
}
