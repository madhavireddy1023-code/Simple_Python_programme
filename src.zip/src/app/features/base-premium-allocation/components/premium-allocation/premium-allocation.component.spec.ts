import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumAllocationComponent } from './premium-allocation.component';
import { FormBuilder, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import {
  DxcAccordionModule,
  DxcButtonModule,
  DxcSelectModule,
  DxcTableModule,
  DxcTextInputModule,
} from '@dxc-technology/halstack-angular';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { NaicReportingStoreService } from '@features/naic-reporting/services/naic-reporting-store.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { Subject, of } from 'rxjs';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { PaginationModel } from '@shared/models';
import { NaicPremiumAllocationTableColumns } from '@features/naic-reporting/const/naic-table-columns';
import { PremiumAllocationStoreService } from '@features/base-premium-allocation/services/premium-allocation-store.service';
import { mockPremiumAllocationTableData } from '@features/base-premium-allocation/const/mock-premium-allocation-data.const';
import {
  PremiumNaicUsslInfo,
  TypeOfField,
  TypeOfLlyodsPremiumsProcessor,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { REPORTING_STATUS_OPTIONS } from '@features/base-premium-allocation/const/naic-reporting-status.const';
import { SharedPremiumDataService } from '@features/section-details/services/shared-premium-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Actions } from '@ngrx/effects';
import { saveNaicslPremiumAllocationSuccess } from '@features/base-premium-allocation/store/actions/premium-allocation-base.action';
import { UppercaseDisplayPipe } from '@shared/pipes/uppercase.pipe';

class TestPremiumAllocationComponent extends PremiumAllocationComponent {
  protected openNJSplitPage(row: any, val: any): void {}
  getSavePayload(): PremiumNaicUsslInfo {
    return {
      premiumId: '123',
      transactionType: {},
      naicDetails: {
        naicRequired: true,
        naicInfoStatus: 'COMPLETE',
        naicCarriers: [
          {
            splitNumber: 0,
            reinsuredName: 'DXC technology',
            companyStatus: 'DXC',
            address: { state: 'Texas' },
            grossPremium: 100,
          },
        ],
      },
    };
  }
  fillPremiumNAICSL(): void {}
}

describe('PremiumAllocationComponent', () => {
  let component: TestPremiumAllocationComponent;
  let fixture: ComponentFixture<TestPremiumAllocationComponent>;
  let storeService: NaicReportingStoreService;
  let activatedRoute: ActivatedRoute;
  let premiumAllocationStoreService: PremiumAllocationStoreService;
  let sectionDetailsStoreService: SectionDetailsStoreService;
  let sharedPremiumDataService: SharedPremiumDataService;
  let translateService: TranslateService;
  let formBuilder: FormBuilder;
  let router: Router;
  let el: DebugElement;
  let actions$: Subject<any>;

  beforeEach(async () => {
    const storeServiceSpy = jasmine.createSpyObj('NaicReportingStoreService', ['']);
    actions$ = new Subject();
    const sectionDetailsStoreServiceSpy = jasmine.createSpyObj('SectionDetailsStoreService', ['selectPremiumData']);
    sectionDetailsStoreServiceSpy.selectPremiumData.and.returnValue(
      of({
        riskCode: 'ANM123',
        countryOfOrigin: {
          typeOfCountry: 'DE',
        },
        premiumId: '',
        grossPremium: 100,
      })
    );
    const premiumAllocationStoreServiceSpy = jasmine.createSpyObj('NaicReportingStoreService', [
      'getPremiumAllocatedRows',
      'deletePremiumRow',
      'clearData',
      'getNaicSLPremiumDetails',
      'getEtagForPremiumNaicSlDetails',
      'saveNaicSLPremiumAllocation',
      'selectPremiumNAICSLDetailsData',
      'addPremiumRow',
      'selectOriginalPremiumNAICSLDetailsData',
    ]);
    premiumAllocationStoreServiceSpy.selectOriginalPremiumNAICSLDetailsData.and.returnValue(
      of({
        premiumId: '123',
        transactionType: {},
        naicDetails: {
          naicRequired: true,
          naicInfoStatus: 'COMPLETE',
          naicCarriers: [
            {
              splitNumber: 0,
              reinsuredName: 'DXC technology',
              companyStatus: 'DXC',
              address: { state: 'Texas' },
              grossPremium: 100,
            },
          ],
        },
      })
    );
    premiumAllocationStoreServiceSpy.getPremiumAllocatedRows.and.returnValue(of(mockPremiumAllocationTableData));
    premiumAllocationStoreServiceSpy.selectPremiumNAICSLDetailsData.and.returnValue(
      of({
        naicDetails: {
          naicInfoStatus: 'INCOMPLETE',
          naicCarriers: [
            {
              splitNumber: 0,
              naicCode: '78388',
              reinsuredName: 'DXC technology',
              companyStatus: 'DXC',
              address: {},
              grossPremium: 100,
              uuid: '585d0c8c-141f-42ba-94b8-a20736709146',
            },
          ],
        },
        usSurplusLineDetails: {
          usSurplusInfoStatus: 'COMPLETE',
          usSurplusLineBrokers: [
            {
              address: { line1: '31 Hicking building Alfreton road ' },
              companyName: 'ABC PRIVATE LTD',
              grossPremium: 100,
              licenseNumber: '12345',
              splitNumber: 0,
              stateOfLicence: {
                refTypeCountrySubDivisionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                typeOfCountrySubDivision: 'US-MI',
              },
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            },
          ],
        },
      })
    );

    await TestBed.configureTestingModule({
      declarations: [TestPremiumAllocationComponent, UppercaseDisplayPipe],
      imports: [
        ReactiveFormsModule,
        TranslateModule.forRoot(),
        DxcSelectModule,
        DxcTextInputModule,
        DxcTableModule,
        DxcButtonModule,
        DxcAccordionModule,
      ],
      providers: [
        { provide: FormBuilder, useValue: new FormBuilder() },
        MockStore,
        provideMockStore(),
        { provide: SectionDetailsStoreService, useValue: sectionDetailsStoreServiceSpy },
        {
          provide: Router,
          useValue: {
            navigateByUrl: jasmine.createSpy('navigateByUrl'),
          },
        },
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: of({ transactionType: 'ORIGINAL_PREMIUM', premiumId: '123', transactionStatus: 'true' }),
          },
        },
        { provide: Actions, useValue: actions$ },
        SharedPremiumDataService,
        { provide: NaicReportingStoreService, useValue: storeServiceSpy },
        { provide: 'any', useValue: storeServiceSpy },
        { provide: PremiumAllocationStoreService, useValue: premiumAllocationStoreServiceSpy },
        TranslateService,
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestPremiumAllocationComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    formBuilder = TestBed.inject(FormBuilder);
    sectionDetailsStoreService = TestBed.inject(SectionDetailsStoreService);
    component.premiumForm = formBuilder.group({
      grossPremium: formBuilder.array([]),
      total: '',
    });
    actions$.next(
      saveNaicslPremiumAllocationSuccess({
        saveNaicSlPremiumAllocationResponse: {},
      })
    );

    storeService = TestBed.inject(NaicReportingStoreService);
    router = TestBed.inject(Router);
    activatedRoute = TestBed.inject(ActivatedRoute);
    sharedPremiumDataService = TestBed.inject(SharedPremiumDataService);
    premiumAllocationStoreService = TestBed.inject(PremiumAllocationStoreService);
    translateService = TestBed.inject(TranslateService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize tableColumns correctly', () => {
    component.premiumAllocationTableColumns = NaicPremiumAllocationTableColumns;
    component.setUpTableColumns();

    expect(component.tableColumns).toEqual([
      {
        id: 1,
        key: 'splitNo',
        label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.SPLIT_NO',
        value: '',
      },
      {
        id: 2,
        label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.CODE_TYPE',
        key: 'codeType',
        value: '',
      },
      {
        id: 3,
        label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.CODE',
        key: 'code',
        value: '',
      },
      {
        id: 4,
        label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.REINSURED_NAME',
        key: 'reinsuredName',
        value: '',
      },
      {
        id: 5,
        label: 'NAIC_REPORTING.PREMIUM_ALLOCATION_TABLE.GROSS_PREMIUM',
        key: 'grossPremium',
        value: '',
      },
      {
        id: 6,
        label: '',
        key: 'remove',
        value: '',
      },
    ]);
  });

  it('should return premiumForm controls', () => {
    const controls = component.premiumFormControls;
    expect(controls).toBeTruthy();
    expect(controls.grossPremium).toBeDefined();
    expect(controls.total).toBeDefined();
  });

  it('should delete premium row and update all table data by ID', () => {
    const index = 1;
    const row = mockPremiumAllocationTableData[0];
    const mockFormArray = formBuilder.array([
      new FormControl({ 0: '100' }),
      new FormControl({ 1: '20' }),
      new FormControl({ 2: '100.00' }),
    ]);
    component.premiumForm = formBuilder.group({
      grossPremium: mockFormArray,
      surplusLinesReporting: '',
      reportingStatus: REPORTING_STATUS_OPTIONS[0],
    });

    component.onDeleteClick(row.id, index);

    expect(premiumAllocationStoreService.deletePremiumRow).toHaveBeenCalledWith('1');
  });

  it('should set tableData on getPremiumAllocatedRows', () => {
    const mockPremiumData = mockPremiumAllocationTableData;

    component.getPremiumAllocatedRows();

    expect(component.tableData).toEqual(mockPremiumData);
  });

  it('should set gross premium from premium data', () => {
    component.ngOnInit();
    expect(component.grossPremium).toEqual(100);
  });

  it('should set totalPremiumAllocationMsg to Under allocated if sum is 0', () => {
    spyOn(component, 'calculateSumOfPremiums').and.returnValue(0);

    component.updateTotalGrossPremium();

    expect(component.totalPremiumAllocationMsg).toBe(
      'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.UNDER_ALLOCATED'
    );
  });

  it('should set totalPremiumAllocationMsg to FULLY_ALLOCATED if sum equals grossPremium', () => {
    const mockSum = 100;
    const mockGrossPremium = 100;
    spyOn(component, 'calculateSumOfPremiums').and.returnValue(mockSum);
    component.grossPremium = mockGrossPremium;

    component.updateTotalGrossPremium();

    expect(component.totalPremiumAllocationMsg).toBe(
      'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.FULLY_ALLOCATED'
    );
  });

  it('should remove control at specified index', () => {
    const index = 1;
    const mockRow = mockPremiumAllocationTableData[0];
    const mockFormArray = formBuilder.array([
      new FormControl({ 0: '10' }),
      new FormControl({ 1: '20' }),
      new FormControl({ 2: '11' }),
    ]);
    component.premiumForm = formBuilder.group({
      grossPremium: mockFormArray,
    });
    component.onDeleteClick(mockRow.id, index);

    expect(mockFormArray.controls.length).toEqual(2);
  });

  it('should set paginated table data and scroll to top', () => {
    const mockEvent: PaginationModel = { paginatedItems: [] };
    const mockTableElement = document.createElement('div');
    spyOn(document, 'getElementById').and.returnValue(mockTableElement);

    component.getPaginatedItems(mockEvent);

    expect(component.paginatedTableData).toBe(mockEvent.paginatedItems);
    expect(document.getElementById).toHaveBeenCalledWith('divTable');
    expect(mockTableElement.scrollTop).toBe(0);
  });

  it('should instalmentDetailsForm to be invalid form  when netAmount value is zero', () => {
    component.getPremiumAllocatedRows();
    const controls = component.grossPremiumFormArray.controls;

    controls[0].setValue('0');
    expect(component.premiumForm.invalid).toBeTruthy();
    expect(controls[0].hasError('zeroValue')).toBeTruthy();

    controls[0].setValue('0.0');
    expect(component.premiumForm.invalid).toBeTruthy();
    expect(controls[0].hasError('zeroValue')).toBeTruthy();

    controls[0].setValue('10');
    expect(component.premiumForm.invalid).toBeFalsy();
    expect(controls[0]?.errors).toBeNull();
  });

  it('should set isDialogOpen to true when calling navBack()', () => {
    component.isDialogOpen = false;
    component.navBack();
    expect(component.isDialogOpen).toBe(true);
  });

  it('should set isDialogOpen to false when calling closeCancelDialog()', () => {
    component.isDialogOpen = true;
    component.closeCancelDialog();
    expect(component.isDialogOpen).toBe(false);
  });

  it('should set isDialogOpen to true when calling submit()', () => {
    const control = new FormControl('');
    control.setErrors({ required: true });
    component.controlsById = { 'mock-key': control };
    component.submit();
    fixture.detectChanges();

    expect(component.isGrossPremiumDialogOpen).toBe(true);
  });

  it('should set isGrossPremiumDialogOpen to false when calling closeCancelDialog()', () => {
    component.isGrossPremiumDialogOpen = true;
    component.closeCancelDialog();
    expect(component.isGrossPremiumDialogOpen).toBe(false);
  });

  it('should make controls empty when confirmRemoveEmptyGrossPremiums() is called', () => {
    const mockControlsById: { [key: string]: FormControl } = {
      1: new FormControl('', Validators.required),
      2: new FormControl('20', Validators.required),
    };

    component.controlsById = mockControlsById;
    component.confirmRemoveEmptyGrossPremiums();

    expect(premiumAllocationStoreService.deletePremiumRow).toHaveBeenCalledWith('1');
    expect(component.isGrossPremiumDialogOpen).toBe(false);
  });

  it('should navigate to the previous URL when calling confirmCancel()', () => {
    spyOn(sharedPremiumDataService, 'getPreviousUrl').and.returnValue('/previous-url');

    component.confirmCancel();

    expect(router.navigateByUrl).toHaveBeenCalledWith('/previous-url');
  });

  it('should call saveNaicSLPremiumAllocation with correct parameters', () => {
    component.premiumData = { premiumId: '123', transactionType: {} };
    component.premiumAllocationType = TypeOfField.NAIC;
    component.controlsById = {
      1: new FormControl(100),
    };
    component.tableData = [
      {
        reinsuredName: 'DXC technology',
        companyStatus: 'DXC',
        address: {
          state: {
            subDivisionName: 'Texas',
          },
        },
        id: '1',
        codeType: 'NAIC',
      },
    ];
    spyOn(component, 'getEtag').and.returnValue('1');
    component.premiumForm = {
      controls: {
        reportingStatus: { value: 'COMPLETE' },
      },
    } as any;
    component.typeOfPremium = 'Original_Premium';
    const etag = '1';

    component.submit();

    const expectedPayload: PremiumNaicUsslInfo = {
      premiumId: '123',
      transactionType: {},
      naicDetails: {
        naicRequired: true,
        naicInfoStatus: 'COMPLETE',
        naicCarriers: [
          {
            splitNumber: 0,
            reinsuredName: 'DXC technology',
            companyStatus: 'DXC',
            address: { state: 'Texas' },
            grossPremium: 100,
          },
        ],
      },
    };
    expect(premiumAllocationStoreService.saveNaicSLPremiumAllocation).toHaveBeenCalledWith(
      etag,
      '123',
      TypeOfLlyodsPremiumsProcessor.OriginalPremium,
      TypeOfField.NAIC,
      expectedPayload,
      false
    );
  });

  it('should set typeOfPremium correctly when calling getTypeOfPremium()', () => {
    component.subscribeToParams();

    expect(component.typeOfPremium).toBe('ORIGINAL_PREMIUM');
  });

  it('should call getNaicSLPremiumDetails with correct parameters when calling getPremiumNaicSlDetails()', () => {
    component.premiumData = { premiumId: '123' };
    component.premiumAllocationType = TypeOfField.NAIC;

    component.getPremiumNaicSlDetails();

    expect(premiumAllocationStoreService.getNaicSLPremiumDetails).toHaveBeenCalledWith(
      '123',
      'ORIGINAL_PREMIUM',
      'NAIC'
    );
  });

  it('should call saveNaicSLPremiumAllocation with correct parameters in surplus', () => {
    component.getSavePayload = () => {
      return {
        premiumId: '123',
        transactionType: {},
        usSurplusLineDetails: {
          usSurplusLineRequired: true,
          usSurplusInfoStatus: 'COMPLETE',
          usSurplusLineBrokers: [
            {
              companyName: 'ABC PRIVATE LTD',
              grossPremium: 100,
              licenseNumber: '12345',
              splitNumber: 0,
              stateOfLicence: {
                refTypeCountrySubDivisionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                typeOfCountrySubDivision: 'US-MI',
              },
              address: { line1: '31 Hicking building Alfreton road' },
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            },
          ],
        },
      };
    };
    component.premiumData = { premiumId: '123', transactionType: {} };
    component.premiumAllocationType = TypeOfField.USSL;
    component.controlsById = {
      1: new FormControl(100),
    };
    component.tableData = [
      {
        address: '31 Hicking building Alfreton road ',
        companyName: 'ABC PRIVATE LTD',
        grossPremium: '',
        id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        licenseNumber: '12345',
      },
    ];
    spyOn(component, 'getEtag').and.returnValue('1');
    component.premiumForm = {
      controls: {
        reportingStatus: { value: 'COMPLETE' },
      },
    } as any;
    component.typeOfPremium = 'Original_Premium';
    const etag = '1';
    component.submit();
    const expectedPayload: PremiumNaicUsslInfo = {
      premiumId: '123',
      transactionType: {},
      usSurplusLineDetails: {
        usSurplusLineRequired: true,
        usSurplusInfoStatus: 'COMPLETE',
        usSurplusLineBrokers: [
          {
            companyName: 'ABC PRIVATE LTD',
            grossPremium: 100,
            licenseNumber: '12345',
            splitNumber: 0,
            stateOfLicence: {
              refTypeCountrySubDivisionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              typeOfCountrySubDivision: 'US-MI',
            },
            address: { line1: '31 Hicking building Alfreton road' },
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          },
        ],
      },
    };
    expect(premiumAllocationStoreService.saveNaicSLPremiumAllocation).toHaveBeenCalledWith(
      etag,
      '123',
      TypeOfLlyodsPremiumsProcessor.OriginalPremium,
      TypeOfField.USSL,
      expectedPayload,
      false
    );
  });

  it('should set signedTransactionStatus correctly when calling getTypeOfPremium()', () => {
    component.subscribeToParams();
    expect(component.signedTransactionStatus).toEqual(true);
  });

  it('should set reportingStatus and call fillPremiumNAICSL for NAIC type', () => {
    component.premiumAllocationType = 'NAIC';
    component.selectNAICSLDetailsData();
    expect(premiumAllocationStoreService.selectPremiumNAICSLDetailsData).toHaveBeenCalled();
    expect(component.premiumForm.controls.reportingStatus.value).toEqual('INCOMPLETE');
  });

  it('should set reportingStatus and call fillPremiumNAICSL for surplus type', () => {
    component.premiumAllocationType = 'USSL';
    component.selectNAICSLDetailsData();
    expect(premiumAllocationStoreService.selectPremiumNAICSLDetailsData).toHaveBeenCalled();
    expect(component.premiumForm.controls.reportingStatus.value).toEqual('COMPLETE');
  });

  it('should show instantly validation message that isn’t required', () => {
    const formControl = new FormControl('');
    formControl.setErrors({ required: true });

    const isRequiredValidation = component.getValidationInputStatus(formControl, null, '12345');

    expect(isRequiredValidation).toBeFalsy();
  });
  it('should set reportingStatus to null when the grossPremium has no value', () => {
    spyOn(component, 'showPremiumAllocationIncompleteStatusWarning').and.returnValue(false);
    spyOn(component, 'getEtag').and.returnValue('1');
    component.premiumForm = formBuilder.group({
      grossPremium: formBuilder.array([]),
      reportingStatus: new FormControl(REPORTING_STATUS_OPTIONS[1].value),
    });
    component.submit();
    expect(component.premiumForm.get('reportingStatus').value).toEqual(REPORTING_STATUS_OPTIONS[0].value);
  });
});
