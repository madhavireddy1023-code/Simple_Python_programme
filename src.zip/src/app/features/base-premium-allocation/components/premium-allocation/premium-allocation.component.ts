import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Inject,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors } from '@angular/forms';
import { DxcTextInputComponent, DxcTextareaComponent } from '@dxc-technology/halstack-angular';
import { REPORTING_STATUS_OPTIONS } from '@features/base-premium-allocation/const/naic-reporting-status.const';
import { ActivatedRoute, Router } from '@angular/router';
import { PremiumAllocationStoreService } from '@features/base-premium-allocation/services/premium-allocation-store.service';
import { NaicReportingStoreService } from '@features/naic-reporting/services/naic-reporting-store.service';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { SharedPremiumDataService } from '@features/section-details/services/shared-premium-data.service';
import { SurplusLinesStoreService } from '@features/surplus-lines/services/surplus-lines.store.service';
import { TranslateService } from '@ngx-translate/core';
import { INPUT_TYPES } from '@shared/consts/shared.enums';
import { FormControls, PaginationModel, TableColumn } from '@shared/models';
import { Subject, Subscription } from 'rxjs';
import { map, take, takeUntil } from 'rxjs/operators';
import { Location } from '@angular/common';
import {
  NaicSlReportingStatus,
  PremiumNaicUsslInfo,
  TypeOfField,
  TypeOfLlyodsPremiumsProcessor,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { ValidationInputStatus, nonZero } from 'src/app/utils';
import { ORIGINAL_PREMIUM } from '@shared/consts/shared.consts';
import { Actions, ofType } from '@ngrx/effects';
import { saveNaicslPremiumAllocationSuccess } from '@features/base-premium-allocation/store/actions/premium-allocation-base.action';

@Component({
  template: '',
})
export abstract class PremiumAllocationComponent implements OnInit, OnChanges, OnDestroy {
  protected readonly destroy$ = new Subject<void>();
  storeService: NaicReportingStoreService | SurplusLinesStoreService;
  readonly inputTypes = INPUT_TYPES;
  TypeOfField = TypeOfField;
  options = REPORTING_STATUS_OPTIONS;
  tableColumns: TableColumn[];
  tableData: any[] = [];
  premiumAllocationTableColumns: {
    id: number;
    key: string;
    label: string;
    value: string;
  }[] = [];
  paginatedTableData: any;
  premiumForm: FormGroup;
  controlsById: { [key: string]: FormControl } = {};
  formArraySubscription: Subscription;
  premiumAllocationType!: TypeOfField;
  grossPremium: number;
  isDialogOpen = false;
  isGrossPremiumDialogOpen = false;
  newJerseyPremiumRowLicenseNo: string | null = null;

  naicSurplusWarningMessage = {
    naic: {
      title: 'NAIC_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.TITLE',
      description: 'NAIC_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.DESCRIPTION',
      continueButtonName: 'NAIC_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.CONTINUE',
      cancelButtonName: 'NAIC_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.CANCEL',
    },
    surplus: {
      title: 'SURPLUS_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.TITLE',
      description: 'SURPLUS_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.DESCRIPTION',
      continueButtonName: 'SURPLUS_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.CONTINUE',
      cancelButtonName: 'SURPLUS_REPORTING.PREMIUM_ALLOCATION.CANCEL_WARNING_MESSAGE.CANCEL',
    },
  };

  grossPremiumAmountsEmptyWarning = {
    title: 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.GROSS_PREMIUM_EMPTY_WARNING.TITLE',
    description: 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.GROSS_PREMIUM_EMPTY_WARNING.DESCRIPTION',
    continueButtonName: 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.GROSS_PREMIUM_EMPTY_WARNING.CONTINUE',
    cancelButtonName: 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.GROSS_PREMIUM_EMPTY_WARNING.CANCEL',
  };

  premiumAllocationIncompleteWarning = {
    title: 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.PREMIUM_ALLOCATION_INCOMPLETE_WARNING.TITLE',
    description:
      'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.PREMIUM_ALLOCATION_INCOMPLETE_WARNING.USSL_DESCRIPTION',
    saveButtonName: 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.PREMIUM_ALLOCATION_INCOMPLETE_WARNING.SAVE',
    cancelButtonName: 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.PREMIUM_ALLOCATION_INCOMPLETE_WARNING.CANCEL',
  };

  premiumData: any;
  isAllocationMessageSuccess: boolean;
  totalPremiumAllocationMsg = '';
  customErrorMsg: boolean;
  saveBtnClicked = false;
  typeOfPremium: TypeOfLlyodsPremiumsProcessor = ORIGINAL_PREMIUM;
  NaicSlReportingStatus = NaicSlReportingStatus;
  premiumId: string;
  signedTransactionStatus: boolean;
  isControlsDisabled: boolean;
  originalPremiumId: string;
  isInitialDataLoaded: boolean;
  incompleteWarningdialogOpen = false;
  premiumNaicSlData: PremiumNaicUsslInfo;
  @Input() originalPremiumClicked: boolean;
  @Output() emitOriginalPremiumStatus = new EventEmitter<boolean>();

  protected abstract getSavePayload(): PremiumNaicUsslInfo;
  protected abstract fillPremiumNAICSL(naicOrSlData): void;
  protected abstract openNJSplitPage(row: any, val: any): void;

  constructor(
    protected formBuilder: FormBuilder,
    @Inject('any') storeService: NaicReportingStoreService | SurplusLinesStoreService,
    protected sectionDetailsStoreService: SectionDetailsStoreService,
    protected translate: TranslateService,
    protected premiumAllocationStoreService: PremiumAllocationStoreService,
    protected route: ActivatedRoute,
    protected router: Router,
    protected sharedPremiumDataService: SharedPremiumDataService,
    protected location: Location,
    protected cdr: ChangeDetectorRef,
    protected actions$: Actions
  ) {
    this.storeService = storeService;
    this.actions$
      .pipe(
        ofType(saveNaicslPremiumAllocationSuccess),
        map((action) => {
          this.formArraySubscription = this.grossPremiumFormArray?.statusChanges.subscribe((value) => {
            // only subscribe to formArray after successful GET response and initial data is loaded
            if (this.isInitialDataLoaded) {
              this.checkReportingStatus();
              this.updateTotalGrossPremium();
            }
          });
        })
      )
      .subscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.originalPremiumClicked && this.typeOfPremium !== TypeOfLlyodsPremiumsProcessor.OriginalPremium) {
      this.premiumAllocationStoreService.getOriginalPremiumDetails(
        this.originalPremiumId,
        ORIGINAL_PREMIUM,
        this.premiumAllocationType
      );
    }
  }

  ngOnInit(): void {
    this.setUpTableColumns();
    this.premiumForm = this.formBuilder.group({
      grossPremium: this.formBuilder.array([]), // Initialize with an empty array
      total: [{ value: this.grossPremium, disabled: true }],
      reportingStatus: REPORTING_STATUS_OPTIONS[0].value,
    });

    // subscribe to data
    this.selectPremiumData();
    this.subscribeToParams();
    this.selectNAICSLDetailsData();
    this.selectOriginalPremiumDetails();
  }

  setUpTableColumns(): void {
    this.tableColumns = [...this.premiumAllocationTableColumns];
  }

  // subscribe
  selectPremiumData(): void {
    this.sectionDetailsStoreService
      .selectPremiumData()
      .pipe(takeUntil(this.destroy$))
      .subscribe((premiumData) => {
        if (premiumData) {
          this.premiumData = premiumData;
          this.grossPremium = premiumData?.grossPremium;
          this.originalPremiumId = premiumData?.originalPremiumId;
          this.premiumForm.controls.total.setValue(this.grossPremium);

          this.getPremiumAllocatedRows();
        }
      });
  }

  subscribeToParams(): void {
    this.route.queryParams.subscribe((params) => {
      this.typeOfPremium = params?.transactionType;
      this.premiumId = params?.premiumId;
      const transactionStatusValue = params?.transactionStatus;
      this.signedTransactionStatus = this.convertToBoolean(transactionStatusValue);
      this.getPremiumNaicSlDetails();
    });
  }

  getPremiumNaicSlDetails(): void {
    this.premiumAllocationStoreService.getNaicSLPremiumDetails(
      this.premiumId,
      this.typeOfPremium,
      this.premiumAllocationType
    );
  }

  selectNAICSLDetailsData(): void {
    this.premiumAllocationStoreService
      .selectPremiumNAICSLDetailsData()
      .pipe(takeUntil(this.destroy$))
      .subscribe((response) => {
        const premiumNAICSLData: PremiumNaicUsslInfo = response;
        this.premiumNaicSlData = premiumNAICSLData;
        if (premiumNAICSLData) {
          if (Object.keys(premiumNAICSLData).length) {
            if (this.premiumAllocationType === TypeOfField.NAIC) {
              this.premiumForm.controls.reportingStatus.setValue(premiumNAICSLData?.naicDetails?.naicInfoStatus);
              this.checkIsControlsDisabled(premiumNAICSLData?.naicDetails?.naicInfoStatus);
              this.fillPremiumNAICSL(premiumNAICSLData?.naicDetails?.naicCarriers);
            } else if (this.premiumAllocationType === TypeOfField.USSL) {
              this.premiumForm.controls.reportingStatus.setValue(
                premiumNAICSLData?.usSurplusLineDetails?.usSurplusInfoStatus
              );
              this.checkIsControlsDisabled(premiumNAICSLData?.usSurplusLineDetails?.usSurplusInfoStatus);
              this.fillPremiumNAICSL(premiumNAICSLData?.usSurplusLineDetails?.usSurplusLineBrokers);
            }
          }
        }
        this.updateTotalGrossPremium();
      });
  }

  selectOriginalPremiumDetails(): void {
    this.premiumAllocationStoreService
      .selectOriginalPremiumNAICSLDetailsData()
      .pipe(takeUntil(this.destroy$))
      .subscribe((response: PremiumNaicUsslInfo) => {
        const originalPremiumNAICSLData = response;
        if (Object.keys(originalPremiumNAICSLData).length) {
          const naicCarriersNullGross = this.mapNullGrossPremium(originalPremiumNAICSLData?.naicDetails?.naicCarriers);
          const usSurplusLineBrokersNullGross = this.mapNullGrossPremium(
            originalPremiumNAICSLData?.usSurplusLineDetails?.usSurplusLineBrokers
          );

          if (this.premiumAllocationType === TypeOfField.NAIC) {
            if (originalPremiumNAICSLData?.naicDetails?.naicInfoStatus === NaicSlReportingStatus.COMPLETE) {
              this.emitOriginalPremiumStatus.emit(false);
              this.fillPremiumNAICSL(naicCarriersNullGross);
            } else {
              this.emitOriginalPremiumStatus.emit(true);
            }
          } else if (this.premiumAllocationType === TypeOfField.USSL) {
            if (
              originalPremiumNAICSLData?.usSurplusLineDetails?.usSurplusInfoStatus === NaicSlReportingStatus.COMPLETE
            ) {
              this.emitOriginalPremiumStatus.emit(false);
              this.fillPremiumNAICSL(usSurplusLineBrokersNullGross);
            } else {
              this.emitOriginalPremiumStatus.emit(true);
            }
          }
        }
      });
  }

  getPremiumAllocatedRows(): void {
    this.premiumAllocationStoreService
      .getPremiumAllocatedRows()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any[]) => {
        this.tableData = data;
        this.cdr.detectChanges();

        if (this.tableData.length) {
          this.updateGrossPremiumArray();
          this.updateTotalGrossPremium();
          this.isInitialDataLoaded = true;
        }
      });
  }

  updateGrossPremiumArray(): void {
    const grossPremiumArray = this.premiumForm.get('grossPremium') as FormArray;

    const arrayControls: { name: string; value: any; validators: any[] }[] = [];
    this.tableData.forEach((item) => {
      if (!this.controlsById[item.code || item?.licenseNumber]) {
        arrayControls.push({
          name: item.code || item?.licenseNumber,
          value: item.grossPremium ? item.grossPremium : '',
          validators: nonZero(1, 20, true),
        });
      }
    });

    // Loop through the initial controls and add them to the FormArray
    arrayControls.forEach((control) => {
      const controlInstance = this.formBuilder.control(control.value, control.validators);
      grossPremiumArray.push(controlInstance);
      this.controlsById[control.name] = controlInstance; // add to controls by ID for referencing
    });
  }

  grossPremiumValueChanges(index: number): void {
    const formControl = this.grossPremiumFormArray.at(index);
    const totalValue = this.premiumFormControls?.total.value;
    const grossPremiumValue = formControl?.value;

    if (grossPremiumValue > totalValue) {
      this.customErrorMsg = true;
      formControl.setErrors({ grossPremiumGreaterThanTotal: 'Must not be more than the gross premium' });
      formControl.markAsTouched();
    } else {
      this.customErrorMsg = false;
    }
  }

  updateTotalGrossPremium(): void {
    const sum = this.calculateSumOfPremiums();
    switch (true) {
      case sum === 0:
        this.isAllocationMessageSuccess = false;
        this.totalPremiumAllocationMsg = this.translate.instant(
          'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.UNDER_ALLOCATED'
        );
        break;
      case sum === this.grossPremium:
        this.isAllocationMessageSuccess = true;
        this.totalPremiumAllocationMsg = this.translate.instant(
          'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.FULLY_ALLOCATED'
        );
        break;
      case sum > this.grossPremium:
        this.isAllocationMessageSuccess = false;
        this.totalPremiumAllocationMsg = this.translate.instant(
          'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.OVER_ALLOCATED'
        );
        break;
      case sum < this.grossPremium:
        this.isAllocationMessageSuccess = false;
        this.totalPremiumAllocationMsg = this.translate.instant(
          'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.UNDER_ALLOCATED'
        );
        break;
      default:
        this.isAllocationMessageSuccess = false;
        this.totalPremiumAllocationMsg = this.translate.instant(
          'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.UNDER_ALLOCATED'
        );
        break;
    }
  }

  calculateSumOfPremiums(): number {
    let sum = 0;
    this.grossPremiumFormArray?.controls.forEach((control) => {
      const value = control.value;
      const parsedValue = parseFloat(value);
      if (!isNaN(parsedValue)) {
        sum += parsedValue;
      }
    });
    return sum;
  }

  getPaginatedItems(event: PaginationModel): void {
    this.paginatedTableData = event.paginatedItems;
    const table = document.getElementById('divTable');
    if (table) {
      table.scrollTop = 0;
    }
  }

  onDeleteClick(code: string, index: number): void {
    if (this.grossPremiumFormArray?.controls?.length > index) {
      this.premiumAllocationStoreService.deletePremiumRow(code);
      this.grossPremiumFormArray.removeAt(index); // remove control at index
      delete this.controlsById[code];
    }
  }

  checkReportingStatus(): void {
    const sum = this.calculateSumOfPremiums();
    if (this.grossPremium && sum !== this.grossPremium) {
      const completeValue = REPORTING_STATUS_OPTIONS[4].value;
      const incompleteValue = REPORTING_STATUS_OPTIONS[0].value;
      if (this.premiumFormControls.reportingStatus?.value === completeValue) {
        this.premiumForm.controls.reportingStatus.setValue(incompleteValue);
      }
    }
  }

  navBack(): void {
    this.isDialogOpen = true;
  }

  closeCancelDialog(): void {
    this.isDialogOpen = false;
    this.isGrossPremiumDialogOpen = false;
    this.incompleteWarningdialogOpen = false;
  }

  confirmCancel(): void {
    const url = this.sharedPremiumDataService.getPreviousUrl();
    url ? this.router.navigateByUrl(url) : this.location.back();
  }

  confirmRemoveEmptyGrossPremiums(): void {
    Object.entries(this.controlsById).forEach(([key, control]) => {
      // renewing index due to delete function index needs to be updated
      const index = Object.entries(this.controlsById).findIndex(([k, _]) => k === key);
      if (control.errors?.required) {
        this.onDeleteClick(key, index);
      }
    });
    this.isGrossPremiumDialogOpen = false;
  }

  openNjSplitPage(row: any, val: string): void {
    this.newJerseyPremiumRowLicenseNo = row?.licenseNumber;
    this.openNJSplitPage(row, val);
  }

  submit(): void {
    this.saveBtnClicked = true;

    for (const control of Object.values(this.controlsById)) {
      if (control.errors?.required) {
        this.isGrossPremiumDialogOpen = true;
        return;
      }
    }
    const shouldShowWarning = this.showPremiumAllocationIncompleteStatusWarning();

    if (shouldShowWarning) {
      return;
    }

    if (this.premiumForm?.invalid) {
      return;
    }
    if (this.premiumForm?.value?.grossPremium?.length === 0) {
      this.premiumForm.get('reportingStatus').setValue(REPORTING_STATUS_OPTIONS[0].value);
    }
    this.savePremiumData(false);
  }

  showPremiumAllocationIncompleteStatusWarning(): boolean {
    this.premiumAllocationIncompleteWarning.description =
      this.premiumAllocationType === TypeOfField.NAIC
        ? 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.PREMIUM_ALLOCATION_INCOMPLETE_WARNING.NAIC_DESCRIPTION'
        : 'NAIC_AND_SURPLUS_SHARED.PREMIUM_ALLOCATION_TABLE.PREMIUM_ALLOCATION_INCOMPLETE_WARNING.USSL_DESCRIPTION';
    if (
      this.signedTransactionStatus &&
      this.premiumForm.controls.reportingStatus.value !== REPORTING_STATUS_OPTIONS[4].value
    ) {
      this.incompleteWarningdialogOpen = true;
      return true;
    }
    return false;
  }

  savePremiumData(isSaveForNewJerseyPremium: boolean): void {
    const premiumId = this.premiumData?.premiumId;
    const etag = this.getEtag();
    const payload = this.getSavePayload();

    this.premiumAllocationStoreService.saveNaicSLPremiumAllocation(
      etag,
      premiumId,
      this.typeOfPremium,
      this.premiumAllocationType,
      payload,
      isSaveForNewJerseyPremium
    );
  }

  confirmSave(): void {
    this.incompleteWarningdialogOpen = false;
    this.savePremiumData(false);
  }

  getEtag(): string {
    let etag = '';
    this.premiumAllocationStoreService
      .getEtagForPremiumNaicSlDetails()
      .pipe(take(1))
      .subscribe((val: string) => {
        etag = val;
      });
    return etag;
  }

  checkIsControlsDisabled(reportingStatus: string): void {
    if (this.signedTransactionStatus && reportingStatus === NaicSlReportingStatus.COMPLETE) {
      this.isControlsDisabled = true;
      return;
    }

    this.isControlsDisabled = false;
  }

  // helpers
  get premiumFormControls(): FormControls {
    return this.premiumForm?.controls;
  }

  get grossPremiumFormArray(): FormArray {
    return this.premiumForm?.get('grossPremium') as FormArray;
  }

  get isCompleteOptionDisabled(): boolean {
    const sum = this.calculateSumOfPremiums();
    if (sum === this.grossPremium) {
      return false;
    }

    return true;
  }

  getValidationInputStatus(
    formControl: FormControl,
    input: DxcTextInputComponent | DxcTextareaComponent,
    licenseNumber: string
  ): boolean | ValidationErrors | null {
    const isRequired = formControl?.errors?.required;
    if (!isRequired) {
      return ValidationInputStatus(true, formControl, input);
    }

    if (this.saveBtnClicked || this.newJerseyPremiumRowLicenseNo === licenseNumber) {
      return ValidationInputStatus(true, formControl, input);
    }
    return null; // Do not show validation for rows that are not clicked unless form is submitted
  }

  translateText(value: string): string {
    const translationTextGroup =
      this.premiumAllocationType === TypeOfField.USSL ? 'SURPLUS_REPORTING' : 'NAIC_REPORTING';
    return this.translate.instant(`${translationTextGroup}.${value}`);
  }

  private mapNullGrossPremium(premiumArray: any[]): any[] {
    return (
      premiumArray?.map((premium) => ({
        ...premium,
        grossPremium: '',
      })) || []
    );
  }

  private convertToBoolean(value: string): boolean {
    return value === 'True' || value === 'true';
  }

  ngOnDestroy(): void {
    if (this.formArraySubscription) {
      this.formArraySubscription.unsubscribe();
    }
    this.destroy$.next();
    this.destroy$.complete();
  }
}
