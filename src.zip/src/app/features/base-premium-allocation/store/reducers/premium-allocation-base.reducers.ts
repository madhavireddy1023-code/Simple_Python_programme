import { Action, ActionReducer, createReducer, on } from '@ngrx/store';
import {
  addPremiumRow,
  clearData,
  deletePremiumRow,
  saveNaicslPremiumAllocation,
  saveNaicslPremiumAllocationSuccess,
  setEtagForSaveNaicSlPremiumAllocation,
  saveOriginalPremiumDetailsSuccess,
  updateSurplusLinesNewJerseyPremiumRows,
} from '../actions/premium-allocation-base.action';
import * as _ from 'lodash';
import { PremiumAllocationBaseState } from '@features/base-premium-allocation/models/premium-base.model';

export const initialState: PremiumAllocationBaseState = {
  premiumAllocationTable: [],
  etagForSaveNaicSlPremium: '',
  naicSlPremiumDetails: {},
  originalPremiumDetails: {},
};

export const PremiumAllocationBaseReducer: ActionReducer<PremiumAllocationBaseState, Action> = createReducer(
  initialState,
  on(addPremiumRow, (state, { row }) => ({
    ...state,
    premiumAllocationTable: [...state.premiumAllocationTable, row],
  })),
  on(deletePremiumRow, (state, { code }) => ({
    ...state,
    premiumAllocationTable: state.premiumAllocationTable.filter(
      (data) => data?.code !== code && data?.licenseNumber !== code
    ),
  })),
  on(clearData, () => initialState),
  on(saveNaicslPremiumAllocationSuccess, (state, { saveNaicSlPremiumAllocationResponse }) => ({
    ...state,
    naicSlPremiumDetails: saveNaicSlPremiumAllocationResponse,
  })),
  on(setEtagForSaveNaicSlPremiumAllocation, (state, { etag }) => ({
    ...state,
    etagForSaveNaicSlPremium: etag,
  })),
  on(saveOriginalPremiumDetailsSuccess, (state, { saveOriginalPremiumDetailResponse }) => ({
    ...state,
    originalPremiumDetails: saveOriginalPremiumDetailResponse,
  })),
  on(updateSurplusLinesNewJerseyPremiumRows, (state, { rows }) => ({
    ...state,
    premiumAllocationTable: rows,
  }))
);
