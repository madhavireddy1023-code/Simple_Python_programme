import { Action } from '@ngrx/store';
import { PremiumAllocationBaseReducer, initialState } from './premium-allocation-base.reducers';
import {
  addPremiumRow,
  deletePremiumRow,
  saveOriginalPremiumDetailsSuccess,
} from '../actions/premium-allocation-base.action';
import { PremiumNaicUsslInfo } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { mockPremiumAllocationTableData } from '@features/base-premium-allocation/const/mock-premium-allocation-data.const';

describe('PremiumAllocationBaseReducer', () => {
  it('should return the default state', () => {
    const action = {} as Action;
    const newState = PremiumAllocationBaseReducer(initialState, action);
    expect(newState).toBe(initialState);
  });

  it('should add a premium row', () => {
    const row = mockPremiumAllocationTableData[0];
    const action = addPremiumRow({ row });
    const newState = PremiumAllocationBaseReducer(initialState, action);

    expect(newState.premiumAllocationTable).toContain(row);
    expect(newState.premiumAllocationTable.length).toBe(initialState.premiumAllocationTable.length + 1);
  });

  it('should delete a premium row', () => {
    const initialStateWithRows = {
      ...initialState,
      premiumAllocationTable: mockPremiumAllocationTableData,
    };
    const idToDelete = '78388';
    const action = deletePremiumRow({ code: idToDelete });
    const newState = PremiumAllocationBaseReducer(initialStateWithRows, action);

    expect(newState.premiumAllocationTable.length).toBe(initialStateWithRows.premiumAllocationTable.length - 1);
    expect(newState.premiumAllocationTable.some((row) => row.code === idToDelete)).toBeFalse();
  });

  it('should save original Premium Details', () => {
    const saveOriginalPremiumDetailResponse: PremiumNaicUsslInfo = {
      premiumId: '123',
      transactionType: {},
      naicDetails: {
        naicRequired: true,
        naicInfoStatus: 'COMPLETE',
        naicCarriers: [
          {
            splitNumber: 0,
            reinsuredName: 'DXC technology',
            companyStatus: 'DXC',
            address: { state: 'Texas' },
            grossPremium: 100,
          },
        ],
      },
    };
    const action = saveOriginalPremiumDetailsSuccess({ saveOriginalPremiumDetailResponse });
    const newState = PremiumAllocationBaseReducer(initialState, action);

    expect(newState.originalPremiumDetails).toEqual(saveOriginalPremiumDetailResponse);
  });
});
