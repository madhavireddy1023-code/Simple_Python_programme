import { mockPremiumAllocationTableData } from '@features/base-premium-allocation/const/mock-premium-allocation-data.const';
import {
  addPremiumRow,
  deletePremiumRow,
  getOriginalPremiumDetails,
  saveOriginalPremiumDetailsSuccess,
} from './premium-allocation-base.action';
import { PremiumNaicUsslInfo } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

describe('Premium Allocation Base Actions', () => {
  it('should create an action to add a premium row', () => {
    const row = mockPremiumAllocationTableData[0];
    const action = addPremiumRow({ row });
    expect(action).toEqual({
      type: '[PremiumAllocation] Add Premium Row',
      row,
    });
  });

  it('should create an action to delete a premium row', () => {
    const code = '1';
    const action = deletePremiumRow({ code });
    expect(action).toEqual({
      type: '[PremiumAllocation] Delete Premium Row',
      code,
    });
  });

  it('should create an action to get original Premium Details', () => {
    const action = getOriginalPremiumDetails({
      premiumId: 'a7bd6421-2373-4350-883d-66cf2f18f1c5',
      typeOfPremium: 'Original_Premium',
      field: 'NAIC',
    });
    expect(action).toEqual({
      type: '[PremiumAllocation] get original premium details',
      premiumId: 'a7bd6421-2373-4350-883d-66cf2f18f1c5',
      typeOfPremium: 'Original_Premium',
      field: 'NAIC',
    });
  });

  it('should create an action to save Original Premium Details Success', () => {
    const saveOriginalPremiumDetailResponse: PremiumNaicUsslInfo = {
      premiumId: '123',
      transactionType: {},
      naicDetails: {
        naicRequired: true,
        naicInfoStatus: 'COMPLETE',
        naicCarriers: [
          {
            splitNumber: 0,
            reinsuredName: 'DXC technology',
            companyStatus: 'DXC',
            address: { state: 'Texas' },
            grossPremium: 100,
          },
        ],
      },
    };
    const action = saveOriginalPremiumDetailsSuccess({ saveOriginalPremiumDetailResponse });
    expect(action).toEqual({
      type: '[PremiumAllocation] Save original premium allocation success',
      saveOriginalPremiumDetailResponse,
    });
  });
});
