import {
  PremiumNaicUsslInfo,
  TypeOfField,
  TypeOfLlyodsPremiumsProcessor,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { createAction, props } from '@ngrx/store';

export const addPremiumRow = createAction('[PremiumAllocation] Add Premium Row', props<{ row: any }>());
export const deletePremiumRow = createAction('[PremiumAllocation] Delete Premium Row', props<{ code: string }>());

export const clearData = createAction('[PremiumAllocation] Clear Data');

export const getPremiumNaicSlDetails = createAction(
  '[PremiumAllocation] get premium naic sl details',
  props<{
    premiumId: string;
    typeOfPremium: TypeOfLlyodsPremiumsProcessor;
    field: TypeOfField;
  }>()
);

export const saveNaicslPremiumAllocation = createAction(
  '[PremiumAllocation] Save premium allocation',
  props<{
    etag: string;
    premiumId: string;
    typeOfPremium: TypeOfLlyodsPremiumsProcessor;
    typeOfUpdate: TypeOfField;
    payload: PremiumNaicUsslInfo;
    isSaveForNewJerseyPremium?: boolean;
  }>()
);

export const saveNaicslPremiumAllocationSuccess = createAction(
  '[PremiumAllocation] Save premium allocation success',
  props<{ saveNaicSlPremiumAllocationResponse: PremiumNaicUsslInfo }>()
);

export const setEtagForSaveNaicSlPremiumAllocation = createAction(
  '[Premium Allocation] set etag',
  props<{ etag: string }>()
);

export const getOriginalPremiumDetails = createAction(
  '[PremiumAllocation] get original premium details',
  props<{
    premiumId: string;
    typeOfPremium: TypeOfLlyodsPremiumsProcessor;
    field: TypeOfField;
  }>()
);

export const saveOriginalPremiumDetailsSuccess = createAction(
  '[PremiumAllocation] Save original premium allocation success',
  props<{ saveOriginalPremiumDetailResponse: PremiumNaicUsslInfo }>()
);

// New Jersey Surplus Lines

export const updateSurplusLinesNewJerseyPremiumRows = createAction(
  '[Surplus Lines New Jersey PremiumAllocation] update Premium Rows',
  props<{ rows: any }>()
);
