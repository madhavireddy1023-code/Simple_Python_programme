import * as PremiumAllocationBaseActions from './actions/premium-allocation-base.action';
import { PremiumAllocationBaseReducer } from './reducers/premium-allocation-base.reducers';
import { PremiumAllocationBaseState } from '../models/premium-base.model';
import { PremiumAllocationBaseEffects } from './effects/premium-allocation-base.effects';

export {
  PremiumAllocationBaseActions,
  PremiumAllocationBaseReducer,
  PremiumAllocationBaseState,
  PremiumAllocationBaseEffects,
};
