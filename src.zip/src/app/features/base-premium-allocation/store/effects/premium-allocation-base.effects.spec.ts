import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable, of, throwError } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';

import { PremiumAllocationBaseEffects } from './premium-allocation-base.effects';
import { TechnicianPortalNAICSLService } from 'src/app/api/technician-portal-naicsl';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { saveNaicslPremiumAllocation } from '../actions/premium-allocation-base.action';
import {
  PremiumNaicUsslInfo,
  TypeOfField,
  TypeOfLlyodsPremiumsProcessor,
} from '@dxc.lm.sdk.angular/ipos-technician-experience-api';
import { ScrollUp } from 'src/app/utils';
import { SectionDetailsStoreService } from '@features/section-details/services/section-details.store.service';
import { Store, StoreModule } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { SharedPremiumDataService } from '@features/section-details/services/shared-premium-data.service';

describe('saveNaicslPremiumAllocation$ Effect', () => {
  let actions$: Observable<any>;
  let effects: PremiumAllocationBaseEffects;
  let technicianPortalNaicSlService: jasmine.SpyObj<TechnicianPortalNAICSLService>;
  let sectionDetailsStoreService: jasmine.SpyObj<SectionDetailsStoreService>;
  let sharedPremiumDataService: SharedPremiumDataService;
  let router: Router;
  let testScheduler: TestScheduler;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, StoreModule.forRoot({})],
      providers: [
        PremiumAllocationBaseEffects,
        provideMockActions(() => actions$),
        SharedPremiumDataService,
        {
          provide: TechnicianPortalNAICSLService,
          useValue: jasmine.createSpyObj('TechnicianPortalNaicSlService', ['apiV1PremiumNAICSLDetailsPatch']),
        },
        provideMockStore(),
        SectionDetailsStoreService,
      ],
    });

    effects = TestBed.inject(PremiumAllocationBaseEffects);

    technicianPortalNaicSlService = TestBed.inject(
      TechnicianPortalNAICSLService
    ) as jasmine.SpyObj<TechnicianPortalNAICSLService>;
    sectionDetailsStoreService = TestBed.inject(
      SectionDetailsStoreService
    ) as jasmine.SpyObj<SectionDetailsStoreService>;
    router = TestBed.inject(Router);
    testScheduler = new TestScheduler((actual, expected) => {
      expect(actual).toEqual(expected);
    });
    sharedPremiumDataService = TestBed.inject(SharedPremiumDataService);
    store = TestBed.inject(Store) as MockStore;
  });

  it('should dispatch saveNaicslPremiumAllocationSuccess action on successful API call', () => {
    const etag = '1';
    const premiumId = '1';
    const typeOfPremium = TypeOfLlyodsPremiumsProcessor.OriginalPremium;
    const typeOfUpdate = TypeOfField.NAIC;
    const payload = {};
    const response: any = {
      premiumId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      transactionType: {
        refTypeOfTransactionTypeId: 'c6a25789-cb7e-4700-97b3-41f5bb9b9baa',
        typeOfTransactionType: 'Premium',
      },
      usSurplusLineDetails: {
        usSurplusLineRequired: true,
        usSurplusInfoStatus: 'INCOMPLETE',
        usSurplusLineBrokers: [
          {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            licenseNumber: 'string',
            companyName: 'string',
            contact: {
              name: {
                fullName: 'string',
              },
              communication: {
                contactNumbers: [
                  {
                    phoneTypeCode: 'Phone',
                    phoneNumber: 'string',
                  },
                ],
                emailAddress: 'string',
              },
            },
            address: {
              line1: 'string',
              city: 'string',
              postalCode: 'string',
              countryCode: 'string',
            },
            njSplits: 0,
          },
        ],
      },
      naicDetails: {
        naicRequired: true,
        naicInfoStatus: 'INCOMPLETE',
        naicCarriers: [
          {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            naicCode: 'string',
            feinCode: 'string',
            groupCode: 'string',
            poolCode: 'string',
            reinsuredName: 'string',
            grossPremium: 0,
            address: {
              line1: 'string',
              city: 'string',
              postalCode: 'string',
              countryCode: 'string',
            },
            telephoneNumber: 'string',
            companyStatus: 'string',
          },
        ],
      },
    };

    const previousUrl = '/section-details';
    spyOn(sharedPremiumDataService, 'getPreviousUrl').and.returnValue('/section-details');
    actions$ = of(
      saveNaicslPremiumAllocation({
        etag,
        premiumId,
        typeOfPremium,
        typeOfUpdate,
        payload,
      })
    );

    technicianPortalNaicSlService.apiV1PremiumNAICSLDetailsPatch.and.returnValue(of(response));
    spyOn(router, 'navigateByUrl');

    effects.saveNaicSLPremiumAllocation$.subscribe(() => {
      expect(router.navigateByUrl).toHaveBeenCalledWith(previousUrl);
    });

    testScheduler.flush();
    expect(technicianPortalNaicSlService.apiV1PremiumNAICSLDetailsPatch).toHaveBeenCalled();
  });

  it('should dispatch loadGlobalAlert action on API call failure', () => {
    const error = new Error('Test Error');

    actions$ = of(
      saveNaicslPremiumAllocation({
        etag: '2',
        premiumId: '1',
        typeOfPremium: TypeOfLlyodsPremiumsProcessor.OriginalPremium,
        typeOfUpdate: TypeOfField.NAIC,
        payload: {},
      })
    );

    technicianPortalNaicSlService.apiV1PremiumNAICSLDetailsPatch.and.returnValue(throwError(error));
    spyOn(router, 'navigateByUrl');

    effects.saveNaicSLPremiumAllocation$.subscribe((resultAction) => {
      expect(resultAction).toEqual(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
    });

    testScheduler.flush();
  });
});
