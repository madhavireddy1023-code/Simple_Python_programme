import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import * as actions from '../actions/premium-allocation-base.action';
import { catchError, switchMap } from 'rxjs/operators';
import { TechnicianPortalNAICSLService } from 'src/app/api/technician-portal-naicsl';
import { loadGlobalAlert } from 'src/app/store/actions/global-alert.action';
import { ScrollUp } from 'src/app/utils';
import {
  getPremiumNaicSlDetails,
  getOriginalPremiumDetails,
  saveNaicslPremiumAllocationSuccess,
  saveOriginalPremiumDetailsSuccess,
  setEtagForSaveNaicSlPremiumAllocation,
} from '../actions/premium-allocation-base.action';
import { SharedPremiumDataService } from '@features/section-details/services/shared-premium-data.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Injectable()
export class PremiumAllocationBaseEffects {
  constructor(
    private actions$: Actions,
    private technicianPortalNaicSlService: TechnicianPortalNAICSLService,
    private router: Router,
    private sharedPremiumDataService: SharedPremiumDataService,
    private location: Location
  ) {}

  saveNaicSLPremiumAllocation$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.saveNaicslPremiumAllocation),
      switchMap((action) =>
        this.technicianPortalNaicSlService
          .apiV1PremiumNAICSLDetailsPatch(
            action.etag,
            action.premiumId,
            action.typeOfPremium,
            action.typeOfUpdate,
            action.payload,
            'response'
          )
          .pipe(
            switchMap((response: any) => {
              if (!action.isSaveForNewJerseyPremium) {
                const url = this.sharedPremiumDataService.getPreviousUrl();
                url ? this.router.navigateByUrl(url) : this.location.back();
              }
              return of(
                actions.saveNaicslPremiumAllocationSuccess({ saveNaicSlPremiumAllocationResponse: response?.body })
              );
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACTION_MESSAGE',
                      isAuthAlert: true,
                      isVisible: true,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          )
      )
    )
  );

  getNaicSLPremiumDetails$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(getPremiumNaicSlDetails),
      switchMap((action) =>
        this.technicianPortalNaicSlService
          .apiV1PremiumNAICSLDetailsGet(action.premiumId, action.typeOfPremium, action.field, 'response')
          .pipe(
            switchMap((response: any) => {
              const etag = response?.headers?.get('ETag')?.replace(/(^"|"$)/g, '');
              return of(
                saveNaicslPremiumAllocationSuccess({ saveNaicSlPremiumAllocationResponse: response?.body }),
                setEtagForSaveNaicSlPremiumAllocation({ etag })
              );
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                      isAuthAlert: true,
                      isVisible: false,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          )
      )
    )
  );

  getOriginalPremiumDetails$: Observable<any> = createEffect(() =>
    this.actions$.pipe(
      ofType(getOriginalPremiumDetails),
      switchMap((action) =>
        this.technicianPortalNaicSlService
          .apiV1PremiumNAICSLDetailsGet(action.premiumId, action.typeOfPremium, action.field, 'body')
          .pipe(
            switchMap((response: any) => {
              return of(saveOriginalPremiumDetailsSuccess({ saveOriginalPremiumDetailResponse: response }));
            }),
            catchError((error) => {
              ScrollUp(0, 0);
              if (error?.status === 403) {
                return of(
                  loadGlobalAlert({
                    response: {
                      ...error,
                      responseMessage: 'ALERTS.NOT_ALLOWED_ACCESS_MESSAGE',
                      isAuthAlert: true,
                      isVisible: false,
                    },
                  })
                );
              }
              return of(loadGlobalAlert({ response: { ...error, isGlobalAlert: true } }));
            })
          )
      )
    )
  );
}
