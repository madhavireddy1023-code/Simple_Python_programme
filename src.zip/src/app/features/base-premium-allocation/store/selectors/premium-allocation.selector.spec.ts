import { selectPremiumAllocationData } from './premium-allocation.selectors';
import { mockPremiumAllocationTableData } from '@features/base-premium-allocation/const/mock-premium-allocation-data.const';

describe('PremiumAllocationSelector', () => {
  const state = {
    premiumAllocationTable: mockPremiumAllocationTableData,
  };

  it('should select selectPremiumRows', () => {
    const expectedData = mockPremiumAllocationTableData;
    const selectPremiumRowsSelector = selectPremiumAllocationData.projector(state);
    expect(selectPremiumRowsSelector).toEqual(expectedData);
  });
});
