import { createSelector } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';

export const selectState = (state: AppState) => state.premiumAllocationBase;

export const selectPremiumAllocationData = createSelector(selectState, (state) => state?.premiumAllocationTable);

export const getETagForSaveNaicSlPremiumAllocation = createSelector(
  selectState,
  (state) => state?.etagForSaveNaicSlPremium
);

export const selectPremiumNAICSLDetails = createSelector(selectState, (state) => state?.naicSlPremiumDetails);

export const selectOriginalPremiumNAICSLDetails = createSelector(selectState, (state) => state?.originalPremiumDetails);
