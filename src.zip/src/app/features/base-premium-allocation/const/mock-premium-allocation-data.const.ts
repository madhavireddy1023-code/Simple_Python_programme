import { UsslBroker } from '@dxc.lm.sdk.angular/premiums-naic-surpluslines-api';
import { NAIC_REPORTING_CODE_OPTIONS } from '@features/naic-reporting/const/naic-reporting.const';
import { NaicPremiumAllocation } from '@features/naic-reporting/models/naic.model';

export const mockPremiumAllocationTableData: NaicPremiumAllocation[] = [
  {
    id: '1',
    codeType: NAIC_REPORTING_CODE_OPTIONS.NAIC,
    code: '78388',
    reinsuredName: 'DXC technology',
    grossPremium: '1,000,000.00',
    address: {},
    companyStatus: 'DXC',
    contactMethods: [],
  },
];

export const nJSplitMockData: UsslBroker[] = [
  {
    address: {
      addressLine1: 'Bicking building',
      addressLine2: 'Blfreton road',
      city: 'New Jersey',
      state: {
        refISOCountryDivisionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        subDivisionCode: 'US-NJ',
        subDivisionName: 'New Jersey',
      },
      zipCode: 'M1 2DE',
    },
    companyName: 'ABC PRIVATE LTD',
    contact: {
      firstName: 'FirstName',
      middleName: 'MidddleName',
      surName: 'SurName',
    },
    createdAt: new Date('2024-04-08T09:25:19.032Z'),
    createdBy: 'string',
    deprecatedDate: 'string',
    effectiveDate: 'string',
    lastUpdatedAt: new Date('2024-04-08T09:25:19.032Z'),
    lastUpdatedBy: 'string',
    licenseNumber: '67890',
    stateOfLicense: {
      refISOCountryDivisionId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      subDivisionCode: 'US-NJ',
      subDivisionName: 'New Jersey',
    },
    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  },
];
