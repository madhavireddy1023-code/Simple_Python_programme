import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from 'src/app/store/app.reducer';
import * as selectors from '../store/selectors/premium-allocation.selectors';
import {
  addPremiumRow,
  clearData,
  deletePremiumRow,
  getOriginalPremiumDetails,
  getPremiumNaicSlDetails,
  saveNaicslPremiumAllocation,
  updateSurplusLinesNewJerseyPremiumRows,
} from '../store/actions/premium-allocation-base.action';
import { Observable } from 'rxjs';
import { PremiumNaicUsslInfo, TypeOfField } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

@Injectable({
  providedIn: 'root',
})
export class PremiumAllocationStoreService {
  constructor(private store: Store<AppState>) {}

  getPremiumAllocatedRows(): any {
    return this.store.select(selectors.selectPremiumAllocationData);
  }

  deletePremiumRow(code: string): void {
    this.store.dispatch(deletePremiumRow({ code }));
  }

  clearData(): void {
    return this.store.dispatch(clearData());
  }

  getNaicSLPremiumDetails(premiumId: string, typeOfPremium, field): void {
    return this.store.dispatch(getPremiumNaicSlDetails({ premiumId, typeOfPremium, field }));
  }

  saveNaicSLPremiumAllocation(
    etag: string,
    premiumId: string,
    typeOfPremium,
    typeOfUpdate: TypeOfField,
    payload: PremiumNaicUsslInfo,
    isSaveForNewJerseyPremium: boolean
  ): void {
    this.store.dispatch(
      saveNaicslPremiumAllocation({ etag, premiumId, typeOfPremium, typeOfUpdate, payload, isSaveForNewJerseyPremium })
    );
  }

  getEtagForPremiumNaicSlDetails(): Observable<string> {
    return this.store.select(selectors.getETagForSaveNaicSlPremiumAllocation);
  }

  getOriginalPremiumDetails(premiumId: string, typeOfPremium, field): void {
    return this.store.dispatch(getOriginalPremiumDetails({ premiumId, typeOfPremium, field }));
  }

  addPremiumRow(newRow): void {
    return this.store.dispatch(addPremiumRow({ row: newRow }));
  }

  selectPremiumNAICSLDetailsData(): any {
    return this.store.select(selectors.selectPremiumNAICSLDetails);
  }

  updateSurplusLinesNewJerseyPremiumRows(rows): void {
    return this.store.dispatch(updateSurplusLinesNewJerseyPremiumRows({ rows }));
  }

  selectOriginalPremiumNAICSLDetailsData(): any {
    return this.store.select(selectors.selectOriginalPremiumNAICSLDetails);
  }
}
