import { TestBed } from '@angular/core/testing';

import { PremiumAllocationStoreService } from './premium-allocation-store.service';
import { mockPremiumAllocationTableData } from '../const/mock-premium-allocation-data.const';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { of } from 'rxjs';
import {
  addPremiumRow,
  deletePremiumRow,
  getOriginalPremiumDetails,
} from '../store/actions/premium-allocation-base.action';
import {
  selectPremiumAllocationData,
  selectPremiumNAICSLDetails,
} from '../store/selectors/premium-allocation.selectors';

describe('PremiumAllocationStoreService', () => {
  let service: PremiumAllocationStoreService;
  let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideMockStore(), MockStore],
    });
    store = TestBed.inject(MockStore);
    service = TestBed.inject(PremiumAllocationStoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return premium allocated rows', () => {
    spyOn(store, 'select').withArgs(selectPremiumAllocationData).and.returnValue(of(mockPremiumAllocationTableData));
    service.getPremiumAllocatedRows();
    expect(store.select).toHaveBeenCalled();
  });

  it('should delete premium row', () => {
    spyOn(store, 'dispatch')
      .withArgs(deletePremiumRow({ code: '1' }))
      .and.returnValue();
    const rowId = '1';
    service.deletePremiumRow(rowId);
    expect(store.dispatch).toHaveBeenCalledWith(deletePremiumRow({ code: rowId }));
  });

  it('should get Original Premium Details', () => {
    spyOn(store, 'dispatch')
      .withArgs(
        getOriginalPremiumDetails({
          premiumId: '1',
          typeOfPremium: 'Original_Premium',
          field: 'NAIC',
        })
      )
      .and.returnValue();
    service.getOriginalPremiumDetails('1', 'Original_Premium', 'NAIC');
    expect(store.dispatch).toHaveBeenCalledWith(
      getOriginalPremiumDetails({
        premiumId: '1',
        typeOfPremium: 'Original_Premium',
        field: 'NAIC',
      })
    );
  });

  it('should add Premium Row', () => {
    const newRow = {
      address: {},
      code: '78388',
      codeType: 'NAIC',
      companyStatus: '',
      contactMethods: [],
      grossPremium: 100,
      id: '585d0c8c-141f-42ba-94b8-a20736709146',
      reinsuredName: 'DXC technology',
    };

    spyOn(store, 'dispatch')
      .withArgs(addPremiumRow({ row: newRow }))
      .and.returnValue();
    service.addPremiumRow(newRow);
    expect(store.dispatch).toHaveBeenCalledWith(addPremiumRow({ row: newRow }));
  });

  it('should return PremiumNAICSLDetailsData', () => {
    const mockData = {
      body: {
        naicDetails: {
          naicInfoStatus: 'INCOMPLETE',
          naicCarriers: [
            {
              splitNumber: 0,
              naicCode: '78388',
              reinsuredName: 'DXC technology',
              companyStatus: 'DXC',
              address: {},
              grossPremium: 100,
              uuid: '585d0c8c-141f-42ba-94b8-a20736709146',
            },
          ],
        },
      },
    };
    spyOn(store, 'select').withArgs(selectPremiumNAICSLDetails).and.returnValue(of(mockData));
    service.selectPremiumNAICSLDetailsData();
    expect(store.select).toHaveBeenCalled();
  });
});
