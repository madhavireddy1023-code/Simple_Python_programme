import { PremiumNaicUsslInfo } from '@dxc.lm.sdk.angular/ipos-technician-experience-api';

export interface PremiumAllocationBaseState {
  premiumAllocationTable: any;
  etagForSaveNaicSlPremium: string;
  naicSlPremiumDetails: PremiumNaicUsslInfo;
  originalPremiumDetails: PremiumNaicUsslInfo;
}
