import { Component, Inject, OnInit } from '@angular/core';
import { ThemeService } from '@dxc-technology/halstack-angular';
import { customTheme } from '../assets/standardTheme';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'premiums-ipos-tech-portal';
  loggedIn: boolean;

  constructor(
    @Inject('ThemeService') private themeService: ThemeService,
    private auth: AuthenticationService,
    private referenceDataStoreService: ReferenceDataStoreService
  ) {}

  async ngOnInit(): Promise<void> {
    this.themeService.registerTheme(customTheme);
    this.auth.authenticate();
    this.loggedIn = !!(await this.auth.session.catch((err) => null));
    if (this.loggedIn) {
      this.referenceDataStoreService.getRefData();
    }
  }
}
