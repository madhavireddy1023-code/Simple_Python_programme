import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './core/login/login.component';
import { AccessGuard } from '@shared/guards/access.guard';
import { GlobalErrorComponent } from '@shared/components/global-error/global-error.component';
import { PageTitle, Role } from '@shared/consts/shared.enums';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./features/global-layout/global-layout.module').then((m) => m.GlobalLayoutModule),
    canActivate: [AccessGuard],
    data: {
      role1: Role.Portal_IPOS, // sending this role to landing page AccessGuard to check if the user has the role or not.
      title: PageTitle.HOME,
    },
  },
  {
    path: 'summary-details',
    loadChildren: () => import('./features/summary/summary.module').then((m) => m.SummaryModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.TECHNICIANPORTAL,
    },
  },
  {
    path: 'section-details',
    loadChildren: () => import('./features/section-details/section-details.module').then((m) => m.SectionDetailsModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.TECHNICIANPORTAL,
    },
  },
  {
    path: 'market-details',
    loadChildren: () => import('./features/market-details/market-details.module').then((m) => m.MarketDetailsModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.TECHNICIANPORTAL,
    },
  },
  {
    path: 'signing-details',
    loadChildren: () => import('./features/signing-details/signing-details.module').then((m) => m.SigningDetailsModule),
    canActivate: [AccessGuard],
    data: {
      role1: Role.PROCESS_HERITAGE_VIEW,
      role2: Role.PROCESS_HERITAGE_EDIT,
      title: PageTitle.TECHNICIANPORTAL,
    },
  },
  {
    path: 'enquiry-details',
    loadChildren: () => import('./features/enquiry/enquiry.module').then((m) => m.EnquiryModule),
    canActivate: [AccessGuard],
    data: {
      role1: Role.PROCESS_HERITAGE_VIEW,
      role2: Role.PROCESS_HERITAGE_EDIT,
      title: PageTitle.ENQUIRY,
    },
  },
  {
    path: 'queries',
    loadChildren: () => import('./features/queries/queries.module').then((m) => m.QueriesModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.QUERIES,
    },
  },
  {
    path: 'corrections',
    loadChildren: () => import('./features/corrections/corrections.module').then((m) => m.CorrectionsModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.CORRECTIONS,
    },
  },
  {
    path: 'stop-block',
    loadChildren: () => import('./features/stop-block/stop-block.module').then((m) => m.StopBlockModule),
    canActivate: [AccessGuard],
    data: {
      role1: Role.PROCESS_STOP_BLOCK_SEARCH,
      role2: Role.PROCESS_STOP_BLOCK_EDIT,
      title: PageTitle.STOPBLOCKADMIN,
    },
  },
  {
    path: 'naic-reporting',
    loadChildren: () => import('./features/naic-reporting/naic-reporting.module').then((m) => m.NAICReportingModule),
    canActivate: [],
    data: {
      title: PageTitle.TECHNICIANPORTAL,
    },
  },
  {
    path: 'surplus-lines',
    loadChildren: () => import('./features/surplus-lines/surplus-lines.module').then((m) => m.SurplusLinesModule),
    canActivate: [],
    data: {
      title: PageTitle.TECHNICIANPORTAL,
    },
  },
  {
    path: 'release-for-settlement',
    loadChildren: () =>
      import('./features/release-for-settlement/release-for-settlement.module').then(
        (m) => m.ReleaseForSettlementModule
      ),
    canActivate: [AccessGuard],
    data: {
      role1: Role.PROCESS_RELEASE_FOR_SETTLEMENT_SEARCH,
      role2: Role.PROCESS_RELEASE_FOR_SETTLEMENT_EDIT,
      role3: Role.PROCESS_RELEASE_FOR_SETTLEMENT_OVERRIDE,
      title: PageTitle.RELEASEFORSETTLEMENT,
    },
  },
  {
    path: 'exchange-rate-enquiry',
    loadChildren: () =>
      import('./features/exchange-rate-enquiry/exchange-rate-enquiry.module').then((m) => m.ExchangeRateEnquiryModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.EXCHANGERATEENQUIRY,
    },
  },
  {
    path: 'company-ref-update',
    loadChildren: () => import('./features/company-ref-update/companyref.module').then((m) => m.CompanyrefModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.COMPANYUWREFUPDATE,
    },
  },
  {
    path: 'instalment-details',
    loadChildren: () =>
      import('./features/instalment-details/instalment-details.module').then((m) => m.InstalmentDetailsModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.DEFINSTALLMENTS,
    },
  },
  {
    path: 'audit',
    loadChildren: () => import('./features/audit/audit.module').then((m) => m.AuditModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.AUDIT,
    },
  },
  {
    path: 'heritage',
    loadChildren: () => import('./features/heritage/heritage.module').then((m) => m.HeritageModule),
    canActivate: [AccessGuard],
    data: {
      title: PageTitle.HERITAGE,
    },
  },
  {
    path: 'review-errors/:id/:section',
    loadChildren: () => import('./features/review-errors/review-errors.module').then((m) => m.ReviewErrorsModule),
    canActivate: [AccessGuard],
    data: {
      role1: Role.PROCESS_HERITAGE_VIEW,
    },
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'error',
    component: GlobalErrorComponent,
  },
  {
    path: '',
    pathMatch: 'full',
    component: LoginComponent,
  },
  {
    path: 'error',
    component: GlobalErrorComponent,
  },
  { path: '**', pathMatch: 'full', redirectTo: 'layout' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
