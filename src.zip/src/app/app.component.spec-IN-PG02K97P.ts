import { TestBed, waitForAsync, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NavigationStart, Router } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Subject } from 'rxjs';
import { AuthenticationService } from '@dxc-lm/keycloak-authorisation';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

import { ReferenceDataStoreService } from '@shared/services/reference-data/reference-data.store.service';
import { AppComponent } from './app.component';
import { IdentityProviderService } from '@shared/services/identity-provider/identity-provider.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EditModePersistenceService } from '@shared/services/edit-mode-router-persistance/edit-mode-router-persistance.service';
import { Title } from '@angular/platform-browser';

describe('AppComponent', () => {
  let authService: AuthenticationService;
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let referenceDataStoreService: ReferenceDataStoreService;
  let editModePersistenceService: EditModePersistenceService;
  const eventsSubject = new Subject<any>();

  const themeServiceSpy = jasmine.createSpyObj('ThemeService', ['getTheme', 'registerTheme']);
  beforeAll(() => {
    window.onbeforeunload = () => 'Oh no!';
  });

  beforeEach(waitForAsync(() => {
    const routerMock = {
      events: eventsSubject.asObservable(),
      routerState: {
        root: {
          firstChild: {
            snapshot: {
              data: { title: 'Test Title' },
              queryParams: {},
            },
            firstChild: null,
          },
        },
      },
    };
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
      providers: [
        AuthenticationService,
        ReferenceDataStoreService,
        { provide: 'ThemeService', useValue: themeServiceSpy },
        MockStore,
        provideMockStore(),
        { provide: Router, useValue: routerMock },
        Title,
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    authService = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    referenceDataStoreService = TestBed.inject(ReferenceDataStoreService) as jasmine.SpyObj<ReferenceDataStoreService>;
    editModePersistenceService = TestBed.inject(
      EditModePersistenceService
    ) as jasmine.SpyObj<EditModePersistenceService>;
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  xit('should call authenticate method', () => {
    spyOn(authService, 'authenticate').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    expect(authService.authenticate).toHaveBeenCalled();
  });

  xit('should call getRefData method', fakeAsync(() => {
    spyOnProperty(authService, 'session').and.returnValue(
      Promise.resolve({
        getIdToken(): any {
          return { payload: { key: 'custom:party', value: '12345' } };
        },
        getRefreshToken: () => {},
        getAccessToken: () => {},
        isValid: () => true,
      })
    );
    spyOn(referenceDataStoreService, 'getRefData');
    component.ngOnInit();
    tick();
    expect(referenceDataStoreService.getRefData).toHaveBeenCalled();
  }));

  describe('router events', () => {
    it('should check if current page is any of queries', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      expect(component.isQueries).toBeFalsy();

      eventsSubject.next(new NavigationStart(2, '/queries/all-queries'));
      expect(component.isQueries).toBeTruthy();

      eventsSubject.next(new NavigationStart(3, '/'));
      eventsSubject.next(new NavigationStart(4, '/queries/search-queries'));
      expect(component.isQueries).toBeTruthy();

      eventsSubject.next(new NavigationStart(5, '/'));
      eventsSubject.next(new NavigationStart(6, '/queries/create-query'));
      expect(component.isQueries).toBeTruthy();
    });

    it('should check if current page is search queries', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/queries/search-queries'));
      expect(component.isSearchQueries).toBeTruthy();
    });

    it('should check if current page is create query', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/queries/create-query'));
      expect(component.isCreateQuery).toBeTruthy();
    });

    it('should check if current page is enquiry', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/enquiry-details'));
      expect(component.isEnquiry).toBeTruthy();
    });

    it('should check if current page is landing page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      expect(component.isLandingPage).toBeTruthy();
    });

    it('should check if current page is stop-block page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/stop-block'));
      expect(component.isStopBlock).toBeTruthy();
    });

    it('should check if current page is release-for-settlement page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/release-for-settlement'));
      expect(component.isReleaseForSettlement).toBeTruthy();
    });

    it('should check if current page is exchange-rate-enquiry page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/exchange-rate-enquiry'));
      expect(component.isExchangeRateEnquiry).toBeTruthy();
    });

    it('should check if current page is naic-reporting page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/naic-reporting'));
      expect(component.isNaicReporting).toBeTruthy();
    });
    it('should check if current page is surplus-lines page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/surplus-lines'));
      expect(component.isSurplusLines).toBeTruthy();
    });
    it('should check if current page is heritage page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/heritage'));
      expect(component.isHeritage).toBeTruthy();
    });
    it('should check if current page is deferred installment history page', () => {
      eventsSubject.next(new NavigationStart(1, '/'));
      eventsSubject.next(new NavigationStart(2, '/enquiry-details/def-inst-hist'));
      expect(component.isDefInstHistRoute).toBeTruthy();
    });
  });
});
