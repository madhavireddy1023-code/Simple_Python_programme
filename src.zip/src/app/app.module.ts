import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { CoreModule } from './core/core.module';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from 'src/environments/environment';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { effects, reducers } from './store/app.reducer';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';
import { HttpLoaderFactory } from './utils/helper/helper';
import {
  AuthInitialiseProvider,
  AuthorisationConfiguration,
  AuthorisationGuardModule,
  AuthorisationInterceptorModule,
  AuthorisationServiceModule,
  KEYCLOAK_CONFIGURATION,
} from '@dxc-lm/keycloak-authorisation';
import { ThemeModule, ThemeService } from '@dxc-technology/halstack-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HTTPRequestInterceptor } from '@shared/interceptors/http-request.interceptor';
import { AppConfigService } from './core/services/app-config/app-config.service';
import { ApiModule } from './api/api.module';

@NgModule({
  declarations: [AppComponent],
  imports: [
    ApiModule,
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    SharedModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    ThemeModule,
    FormsModule,
    ReactiveFormsModule,
    AngularSvgIconModule.forRoot(),
    StoreModule.forRoot(reducers),
    EffectsModule.forRoot(effects),
    AuthorisationGuardModule,
    AuthorisationInterceptorModule.forRoot(
      () =>
        new AuthorisationConfiguration({
          domainWhiteList: [
            'https://lm-do-doma-tf-dev001.s3.eu-west-2.amazonaws.com',
            'https://lm-do-doma-tf-tst001.s3.eu-west-2.amazonaws.com',
            'https://lm-do-doma-tf-uat101.s3.eu-west-2.amazonaws.com',
            'https://lm-do-doma-tf-nft001.s3.eu-west-2.amazonaws.com',
          ],
        })
    ),
    AuthorisationServiceModule,
    !environment.production ? StoreDevtoolsModule.instrument({ name: 'IPOS-TECH', maxAge: 50 }) : [],
    ThemeModule,
    FormsModule,
    ReactiveFormsModule,
    CoreModule,
  ],
  providers: [
    { provide: KEYCLOAK_CONFIGURATION, useClass: AppConfigService },
    { provide: 'ThemeService', useClass: ThemeService },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HTTPRequestInterceptor,
      multi: true,
    },
    AuthInitialiseProvider,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(translate: TranslateService) {
    translate.setDefaultLang('en');
    translate.use('en');
  }
}
