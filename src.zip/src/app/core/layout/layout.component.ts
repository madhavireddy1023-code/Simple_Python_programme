import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { LandingPageRoles } from '@shared/consts/shared.consts';
import { Role } from '@shared/consts/shared.enums';
import { RolesType } from '@shared/models';
import { RoleAuthorization } from '@shared/services/identity-provider/identity-provider-response.interface';
import { IdentityProviderService } from '@shared/services/identity-provider/identity-provider.service';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
})
export class LayoutComponent implements OnInit {
  queryParams$: Observable<Params>;

  @Input() isCreateQuery: boolean;
  @Input() isEnquiry: boolean;
  @Input() isEnquirySubmission: boolean;
  @Input() isCorrections: boolean;
  @Input() isCompanyRefUpdate: boolean;
  @Input() isInstalmentDetails: boolean;
  @Input() isStopBlock: boolean;
  @Input() isReleaseForSettlement: boolean;
  @Input() isExchangeRateEnquiry: boolean;
  @Input() isNaicReporting: boolean;
  @Input() isQueries: boolean;
  @Input() isSearchQueries: boolean;
  @Input() isAudit: boolean;
  @Input() loggedIn: boolean;
  @Input() isSurplusLines: boolean;
  @Input() isHeritage: boolean;
  @Input() isReviewErrors: boolean;
  @Input() isDefInstHistRoute: boolean;
  @Input() isEditMode: boolean;

  isAccountEnquiry: RoleAuthorization;
  landingPageRoles$: Observable<RolesType>;
  constructor(private route: ActivatedRoute, private identityProviderService: IdentityProviderService) {}

  ngOnInit(): void {
    this.landingPageRoles$ = this.identityProviderService.roles;
    this.identityProviderService.getRolesAuthorization(LandingPageRoles);
    this.queryParams$ = this.route.queryParams;
    this.hasAccountEnquiryRole().subscribe((res: RoleAuthorization) => {
      this.isAccountEnquiry = res;
    });
  }

  hasAccountEnquiryRole(): Observable<RoleAuthorization> {
    const role1: string = Role.AccountEnquiry_Screen;
    return this.identityProviderService.getRoleAuthorization(role1).pipe(
      map((res: RoleAuthorization) => {
        return res;
      })
    );
  }
}
