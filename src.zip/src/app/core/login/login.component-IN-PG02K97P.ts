import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit(): void {
    const redirectedURL = sessionStorage.getItem('redirectedURL');
    if (redirectedURL) {
      this.router.navigateByUrl(redirectedURL);
      return;
    }
    this.router.navigate([''], { queryParams: {}, replaceUrl: true });
  }
}
