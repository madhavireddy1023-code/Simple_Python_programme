import { AfterContentInit, Component, ElementRef, OnInit } from '@angular/core';
import { AppConfigService } from '../services/app-config/app-config.service';

@Component({
  selector: 'app-dynatrace',
  templateUrl: './dynatrace.component.html',
  styleUrls: ['./dynatrace.component.scss'],
})
export class DynatraceComponent implements OnInit, AfterContentInit {
  constructor(private elementRef: ElementRef, private appConfigService: AppConfigService) {}

  ngOnInit(): void {}

  get dynaScript(): string {
    return this.appConfigService.get('endPoints.dynatrace.base');
  }

  ngAfterContentInit(): void {
    const scriptPath = document.createElement('script');
    scriptPath.type = 'text/javascript';
    scriptPath.src = this.dynaScript;
    scriptPath.setAttribute('crossorigin', 'anonymous');
    this.elementRef.nativeElement.appendChild(scriptPath);
  }
}
