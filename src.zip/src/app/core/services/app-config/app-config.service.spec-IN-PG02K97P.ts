import { TestBed } from '@angular/core/testing';
import { AppConfigService } from './app-config.service';
import { environment } from '../../../../environments/environment';

describe('AppConfigService', () => {
  let service: AppConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppConfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get window location', () => {
    const windowLocation = window.location.origin;
    expect(service.getWindowLocation()).toBe(windowLocation);
  });

  it('should return local environment', () => {
    const url = environment.settingsLocal.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsLocal);
  });

  it('should return dev environment', () => {
    const url = environment.settingsDev.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsDev);
  });

  it('should return test environment', () => {
    const url = environment.settingsTest.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsTest);
  });

  it('should return uat environment', () => {
    const url = environment.settingsUat.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsUat);
  });
  it('should return preprod environment', () => {
    const url = environment.settingsPreProd.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsPreProd);
  });
  it('should return prod environment', () => {
    const url = environment.settingsProd.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsProd);
  });
  it('should return nft environment', () => {
    const url = environment.settingsNft.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsNft);
  });
  it('should return vanguard environment', () => {
    const url = environment.settingsVanguard.endPoints.LOGIN_ENDPOINT_URI;
    expect(service.setAppSettings(url)).toEqual(environment.settingsVanguard);
  });
});
