import { Injectable } from '@angular/core';
import {
  ConfigurationService,
  ConfigurationSettings,
  getPathValue,
  setPathValue,
} from '@dxc-lm/keycloak-authorisation';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AppConfigService implements ConfigurationService {
  settings: ConfigurationSettings;

  constructor() {
    const url = this.getWindowLocation();
    this.settings = this.setAppSettings(url);
  }

  getWindowLocation(): string {
    return window.location.origin;
  }

  public get(key: string): string {
    return getPathValue(this.settings, key);
  }

  public set(key: string, value: any): void {
    setPathValue(this.settings, key, value);
  }

  public setAppSettings(url: string): ConfigurationSettings {
    switch (url) {
      // local Settings
      case environment.settingsLocal.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using Local Settings ***');
        return environment.settingsLocal;
      // dev Settings
      case environment.settingsDev.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using Dev Settings ***');
        return environment.settingsDev;
      // test Settings
      case environment.settingsTest.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using Test Settings ***');
        return environment.settingsTest;
      // uat Settings
      case environment.settingsUat.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using UAT Settings ***');
        return environment.settingsUat;
      default:
        return environment.settingsDev;
    }
  }
}
