import { Injectable } from '@angular/core';
import {
  ConfigurationService,
  ConfigurationSettings,
  getPathValue,
  setPathValue,
} from '@dxc-lm/keycloak-authorisation';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AppConfigService implements ConfigurationService {
  settings: ConfigurationSettings;
  environmentLocation = environment.settingsDev;

  constructor() {
    const url = this.getWindowLocation();
    this.settings = this.setAppSettings(url);
  }

  getWindowLocation(): string {
    return window.location.origin;
  }

  public get(key: string): string {
    return getPathValue(this.settings, key);
  }

  public set(key: string, value: any): void {
    setPathValue(this.settings, key, value);
  }

  public setAppSettings(url: string): ConfigurationSettings {
    switch (url) {
      // local Settings
      case environment.settingsLocal.endPoints.LOGIN_ENDPOINT_URI:
        console.log(`*** Using Local Settings [${environment.appVersion}] ***`);
        this.environmentLocation = environment.settingsLocal;
        return environment.settingsLocal;
      // dev Settings
      case environment.settingsDev.endPoints.LOGIN_ENDPOINT_URI:
        console.log(`*** Using Dev Settings [${environment.appVersion}] ***`);
        this.environmentLocation = environment.settingsDev;
        return environment.settingsDev;
      // test Settings
      case environment.settingsTest.endPoints.LOGIN_ENDPOINT_URI:
        console.log(`*** Using Test Settings [${environment.appVersion}] ***`);
        this.environmentLocation = environment.settingsTest;
        return environment.settingsTest;
      // uat Settings
      case environment.settingsUat.endPoints.LOGIN_ENDPOINT_URI:
        console.log(`*** Using UAT Settings [${environment.appVersion}] ***`);
        this.environmentLocation = environment.settingsUat;
        return environment.settingsUat;
      // preprod Settings
      case environment.settingsPreProd.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using PreProd Settings ***');
        this.environmentLocation = environment.settingsPreProd;
        return environment.settingsPreProd;
      // prod settings
      case environment.settingsProd.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using Prod Settings ***');
        this.environmentLocation = environment.settingsProd;
        return environment.settingsProd;
      // vanguard settings
      case environment.settingsVanguard.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using vanguard Settings ***');
        this.environmentLocation = environment.settingsVanguard;
        return environment.settingsVanguard;
      // nft settings
      case environment.settingsNft.endPoints.LOGIN_ENDPOINT_URI:
        console.log('*** Using Nft Settings ***');
        this.environmentLocation = environment.settingsNft;
        return environment.settingsNft;
      default:
        return environment.settingsDev;
    }
  }
}
