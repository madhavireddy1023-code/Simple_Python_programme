from typing import Required

from django import forms
from .models import Item

class ItemForms(forms.ModelForm):
    # ClearableFileInput
    class Meta:
        model = Item
        fields = ["item_name", "item_desc", "item_image", "item_price"]
        widgets = {
            'item_name': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 rounded px-3 py-2',
                'placeholder': 'Item Name',
                "required": True
            }),
            'item_desc': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 rounded px-3 py-2',
                'placeholder': 'Description',
                "required": False
            }),
            'item_image': forms.TextInput(attrs={
                'class': 'w-full border border-gray-300 rounded px-3 py-2',
                'placeholder': 'Upload Image',
                "required": True
            }),
            'item_price': forms.NumberInput(attrs={
                'class': 'w-full border border-gray-300 rounded px-3 py-2',
                'placeholder': 'Price',
                "required": True
            }),
        }

        def form_valid(self, form):
            form.instance.user_name = self.request.user
            return super().form_valid(form)
        
    def clean_item_price(self):
        price = self.cleaned_data.get("item_price")
        if price is not None and price < 0:
            raise forms.ValidationError("Price cannot be negative.")
        return price

    def clean(self):
        cleaned = super().clean()
        name = cleaned.get('item_name')
        desc = cleaned.get('item_desc')
        if not name and not desc:
            raise forms.ValidationError("Enter either item name and description.")
        return cleaned
        