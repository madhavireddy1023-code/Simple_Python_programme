from django.urls import path, include
from . import views
#from django.views.decorators import cache_page

app_name = "myapp"

urlpatterns = [
    path('', views.index, name="index"),
    path('items/', views.item_form, name="items"),
    path('details/<int:id>/', views.item_details, name="item_details"),
    path('update/<int:id>/', views.item_edit, name="edit_item"),
    path('delete/<int:id>/', views.item_delete, name="delete_item"),
]
