from django.db import models
from django.contrib.auth.models import User
from .manager import ItemManager
from django.utils import timezone
# Create your models here.

class Item(models.Model):
    class Meta:
        indexes = [
             models.Index(fields=['user_name', 'item_price']),
        ]

    def delete(self, using=None, keep_parents=False):
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.save()
    
    user_name = models.ForeignKey(User, on_delete=models.CASCADE, default=1)
    item_name = models.CharField(max_length=100, db_index=True)
    item_desc = models.TextField()
    item_image = models.URLField(max_length=500, default="https://cdn-icons-png.freepik.com/512/14228/14228079.png")
    item_price = models.DecimalField(max_digits=5, decimal_places=2, db_index=True)
    is_avaiable = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    objects = ItemManager()
    all_objects = models.Manager()

    def __str__(self):
        return self.item_name