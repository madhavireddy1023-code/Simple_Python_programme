import time
from django.http import HttpResponseForbidden

class LogRequestMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # process before
        print(f"[Middleware] Request Path {request.path}")
        response = self.get_response(request)
        # process after
        print(f"[Middleware] Request Status {request}")
        return response
    
class TimeMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start = time.time()
        response = self.get_response(request)
        duration = time.time() - start
        print(f"[Middleware] Request Status {duration:.2f} seconds")
        return response
    
class BlockIpMiddleware:
    BLOCKED_IPS = []
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        ip = request.META.get("REMOTE_ADDR")
        if ip in self.BLOCKED_IPS:
            return HttpResponseForbidden("You IP address blocked")
        return self.get_response(request)
     