from django.shortcuts import render, redirect
from .models import Item
from .forms import ItemForms
from django.core.paginator import Paginator
from django.views.decorators.cache import cache_page
from django.views.decorators.vary import vary_on_headers
import logging
from django.shortcuts import get_object_or_404
from django.utils import timezone
# Create your views here.

logger = logging.getLogger(__name__)
#@cache_page(60 * 15)
#@vary_on_headers("User-Agent")
def index(request):
    logger.info("Fetch all the items from database")
    logger.info(f"User [{timezone.localtime()}] {request.user} requested item list from {request.META.get('REMOTE_ADDR')}")
    item_list = Item.objects.all()
    logger.debug(f"Found {item_list.count()} items")
    paginator = Paginator(item_list, 6)
    page_number = request.GET.get("page")
    items = paginator.get_page(page_number)
    context = {"items": items}
    return render(request, "myapp/home.html", context)

def item_form(request):
    forms = ItemForms(request.POST or None)
    if request.method == "POST":
        if forms.is_valid():
            forms.instance.user_name = request.user
            forms.save()
            return redirect("myapp:index")
        else:
            print(forms.errors['item_price'])
    context = {"forms": forms}
    return render(request, "myapp/item_form.html", context)

def item_details(request, id):
    logger.info(f"Fetching an item with id: {id}")
    try:
        item = get_object_or_404(Item, pk=id)
        logger.debug(f"Item found {item.item_name} (${item.item_price})")
    except Exception as e:
        logger.error("Error fectching the item with id %s %s", id, e)
        raise
    context = {"item": item}
    return render(request, "myapp/item_details.html", context)

def item_edit(request, id):
    item = Item.objects.get(id=id, user=request.user)
    forms = ItemForms(request.POST or None, instance=item)
    if request.method == "POST":
        if forms.is_valid():
            forms.instance.user_name = request.user
            forms.save()
            return redirect("myapp:index")
        else:
            forms = ItemForms()
    context = {"forms": forms}
    return render(request, "myapp/item_form.html", context)

def item_delete(request, id):
    item = Item.objects.get(id=id)
    if request.method == "POST":
        item.delete()
        return redirect("myapp:index")
    context = {"item":item}
    return render(request, "myapp/delete_item.html", context)