from django.db import models

class ItemManager(models.Manager):
    def cheap_item(self):
        return self.filter(item_price__lt=5)
    def expensive_item(self):
        return self.filter(item_price__gt=5)
    def search(self, keyword):
        return self.filter(item_name__icontains=keyword)
    def get_gueryset(self):
        return super().get_gueryset().filter(is_deleted=False)
    def deleted(self):
        return super().get_gueryset().filter(is_deleted=True)
