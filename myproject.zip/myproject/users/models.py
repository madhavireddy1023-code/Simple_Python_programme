from django.db import models
from django.contrib.auth.models import User

class ProfileModels(models.Model):
    user_name = models.OneToOneField(User, on_delete=models.CASCADE)
    upload_image = models.ImageField(upload_to='pictures/', default="pictures/picturepic.png")
    location = models.CharField(max_length=100, default="India")
    date_of_birth = models.DateField(blank=True, null=True)

    def __str__(self):
        return f"{self.user_name.username}'s profile"
