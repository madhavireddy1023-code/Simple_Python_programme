from django.urls import path
from . import views

app_name = 'users'

urlpatterns = [
    path('', views.user_login, name="login"),
    path('signup/', views.user_register, name="signup"),
    path('logout/', views.user_logout, name="logout"),
    path('profile/<str:username>/', views.user_profile, name="profile"),
]