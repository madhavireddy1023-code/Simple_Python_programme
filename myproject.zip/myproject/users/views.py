from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import RegisterUser, ProfileUser
from django.contrib.auth.models import User
from .models import ProfileModels
from django.contrib import messages

# Create your views here.
def user_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, f"{request.POST.get("username")} login successfully.")
            return redirect("myapp:index")
        else:
            return render(request, "users/login.html", {"error": "Invalid Creadientials."})
    return render(request, "users/login.html")

def user_register(request):
    form = RegisterUser(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, f"{request.POST.get('username')} has been successfully sigup")
            return redirect("users:login")
    return render(request, "users/signup.html", {"form": form})

def user_logout(request):
    if request.method == "POST":
        logout(request)
        return redirect("users:login")
    return render(request, "users/logout.html")

def user_profile(request, username):
    user = User.objects.get(username=username)
    profile = ProfileModels.objects.get(user_name=user)
    return render(request, "users/profile.html", {"profile": profile})